#include "types.h"
#include "user.h"

void 
work(void){
	volatile int x = 0;
	for(int i = 0; i < 50000000; i++){
		x += i;
	}
}

int
main(void){
	for(int i = 0; i < 3; i++){
		int pid = fork();
		if(pid == 0){
			printf(1, "Child %d (PID %d) started \n", i, getpid());
			work();
			printf(1, "Child %d (PID %d) finished \n", i, getpid());
			exit();
		}
		sleep(5);
	}
	for(int i = 0; i<3; i++){
		wait();
	}
	exit();
}


kernel:     file format elf32-i386


Disassembly of section .text:

80100000 <multiboot_header>:
80100000:	02 b0 ad 1b 00 00    	add    0x1bad(%eax),%dh
80100006:	00 00                	add    %al,(%eax)
80100008:	fe 4f 52             	decb   0x52(%edi)
8010000b:	e4                   	.byte 0xe4

8010000c <entry>:

# Entering xv6 on boot processor, with paging off.
.globl entry
entry:
  # Turn on page size extension for 4Mbyte pages
  movl    %cr4, %eax
8010000c:	0f 20 e0             	mov    %cr4,%eax
  orl     $(CR4_PSE), %eax
8010000f:	83 c8 10             	or     $0x10,%eax
  movl    %eax, %cr4
80100012:	0f 22 e0             	mov    %eax,%cr4
  # Set page directory
  movl    $(V2P_WO(entrypgdir)), %eax
80100015:	b8 00 a0 10 00       	mov    $0x10a000,%eax
  movl    %eax, %cr3
8010001a:	0f 22 d8             	mov    %eax,%cr3
  # Turn on paging.
  movl    %cr0, %eax
8010001d:	0f 20 c0             	mov    %cr0,%eax
  orl     $(CR0_PG|CR0_WP), %eax
80100020:	0d 00 00 01 80       	or     $0x80010000,%eax
  movl    %eax, %cr0
80100025:	0f 22 c0             	mov    %eax,%cr0

  # Set up the stack pointer.
  movl $(stack + KSTACKSIZE), %esp
80100028:	bc 80 68 11 80       	mov    $0x80116880,%esp

  # Jump to main(), and switch to executing at
  # high addresses. The indirect call is needed because
  # the assembler produces a PC-relative instruction
  # for a direct jump.
  mov $main, %eax
8010002d:	b8 a0 30 10 80       	mov    $0x801030a0,%eax
  jmp *%eax
80100032:	ff e0                	jmp    *%eax
80100034:	66 90                	xchg   %ax,%ax
80100036:	66 90                	xchg   %ax,%ax
80100038:	66 90                	xchg   %ax,%ax
8010003a:	66 90                	xchg   %ax,%ax
8010003c:	66 90                	xchg   %ax,%ax
8010003e:	66 90                	xchg   %ax,%ax

80100040 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
80100040:	55                   	push   %ebp
80100041:	89 e5                	mov    %esp,%ebp
80100043:	53                   	push   %ebx

//PAGEBREAK!
  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
  bcache.head.next = &bcache.head;
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100044:	bb 54 b5 10 80       	mov    $0x8010b554,%ebx
{
80100049:	83 ec 0c             	sub    $0xc,%esp
  initlock(&bcache.lock, "bcache");
8010004c:	68 20 78 10 80       	push   $0x80107820
80100051:	68 20 b5 10 80       	push   $0x8010b520
80100056:	e8 a5 44 00 00       	call   80104500 <initlock>
  bcache.head.next = &bcache.head;
8010005b:	83 c4 10             	add    $0x10,%esp
8010005e:	b8 1c fc 10 80       	mov    $0x8010fc1c,%eax
  bcache.head.prev = &bcache.head;
80100063:	c7 05 6c fc 10 80 1c 	movl   $0x8010fc1c,0x8010fc6c
8010006a:	fc 10 80 
  bcache.head.next = &bcache.head;
8010006d:	c7 05 70 fc 10 80 1c 	movl   $0x8010fc1c,0x8010fc70
80100074:	fc 10 80 
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
80100077:	eb 09                	jmp    80100082 <binit+0x42>
80100079:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80100080:	89 d3                	mov    %edx,%ebx
    b->next = bcache.head.next;
80100082:	89 43 54             	mov    %eax,0x54(%ebx)
    b->prev = &bcache.head;
    initsleeplock(&b->lock, "buffer");
80100085:	83 ec 08             	sub    $0x8,%esp
80100088:	8d 43 0c             	lea    0xc(%ebx),%eax
    b->prev = &bcache.head;
8010008b:	c7 43 50 1c fc 10 80 	movl   $0x8010fc1c,0x50(%ebx)
    initsleeplock(&b->lock, "buffer");
80100092:	68 27 78 10 80       	push   $0x80107827
80100097:	50                   	push   %eax
80100098:	e8 33 43 00 00       	call   801043d0 <initsleeplock>
    bcache.head.next->prev = b;
8010009d:	a1 70 fc 10 80       	mov    0x8010fc70,%eax
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000a2:	8d 93 5c 02 00 00    	lea    0x25c(%ebx),%edx
801000a8:	83 c4 10             	add    $0x10,%esp
    bcache.head.next->prev = b;
801000ab:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
801000ae:	89 d8                	mov    %ebx,%eax
801000b0:	89 1d 70 fc 10 80    	mov    %ebx,0x8010fc70
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
801000b6:	81 fb c0 f9 10 80    	cmp    $0x8010f9c0,%ebx
801000bc:	75 c2                	jne    80100080 <binit+0x40>
  }
}
801000be:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801000c1:	c9                   	leave
801000c2:	c3                   	ret
801000c3:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801000ca:	00 
801000cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801000d0 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
801000d0:	55                   	push   %ebp
801000d1:	89 e5                	mov    %esp,%ebp
801000d3:	57                   	push   %edi
801000d4:	56                   	push   %esi
801000d5:	53                   	push   %ebx
801000d6:	83 ec 18             	sub    $0x18,%esp
801000d9:	8b 75 08             	mov    0x8(%ebp),%esi
801000dc:	8b 7d 0c             	mov    0xc(%ebp),%edi
  acquire(&bcache.lock);
801000df:	68 20 b5 10 80       	push   $0x8010b520
801000e4:	e8 07 46 00 00       	call   801046f0 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
801000e9:	8b 1d 70 fc 10 80    	mov    0x8010fc70,%ebx
801000ef:	83 c4 10             	add    $0x10,%esp
801000f2:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
801000f8:	75 11                	jne    8010010b <bread+0x3b>
801000fa:	eb 24                	jmp    80100120 <bread+0x50>
801000fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80100100:	8b 5b 54             	mov    0x54(%ebx),%ebx
80100103:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
80100109:	74 15                	je     80100120 <bread+0x50>
    if(b->dev == dev && b->blockno == blockno){
8010010b:	3b 73 04             	cmp    0x4(%ebx),%esi
8010010e:	75 f0                	jne    80100100 <bread+0x30>
80100110:	3b 7b 08             	cmp    0x8(%ebx),%edi
80100113:	75 eb                	jne    80100100 <bread+0x30>
      b->refcnt++;
80100115:	83 43 4c 01          	addl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
80100119:	eb 3f                	jmp    8010015a <bread+0x8a>
8010011b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
80100120:	8b 1d 6c fc 10 80    	mov    0x8010fc6c,%ebx
80100126:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
8010012c:	75 0d                	jne    8010013b <bread+0x6b>
8010012e:	eb 6e                	jmp    8010019e <bread+0xce>
80100130:	8b 5b 50             	mov    0x50(%ebx),%ebx
80100133:	81 fb 1c fc 10 80    	cmp    $0x8010fc1c,%ebx
80100139:	74 63                	je     8010019e <bread+0xce>
    if(b->refcnt == 0 && (b->flags & B_DIRTY) == 0) {
8010013b:	8b 43 4c             	mov    0x4c(%ebx),%eax
8010013e:	85 c0                	test   %eax,%eax
80100140:	75 ee                	jne    80100130 <bread+0x60>
80100142:	f6 03 04             	testb  $0x4,(%ebx)
80100145:	75 e9                	jne    80100130 <bread+0x60>
      b->dev = dev;
80100147:	89 73 04             	mov    %esi,0x4(%ebx)
      b->blockno = blockno;
8010014a:	89 7b 08             	mov    %edi,0x8(%ebx)
      b->flags = 0;
8010014d:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
      b->refcnt = 1;
80100153:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
      release(&bcache.lock);
8010015a:	83 ec 0c             	sub    $0xc,%esp
8010015d:	68 20 b5 10 80       	push   $0x8010b520
80100162:	e8 29 45 00 00       	call   80104690 <release>
      acquiresleep(&b->lock);
80100167:	8d 43 0c             	lea    0xc(%ebx),%eax
8010016a:	89 04 24             	mov    %eax,(%esp)
8010016d:	e8 9e 42 00 00       	call   80104410 <acquiresleep>
      return b;
80100172:	83 c4 10             	add    $0x10,%esp
  struct buf *b;

  b = bget(dev, blockno);
  if((b->flags & B_VALID) == 0) {
80100175:	f6 03 02             	testb  $0x2,(%ebx)
80100178:	74 0e                	je     80100188 <bread+0xb8>
    iderw(b);
  }
  return b;
}
8010017a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010017d:	89 d8                	mov    %ebx,%eax
8010017f:	5b                   	pop    %ebx
80100180:	5e                   	pop    %esi
80100181:	5f                   	pop    %edi
80100182:	5d                   	pop    %ebp
80100183:	c3                   	ret
80100184:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    iderw(b);
80100188:	83 ec 0c             	sub    $0xc,%esp
8010018b:	53                   	push   %ebx
8010018c:	e8 3f 21 00 00       	call   801022d0 <iderw>
80100191:	83 c4 10             	add    $0x10,%esp
}
80100194:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100197:	89 d8                	mov    %ebx,%eax
80100199:	5b                   	pop    %ebx
8010019a:	5e                   	pop    %esi
8010019b:	5f                   	pop    %edi
8010019c:	5d                   	pop    %ebp
8010019d:	c3                   	ret
  panic("bget: no buffers");
8010019e:	83 ec 0c             	sub    $0xc,%esp
801001a1:	68 2e 78 10 80       	push   $0x8010782e
801001a6:	e8 d5 01 00 00       	call   80100380 <panic>
801001ab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801001b0 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
801001b0:	55                   	push   %ebp
801001b1:	89 e5                	mov    %esp,%ebp
801001b3:	53                   	push   %ebx
801001b4:	83 ec 10             	sub    $0x10,%esp
801001b7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001ba:	8d 43 0c             	lea    0xc(%ebx),%eax
801001bd:	50                   	push   %eax
801001be:	e8 ed 42 00 00       	call   801044b0 <holdingsleep>
801001c3:	83 c4 10             	add    $0x10,%esp
801001c6:	85 c0                	test   %eax,%eax
801001c8:	74 0f                	je     801001d9 <bwrite+0x29>
    panic("bwrite");
  b->flags |= B_DIRTY;
801001ca:	83 0b 04             	orl    $0x4,(%ebx)
  iderw(b);
801001cd:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801001d0:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801001d3:	c9                   	leave
  iderw(b);
801001d4:	e9 f7 20 00 00       	jmp    801022d0 <iderw>
    panic("bwrite");
801001d9:	83 ec 0c             	sub    $0xc,%esp
801001dc:	68 3f 78 10 80       	push   $0x8010783f
801001e1:	e8 9a 01 00 00       	call   80100380 <panic>
801001e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801001ed:	00 
801001ee:	66 90                	xchg   %ax,%ax

801001f0 <brelse>:

// Release a locked buffer.
// Move to the head of the MRU list.
void
brelse(struct buf *b)
{
801001f0:	55                   	push   %ebp
801001f1:	89 e5                	mov    %esp,%ebp
801001f3:	56                   	push   %esi
801001f4:	53                   	push   %ebx
801001f5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(!holdingsleep(&b->lock))
801001f8:	8d 73 0c             	lea    0xc(%ebx),%esi
801001fb:	83 ec 0c             	sub    $0xc,%esp
801001fe:	56                   	push   %esi
801001ff:	e8 ac 42 00 00       	call   801044b0 <holdingsleep>
80100204:	83 c4 10             	add    $0x10,%esp
80100207:	85 c0                	test   %eax,%eax
80100209:	74 63                	je     8010026e <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
8010020b:	83 ec 0c             	sub    $0xc,%esp
8010020e:	56                   	push   %esi
8010020f:	e8 5c 42 00 00       	call   80104470 <releasesleep>

  acquire(&bcache.lock);
80100214:	c7 04 24 20 b5 10 80 	movl   $0x8010b520,(%esp)
8010021b:	e8 d0 44 00 00       	call   801046f0 <acquire>
  b->refcnt--;
80100220:	8b 43 4c             	mov    0x4c(%ebx),%eax
  if (b->refcnt == 0) {
80100223:	83 c4 10             	add    $0x10,%esp
  b->refcnt--;
80100226:	83 e8 01             	sub    $0x1,%eax
80100229:	89 43 4c             	mov    %eax,0x4c(%ebx)
  if (b->refcnt == 0) {
8010022c:	85 c0                	test   %eax,%eax
8010022e:	75 2c                	jne    8010025c <brelse+0x6c>
    // no one is waiting for it.
    b->next->prev = b->prev;
80100230:	8b 53 54             	mov    0x54(%ebx),%edx
80100233:	8b 43 50             	mov    0x50(%ebx),%eax
80100236:	89 42 50             	mov    %eax,0x50(%edx)
    b->prev->next = b->next;
80100239:	8b 53 54             	mov    0x54(%ebx),%edx
8010023c:	89 50 54             	mov    %edx,0x54(%eax)
    b->next = bcache.head.next;
8010023f:	a1 70 fc 10 80       	mov    0x8010fc70,%eax
    b->prev = &bcache.head;
80100244:	c7 43 50 1c fc 10 80 	movl   $0x8010fc1c,0x50(%ebx)
    b->next = bcache.head.next;
8010024b:	89 43 54             	mov    %eax,0x54(%ebx)
    bcache.head.next->prev = b;
8010024e:	a1 70 fc 10 80       	mov    0x8010fc70,%eax
80100253:	89 58 50             	mov    %ebx,0x50(%eax)
    bcache.head.next = b;
80100256:	89 1d 70 fc 10 80    	mov    %ebx,0x8010fc70
  }
  
  release(&bcache.lock);
8010025c:	c7 45 08 20 b5 10 80 	movl   $0x8010b520,0x8(%ebp)
}
80100263:	8d 65 f8             	lea    -0x8(%ebp),%esp
80100266:	5b                   	pop    %ebx
80100267:	5e                   	pop    %esi
80100268:	5d                   	pop    %ebp
  release(&bcache.lock);
80100269:	e9 22 44 00 00       	jmp    80104690 <release>
    panic("brelse");
8010026e:	83 ec 0c             	sub    $0xc,%esp
80100271:	68 46 78 10 80       	push   $0x80107846
80100276:	e8 05 01 00 00       	call   80100380 <panic>
8010027b:	66 90                	xchg   %ax,%ax
8010027d:	66 90                	xchg   %ax,%ax
8010027f:	90                   	nop

80100280 <consoleread>:
  }
}

int
consoleread(struct inode *ip, char *dst, int n)
{
80100280:	55                   	push   %ebp
80100281:	89 e5                	mov    %esp,%ebp
80100283:	57                   	push   %edi
80100284:	56                   	push   %esi
80100285:	53                   	push   %ebx
80100286:	83 ec 18             	sub    $0x18,%esp
80100289:	8b 5d 10             	mov    0x10(%ebp),%ebx
8010028c:	8b 75 0c             	mov    0xc(%ebp),%esi
  uint target;
  int c;

  iunlock(ip);
8010028f:	ff 75 08             	push   0x8(%ebp)
  target = n;
80100292:	89 df                	mov    %ebx,%edi
  iunlock(ip);
80100294:	e8 e7 15 00 00       	call   80101880 <iunlock>
  acquire(&cons.lock);
80100299:	c7 04 24 20 ff 10 80 	movl   $0x8010ff20,(%esp)
801002a0:	e8 4b 44 00 00       	call   801046f0 <acquire>
  while(n > 0){
801002a5:	83 c4 10             	add    $0x10,%esp
801002a8:	85 db                	test   %ebx,%ebx
801002aa:	0f 8e 94 00 00 00    	jle    80100344 <consoleread+0xc4>
    while(input.r == input.w){
801002b0:	a1 00 ff 10 80       	mov    0x8010ff00,%eax
801002b5:	39 05 04 ff 10 80    	cmp    %eax,0x8010ff04
801002bb:	74 25                	je     801002e2 <consoleread+0x62>
801002bd:	eb 59                	jmp    80100318 <consoleread+0x98>
801002bf:	90                   	nop
      if(myproc()->killed){
        release(&cons.lock);
        ilock(ip);
        return -1;
      }
      sleep(&input.r, &cons.lock);
801002c0:	83 ec 08             	sub    $0x8,%esp
801002c3:	68 20 ff 10 80       	push   $0x8010ff20
801002c8:	68 00 ff 10 80       	push   $0x8010ff00
801002cd:	e8 1e 3e 00 00       	call   801040f0 <sleep>
    while(input.r == input.w){
801002d2:	a1 00 ff 10 80       	mov    0x8010ff00,%eax
801002d7:	83 c4 10             	add    $0x10,%esp
801002da:	3b 05 04 ff 10 80    	cmp    0x8010ff04,%eax
801002e0:	75 36                	jne    80100318 <consoleread+0x98>
      if(myproc()->killed){
801002e2:	e8 09 37 00 00       	call   801039f0 <myproc>
801002e7:	8b 48 24             	mov    0x24(%eax),%ecx
801002ea:	85 c9                	test   %ecx,%ecx
801002ec:	74 d2                	je     801002c0 <consoleread+0x40>
        release(&cons.lock);
801002ee:	83 ec 0c             	sub    $0xc,%esp
801002f1:	68 20 ff 10 80       	push   $0x8010ff20
801002f6:	e8 95 43 00 00       	call   80104690 <release>
        ilock(ip);
801002fb:	5a                   	pop    %edx
801002fc:	ff 75 08             	push   0x8(%ebp)
801002ff:	e8 9c 14 00 00       	call   801017a0 <ilock>
        return -1;
80100304:	83 c4 10             	add    $0x10,%esp
  }
  release(&cons.lock);
  ilock(ip);

  return target - n;
}
80100307:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return -1;
8010030a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010030f:	5b                   	pop    %ebx
80100310:	5e                   	pop    %esi
80100311:	5f                   	pop    %edi
80100312:	5d                   	pop    %ebp
80100313:	c3                   	ret
80100314:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    c = input.buf[input.r++ % INPUT_BUF];
80100318:	8d 50 01             	lea    0x1(%eax),%edx
8010031b:	89 15 00 ff 10 80    	mov    %edx,0x8010ff00
80100321:	89 c2                	mov    %eax,%edx
80100323:	83 e2 7f             	and    $0x7f,%edx
80100326:	0f be 8a 80 fe 10 80 	movsbl -0x7fef0180(%edx),%ecx
    if(c == C('D')){  // EOF
8010032d:	80 f9 04             	cmp    $0x4,%cl
80100330:	74 37                	je     80100369 <consoleread+0xe9>
    *dst++ = c;
80100332:	83 c6 01             	add    $0x1,%esi
    --n;
80100335:	83 eb 01             	sub    $0x1,%ebx
    *dst++ = c;
80100338:	88 4e ff             	mov    %cl,-0x1(%esi)
    if(c == '\n')
8010033b:	83 f9 0a             	cmp    $0xa,%ecx
8010033e:	0f 85 64 ff ff ff    	jne    801002a8 <consoleread+0x28>
  release(&cons.lock);
80100344:	83 ec 0c             	sub    $0xc,%esp
80100347:	68 20 ff 10 80       	push   $0x8010ff20
8010034c:	e8 3f 43 00 00       	call   80104690 <release>
  ilock(ip);
80100351:	58                   	pop    %eax
80100352:	ff 75 08             	push   0x8(%ebp)
80100355:	e8 46 14 00 00       	call   801017a0 <ilock>
  return target - n;
8010035a:	89 f8                	mov    %edi,%eax
8010035c:	83 c4 10             	add    $0x10,%esp
}
8010035f:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return target - n;
80100362:	29 d8                	sub    %ebx,%eax
}
80100364:	5b                   	pop    %ebx
80100365:	5e                   	pop    %esi
80100366:	5f                   	pop    %edi
80100367:	5d                   	pop    %ebp
80100368:	c3                   	ret
      if(n < target){
80100369:	39 fb                	cmp    %edi,%ebx
8010036b:	73 d7                	jae    80100344 <consoleread+0xc4>
        input.r--;
8010036d:	a3 00 ff 10 80       	mov    %eax,0x8010ff00
80100372:	eb d0                	jmp    80100344 <consoleread+0xc4>
80100374:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010037b:	00 
8010037c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100380 <panic>:
{
80100380:	55                   	push   %ebp
80100381:	89 e5                	mov    %esp,%ebp
80100383:	56                   	push   %esi
80100384:	53                   	push   %ebx
80100385:	83 ec 30             	sub    $0x30,%esp
}

static inline void
cli(void)
{
  asm volatile("cli");
80100388:	fa                   	cli
  cons.locking = 0;
80100389:	c7 05 54 ff 10 80 00 	movl   $0x0,0x8010ff54
80100390:	00 00 00 
  getcallerpcs(&s, pcs);
80100393:	8d 5d d0             	lea    -0x30(%ebp),%ebx
80100396:	8d 75 f8             	lea    -0x8(%ebp),%esi
  cprintf("lapicid %d: panic: ", lapicid());
80100399:	e8 a2 25 00 00       	call   80102940 <lapicid>
8010039e:	83 ec 08             	sub    $0x8,%esp
801003a1:	50                   	push   %eax
801003a2:	68 4d 78 10 80       	push   $0x8010784d
801003a7:	e8 04 03 00 00       	call   801006b0 <cprintf>
  cprintf(s);
801003ac:	58                   	pop    %eax
801003ad:	ff 75 08             	push   0x8(%ebp)
801003b0:	e8 fb 02 00 00       	call   801006b0 <cprintf>
  cprintf("\n");
801003b5:	c7 04 24 e4 7c 10 80 	movl   $0x80107ce4,(%esp)
801003bc:	e8 ef 02 00 00       	call   801006b0 <cprintf>
  getcallerpcs(&s, pcs);
801003c1:	8d 45 08             	lea    0x8(%ebp),%eax
801003c4:	5a                   	pop    %edx
801003c5:	59                   	pop    %ecx
801003c6:	53                   	push   %ebx
801003c7:	50                   	push   %eax
801003c8:	e8 53 41 00 00       	call   80104520 <getcallerpcs>
  for(i=0; i<10; i++)
801003cd:	83 c4 10             	add    $0x10,%esp
    cprintf(" %p", pcs[i]);
801003d0:	83 ec 08             	sub    $0x8,%esp
801003d3:	ff 33                	push   (%ebx)
  for(i=0; i<10; i++)
801003d5:	83 c3 04             	add    $0x4,%ebx
    cprintf(" %p", pcs[i]);
801003d8:	68 61 78 10 80       	push   $0x80107861
801003dd:	e8 ce 02 00 00       	call   801006b0 <cprintf>
  for(i=0; i<10; i++)
801003e2:	83 c4 10             	add    $0x10,%esp
801003e5:	39 f3                	cmp    %esi,%ebx
801003e7:	75 e7                	jne    801003d0 <panic+0x50>
  panicked = 1; // freeze other CPU
801003e9:	c7 05 58 ff 10 80 01 	movl   $0x1,0x8010ff58
801003f0:	00 00 00 
  for(;;)
801003f3:	eb fe                	jmp    801003f3 <panic+0x73>
801003f5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801003fc:	00 
801003fd:	8d 76 00             	lea    0x0(%esi),%esi

80100400 <consputc.part.0>:
consputc(int c)
80100400:	55                   	push   %ebp
80100401:	89 e5                	mov    %esp,%ebp
80100403:	57                   	push   %edi
80100404:	56                   	push   %esi
80100405:	53                   	push   %ebx
80100406:	83 ec 1c             	sub    $0x1c,%esp
  if(c == BACKSPACE){
80100409:	3d 00 01 00 00       	cmp    $0x100,%eax
8010040e:	0f 84 cc 00 00 00    	je     801004e0 <consputc.part.0+0xe0>
    uartputc(c);
80100414:	83 ec 0c             	sub    $0xc,%esp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100417:	bf d4 03 00 00       	mov    $0x3d4,%edi
8010041c:	89 c3                	mov    %eax,%ebx
8010041e:	50                   	push   %eax
8010041f:	e8 1c 5c 00 00       	call   80106040 <uartputc>
80100424:	b8 0e 00 00 00       	mov    $0xe,%eax
80100429:	89 fa                	mov    %edi,%edx
8010042b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010042c:	be d5 03 00 00       	mov    $0x3d5,%esi
80100431:	89 f2                	mov    %esi,%edx
80100433:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100434:	0f b6 c8             	movzbl %al,%ecx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80100437:	89 fa                	mov    %edi,%edx
80100439:	b8 0f 00 00 00       	mov    $0xf,%eax
8010043e:	c1 e1 08             	shl    $0x8,%ecx
80100441:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100442:	89 f2                	mov    %esi,%edx
80100444:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
80100445:	0f b6 c0             	movzbl %al,%eax
  if(c == '\n')
80100448:	83 c4 10             	add    $0x10,%esp
  pos |= inb(CRTPORT+1);
8010044b:	09 c8                	or     %ecx,%eax
  if(c == '\n')
8010044d:	83 fb 0a             	cmp    $0xa,%ebx
80100450:	75 76                	jne    801004c8 <consputc.part.0+0xc8>
    pos += 80 - pos%80;
80100452:	ba cd cc cc cc       	mov    $0xcccccccd,%edx
80100457:	f7 e2                	mul    %edx
80100459:	c1 ea 06             	shr    $0x6,%edx
8010045c:	8d 04 92             	lea    (%edx,%edx,4),%eax
8010045f:	c1 e0 04             	shl    $0x4,%eax
80100462:	8d 70 50             	lea    0x50(%eax),%esi
  if(pos < 0 || pos > 25*80)
80100465:	81 fe d0 07 00 00    	cmp    $0x7d0,%esi
8010046b:	0f 8f 2f 01 00 00    	jg     801005a0 <consputc.part.0+0x1a0>
  if((pos/80) >= 24){  // Scroll up.
80100471:	81 fe 7f 07 00 00    	cmp    $0x77f,%esi
80100477:	0f 8f c3 00 00 00    	jg     80100540 <consputc.part.0+0x140>
  outb(CRTPORT+1, pos>>8);
8010047d:	89 f0                	mov    %esi,%eax
  crt[pos] = ' ' | 0x0700;
8010047f:	8d b4 36 00 80 0b 80 	lea    -0x7ff48000(%esi,%esi,1),%esi
  outb(CRTPORT+1, pos);
80100486:	88 45 e7             	mov    %al,-0x19(%ebp)
  outb(CRTPORT+1, pos>>8);
80100489:	0f b6 fc             	movzbl %ah,%edi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010048c:	bb d4 03 00 00       	mov    $0x3d4,%ebx
80100491:	b8 0e 00 00 00       	mov    $0xe,%eax
80100496:	89 da                	mov    %ebx,%edx
80100498:	ee                   	out    %al,(%dx)
80100499:	b9 d5 03 00 00       	mov    $0x3d5,%ecx
8010049e:	89 f8                	mov    %edi,%eax
801004a0:	89 ca                	mov    %ecx,%edx
801004a2:	ee                   	out    %al,(%dx)
801004a3:	b8 0f 00 00 00       	mov    $0xf,%eax
801004a8:	89 da                	mov    %ebx,%edx
801004aa:	ee                   	out    %al,(%dx)
801004ab:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
801004af:	89 ca                	mov    %ecx,%edx
801004b1:	ee                   	out    %al,(%dx)
  crt[pos] = ' ' | 0x0700;
801004b2:	b8 20 07 00 00       	mov    $0x720,%eax
801004b7:	66 89 06             	mov    %ax,(%esi)
}
801004ba:	8d 65 f4             	lea    -0xc(%ebp),%esp
801004bd:	5b                   	pop    %ebx
801004be:	5e                   	pop    %esi
801004bf:	5f                   	pop    %edi
801004c0:	5d                   	pop    %ebp
801004c1:	c3                   	ret
801004c2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    crt[pos++] = (c&0xff) | 0x0700;  // black on white
801004c8:	0f b6 db             	movzbl %bl,%ebx
801004cb:	8d 70 01             	lea    0x1(%eax),%esi
801004ce:	80 cf 07             	or     $0x7,%bh
801004d1:	66 89 9c 00 00 80 0b 	mov    %bx,-0x7ff48000(%eax,%eax,1)
801004d8:	80 
801004d9:	eb 8a                	jmp    80100465 <consputc.part.0+0x65>
801004db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    uartputc('\b'); uartputc(' '); uartputc('\b');
801004e0:	83 ec 0c             	sub    $0xc,%esp
801004e3:	be d4 03 00 00       	mov    $0x3d4,%esi
801004e8:	6a 08                	push   $0x8
801004ea:	e8 51 5b 00 00       	call   80106040 <uartputc>
801004ef:	c7 04 24 20 00 00 00 	movl   $0x20,(%esp)
801004f6:	e8 45 5b 00 00       	call   80106040 <uartputc>
801004fb:	c7 04 24 08 00 00 00 	movl   $0x8,(%esp)
80100502:	e8 39 5b 00 00       	call   80106040 <uartputc>
80100507:	b8 0e 00 00 00       	mov    $0xe,%eax
8010050c:	89 f2                	mov    %esi,%edx
8010050e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010050f:	bb d5 03 00 00       	mov    $0x3d5,%ebx
80100514:	89 da                	mov    %ebx,%edx
80100516:	ec                   	in     (%dx),%al
  pos = inb(CRTPORT+1) << 8;
80100517:	0f b6 c8             	movzbl %al,%ecx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010051a:	89 f2                	mov    %esi,%edx
8010051c:	b8 0f 00 00 00       	mov    $0xf,%eax
80100521:	c1 e1 08             	shl    $0x8,%ecx
80100524:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80100525:	89 da                	mov    %ebx,%edx
80100527:	ec                   	in     (%dx),%al
  pos |= inb(CRTPORT+1);
80100528:	0f b6 f0             	movzbl %al,%esi
    if(pos > 0) --pos;
8010052b:	83 c4 10             	add    $0x10,%esp
8010052e:	09 ce                	or     %ecx,%esi
80100530:	74 5e                	je     80100590 <consputc.part.0+0x190>
80100532:	83 ee 01             	sub    $0x1,%esi
80100535:	e9 2b ff ff ff       	jmp    80100465 <consputc.part.0+0x65>
8010053a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100540:	83 ec 04             	sub    $0x4,%esp
    pos -= 80;
80100543:	8d 5e b0             	lea    -0x50(%esi),%ebx
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100546:	8d b4 36 60 7f 0b 80 	lea    -0x7ff480a0(%esi,%esi,1),%esi
  outb(CRTPORT+1, pos);
8010054d:	bf 07 00 00 00       	mov    $0x7,%edi
    memmove(crt, crt+80, sizeof(crt[0])*23*80);
80100552:	68 60 0e 00 00       	push   $0xe60
80100557:	68 a0 80 0b 80       	push   $0x800b80a0
8010055c:	68 00 80 0b 80       	push   $0x800b8000
80100561:	e8 1a 43 00 00       	call   80104880 <memmove>
    memset(crt+pos, 0, sizeof(crt[0])*(24*80 - pos));
80100566:	b8 80 07 00 00       	mov    $0x780,%eax
8010056b:	83 c4 0c             	add    $0xc,%esp
8010056e:	29 d8                	sub    %ebx,%eax
80100570:	01 c0                	add    %eax,%eax
80100572:	50                   	push   %eax
80100573:	6a 00                	push   $0x0
80100575:	56                   	push   %esi
80100576:	e8 75 42 00 00       	call   801047f0 <memset>
  outb(CRTPORT+1, pos);
8010057b:	88 5d e7             	mov    %bl,-0x19(%ebp)
8010057e:	83 c4 10             	add    $0x10,%esp
80100581:	e9 06 ff ff ff       	jmp    8010048c <consputc.part.0+0x8c>
80100586:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010058d:	00 
8010058e:	66 90                	xchg   %ax,%ax
80100590:	c6 45 e7 00          	movb   $0x0,-0x19(%ebp)
80100594:	be 00 80 0b 80       	mov    $0x800b8000,%esi
80100599:	31 ff                	xor    %edi,%edi
8010059b:	e9 ec fe ff ff       	jmp    8010048c <consputc.part.0+0x8c>
    panic("pos under/overflow");
801005a0:	83 ec 0c             	sub    $0xc,%esp
801005a3:	68 65 78 10 80       	push   $0x80107865
801005a8:	e8 d3 fd ff ff       	call   80100380 <panic>
801005ad:	8d 76 00             	lea    0x0(%esi),%esi

801005b0 <consolewrite>:

int
consolewrite(struct inode *ip, char *buf, int n)
{
801005b0:	55                   	push   %ebp
801005b1:	89 e5                	mov    %esp,%ebp
801005b3:	57                   	push   %edi
801005b4:	56                   	push   %esi
801005b5:	53                   	push   %ebx
801005b6:	83 ec 18             	sub    $0x18,%esp
801005b9:	8b 75 10             	mov    0x10(%ebp),%esi
  int i;

  iunlock(ip);
801005bc:	ff 75 08             	push   0x8(%ebp)
801005bf:	e8 bc 12 00 00       	call   80101880 <iunlock>
  acquire(&cons.lock);
801005c4:	c7 04 24 20 ff 10 80 	movl   $0x8010ff20,(%esp)
801005cb:	e8 20 41 00 00       	call   801046f0 <acquire>
  for(i = 0; i < n; i++)
801005d0:	83 c4 10             	add    $0x10,%esp
801005d3:	85 f6                	test   %esi,%esi
801005d5:	7e 25                	jle    801005fc <consolewrite+0x4c>
801005d7:	8b 5d 0c             	mov    0xc(%ebp),%ebx
801005da:	8d 3c 33             	lea    (%ebx,%esi,1),%edi
  if(panicked){
801005dd:	8b 15 58 ff 10 80    	mov    0x8010ff58,%edx
    consputc(buf[i] & 0xff);
801005e3:	0f b6 03             	movzbl (%ebx),%eax
  if(panicked){
801005e6:	85 d2                	test   %edx,%edx
801005e8:	74 06                	je     801005f0 <consolewrite+0x40>
  asm volatile("cli");
801005ea:	fa                   	cli
    for(;;)
801005eb:	eb fe                	jmp    801005eb <consolewrite+0x3b>
801005ed:	8d 76 00             	lea    0x0(%esi),%esi
801005f0:	e8 0b fe ff ff       	call   80100400 <consputc.part.0>
  for(i = 0; i < n; i++)
801005f5:	83 c3 01             	add    $0x1,%ebx
801005f8:	39 fb                	cmp    %edi,%ebx
801005fa:	75 e1                	jne    801005dd <consolewrite+0x2d>
  release(&cons.lock);
801005fc:	83 ec 0c             	sub    $0xc,%esp
801005ff:	68 20 ff 10 80       	push   $0x8010ff20
80100604:	e8 87 40 00 00       	call   80104690 <release>
  ilock(ip);
80100609:	58                   	pop    %eax
8010060a:	ff 75 08             	push   0x8(%ebp)
8010060d:	e8 8e 11 00 00       	call   801017a0 <ilock>

  return n;
}
80100612:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100615:	89 f0                	mov    %esi,%eax
80100617:	5b                   	pop    %ebx
80100618:	5e                   	pop    %esi
80100619:	5f                   	pop    %edi
8010061a:	5d                   	pop    %ebp
8010061b:	c3                   	ret
8010061c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80100620 <printint>:
{
80100620:	55                   	push   %ebp
80100621:	89 e5                	mov    %esp,%ebp
80100623:	57                   	push   %edi
80100624:	56                   	push   %esi
80100625:	53                   	push   %ebx
80100626:	89 d3                	mov    %edx,%ebx
80100628:	83 ec 2c             	sub    $0x2c,%esp
  if(sign && (sign = xx < 0))
8010062b:	85 c0                	test   %eax,%eax
8010062d:	79 05                	jns    80100634 <printint+0x14>
8010062f:	83 e1 01             	and    $0x1,%ecx
80100632:	75 64                	jne    80100698 <printint+0x78>
    x = xx;
80100634:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
8010063b:	89 c1                	mov    %eax,%ecx
  i = 0;
8010063d:	31 f6                	xor    %esi,%esi
8010063f:	90                   	nop
    buf[i++] = digits[x % base];
80100640:	89 c8                	mov    %ecx,%eax
80100642:	31 d2                	xor    %edx,%edx
80100644:	89 f7                	mov    %esi,%edi
80100646:	f7 f3                	div    %ebx
80100648:	8d 76 01             	lea    0x1(%esi),%esi
8010064b:	0f b6 92 4c 7d 10 80 	movzbl -0x7fef82b4(%edx),%edx
80100652:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
80100656:	89 ca                	mov    %ecx,%edx
80100658:	89 c1                	mov    %eax,%ecx
8010065a:	39 da                	cmp    %ebx,%edx
8010065c:	73 e2                	jae    80100640 <printint+0x20>
  if(sign)
8010065e:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
80100661:	85 c9                	test   %ecx,%ecx
80100663:	74 07                	je     8010066c <printint+0x4c>
    buf[i++] = '-';
80100665:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
  while(--i >= 0)
8010066a:	89 f7                	mov    %esi,%edi
8010066c:	8d 5d d8             	lea    -0x28(%ebp),%ebx
8010066f:	01 df                	add    %ebx,%edi
  if(panicked){
80100671:	8b 15 58 ff 10 80    	mov    0x8010ff58,%edx
    consputc(buf[i]);
80100677:	0f be 07             	movsbl (%edi),%eax
  if(panicked){
8010067a:	85 d2                	test   %edx,%edx
8010067c:	74 0a                	je     80100688 <printint+0x68>
8010067e:	fa                   	cli
    for(;;)
8010067f:	eb fe                	jmp    8010067f <printint+0x5f>
80100681:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80100688:	e8 73 fd ff ff       	call   80100400 <consputc.part.0>
  while(--i >= 0)
8010068d:	8d 47 ff             	lea    -0x1(%edi),%eax
80100690:	39 df                	cmp    %ebx,%edi
80100692:	74 11                	je     801006a5 <printint+0x85>
80100694:	89 c7                	mov    %eax,%edi
80100696:	eb d9                	jmp    80100671 <printint+0x51>
    x = -xx;
80100698:	f7 d8                	neg    %eax
  if(sign && (sign = xx < 0))
8010069a:	c7 45 d4 01 00 00 00 	movl   $0x1,-0x2c(%ebp)
    x = -xx;
801006a1:	89 c1                	mov    %eax,%ecx
801006a3:	eb 98                	jmp    8010063d <printint+0x1d>
}
801006a5:	83 c4 2c             	add    $0x2c,%esp
801006a8:	5b                   	pop    %ebx
801006a9:	5e                   	pop    %esi
801006aa:	5f                   	pop    %edi
801006ab:	5d                   	pop    %ebp
801006ac:	c3                   	ret
801006ad:	8d 76 00             	lea    0x0(%esi),%esi

801006b0 <cprintf>:
{
801006b0:	55                   	push   %ebp
801006b1:	89 e5                	mov    %esp,%ebp
801006b3:	57                   	push   %edi
801006b4:	56                   	push   %esi
801006b5:	53                   	push   %ebx
801006b6:	83 ec 1c             	sub    $0x1c,%esp
  locking = cons.locking;
801006b9:	8b 3d 54 ff 10 80    	mov    0x8010ff54,%edi
  if (fmt == 0)
801006bf:	8b 75 08             	mov    0x8(%ebp),%esi
  if(locking)
801006c2:	85 ff                	test   %edi,%edi
801006c4:	0f 85 06 01 00 00    	jne    801007d0 <cprintf+0x120>
  if (fmt == 0)
801006ca:	85 f6                	test   %esi,%esi
801006cc:	0f 84 b7 01 00 00    	je     80100889 <cprintf+0x1d9>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801006d2:	0f b6 06             	movzbl (%esi),%eax
801006d5:	85 c0                	test   %eax,%eax
801006d7:	74 5f                	je     80100738 <cprintf+0x88>
  argp = (uint*)(void*)(&fmt + 1);
801006d9:	8d 55 0c             	lea    0xc(%ebp),%edx
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801006dc:	89 7d e4             	mov    %edi,-0x1c(%ebp)
801006df:	31 db                	xor    %ebx,%ebx
801006e1:	89 d7                	mov    %edx,%edi
    if(c != '%'){
801006e3:	83 f8 25             	cmp    $0x25,%eax
801006e6:	75 58                	jne    80100740 <cprintf+0x90>
    c = fmt[++i] & 0xff;
801006e8:	83 c3 01             	add    $0x1,%ebx
801006eb:	0f b6 0c 1e          	movzbl (%esi,%ebx,1),%ecx
    if(c == 0)
801006ef:	85 c9                	test   %ecx,%ecx
801006f1:	74 3a                	je     8010072d <cprintf+0x7d>
    switch(c){
801006f3:	83 f9 70             	cmp    $0x70,%ecx
801006f6:	0f 84 b4 00 00 00    	je     801007b0 <cprintf+0x100>
801006fc:	7f 72                	jg     80100770 <cprintf+0xc0>
801006fe:	83 f9 25             	cmp    $0x25,%ecx
80100701:	74 4d                	je     80100750 <cprintf+0xa0>
80100703:	83 f9 64             	cmp    $0x64,%ecx
80100706:	75 76                	jne    8010077e <cprintf+0xce>
      printint(*argp++, 10, 1);
80100708:	8d 47 04             	lea    0x4(%edi),%eax
8010070b:	b9 01 00 00 00       	mov    $0x1,%ecx
80100710:	ba 0a 00 00 00       	mov    $0xa,%edx
80100715:	89 45 e0             	mov    %eax,-0x20(%ebp)
80100718:	8b 07                	mov    (%edi),%eax
8010071a:	e8 01 ff ff ff       	call   80100620 <printint>
8010071f:	8b 7d e0             	mov    -0x20(%ebp),%edi
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
80100722:	83 c3 01             	add    $0x1,%ebx
80100725:	0f b6 04 1e          	movzbl (%esi,%ebx,1),%eax
80100729:	85 c0                	test   %eax,%eax
8010072b:	75 b6                	jne    801006e3 <cprintf+0x33>
8010072d:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  if(locking)
80100730:	85 ff                	test   %edi,%edi
80100732:	0f 85 bb 00 00 00    	jne    801007f3 <cprintf+0x143>
}
80100738:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010073b:	5b                   	pop    %ebx
8010073c:	5e                   	pop    %esi
8010073d:	5f                   	pop    %edi
8010073e:	5d                   	pop    %ebp
8010073f:	c3                   	ret
  if(panicked){
80100740:	8b 0d 58 ff 10 80    	mov    0x8010ff58,%ecx
80100746:	85 c9                	test   %ecx,%ecx
80100748:	74 19                	je     80100763 <cprintf+0xb3>
8010074a:	fa                   	cli
    for(;;)
8010074b:	eb fe                	jmp    8010074b <cprintf+0x9b>
8010074d:	8d 76 00             	lea    0x0(%esi),%esi
  if(panicked){
80100750:	8b 0d 58 ff 10 80    	mov    0x8010ff58,%ecx
80100756:	85 c9                	test   %ecx,%ecx
80100758:	0f 85 f2 00 00 00    	jne    80100850 <cprintf+0x1a0>
8010075e:	b8 25 00 00 00       	mov    $0x25,%eax
80100763:	e8 98 fc ff ff       	call   80100400 <consputc.part.0>
      break;
80100768:	eb b8                	jmp    80100722 <cprintf+0x72>
8010076a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    switch(c){
80100770:	83 f9 73             	cmp    $0x73,%ecx
80100773:	0f 84 8f 00 00 00    	je     80100808 <cprintf+0x158>
80100779:	83 f9 78             	cmp    $0x78,%ecx
8010077c:	74 32                	je     801007b0 <cprintf+0x100>
  if(panicked){
8010077e:	8b 15 58 ff 10 80    	mov    0x8010ff58,%edx
80100784:	85 d2                	test   %edx,%edx
80100786:	0f 85 b8 00 00 00    	jne    80100844 <cprintf+0x194>
8010078c:	b8 25 00 00 00       	mov    $0x25,%eax
80100791:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80100794:	e8 67 fc ff ff       	call   80100400 <consputc.part.0>
80100799:	a1 58 ff 10 80       	mov    0x8010ff58,%eax
8010079e:	8b 4d e0             	mov    -0x20(%ebp),%ecx
801007a1:	85 c0                	test   %eax,%eax
801007a3:	0f 84 cd 00 00 00    	je     80100876 <cprintf+0x1c6>
801007a9:	fa                   	cli
    for(;;)
801007aa:	eb fe                	jmp    801007aa <cprintf+0xfa>
801007ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      printint(*argp++, 16, 0);
801007b0:	8d 47 04             	lea    0x4(%edi),%eax
801007b3:	31 c9                	xor    %ecx,%ecx
801007b5:	ba 10 00 00 00       	mov    $0x10,%edx
801007ba:	89 45 e0             	mov    %eax,-0x20(%ebp)
801007bd:	8b 07                	mov    (%edi),%eax
801007bf:	e8 5c fe ff ff       	call   80100620 <printint>
801007c4:	8b 7d e0             	mov    -0x20(%ebp),%edi
      break;
801007c7:	e9 56 ff ff ff       	jmp    80100722 <cprintf+0x72>
801007cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    acquire(&cons.lock);
801007d0:	83 ec 0c             	sub    $0xc,%esp
801007d3:	68 20 ff 10 80       	push   $0x8010ff20
801007d8:	e8 13 3f 00 00       	call   801046f0 <acquire>
  if (fmt == 0)
801007dd:	83 c4 10             	add    $0x10,%esp
801007e0:	85 f6                	test   %esi,%esi
801007e2:	0f 84 a1 00 00 00    	je     80100889 <cprintf+0x1d9>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
801007e8:	0f b6 06             	movzbl (%esi),%eax
801007eb:	85 c0                	test   %eax,%eax
801007ed:	0f 85 e6 fe ff ff    	jne    801006d9 <cprintf+0x29>
    release(&cons.lock);
801007f3:	83 ec 0c             	sub    $0xc,%esp
801007f6:	68 20 ff 10 80       	push   $0x8010ff20
801007fb:	e8 90 3e 00 00       	call   80104690 <release>
80100800:	83 c4 10             	add    $0x10,%esp
80100803:	e9 30 ff ff ff       	jmp    80100738 <cprintf+0x88>
      if((s = (char*)*argp++) == 0)
80100808:	8b 17                	mov    (%edi),%edx
8010080a:	8d 47 04             	lea    0x4(%edi),%eax
8010080d:	85 d2                	test   %edx,%edx
8010080f:	74 27                	je     80100838 <cprintf+0x188>
      for(; *s; s++)
80100811:	0f b6 0a             	movzbl (%edx),%ecx
      if((s = (char*)*argp++) == 0)
80100814:	89 d7                	mov    %edx,%edi
      for(; *s; s++)
80100816:	84 c9                	test   %cl,%cl
80100818:	74 68                	je     80100882 <cprintf+0x1d2>
8010081a:	89 5d e0             	mov    %ebx,-0x20(%ebp)
8010081d:	89 fb                	mov    %edi,%ebx
8010081f:	89 f7                	mov    %esi,%edi
80100821:	89 c6                	mov    %eax,%esi
80100823:	0f be c1             	movsbl %cl,%eax
  if(panicked){
80100826:	8b 15 58 ff 10 80    	mov    0x8010ff58,%edx
8010082c:	85 d2                	test   %edx,%edx
8010082e:	74 28                	je     80100858 <cprintf+0x1a8>
80100830:	fa                   	cli
    for(;;)
80100831:	eb fe                	jmp    80100831 <cprintf+0x181>
80100833:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100838:	b9 28 00 00 00       	mov    $0x28,%ecx
        s = "(null)";
8010083d:	bf 78 78 10 80       	mov    $0x80107878,%edi
80100842:	eb d6                	jmp    8010081a <cprintf+0x16a>
80100844:	fa                   	cli
    for(;;)
80100845:	eb fe                	jmp    80100845 <cprintf+0x195>
80100847:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010084e:	00 
8010084f:	90                   	nop
80100850:	fa                   	cli
80100851:	eb fe                	jmp    80100851 <cprintf+0x1a1>
80100853:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100858:	e8 a3 fb ff ff       	call   80100400 <consputc.part.0>
      for(; *s; s++)
8010085d:	0f be 43 01          	movsbl 0x1(%ebx),%eax
80100861:	83 c3 01             	add    $0x1,%ebx
80100864:	84 c0                	test   %al,%al
80100866:	75 be                	jne    80100826 <cprintf+0x176>
      if((s = (char*)*argp++) == 0)
80100868:	89 f0                	mov    %esi,%eax
8010086a:	8b 5d e0             	mov    -0x20(%ebp),%ebx
8010086d:	89 fe                	mov    %edi,%esi
8010086f:	89 c7                	mov    %eax,%edi
80100871:	e9 ac fe ff ff       	jmp    80100722 <cprintf+0x72>
80100876:	89 c8                	mov    %ecx,%eax
80100878:	e8 83 fb ff ff       	call   80100400 <consputc.part.0>
      break;
8010087d:	e9 a0 fe ff ff       	jmp    80100722 <cprintf+0x72>
      if((s = (char*)*argp++) == 0)
80100882:	89 c7                	mov    %eax,%edi
80100884:	e9 99 fe ff ff       	jmp    80100722 <cprintf+0x72>
    panic("null fmt");
80100889:	83 ec 0c             	sub    $0xc,%esp
8010088c:	68 7f 78 10 80       	push   $0x8010787f
80100891:	e8 ea fa ff ff       	call   80100380 <panic>
80100896:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010089d:	00 
8010089e:	66 90                	xchg   %ax,%ax

801008a0 <consoleintr>:
{
801008a0:	55                   	push   %ebp
801008a1:	89 e5                	mov    %esp,%ebp
801008a3:	57                   	push   %edi
  int c, doprocdump = 0;
801008a4:	31 ff                	xor    %edi,%edi
{
801008a6:	56                   	push   %esi
801008a7:	53                   	push   %ebx
801008a8:	83 ec 18             	sub    $0x18,%esp
801008ab:	8b 75 08             	mov    0x8(%ebp),%esi
  acquire(&cons.lock);
801008ae:	68 20 ff 10 80       	push   $0x8010ff20
801008b3:	e8 38 3e 00 00       	call   801046f0 <acquire>
  while((c = getc()) >= 0){
801008b8:	83 c4 10             	add    $0x10,%esp
801008bb:	ff d6                	call   *%esi
801008bd:	89 c3                	mov    %eax,%ebx
801008bf:	85 c0                	test   %eax,%eax
801008c1:	78 22                	js     801008e5 <consoleintr+0x45>
    switch(c){
801008c3:	83 fb 15             	cmp    $0x15,%ebx
801008c6:	74 47                	je     8010090f <consoleintr+0x6f>
801008c8:	7f 76                	jg     80100940 <consoleintr+0xa0>
801008ca:	83 fb 08             	cmp    $0x8,%ebx
801008cd:	74 76                	je     80100945 <consoleintr+0xa5>
801008cf:	83 fb 10             	cmp    $0x10,%ebx
801008d2:	0f 85 f8 00 00 00    	jne    801009d0 <consoleintr+0x130>
  while((c = getc()) >= 0){
801008d8:	ff d6                	call   *%esi
    switch(c){
801008da:	bf 01 00 00 00       	mov    $0x1,%edi
  while((c = getc()) >= 0){
801008df:	89 c3                	mov    %eax,%ebx
801008e1:	85 c0                	test   %eax,%eax
801008e3:	79 de                	jns    801008c3 <consoleintr+0x23>
  release(&cons.lock);
801008e5:	83 ec 0c             	sub    $0xc,%esp
801008e8:	68 20 ff 10 80       	push   $0x8010ff20
801008ed:	e8 9e 3d 00 00       	call   80104690 <release>
  if(doprocdump) {
801008f2:	83 c4 10             	add    $0x10,%esp
801008f5:	85 ff                	test   %edi,%edi
801008f7:	0f 85 4b 01 00 00    	jne    80100a48 <consoleintr+0x1a8>
}
801008fd:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100900:	5b                   	pop    %ebx
80100901:	5e                   	pop    %esi
80100902:	5f                   	pop    %edi
80100903:	5d                   	pop    %ebp
80100904:	c3                   	ret
80100905:	b8 00 01 00 00       	mov    $0x100,%eax
8010090a:	e8 f1 fa ff ff       	call   80100400 <consputc.part.0>
      while(input.e != input.w &&
8010090f:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
80100914:	3b 05 04 ff 10 80    	cmp    0x8010ff04,%eax
8010091a:	74 9f                	je     801008bb <consoleintr+0x1b>
            input.buf[(input.e-1) % INPUT_BUF] != '\n'){
8010091c:	83 e8 01             	sub    $0x1,%eax
8010091f:	89 c2                	mov    %eax,%edx
80100921:	83 e2 7f             	and    $0x7f,%edx
      while(input.e != input.w &&
80100924:	80 ba 80 fe 10 80 0a 	cmpb   $0xa,-0x7fef0180(%edx)
8010092b:	74 8e                	je     801008bb <consoleintr+0x1b>
  if(panicked){
8010092d:	8b 15 58 ff 10 80    	mov    0x8010ff58,%edx
        input.e--;
80100933:	a3 08 ff 10 80       	mov    %eax,0x8010ff08
  if(panicked){
80100938:	85 d2                	test   %edx,%edx
8010093a:	74 c9                	je     80100905 <consoleintr+0x65>
8010093c:	fa                   	cli
    for(;;)
8010093d:	eb fe                	jmp    8010093d <consoleintr+0x9d>
8010093f:	90                   	nop
    switch(c){
80100940:	83 fb 7f             	cmp    $0x7f,%ebx
80100943:	75 2b                	jne    80100970 <consoleintr+0xd0>
      if(input.e != input.w){
80100945:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
8010094a:	3b 05 04 ff 10 80    	cmp    0x8010ff04,%eax
80100950:	0f 84 65 ff ff ff    	je     801008bb <consoleintr+0x1b>
        input.e--;
80100956:	83 e8 01             	sub    $0x1,%eax
80100959:	a3 08 ff 10 80       	mov    %eax,0x8010ff08
  if(panicked){
8010095e:	a1 58 ff 10 80       	mov    0x8010ff58,%eax
80100963:	85 c0                	test   %eax,%eax
80100965:	0f 84 ce 00 00 00    	je     80100a39 <consoleintr+0x199>
8010096b:	fa                   	cli
    for(;;)
8010096c:	eb fe                	jmp    8010096c <consoleintr+0xcc>
8010096e:	66 90                	xchg   %ax,%ax
      if(c != 0 && input.e-input.r < INPUT_BUF){
80100970:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
80100975:	89 c2                	mov    %eax,%edx
80100977:	2b 15 00 ff 10 80    	sub    0x8010ff00,%edx
8010097d:	83 fa 7f             	cmp    $0x7f,%edx
80100980:	0f 87 35 ff ff ff    	ja     801008bb <consoleintr+0x1b>
  if(panicked){
80100986:	8b 0d 58 ff 10 80    	mov    0x8010ff58,%ecx
        input.buf[input.e++ % INPUT_BUF] = c;
8010098c:	8d 50 01             	lea    0x1(%eax),%edx
8010098f:	83 e0 7f             	and    $0x7f,%eax
80100992:	89 15 08 ff 10 80    	mov    %edx,0x8010ff08
80100998:	88 98 80 fe 10 80    	mov    %bl,-0x7fef0180(%eax)
  if(panicked){
8010099e:	85 c9                	test   %ecx,%ecx
801009a0:	0f 85 ae 00 00 00    	jne    80100a54 <consoleintr+0x1b4>
801009a6:	89 d8                	mov    %ebx,%eax
801009a8:	e8 53 fa ff ff       	call   80100400 <consputc.part.0>
        if(c == '\n' || c == C('D') || input.e == input.r+INPUT_BUF){
801009ad:	83 fb 0a             	cmp    $0xa,%ebx
801009b0:	74 68                	je     80100a1a <consoleintr+0x17a>
801009b2:	83 fb 04             	cmp    $0x4,%ebx
801009b5:	74 63                	je     80100a1a <consoleintr+0x17a>
801009b7:	a1 00 ff 10 80       	mov    0x8010ff00,%eax
801009bc:	83 e8 80             	sub    $0xffffff80,%eax
801009bf:	39 05 08 ff 10 80    	cmp    %eax,0x8010ff08
801009c5:	0f 85 f0 fe ff ff    	jne    801008bb <consoleintr+0x1b>
801009cb:	eb 52                	jmp    80100a1f <consoleintr+0x17f>
801009cd:	8d 76 00             	lea    0x0(%esi),%esi
      if(c != 0 && input.e-input.r < INPUT_BUF){
801009d0:	85 db                	test   %ebx,%ebx
801009d2:	0f 84 e3 fe ff ff    	je     801008bb <consoleintr+0x1b>
801009d8:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
801009dd:	89 c2                	mov    %eax,%edx
801009df:	2b 15 00 ff 10 80    	sub    0x8010ff00,%edx
801009e5:	83 fa 7f             	cmp    $0x7f,%edx
801009e8:	0f 87 cd fe ff ff    	ja     801008bb <consoleintr+0x1b>
        input.buf[input.e++ % INPUT_BUF] = c;
801009ee:	8d 50 01             	lea    0x1(%eax),%edx
  if(panicked){
801009f1:	8b 0d 58 ff 10 80    	mov    0x8010ff58,%ecx
        input.buf[input.e++ % INPUT_BUF] = c;
801009f7:	83 e0 7f             	and    $0x7f,%eax
        c = (c == '\r') ? '\n' : c;
801009fa:	83 fb 0d             	cmp    $0xd,%ebx
801009fd:	75 93                	jne    80100992 <consoleintr+0xf2>
        input.buf[input.e++ % INPUT_BUF] = c;
801009ff:	89 15 08 ff 10 80    	mov    %edx,0x8010ff08
80100a05:	c6 80 80 fe 10 80 0a 	movb   $0xa,-0x7fef0180(%eax)
  if(panicked){
80100a0c:	85 c9                	test   %ecx,%ecx
80100a0e:	75 44                	jne    80100a54 <consoleintr+0x1b4>
80100a10:	b8 0a 00 00 00       	mov    $0xa,%eax
80100a15:	e8 e6 f9 ff ff       	call   80100400 <consputc.part.0>
          input.w = input.e;
80100a1a:	a1 08 ff 10 80       	mov    0x8010ff08,%eax
          wakeup(&input.r);
80100a1f:	83 ec 0c             	sub    $0xc,%esp
          input.w = input.e;
80100a22:	a3 04 ff 10 80       	mov    %eax,0x8010ff04
          wakeup(&input.r);
80100a27:	68 00 ff 10 80       	push   $0x8010ff00
80100a2c:	e8 7f 37 00 00       	call   801041b0 <wakeup>
80100a31:	83 c4 10             	add    $0x10,%esp
80100a34:	e9 82 fe ff ff       	jmp    801008bb <consoleintr+0x1b>
80100a39:	b8 00 01 00 00       	mov    $0x100,%eax
80100a3e:	e8 bd f9 ff ff       	call   80100400 <consputc.part.0>
80100a43:	e9 73 fe ff ff       	jmp    801008bb <consoleintr+0x1b>
}
80100a48:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100a4b:	5b                   	pop    %ebx
80100a4c:	5e                   	pop    %esi
80100a4d:	5f                   	pop    %edi
80100a4e:	5d                   	pop    %ebp
    procdump();  // now call procdump() wo. cons.lock held
80100a4f:	e9 3c 38 00 00       	jmp    80104290 <procdump>
80100a54:	fa                   	cli
    for(;;)
80100a55:	eb fe                	jmp    80100a55 <consoleintr+0x1b5>
80100a57:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100a5e:	00 
80100a5f:	90                   	nop

80100a60 <consoleinit>:

void
consoleinit(void)
{
80100a60:	55                   	push   %ebp
80100a61:	89 e5                	mov    %esp,%ebp
80100a63:	83 ec 10             	sub    $0x10,%esp
  initlock(&cons.lock, "console");
80100a66:	68 88 78 10 80       	push   $0x80107888
80100a6b:	68 20 ff 10 80       	push   $0x8010ff20
80100a70:	e8 8b 3a 00 00       	call   80104500 <initlock>

  devsw[CONSOLE].write = consolewrite;
  devsw[CONSOLE].read = consoleread;
  cons.locking = 1;

  ioapicenable(IRQ_KBD, 0);
80100a75:	58                   	pop    %eax
80100a76:	5a                   	pop    %edx
80100a77:	6a 00                	push   $0x0
80100a79:	6a 01                	push   $0x1
  devsw[CONSOLE].write = consolewrite;
80100a7b:	c7 05 0c 09 11 80 b0 	movl   $0x801005b0,0x8011090c
80100a82:	05 10 80 
  devsw[CONSOLE].read = consoleread;
80100a85:	c7 05 08 09 11 80 80 	movl   $0x80100280,0x80110908
80100a8c:	02 10 80 
  cons.locking = 1;
80100a8f:	c7 05 54 ff 10 80 01 	movl   $0x1,0x8010ff54
80100a96:	00 00 00 
  ioapicenable(IRQ_KBD, 0);
80100a99:	e8 c2 19 00 00       	call   80102460 <ioapicenable>
}
80100a9e:	83 c4 10             	add    $0x10,%esp
80100aa1:	c9                   	leave
80100aa2:	c3                   	ret
80100aa3:	66 90                	xchg   %ax,%ax
80100aa5:	66 90                	xchg   %ax,%ax
80100aa7:	66 90                	xchg   %ax,%ax
80100aa9:	66 90                	xchg   %ax,%ax
80100aab:	66 90                	xchg   %ax,%ax
80100aad:	66 90                	xchg   %ax,%ax
80100aaf:	90                   	nop

80100ab0 <exec>:
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
80100ab0:	55                   	push   %ebp
80100ab1:	89 e5                	mov    %esp,%ebp
80100ab3:	57                   	push   %edi
80100ab4:	56                   	push   %esi
80100ab5:	53                   	push   %ebx
80100ab6:	81 ec 0c 01 00 00    	sub    $0x10c,%esp
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
80100abc:	e8 2f 2f 00 00       	call   801039f0 <myproc>
80100ac1:	89 85 ec fe ff ff    	mov    %eax,-0x114(%ebp)

  begin_op();
80100ac7:	e8 e4 22 00 00       	call   80102db0 <begin_op>

  if((ip = namei(path)) == 0){
80100acc:	83 ec 0c             	sub    $0xc,%esp
80100acf:	ff 75 08             	push   0x8(%ebp)
80100ad2:	e8 a9 15 00 00       	call   80102080 <namei>
80100ad7:	83 c4 10             	add    $0x10,%esp
80100ada:	85 c0                	test   %eax,%eax
80100adc:	0f 84 30 03 00 00    	je     80100e12 <exec+0x362>
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
80100ae2:	83 ec 0c             	sub    $0xc,%esp
80100ae5:	89 c7                	mov    %eax,%edi
80100ae7:	50                   	push   %eax
80100ae8:	e8 b3 0c 00 00       	call   801017a0 <ilock>
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
80100aed:	8d 85 24 ff ff ff    	lea    -0xdc(%ebp),%eax
80100af3:	6a 34                	push   $0x34
80100af5:	6a 00                	push   $0x0
80100af7:	50                   	push   %eax
80100af8:	57                   	push   %edi
80100af9:	e8 b2 0f 00 00       	call   80101ab0 <readi>
80100afe:	83 c4 20             	add    $0x20,%esp
80100b01:	83 f8 34             	cmp    $0x34,%eax
80100b04:	0f 85 01 01 00 00    	jne    80100c0b <exec+0x15b>
    goto bad;
  if(elf.magic != ELF_MAGIC)
80100b0a:	81 bd 24 ff ff ff 7f 	cmpl   $0x464c457f,-0xdc(%ebp)
80100b11:	45 4c 46 
80100b14:	0f 85 f1 00 00 00    	jne    80100c0b <exec+0x15b>
    goto bad;

  if((pgdir = setupkvm()) == 0)
80100b1a:	e8 71 66 00 00       	call   80107190 <setupkvm>
80100b1f:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%ebp)
80100b25:	85 c0                	test   %eax,%eax
80100b27:	0f 84 de 00 00 00    	je     80100c0b <exec+0x15b>
    goto bad;

  // Load program into memory.
  sz = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100b2d:	66 83 bd 50 ff ff ff 	cmpw   $0x0,-0xb0(%ebp)
80100b34:	00 
80100b35:	8b b5 40 ff ff ff    	mov    -0xc0(%ebp),%esi
80100b3b:	0f 84 a1 02 00 00    	je     80100de2 <exec+0x332>
  sz = 0;
80100b41:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80100b48:	00 00 00 
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100b4b:	31 db                	xor    %ebx,%ebx
80100b4d:	e9 8c 00 00 00       	jmp    80100bde <exec+0x12e>
80100b52:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
80100b58:	83 bd 04 ff ff ff 01 	cmpl   $0x1,-0xfc(%ebp)
80100b5f:	75 6c                	jne    80100bcd <exec+0x11d>
      continue;
    if(ph.memsz < ph.filesz)
80100b61:	8b 85 18 ff ff ff    	mov    -0xe8(%ebp),%eax
80100b67:	3b 85 14 ff ff ff    	cmp    -0xec(%ebp),%eax
80100b6d:	0f 82 87 00 00 00    	jb     80100bfa <exec+0x14a>
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
80100b73:	03 85 0c ff ff ff    	add    -0xf4(%ebp),%eax
80100b79:	72 7f                	jb     80100bfa <exec+0x14a>
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
80100b7b:	83 ec 04             	sub    $0x4,%esp
80100b7e:	50                   	push   %eax
80100b7f:	ff b5 f0 fe ff ff    	push   -0x110(%ebp)
80100b85:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100b8b:	e8 30 64 00 00       	call   80106fc0 <allocuvm>
80100b90:	83 c4 10             	add    $0x10,%esp
80100b93:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100b99:	85 c0                	test   %eax,%eax
80100b9b:	74 5d                	je     80100bfa <exec+0x14a>
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
80100b9d:	8b 85 0c ff ff ff    	mov    -0xf4(%ebp),%eax
80100ba3:	a9 ff 0f 00 00       	test   $0xfff,%eax
80100ba8:	75 50                	jne    80100bfa <exec+0x14a>
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
80100baa:	83 ec 0c             	sub    $0xc,%esp
80100bad:	ff b5 14 ff ff ff    	push   -0xec(%ebp)
80100bb3:	ff b5 08 ff ff ff    	push   -0xf8(%ebp)
80100bb9:	57                   	push   %edi
80100bba:	50                   	push   %eax
80100bbb:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100bc1:	e8 2a 63 00 00       	call   80106ef0 <loaduvm>
80100bc6:	83 c4 20             	add    $0x20,%esp
80100bc9:	85 c0                	test   %eax,%eax
80100bcb:	78 2d                	js     80100bfa <exec+0x14a>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100bcd:	0f b7 85 50 ff ff ff 	movzwl -0xb0(%ebp),%eax
80100bd4:	83 c3 01             	add    $0x1,%ebx
80100bd7:	83 c6 20             	add    $0x20,%esi
80100bda:	39 d8                	cmp    %ebx,%eax
80100bdc:	7e 52                	jle    80100c30 <exec+0x180>
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
80100bde:	8d 85 04 ff ff ff    	lea    -0xfc(%ebp),%eax
80100be4:	6a 20                	push   $0x20
80100be6:	56                   	push   %esi
80100be7:	50                   	push   %eax
80100be8:	57                   	push   %edi
80100be9:	e8 c2 0e 00 00       	call   80101ab0 <readi>
80100bee:	83 c4 10             	add    $0x10,%esp
80100bf1:	83 f8 20             	cmp    $0x20,%eax
80100bf4:	0f 84 5e ff ff ff    	je     80100b58 <exec+0xa8>
  freevm(oldpgdir);
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
80100bfa:	83 ec 0c             	sub    $0xc,%esp
80100bfd:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100c03:	e8 08 65 00 00       	call   80107110 <freevm>
  if(ip){
80100c08:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
80100c0b:	83 ec 0c             	sub    $0xc,%esp
80100c0e:	57                   	push   %edi
80100c0f:	e8 1c 0e 00 00       	call   80101a30 <iunlockput>
    end_op();
80100c14:	e8 07 22 00 00       	call   80102e20 <end_op>
80100c19:	83 c4 10             	add    $0x10,%esp
    return -1;
80100c1c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  }
  return -1;
}
80100c21:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100c24:	5b                   	pop    %ebx
80100c25:	5e                   	pop    %esi
80100c26:	5f                   	pop    %edi
80100c27:	5d                   	pop    %ebp
80100c28:	c3                   	ret
80100c29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  sz = PGROUNDUP(sz);
80100c30:	8b b5 f0 fe ff ff    	mov    -0x110(%ebp),%esi
80100c36:	81 c6 ff 0f 00 00    	add    $0xfff,%esi
80100c3c:	81 e6 00 f0 ff ff    	and    $0xfffff000,%esi
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100c42:	8d 9e 00 20 00 00    	lea    0x2000(%esi),%ebx
  iunlockput(ip);
80100c48:	83 ec 0c             	sub    $0xc,%esp
80100c4b:	57                   	push   %edi
80100c4c:	e8 df 0d 00 00       	call   80101a30 <iunlockput>
  end_op();
80100c51:	e8 ca 21 00 00       	call   80102e20 <end_op>
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
80100c56:	83 c4 0c             	add    $0xc,%esp
80100c59:	53                   	push   %ebx
80100c5a:	56                   	push   %esi
80100c5b:	8b b5 f4 fe ff ff    	mov    -0x10c(%ebp),%esi
80100c61:	56                   	push   %esi
80100c62:	e8 59 63 00 00       	call   80106fc0 <allocuvm>
80100c67:	83 c4 10             	add    $0x10,%esp
80100c6a:	89 c7                	mov    %eax,%edi
80100c6c:	85 c0                	test   %eax,%eax
80100c6e:	0f 84 86 00 00 00    	je     80100cfa <exec+0x24a>
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100c74:	83 ec 08             	sub    $0x8,%esp
80100c77:	8d 80 00 e0 ff ff    	lea    -0x2000(%eax),%eax
  sp = sz;
80100c7d:	89 fb                	mov    %edi,%ebx
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100c7f:	50                   	push   %eax
80100c80:	56                   	push   %esi
  for(argc = 0; argv[argc]; argc++) {
80100c81:	31 f6                	xor    %esi,%esi
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
80100c83:	e8 a8 65 00 00       	call   80107230 <clearpteu>
  for(argc = 0; argv[argc]; argc++) {
80100c88:	8b 45 0c             	mov    0xc(%ebp),%eax
80100c8b:	83 c4 10             	add    $0x10,%esp
80100c8e:	8b 10                	mov    (%eax),%edx
80100c90:	85 d2                	test   %edx,%edx
80100c92:	0f 84 56 01 00 00    	je     80100dee <exec+0x33e>
80100c98:	89 bd f0 fe ff ff    	mov    %edi,-0x110(%ebp)
80100c9e:	8b 7d 0c             	mov    0xc(%ebp),%edi
80100ca1:	eb 23                	jmp    80100cc6 <exec+0x216>
80100ca3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80100ca8:	8d 46 01             	lea    0x1(%esi),%eax
    ustack[3+argc] = sp;
80100cab:	89 9c b5 64 ff ff ff 	mov    %ebx,-0x9c(%ebp,%esi,4)
80100cb2:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
  for(argc = 0; argv[argc]; argc++) {
80100cb8:	8b 14 87             	mov    (%edi,%eax,4),%edx
80100cbb:	85 d2                	test   %edx,%edx
80100cbd:	74 51                	je     80100d10 <exec+0x260>
    if(argc >= MAXARG)
80100cbf:	83 f8 20             	cmp    $0x20,%eax
80100cc2:	74 36                	je     80100cfa <exec+0x24a>
80100cc4:	89 c6                	mov    %eax,%esi
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100cc6:	83 ec 0c             	sub    $0xc,%esp
80100cc9:	52                   	push   %edx
80100cca:	e8 11 3d 00 00       	call   801049e0 <strlen>
80100ccf:	29 c3                	sub    %eax,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100cd1:	58                   	pop    %eax
80100cd2:	ff 34 b7             	push   (%edi,%esi,4)
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
80100cd5:	83 eb 01             	sub    $0x1,%ebx
80100cd8:	83 e3 fc             	and    $0xfffffffc,%ebx
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
80100cdb:	e8 00 3d 00 00       	call   801049e0 <strlen>
80100ce0:	83 c0 01             	add    $0x1,%eax
80100ce3:	50                   	push   %eax
80100ce4:	ff 34 b7             	push   (%edi,%esi,4)
80100ce7:	53                   	push   %ebx
80100ce8:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100cee:	e8 ed 66 00 00       	call   801073e0 <copyout>
80100cf3:	83 c4 20             	add    $0x20,%esp
80100cf6:	85 c0                	test   %eax,%eax
80100cf8:	79 ae                	jns    80100ca8 <exec+0x1f8>
    freevm(pgdir);
80100cfa:	83 ec 0c             	sub    $0xc,%esp
80100cfd:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100d03:	e8 08 64 00 00       	call   80107110 <freevm>
80100d08:	83 c4 10             	add    $0x10,%esp
80100d0b:	e9 0c ff ff ff       	jmp    80100c1c <exec+0x16c>
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100d10:	8d 14 b5 08 00 00 00 	lea    0x8(,%esi,4),%edx
  ustack[3+argc] = 0;
80100d17:	8b bd f0 fe ff ff    	mov    -0x110(%ebp),%edi
80100d1d:	89 85 f0 fe ff ff    	mov    %eax,-0x110(%ebp)
80100d23:	8d 46 04             	lea    0x4(%esi),%eax
  sp -= (3+argc+1) * 4;
80100d26:	8d 72 0c             	lea    0xc(%edx),%esi
  ustack[3+argc] = 0;
80100d29:	c7 84 85 58 ff ff ff 	movl   $0x0,-0xa8(%ebp,%eax,4)
80100d30:	00 00 00 00 
  ustack[1] = argc;
80100d34:	8b 85 f0 fe ff ff    	mov    -0x110(%ebp),%eax
  ustack[0] = 0xffffffff;  // fake return PC
80100d3a:	c7 85 58 ff ff ff ff 	movl   $0xffffffff,-0xa8(%ebp)
80100d41:	ff ff ff 
  ustack[1] = argc;
80100d44:	89 85 5c ff ff ff    	mov    %eax,-0xa4(%ebp)
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100d4a:	89 d8                	mov    %ebx,%eax
  sp -= (3+argc+1) * 4;
80100d4c:	29 f3                	sub    %esi,%ebx
  ustack[2] = sp - (argc+1)*4;  // argv pointer
80100d4e:	29 d0                	sub    %edx,%eax
80100d50:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%ebp)
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
80100d56:	56                   	push   %esi
80100d57:	51                   	push   %ecx
80100d58:	53                   	push   %ebx
80100d59:	ff b5 f4 fe ff ff    	push   -0x10c(%ebp)
80100d5f:	e8 7c 66 00 00       	call   801073e0 <copyout>
80100d64:	83 c4 10             	add    $0x10,%esp
80100d67:	85 c0                	test   %eax,%eax
80100d69:	78 8f                	js     80100cfa <exec+0x24a>
  for(last=s=path; *s; s++)
80100d6b:	8b 45 08             	mov    0x8(%ebp),%eax
80100d6e:	8b 55 08             	mov    0x8(%ebp),%edx
80100d71:	0f b6 00             	movzbl (%eax),%eax
80100d74:	84 c0                	test   %al,%al
80100d76:	74 17                	je     80100d8f <exec+0x2df>
80100d78:	89 d1                	mov    %edx,%ecx
80100d7a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      last = s+1;
80100d80:	83 c1 01             	add    $0x1,%ecx
80100d83:	3c 2f                	cmp    $0x2f,%al
  for(last=s=path; *s; s++)
80100d85:	0f b6 01             	movzbl (%ecx),%eax
      last = s+1;
80100d88:	0f 44 d1             	cmove  %ecx,%edx
  for(last=s=path; *s; s++)
80100d8b:	84 c0                	test   %al,%al
80100d8d:	75 f1                	jne    80100d80 <exec+0x2d0>
  safestrcpy(curproc->name, last, sizeof(curproc->name));
80100d8f:	83 ec 04             	sub    $0x4,%esp
80100d92:	6a 10                	push   $0x10
80100d94:	52                   	push   %edx
80100d95:	8b b5 ec fe ff ff    	mov    -0x114(%ebp),%esi
80100d9b:	8d 46 6c             	lea    0x6c(%esi),%eax
80100d9e:	50                   	push   %eax
80100d9f:	e8 fc 3b 00 00       	call   801049a0 <safestrcpy>
  curproc->pgdir = pgdir;
80100da4:	8b 8d f4 fe ff ff    	mov    -0x10c(%ebp),%ecx
  oldpgdir = curproc->pgdir;
80100daa:	89 f0                	mov    %esi,%eax
80100dac:	8b 76 04             	mov    0x4(%esi),%esi
  curproc->sz = sz;
80100daf:	89 38                	mov    %edi,(%eax)
  curproc->pgdir = pgdir;
80100db1:	89 48 04             	mov    %ecx,0x4(%eax)
  curproc->tf->eip = elf.entry;  // main
80100db4:	89 c1                	mov    %eax,%ecx
80100db6:	8b 95 3c ff ff ff    	mov    -0xc4(%ebp),%edx
80100dbc:	8b 40 18             	mov    0x18(%eax),%eax
80100dbf:	89 50 38             	mov    %edx,0x38(%eax)
  curproc->tf->esp = sp;
80100dc2:	8b 41 18             	mov    0x18(%ecx),%eax
80100dc5:	89 58 44             	mov    %ebx,0x44(%eax)
  switchuvm(curproc);
80100dc8:	89 0c 24             	mov    %ecx,(%esp)
80100dcb:	e8 90 5f 00 00       	call   80106d60 <switchuvm>
  freevm(oldpgdir);
80100dd0:	89 34 24             	mov    %esi,(%esp)
80100dd3:	e8 38 63 00 00       	call   80107110 <freevm>
  return 0;
80100dd8:	83 c4 10             	add    $0x10,%esp
80100ddb:	31 c0                	xor    %eax,%eax
80100ddd:	e9 3f fe ff ff       	jmp    80100c21 <exec+0x171>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
80100de2:	bb 00 20 00 00       	mov    $0x2000,%ebx
80100de7:	31 f6                	xor    %esi,%esi
80100de9:	e9 5a fe ff ff       	jmp    80100c48 <exec+0x198>
  for(argc = 0; argv[argc]; argc++) {
80100dee:	be 10 00 00 00       	mov    $0x10,%esi
80100df3:	ba 04 00 00 00       	mov    $0x4,%edx
80100df8:	b8 03 00 00 00       	mov    $0x3,%eax
80100dfd:	c7 85 f0 fe ff ff 00 	movl   $0x0,-0x110(%ebp)
80100e04:	00 00 00 
80100e07:	8d 8d 58 ff ff ff    	lea    -0xa8(%ebp),%ecx
80100e0d:	e9 17 ff ff ff       	jmp    80100d29 <exec+0x279>
    end_op();
80100e12:	e8 09 20 00 00       	call   80102e20 <end_op>
    cprintf("exec: fail\n");
80100e17:	83 ec 0c             	sub    $0xc,%esp
80100e1a:	68 90 78 10 80       	push   $0x80107890
80100e1f:	e8 8c f8 ff ff       	call   801006b0 <cprintf>
    return -1;
80100e24:	83 c4 10             	add    $0x10,%esp
80100e27:	e9 f0 fd ff ff       	jmp    80100c1c <exec+0x16c>
80100e2c:	66 90                	xchg   %ax,%ax
80100e2e:	66 90                	xchg   %ax,%ax

80100e30 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
80100e30:	55                   	push   %ebp
80100e31:	89 e5                	mov    %esp,%ebp
80100e33:	83 ec 10             	sub    $0x10,%esp
  initlock(&ftable.lock, "ftable");
80100e36:	68 9c 78 10 80       	push   $0x8010789c
80100e3b:	68 60 ff 10 80       	push   $0x8010ff60
80100e40:	e8 bb 36 00 00       	call   80104500 <initlock>
}
80100e45:	83 c4 10             	add    $0x10,%esp
80100e48:	c9                   	leave
80100e49:	c3                   	ret
80100e4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80100e50 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
80100e50:	55                   	push   %ebp
80100e51:	89 e5                	mov    %esp,%ebp
80100e53:	53                   	push   %ebx
  struct file *f;

  acquire(&ftable.lock);
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100e54:	bb 94 ff 10 80       	mov    $0x8010ff94,%ebx
{
80100e59:	83 ec 10             	sub    $0x10,%esp
  acquire(&ftable.lock);
80100e5c:	68 60 ff 10 80       	push   $0x8010ff60
80100e61:	e8 8a 38 00 00       	call   801046f0 <acquire>
80100e66:	83 c4 10             	add    $0x10,%esp
80100e69:	eb 10                	jmp    80100e7b <filealloc+0x2b>
80100e6b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(f = ftable.file; f < ftable.file + NFILE; f++){
80100e70:	83 c3 18             	add    $0x18,%ebx
80100e73:	81 fb f4 08 11 80    	cmp    $0x801108f4,%ebx
80100e79:	74 25                	je     80100ea0 <filealloc+0x50>
    if(f->ref == 0){
80100e7b:	8b 43 04             	mov    0x4(%ebx),%eax
80100e7e:	85 c0                	test   %eax,%eax
80100e80:	75 ee                	jne    80100e70 <filealloc+0x20>
      f->ref = 1;
      release(&ftable.lock);
80100e82:	83 ec 0c             	sub    $0xc,%esp
      f->ref = 1;
80100e85:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%ebx)
      release(&ftable.lock);
80100e8c:	68 60 ff 10 80       	push   $0x8010ff60
80100e91:	e8 fa 37 00 00       	call   80104690 <release>
      return f;
    }
  }
  release(&ftable.lock);
  return 0;
}
80100e96:	89 d8                	mov    %ebx,%eax
      return f;
80100e98:	83 c4 10             	add    $0x10,%esp
}
80100e9b:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100e9e:	c9                   	leave
80100e9f:	c3                   	ret
  release(&ftable.lock);
80100ea0:	83 ec 0c             	sub    $0xc,%esp
  return 0;
80100ea3:	31 db                	xor    %ebx,%ebx
  release(&ftable.lock);
80100ea5:	68 60 ff 10 80       	push   $0x8010ff60
80100eaa:	e8 e1 37 00 00       	call   80104690 <release>
}
80100eaf:	89 d8                	mov    %ebx,%eax
  return 0;
80100eb1:	83 c4 10             	add    $0x10,%esp
}
80100eb4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100eb7:	c9                   	leave
80100eb8:	c3                   	ret
80100eb9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80100ec0 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
80100ec0:	55                   	push   %ebp
80100ec1:	89 e5                	mov    %esp,%ebp
80100ec3:	53                   	push   %ebx
80100ec4:	83 ec 10             	sub    $0x10,%esp
80100ec7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ftable.lock);
80100eca:	68 60 ff 10 80       	push   $0x8010ff60
80100ecf:	e8 1c 38 00 00       	call   801046f0 <acquire>
  if(f->ref < 1)
80100ed4:	8b 43 04             	mov    0x4(%ebx),%eax
80100ed7:	83 c4 10             	add    $0x10,%esp
80100eda:	85 c0                	test   %eax,%eax
80100edc:	7e 1a                	jle    80100ef8 <filedup+0x38>
    panic("filedup");
  f->ref++;
80100ede:	83 c0 01             	add    $0x1,%eax
  release(&ftable.lock);
80100ee1:	83 ec 0c             	sub    $0xc,%esp
  f->ref++;
80100ee4:	89 43 04             	mov    %eax,0x4(%ebx)
  release(&ftable.lock);
80100ee7:	68 60 ff 10 80       	push   $0x8010ff60
80100eec:	e8 9f 37 00 00       	call   80104690 <release>
  return f;
}
80100ef1:	89 d8                	mov    %ebx,%eax
80100ef3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80100ef6:	c9                   	leave
80100ef7:	c3                   	ret
    panic("filedup");
80100ef8:	83 ec 0c             	sub    $0xc,%esp
80100efb:	68 a3 78 10 80       	push   $0x801078a3
80100f00:	e8 7b f4 ff ff       	call   80100380 <panic>
80100f05:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100f0c:	00 
80100f0d:	8d 76 00             	lea    0x0(%esi),%esi

80100f10 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
80100f10:	55                   	push   %ebp
80100f11:	89 e5                	mov    %esp,%ebp
80100f13:	57                   	push   %edi
80100f14:	56                   	push   %esi
80100f15:	53                   	push   %ebx
80100f16:	83 ec 28             	sub    $0x28,%esp
80100f19:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct file ff;

  acquire(&ftable.lock);
80100f1c:	68 60 ff 10 80       	push   $0x8010ff60
80100f21:	e8 ca 37 00 00       	call   801046f0 <acquire>
  if(f->ref < 1)
80100f26:	8b 53 04             	mov    0x4(%ebx),%edx
80100f29:	83 c4 10             	add    $0x10,%esp
80100f2c:	85 d2                	test   %edx,%edx
80100f2e:	0f 8e a5 00 00 00    	jle    80100fd9 <fileclose+0xc9>
    panic("fileclose");
  if(--f->ref > 0){
80100f34:	83 ea 01             	sub    $0x1,%edx
80100f37:	89 53 04             	mov    %edx,0x4(%ebx)
80100f3a:	75 44                	jne    80100f80 <fileclose+0x70>
    release(&ftable.lock);
    return;
  }
  ff = *f;
80100f3c:	0f b6 43 09          	movzbl 0x9(%ebx),%eax
  f->ref = 0;
  f->type = FD_NONE;
  release(&ftable.lock);
80100f40:	83 ec 0c             	sub    $0xc,%esp
  ff = *f;
80100f43:	8b 3b                	mov    (%ebx),%edi
  f->type = FD_NONE;
80100f45:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  ff = *f;
80100f4b:	8b 73 0c             	mov    0xc(%ebx),%esi
80100f4e:	88 45 e7             	mov    %al,-0x19(%ebp)
80100f51:	8b 43 10             	mov    0x10(%ebx),%eax
80100f54:	89 45 e0             	mov    %eax,-0x20(%ebp)
  release(&ftable.lock);
80100f57:	68 60 ff 10 80       	push   $0x8010ff60
80100f5c:	e8 2f 37 00 00       	call   80104690 <release>

  if(ff.type == FD_PIPE)
80100f61:	83 c4 10             	add    $0x10,%esp
80100f64:	83 ff 01             	cmp    $0x1,%edi
80100f67:	74 57                	je     80100fc0 <fileclose+0xb0>
    pipeclose(ff.pipe, ff.writable);
  else if(ff.type == FD_INODE){
80100f69:	83 ff 02             	cmp    $0x2,%edi
80100f6c:	74 2a                	je     80100f98 <fileclose+0x88>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
80100f6e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100f71:	5b                   	pop    %ebx
80100f72:	5e                   	pop    %esi
80100f73:	5f                   	pop    %edi
80100f74:	5d                   	pop    %ebp
80100f75:	c3                   	ret
80100f76:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100f7d:	00 
80100f7e:	66 90                	xchg   %ax,%ax
    release(&ftable.lock);
80100f80:	c7 45 08 60 ff 10 80 	movl   $0x8010ff60,0x8(%ebp)
}
80100f87:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100f8a:	5b                   	pop    %ebx
80100f8b:	5e                   	pop    %esi
80100f8c:	5f                   	pop    %edi
80100f8d:	5d                   	pop    %ebp
    release(&ftable.lock);
80100f8e:	e9 fd 36 00 00       	jmp    80104690 <release>
80100f93:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    begin_op();
80100f98:	e8 13 1e 00 00       	call   80102db0 <begin_op>
    iput(ff.ip);
80100f9d:	83 ec 0c             	sub    $0xc,%esp
80100fa0:	ff 75 e0             	push   -0x20(%ebp)
80100fa3:	e8 28 09 00 00       	call   801018d0 <iput>
    end_op();
80100fa8:	83 c4 10             	add    $0x10,%esp
}
80100fab:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fae:	5b                   	pop    %ebx
80100faf:	5e                   	pop    %esi
80100fb0:	5f                   	pop    %edi
80100fb1:	5d                   	pop    %ebp
    end_op();
80100fb2:	e9 69 1e 00 00       	jmp    80102e20 <end_op>
80100fb7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100fbe:	00 
80100fbf:	90                   	nop
    pipeclose(ff.pipe, ff.writable);
80100fc0:	0f be 5d e7          	movsbl -0x19(%ebp),%ebx
80100fc4:	83 ec 08             	sub    $0x8,%esp
80100fc7:	53                   	push   %ebx
80100fc8:	56                   	push   %esi
80100fc9:	e8 a2 25 00 00       	call   80103570 <pipeclose>
80100fce:	83 c4 10             	add    $0x10,%esp
}
80100fd1:	8d 65 f4             	lea    -0xc(%ebp),%esp
80100fd4:	5b                   	pop    %ebx
80100fd5:	5e                   	pop    %esi
80100fd6:	5f                   	pop    %edi
80100fd7:	5d                   	pop    %ebp
80100fd8:	c3                   	ret
    panic("fileclose");
80100fd9:	83 ec 0c             	sub    $0xc,%esp
80100fdc:	68 ab 78 10 80       	push   $0x801078ab
80100fe1:	e8 9a f3 ff ff       	call   80100380 <panic>
80100fe6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80100fed:	00 
80100fee:	66 90                	xchg   %ax,%ax

80100ff0 <filestat>:

// Get metadata about file f.
int
filestat(struct file *f, struct stat *st)
{
80100ff0:	55                   	push   %ebp
80100ff1:	89 e5                	mov    %esp,%ebp
80100ff3:	53                   	push   %ebx
80100ff4:	83 ec 04             	sub    $0x4,%esp
80100ff7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(f->type == FD_INODE){
80100ffa:	83 3b 02             	cmpl   $0x2,(%ebx)
80100ffd:	75 31                	jne    80101030 <filestat+0x40>
    ilock(f->ip);
80100fff:	83 ec 0c             	sub    $0xc,%esp
80101002:	ff 73 10             	push   0x10(%ebx)
80101005:	e8 96 07 00 00       	call   801017a0 <ilock>
    stati(f->ip, st);
8010100a:	58                   	pop    %eax
8010100b:	5a                   	pop    %edx
8010100c:	ff 75 0c             	push   0xc(%ebp)
8010100f:	ff 73 10             	push   0x10(%ebx)
80101012:	e8 69 0a 00 00       	call   80101a80 <stati>
    iunlock(f->ip);
80101017:	59                   	pop    %ecx
80101018:	ff 73 10             	push   0x10(%ebx)
8010101b:	e8 60 08 00 00       	call   80101880 <iunlock>
    return 0;
  }
  return -1;
}
80101020:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80101023:	83 c4 10             	add    $0x10,%esp
80101026:	31 c0                	xor    %eax,%eax
}
80101028:	c9                   	leave
80101029:	c3                   	ret
8010102a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80101030:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
80101033:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80101038:	c9                   	leave
80101039:	c3                   	ret
8010103a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80101040 <fileread>:

// Read from file f.
int
fileread(struct file *f, char *addr, int n)
{
80101040:	55                   	push   %ebp
80101041:	89 e5                	mov    %esp,%ebp
80101043:	57                   	push   %edi
80101044:	56                   	push   %esi
80101045:	53                   	push   %ebx
80101046:	83 ec 0c             	sub    $0xc,%esp
80101049:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010104c:	8b 75 0c             	mov    0xc(%ebp),%esi
8010104f:	8b 7d 10             	mov    0x10(%ebp),%edi
  int r;

  if(f->readable == 0)
80101052:	80 7b 08 00          	cmpb   $0x0,0x8(%ebx)
80101056:	74 60                	je     801010b8 <fileread+0x78>
    return -1;
  if(f->type == FD_PIPE)
80101058:	8b 03                	mov    (%ebx),%eax
8010105a:	83 f8 01             	cmp    $0x1,%eax
8010105d:	74 41                	je     801010a0 <fileread+0x60>
    return piperead(f->pipe, addr, n);
  if(f->type == FD_INODE){
8010105f:	83 f8 02             	cmp    $0x2,%eax
80101062:	75 5b                	jne    801010bf <fileread+0x7f>
    ilock(f->ip);
80101064:	83 ec 0c             	sub    $0xc,%esp
80101067:	ff 73 10             	push   0x10(%ebx)
8010106a:	e8 31 07 00 00       	call   801017a0 <ilock>
    if((r = readi(f->ip, addr, f->off, n)) > 0)
8010106f:	57                   	push   %edi
80101070:	ff 73 14             	push   0x14(%ebx)
80101073:	56                   	push   %esi
80101074:	ff 73 10             	push   0x10(%ebx)
80101077:	e8 34 0a 00 00       	call   80101ab0 <readi>
8010107c:	83 c4 20             	add    $0x20,%esp
8010107f:	89 c6                	mov    %eax,%esi
80101081:	85 c0                	test   %eax,%eax
80101083:	7e 03                	jle    80101088 <fileread+0x48>
      f->off += r;
80101085:	01 43 14             	add    %eax,0x14(%ebx)
    iunlock(f->ip);
80101088:	83 ec 0c             	sub    $0xc,%esp
8010108b:	ff 73 10             	push   0x10(%ebx)
8010108e:	e8 ed 07 00 00       	call   80101880 <iunlock>
    return r;
80101093:	83 c4 10             	add    $0x10,%esp
  }
  panic("fileread");
}
80101096:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101099:	89 f0                	mov    %esi,%eax
8010109b:	5b                   	pop    %ebx
8010109c:	5e                   	pop    %esi
8010109d:	5f                   	pop    %edi
8010109e:	5d                   	pop    %ebp
8010109f:	c3                   	ret
    return piperead(f->pipe, addr, n);
801010a0:	8b 43 0c             	mov    0xc(%ebx),%eax
801010a3:	89 45 08             	mov    %eax,0x8(%ebp)
}
801010a6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801010a9:	5b                   	pop    %ebx
801010aa:	5e                   	pop    %esi
801010ab:	5f                   	pop    %edi
801010ac:	5d                   	pop    %ebp
    return piperead(f->pipe, addr, n);
801010ad:	e9 7e 26 00 00       	jmp    80103730 <piperead>
801010b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
801010b8:	be ff ff ff ff       	mov    $0xffffffff,%esi
801010bd:	eb d7                	jmp    80101096 <fileread+0x56>
  panic("fileread");
801010bf:	83 ec 0c             	sub    $0xc,%esp
801010c2:	68 b5 78 10 80       	push   $0x801078b5
801010c7:	e8 b4 f2 ff ff       	call   80100380 <panic>
801010cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801010d0 <filewrite>:

//PAGEBREAK!
// Write to file f.
int
filewrite(struct file *f, char *addr, int n)
{
801010d0:	55                   	push   %ebp
801010d1:	89 e5                	mov    %esp,%ebp
801010d3:	57                   	push   %edi
801010d4:	56                   	push   %esi
801010d5:	53                   	push   %ebx
801010d6:	83 ec 1c             	sub    $0x1c,%esp
801010d9:	8b 45 0c             	mov    0xc(%ebp),%eax
801010dc:	8b 5d 08             	mov    0x8(%ebp),%ebx
801010df:	89 45 dc             	mov    %eax,-0x24(%ebp)
801010e2:	8b 45 10             	mov    0x10(%ebp),%eax
  int r;

  if(f->writable == 0)
801010e5:	80 7b 09 00          	cmpb   $0x0,0x9(%ebx)
{
801010e9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(f->writable == 0)
801010ec:	0f 84 bb 00 00 00    	je     801011ad <filewrite+0xdd>
    return -1;
  if(f->type == FD_PIPE)
801010f2:	8b 03                	mov    (%ebx),%eax
801010f4:	83 f8 01             	cmp    $0x1,%eax
801010f7:	0f 84 bf 00 00 00    	je     801011bc <filewrite+0xec>
    return pipewrite(f->pipe, addr, n);
  if(f->type == FD_INODE){
801010fd:	83 f8 02             	cmp    $0x2,%eax
80101100:	0f 85 c8 00 00 00    	jne    801011ce <filewrite+0xfe>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * 512;
    int i = 0;
    while(i < n){
80101106:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    int i = 0;
80101109:	31 f6                	xor    %esi,%esi
    while(i < n){
8010110b:	85 c0                	test   %eax,%eax
8010110d:	7f 30                	jg     8010113f <filewrite+0x6f>
8010110f:	e9 94 00 00 00       	jmp    801011a8 <filewrite+0xd8>
80101114:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
        f->off += r;
80101118:	01 43 14             	add    %eax,0x14(%ebx)
      iunlock(f->ip);
8010111b:	83 ec 0c             	sub    $0xc,%esp
        f->off += r;
8010111e:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
80101121:	ff 73 10             	push   0x10(%ebx)
80101124:	e8 57 07 00 00       	call   80101880 <iunlock>
      end_op();
80101129:	e8 f2 1c 00 00       	call   80102e20 <end_op>

      if(r < 0)
        break;
      if(r != n1)
8010112e:	8b 45 e0             	mov    -0x20(%ebp),%eax
80101131:	83 c4 10             	add    $0x10,%esp
80101134:	39 c7                	cmp    %eax,%edi
80101136:	75 5c                	jne    80101194 <filewrite+0xc4>
        panic("short filewrite");
      i += r;
80101138:	01 fe                	add    %edi,%esi
    while(i < n){
8010113a:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
8010113d:	7e 69                	jle    801011a8 <filewrite+0xd8>
      int n1 = n - i;
8010113f:	8b 7d e4             	mov    -0x1c(%ebp),%edi
      if(n1 > max)
80101142:	b8 00 06 00 00       	mov    $0x600,%eax
      int n1 = n - i;
80101147:	29 f7                	sub    %esi,%edi
      if(n1 > max)
80101149:	39 c7                	cmp    %eax,%edi
8010114b:	0f 4f f8             	cmovg  %eax,%edi
      begin_op();
8010114e:	e8 5d 1c 00 00       	call   80102db0 <begin_op>
      ilock(f->ip);
80101153:	83 ec 0c             	sub    $0xc,%esp
80101156:	ff 73 10             	push   0x10(%ebx)
80101159:	e8 42 06 00 00       	call   801017a0 <ilock>
      if ((r = writei(f->ip, addr + i, f->off, n1)) > 0)
8010115e:	57                   	push   %edi
8010115f:	ff 73 14             	push   0x14(%ebx)
80101162:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101165:	01 f0                	add    %esi,%eax
80101167:	50                   	push   %eax
80101168:	ff 73 10             	push   0x10(%ebx)
8010116b:	e8 40 0a 00 00       	call   80101bb0 <writei>
80101170:	83 c4 20             	add    $0x20,%esp
80101173:	85 c0                	test   %eax,%eax
80101175:	7f a1                	jg     80101118 <filewrite+0x48>
80101177:	89 45 e0             	mov    %eax,-0x20(%ebp)
      iunlock(f->ip);
8010117a:	83 ec 0c             	sub    $0xc,%esp
8010117d:	ff 73 10             	push   0x10(%ebx)
80101180:	e8 fb 06 00 00       	call   80101880 <iunlock>
      end_op();
80101185:	e8 96 1c 00 00       	call   80102e20 <end_op>
      if(r < 0)
8010118a:	8b 45 e0             	mov    -0x20(%ebp),%eax
8010118d:	83 c4 10             	add    $0x10,%esp
80101190:	85 c0                	test   %eax,%eax
80101192:	75 14                	jne    801011a8 <filewrite+0xd8>
        panic("short filewrite");
80101194:	83 ec 0c             	sub    $0xc,%esp
80101197:	68 be 78 10 80       	push   $0x801078be
8010119c:	e8 df f1 ff ff       	call   80100380 <panic>
801011a1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    }
    return i == n ? n : -1;
801011a8:	39 75 e4             	cmp    %esi,-0x1c(%ebp)
801011ab:	74 05                	je     801011b2 <filewrite+0xe2>
801011ad:	be ff ff ff ff       	mov    $0xffffffff,%esi
  }
  panic("filewrite");
}
801011b2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801011b5:	89 f0                	mov    %esi,%eax
801011b7:	5b                   	pop    %ebx
801011b8:	5e                   	pop    %esi
801011b9:	5f                   	pop    %edi
801011ba:	5d                   	pop    %ebp
801011bb:	c3                   	ret
    return pipewrite(f->pipe, addr, n);
801011bc:	8b 43 0c             	mov    0xc(%ebx),%eax
801011bf:	89 45 08             	mov    %eax,0x8(%ebp)
}
801011c2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801011c5:	5b                   	pop    %ebx
801011c6:	5e                   	pop    %esi
801011c7:	5f                   	pop    %edi
801011c8:	5d                   	pop    %ebp
    return pipewrite(f->pipe, addr, n);
801011c9:	e9 42 24 00 00       	jmp    80103610 <pipewrite>
  panic("filewrite");
801011ce:	83 ec 0c             	sub    $0xc,%esp
801011d1:	68 c4 78 10 80       	push   $0x801078c4
801011d6:	e8 a5 f1 ff ff       	call   80100380 <panic>
801011db:	66 90                	xchg   %ax,%ax
801011dd:	66 90                	xchg   %ax,%ax
801011df:	90                   	nop

801011e0 <balloc>:
// Blocks.

// Allocate a zeroed disk block.
static uint
balloc(uint dev)
{
801011e0:	55                   	push   %ebp
801011e1:	89 e5                	mov    %esp,%ebp
801011e3:	57                   	push   %edi
801011e4:	56                   	push   %esi
801011e5:	53                   	push   %ebx
801011e6:	83 ec 1c             	sub    $0x1c,%esp
  int b, bi, m;
  struct buf *bp;

  bp = 0;
  for(b = 0; b < sb.size; b += BPB){
801011e9:	8b 0d b4 25 11 80    	mov    0x801125b4,%ecx
{
801011ef:	89 45 dc             	mov    %eax,-0x24(%ebp)
  for(b = 0; b < sb.size; b += BPB){
801011f2:	85 c9                	test   %ecx,%ecx
801011f4:	0f 84 8c 00 00 00    	je     80101286 <balloc+0xa6>
801011fa:	31 ff                	xor    %edi,%edi
    bp = bread(dev, BBLOCK(b, sb));
801011fc:	89 f8                	mov    %edi,%eax
801011fe:	83 ec 08             	sub    $0x8,%esp
80101201:	89 fe                	mov    %edi,%esi
80101203:	c1 f8 0c             	sar    $0xc,%eax
80101206:	03 05 cc 25 11 80    	add    0x801125cc,%eax
8010120c:	50                   	push   %eax
8010120d:	ff 75 dc             	push   -0x24(%ebp)
80101210:	e8 bb ee ff ff       	call   801000d0 <bread>
80101215:	83 c4 10             	add    $0x10,%esp
80101218:	89 7d d8             	mov    %edi,-0x28(%ebp)
8010121b:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010121e:	a1 b4 25 11 80       	mov    0x801125b4,%eax
80101223:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101226:	31 c0                	xor    %eax,%eax
80101228:	eb 32                	jmp    8010125c <balloc+0x7c>
8010122a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      m = 1 << (bi % 8);
80101230:	89 c1                	mov    %eax,%ecx
80101232:	bb 01 00 00 00       	mov    $0x1,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
80101237:	8b 7d e4             	mov    -0x1c(%ebp),%edi
      m = 1 << (bi % 8);
8010123a:	83 e1 07             	and    $0x7,%ecx
8010123d:	d3 e3                	shl    %cl,%ebx
      if((bp->data[bi/8] & m) == 0){  // Is block free?
8010123f:	89 c1                	mov    %eax,%ecx
80101241:	c1 f9 03             	sar    $0x3,%ecx
80101244:	0f b6 7c 0f 5c       	movzbl 0x5c(%edi,%ecx,1),%edi
80101249:	89 fa                	mov    %edi,%edx
8010124b:	85 df                	test   %ebx,%edi
8010124d:	74 49                	je     80101298 <balloc+0xb8>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
8010124f:	83 c0 01             	add    $0x1,%eax
80101252:	83 c6 01             	add    $0x1,%esi
80101255:	3d 00 10 00 00       	cmp    $0x1000,%eax
8010125a:	74 07                	je     80101263 <balloc+0x83>
8010125c:	8b 55 e0             	mov    -0x20(%ebp),%edx
8010125f:	39 d6                	cmp    %edx,%esi
80101261:	72 cd                	jb     80101230 <balloc+0x50>
        brelse(bp);
        bzero(dev, b + bi);
        return b + bi;
      }
    }
    brelse(bp);
80101263:	8b 7d d8             	mov    -0x28(%ebp),%edi
80101266:	83 ec 0c             	sub    $0xc,%esp
80101269:	ff 75 e4             	push   -0x1c(%ebp)
  for(b = 0; b < sb.size; b += BPB){
8010126c:	81 c7 00 10 00 00    	add    $0x1000,%edi
    brelse(bp);
80101272:	e8 79 ef ff ff       	call   801001f0 <brelse>
  for(b = 0; b < sb.size; b += BPB){
80101277:	83 c4 10             	add    $0x10,%esp
8010127a:	3b 3d b4 25 11 80    	cmp    0x801125b4,%edi
80101280:	0f 82 76 ff ff ff    	jb     801011fc <balloc+0x1c>
  }
  panic("balloc: out of blocks");
80101286:	83 ec 0c             	sub    $0xc,%esp
80101289:	68 ce 78 10 80       	push   $0x801078ce
8010128e:	e8 ed f0 ff ff       	call   80100380 <panic>
80101293:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        bp->data[bi/8] |= m;  // Mark block in use.
80101298:	8b 7d e4             	mov    -0x1c(%ebp),%edi
        log_write(bp);
8010129b:	83 ec 0c             	sub    $0xc,%esp
        bp->data[bi/8] |= m;  // Mark block in use.
8010129e:	09 da                	or     %ebx,%edx
801012a0:	88 54 0f 5c          	mov    %dl,0x5c(%edi,%ecx,1)
        log_write(bp);
801012a4:	57                   	push   %edi
801012a5:	e8 e6 1c 00 00       	call   80102f90 <log_write>
        brelse(bp);
801012aa:	89 3c 24             	mov    %edi,(%esp)
801012ad:	e8 3e ef ff ff       	call   801001f0 <brelse>
  bp = bread(dev, bno);
801012b2:	58                   	pop    %eax
801012b3:	5a                   	pop    %edx
801012b4:	56                   	push   %esi
801012b5:	ff 75 dc             	push   -0x24(%ebp)
801012b8:	e8 13 ee ff ff       	call   801000d0 <bread>
  memset(bp->data, 0, BSIZE);
801012bd:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, bno);
801012c0:	89 c3                	mov    %eax,%ebx
  memset(bp->data, 0, BSIZE);
801012c2:	8d 40 5c             	lea    0x5c(%eax),%eax
801012c5:	68 00 02 00 00       	push   $0x200
801012ca:	6a 00                	push   $0x0
801012cc:	50                   	push   %eax
801012cd:	e8 1e 35 00 00       	call   801047f0 <memset>
  log_write(bp);
801012d2:	89 1c 24             	mov    %ebx,(%esp)
801012d5:	e8 b6 1c 00 00       	call   80102f90 <log_write>
  brelse(bp);
801012da:	89 1c 24             	mov    %ebx,(%esp)
801012dd:	e8 0e ef ff ff       	call   801001f0 <brelse>
}
801012e2:	8d 65 f4             	lea    -0xc(%ebp),%esp
801012e5:	89 f0                	mov    %esi,%eax
801012e7:	5b                   	pop    %ebx
801012e8:	5e                   	pop    %esi
801012e9:	5f                   	pop    %edi
801012ea:	5d                   	pop    %ebp
801012eb:	c3                   	ret
801012ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801012f0 <iget>:
// Find the inode with number inum on device dev
// and return the in-memory copy. Does not lock
// the inode and does not read it from disk.
static struct inode*
iget(uint dev, uint inum)
{
801012f0:	55                   	push   %ebp
801012f1:	89 e5                	mov    %esp,%ebp
801012f3:	57                   	push   %edi
  struct inode *ip, *empty;

  acquire(&icache.lock);

  // Is the inode already cached?
  empty = 0;
801012f4:	31 ff                	xor    %edi,%edi
{
801012f6:	56                   	push   %esi
801012f7:	89 c6                	mov    %eax,%esi
801012f9:	53                   	push   %ebx
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801012fa:	bb 94 09 11 80       	mov    $0x80110994,%ebx
{
801012ff:	83 ec 28             	sub    $0x28,%esp
80101302:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  acquire(&icache.lock);
80101305:	68 60 09 11 80       	push   $0x80110960
8010130a:	e8 e1 33 00 00       	call   801046f0 <acquire>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
8010130f:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  acquire(&icache.lock);
80101312:	83 c4 10             	add    $0x10,%esp
80101315:	eb 1b                	jmp    80101332 <iget+0x42>
80101317:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010131e:	00 
8010131f:	90                   	nop
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101320:	39 33                	cmp    %esi,(%ebx)
80101322:	74 6c                	je     80101390 <iget+0xa0>
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101324:	81 c3 90 00 00 00    	add    $0x90,%ebx
8010132a:	81 fb b4 25 11 80    	cmp    $0x801125b4,%ebx
80101330:	74 26                	je     80101358 <iget+0x68>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101332:	8b 43 08             	mov    0x8(%ebx),%eax
80101335:	85 c0                	test   %eax,%eax
80101337:	7f e7                	jg     80101320 <iget+0x30>
      ip->ref++;
      release(&icache.lock);
      return ip;
    }
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
80101339:	85 ff                	test   %edi,%edi
8010133b:	75 e7                	jne    80101324 <iget+0x34>
8010133d:	85 c0                	test   %eax,%eax
8010133f:	75 76                	jne    801013b7 <iget+0xc7>
      empty = ip;
80101341:	89 df                	mov    %ebx,%edi
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
80101343:	81 c3 90 00 00 00    	add    $0x90,%ebx
80101349:	81 fb b4 25 11 80    	cmp    $0x801125b4,%ebx
8010134f:	75 e1                	jne    80101332 <iget+0x42>
80101351:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  }

  // Recycle an inode cache entry.
  if(empty == 0)
80101358:	85 ff                	test   %edi,%edi
8010135a:	74 79                	je     801013d5 <iget+0xe5>
  ip = empty;
  ip->dev = dev;
  ip->inum = inum;
  ip->ref = 1;
  ip->valid = 0;
  release(&icache.lock);
8010135c:	83 ec 0c             	sub    $0xc,%esp
  ip->dev = dev;
8010135f:	89 37                	mov    %esi,(%edi)
  ip->inum = inum;
80101361:	89 57 04             	mov    %edx,0x4(%edi)
  ip->ref = 1;
80101364:	c7 47 08 01 00 00 00 	movl   $0x1,0x8(%edi)
  ip->valid = 0;
8010136b:	c7 47 4c 00 00 00 00 	movl   $0x0,0x4c(%edi)
  release(&icache.lock);
80101372:	68 60 09 11 80       	push   $0x80110960
80101377:	e8 14 33 00 00       	call   80104690 <release>

  return ip;
8010137c:	83 c4 10             	add    $0x10,%esp
}
8010137f:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101382:	89 f8                	mov    %edi,%eax
80101384:	5b                   	pop    %ebx
80101385:	5e                   	pop    %esi
80101386:	5f                   	pop    %edi
80101387:	5d                   	pop    %ebp
80101388:	c3                   	ret
80101389:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
80101390:	39 53 04             	cmp    %edx,0x4(%ebx)
80101393:	75 8f                	jne    80101324 <iget+0x34>
      ip->ref++;
80101395:	83 c0 01             	add    $0x1,%eax
      release(&icache.lock);
80101398:	83 ec 0c             	sub    $0xc,%esp
      return ip;
8010139b:	89 df                	mov    %ebx,%edi
      ip->ref++;
8010139d:	89 43 08             	mov    %eax,0x8(%ebx)
      release(&icache.lock);
801013a0:	68 60 09 11 80       	push   $0x80110960
801013a5:	e8 e6 32 00 00       	call   80104690 <release>
      return ip;
801013aa:	83 c4 10             	add    $0x10,%esp
}
801013ad:	8d 65 f4             	lea    -0xc(%ebp),%esp
801013b0:	89 f8                	mov    %edi,%eax
801013b2:	5b                   	pop    %ebx
801013b3:	5e                   	pop    %esi
801013b4:	5f                   	pop    %edi
801013b5:	5d                   	pop    %ebp
801013b6:	c3                   	ret
  for(ip = &icache.inode[0]; ip < &icache.inode[NINODE]; ip++){
801013b7:	81 c3 90 00 00 00    	add    $0x90,%ebx
801013bd:	81 fb b4 25 11 80    	cmp    $0x801125b4,%ebx
801013c3:	74 10                	je     801013d5 <iget+0xe5>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
801013c5:	8b 43 08             	mov    0x8(%ebx),%eax
801013c8:	85 c0                	test   %eax,%eax
801013ca:	0f 8f 50 ff ff ff    	jg     80101320 <iget+0x30>
801013d0:	e9 68 ff ff ff       	jmp    8010133d <iget+0x4d>
    panic("iget: no inodes");
801013d5:	83 ec 0c             	sub    $0xc,%esp
801013d8:	68 e4 78 10 80       	push   $0x801078e4
801013dd:	e8 9e ef ff ff       	call   80100380 <panic>
801013e2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801013e9:	00 
801013ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801013f0 <bfree>:
{
801013f0:	55                   	push   %ebp
801013f1:	89 c1                	mov    %eax,%ecx
  bp = bread(dev, BBLOCK(b, sb));
801013f3:	89 d0                	mov    %edx,%eax
801013f5:	c1 e8 0c             	shr    $0xc,%eax
{
801013f8:	89 e5                	mov    %esp,%ebp
801013fa:	56                   	push   %esi
801013fb:	53                   	push   %ebx
  bp = bread(dev, BBLOCK(b, sb));
801013fc:	03 05 cc 25 11 80    	add    0x801125cc,%eax
{
80101402:	89 d3                	mov    %edx,%ebx
  bp = bread(dev, BBLOCK(b, sb));
80101404:	83 ec 08             	sub    $0x8,%esp
80101407:	50                   	push   %eax
80101408:	51                   	push   %ecx
80101409:	e8 c2 ec ff ff       	call   801000d0 <bread>
  m = 1 << (bi % 8);
8010140e:	89 d9                	mov    %ebx,%ecx
  if((bp->data[bi/8] & m) == 0)
80101410:	c1 fb 03             	sar    $0x3,%ebx
80101413:	83 c4 10             	add    $0x10,%esp
  bp = bread(dev, BBLOCK(b, sb));
80101416:	89 c6                	mov    %eax,%esi
  m = 1 << (bi % 8);
80101418:	83 e1 07             	and    $0x7,%ecx
8010141b:	b8 01 00 00 00       	mov    $0x1,%eax
  if((bp->data[bi/8] & m) == 0)
80101420:	81 e3 ff 01 00 00    	and    $0x1ff,%ebx
  m = 1 << (bi % 8);
80101426:	d3 e0                	shl    %cl,%eax
  if((bp->data[bi/8] & m) == 0)
80101428:	0f b6 4c 1e 5c       	movzbl 0x5c(%esi,%ebx,1),%ecx
8010142d:	85 c1                	test   %eax,%ecx
8010142f:	74 23                	je     80101454 <bfree+0x64>
  bp->data[bi/8] &= ~m;
80101431:	f7 d0                	not    %eax
  log_write(bp);
80101433:	83 ec 0c             	sub    $0xc,%esp
  bp->data[bi/8] &= ~m;
80101436:	21 c8                	and    %ecx,%eax
80101438:	88 44 1e 5c          	mov    %al,0x5c(%esi,%ebx,1)
  log_write(bp);
8010143c:	56                   	push   %esi
8010143d:	e8 4e 1b 00 00       	call   80102f90 <log_write>
  brelse(bp);
80101442:	89 34 24             	mov    %esi,(%esp)
80101445:	e8 a6 ed ff ff       	call   801001f0 <brelse>
}
8010144a:	83 c4 10             	add    $0x10,%esp
8010144d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101450:	5b                   	pop    %ebx
80101451:	5e                   	pop    %esi
80101452:	5d                   	pop    %ebp
80101453:	c3                   	ret
    panic("freeing free block");
80101454:	83 ec 0c             	sub    $0xc,%esp
80101457:	68 f4 78 10 80       	push   $0x801078f4
8010145c:	e8 1f ef ff ff       	call   80100380 <panic>
80101461:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101468:	00 
80101469:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80101470 <bmap>:

// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
static uint
bmap(struct inode *ip, uint bn)
{
80101470:	55                   	push   %ebp
80101471:	89 e5                	mov    %esp,%ebp
80101473:	57                   	push   %edi
80101474:	56                   	push   %esi
80101475:	89 c6                	mov    %eax,%esi
80101477:	53                   	push   %ebx
80101478:	83 ec 1c             	sub    $0x1c,%esp
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
8010147b:	83 fa 0b             	cmp    $0xb,%edx
8010147e:	0f 86 8c 00 00 00    	jbe    80101510 <bmap+0xa0>
    if((addr = ip->addrs[bn]) == 0)
      ip->addrs[bn] = addr = balloc(ip->dev);
    return addr;
  }
  bn -= NDIRECT;
80101484:	8d 5a f4             	lea    -0xc(%edx),%ebx

  if(bn < NINDIRECT){
80101487:	83 fb 7f             	cmp    $0x7f,%ebx
8010148a:	0f 87 a2 00 00 00    	ja     80101532 <bmap+0xc2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0)
80101490:	8b 80 8c 00 00 00    	mov    0x8c(%eax),%eax
80101496:	85 c0                	test   %eax,%eax
80101498:	74 5e                	je     801014f8 <bmap+0x88>
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
    bp = bread(ip->dev, addr);
8010149a:	83 ec 08             	sub    $0x8,%esp
8010149d:	50                   	push   %eax
8010149e:	ff 36                	push   (%esi)
801014a0:	e8 2b ec ff ff       	call   801000d0 <bread>
    a = (uint*)bp->data;
    if((addr = a[bn]) == 0){
801014a5:	83 c4 10             	add    $0x10,%esp
801014a8:	8d 5c 98 5c          	lea    0x5c(%eax,%ebx,4),%ebx
    bp = bread(ip->dev, addr);
801014ac:	89 c2                	mov    %eax,%edx
    if((addr = a[bn]) == 0){
801014ae:	8b 3b                	mov    (%ebx),%edi
801014b0:	85 ff                	test   %edi,%edi
801014b2:	74 1c                	je     801014d0 <bmap+0x60>
      a[bn] = addr = balloc(ip->dev);
      log_write(bp);
    }
    brelse(bp);
801014b4:	83 ec 0c             	sub    $0xc,%esp
801014b7:	52                   	push   %edx
801014b8:	e8 33 ed ff ff       	call   801001f0 <brelse>
801014bd:	83 c4 10             	add    $0x10,%esp
    return addr;
  }

  panic("bmap: out of range");
}
801014c0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801014c3:	89 f8                	mov    %edi,%eax
801014c5:	5b                   	pop    %ebx
801014c6:	5e                   	pop    %esi
801014c7:	5f                   	pop    %edi
801014c8:	5d                   	pop    %ebp
801014c9:	c3                   	ret
801014ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801014d0:	89 45 e4             	mov    %eax,-0x1c(%ebp)
      a[bn] = addr = balloc(ip->dev);
801014d3:	8b 06                	mov    (%esi),%eax
801014d5:	e8 06 fd ff ff       	call   801011e0 <balloc>
      log_write(bp);
801014da:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801014dd:	83 ec 0c             	sub    $0xc,%esp
      a[bn] = addr = balloc(ip->dev);
801014e0:	89 03                	mov    %eax,(%ebx)
801014e2:	89 c7                	mov    %eax,%edi
      log_write(bp);
801014e4:	52                   	push   %edx
801014e5:	e8 a6 1a 00 00       	call   80102f90 <log_write>
801014ea:	8b 55 e4             	mov    -0x1c(%ebp),%edx
801014ed:	83 c4 10             	add    $0x10,%esp
801014f0:	eb c2                	jmp    801014b4 <bmap+0x44>
801014f2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      ip->addrs[NDIRECT] = addr = balloc(ip->dev);
801014f8:	8b 06                	mov    (%esi),%eax
801014fa:	e8 e1 fc ff ff       	call   801011e0 <balloc>
801014ff:	89 86 8c 00 00 00    	mov    %eax,0x8c(%esi)
80101505:	eb 93                	jmp    8010149a <bmap+0x2a>
80101507:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010150e:	00 
8010150f:	90                   	nop
    if((addr = ip->addrs[bn]) == 0)
80101510:	8d 5a 14             	lea    0x14(%edx),%ebx
80101513:	8b 7c 98 0c          	mov    0xc(%eax,%ebx,4),%edi
80101517:	85 ff                	test   %edi,%edi
80101519:	75 a5                	jne    801014c0 <bmap+0x50>
      ip->addrs[bn] = addr = balloc(ip->dev);
8010151b:	8b 00                	mov    (%eax),%eax
8010151d:	e8 be fc ff ff       	call   801011e0 <balloc>
80101522:	89 44 9e 0c          	mov    %eax,0xc(%esi,%ebx,4)
80101526:	89 c7                	mov    %eax,%edi
}
80101528:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010152b:	5b                   	pop    %ebx
8010152c:	89 f8                	mov    %edi,%eax
8010152e:	5e                   	pop    %esi
8010152f:	5f                   	pop    %edi
80101530:	5d                   	pop    %ebp
80101531:	c3                   	ret
  panic("bmap: out of range");
80101532:	83 ec 0c             	sub    $0xc,%esp
80101535:	68 07 79 10 80       	push   $0x80107907
8010153a:	e8 41 ee ff ff       	call   80100380 <panic>
8010153f:	90                   	nop

80101540 <readsb>:
{
80101540:	55                   	push   %ebp
80101541:	89 e5                	mov    %esp,%ebp
80101543:	56                   	push   %esi
80101544:	53                   	push   %ebx
80101545:	8b 75 0c             	mov    0xc(%ebp),%esi
  bp = bread(dev, 1);
80101548:	83 ec 08             	sub    $0x8,%esp
8010154b:	6a 01                	push   $0x1
8010154d:	ff 75 08             	push   0x8(%ebp)
80101550:	e8 7b eb ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
80101555:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
80101558:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
8010155a:	8d 40 5c             	lea    0x5c(%eax),%eax
8010155d:	6a 1c                	push   $0x1c
8010155f:	50                   	push   %eax
80101560:	56                   	push   %esi
80101561:	e8 1a 33 00 00       	call   80104880 <memmove>
  brelse(bp);
80101566:	83 c4 10             	add    $0x10,%esp
80101569:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
8010156c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010156f:	5b                   	pop    %ebx
80101570:	5e                   	pop    %esi
80101571:	5d                   	pop    %ebp
  brelse(bp);
80101572:	e9 79 ec ff ff       	jmp    801001f0 <brelse>
80101577:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010157e:	00 
8010157f:	90                   	nop

80101580 <iinit>:
{
80101580:	55                   	push   %ebp
80101581:	89 e5                	mov    %esp,%ebp
80101583:	53                   	push   %ebx
80101584:	bb a0 09 11 80       	mov    $0x801109a0,%ebx
80101589:	83 ec 0c             	sub    $0xc,%esp
  initlock(&icache.lock, "icache");
8010158c:	68 1a 79 10 80       	push   $0x8010791a
80101591:	68 60 09 11 80       	push   $0x80110960
80101596:	e8 65 2f 00 00       	call   80104500 <initlock>
  for(i = 0; i < NINODE; i++) {
8010159b:	83 c4 10             	add    $0x10,%esp
8010159e:	66 90                	xchg   %ax,%ax
    initsleeplock(&icache.inode[i].lock, "inode");
801015a0:	83 ec 08             	sub    $0x8,%esp
801015a3:	68 21 79 10 80       	push   $0x80107921
801015a8:	53                   	push   %ebx
  for(i = 0; i < NINODE; i++) {
801015a9:	81 c3 90 00 00 00    	add    $0x90,%ebx
    initsleeplock(&icache.inode[i].lock, "inode");
801015af:	e8 1c 2e 00 00       	call   801043d0 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
801015b4:	83 c4 10             	add    $0x10,%esp
801015b7:	81 fb c0 25 11 80    	cmp    $0x801125c0,%ebx
801015bd:	75 e1                	jne    801015a0 <iinit+0x20>
  bp = bread(dev, 1);
801015bf:	83 ec 08             	sub    $0x8,%esp
801015c2:	6a 01                	push   $0x1
801015c4:	ff 75 08             	push   0x8(%ebp)
801015c7:	e8 04 eb ff ff       	call   801000d0 <bread>
  memmove(sb, bp->data, sizeof(*sb));
801015cc:	83 c4 0c             	add    $0xc,%esp
  bp = bread(dev, 1);
801015cf:	89 c3                	mov    %eax,%ebx
  memmove(sb, bp->data, sizeof(*sb));
801015d1:	8d 40 5c             	lea    0x5c(%eax),%eax
801015d4:	6a 1c                	push   $0x1c
801015d6:	50                   	push   %eax
801015d7:	68 b4 25 11 80       	push   $0x801125b4
801015dc:	e8 9f 32 00 00       	call   80104880 <memmove>
  brelse(bp);
801015e1:	89 1c 24             	mov    %ebx,(%esp)
801015e4:	e8 07 ec ff ff       	call   801001f0 <brelse>
  cprintf("sb: size %d nblocks %d ninodes %d nlog %d logstart %d\
801015e9:	ff 35 cc 25 11 80    	push   0x801125cc
801015ef:	ff 35 c8 25 11 80    	push   0x801125c8
801015f5:	ff 35 c4 25 11 80    	push   0x801125c4
801015fb:	ff 35 c0 25 11 80    	push   0x801125c0
80101601:	ff 35 bc 25 11 80    	push   0x801125bc
80101607:	ff 35 b8 25 11 80    	push   0x801125b8
8010160d:	ff 35 b4 25 11 80    	push   0x801125b4
80101613:	68 60 7d 10 80       	push   $0x80107d60
80101618:	e8 93 f0 ff ff       	call   801006b0 <cprintf>
}
8010161d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101620:	83 c4 30             	add    $0x30,%esp
80101623:	c9                   	leave
80101624:	c3                   	ret
80101625:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010162c:	00 
8010162d:	8d 76 00             	lea    0x0(%esi),%esi

80101630 <ialloc>:
{
80101630:	55                   	push   %ebp
80101631:	89 e5                	mov    %esp,%ebp
80101633:	57                   	push   %edi
80101634:	56                   	push   %esi
80101635:	53                   	push   %ebx
80101636:	83 ec 1c             	sub    $0x1c,%esp
80101639:	8b 45 0c             	mov    0xc(%ebp),%eax
  for(inum = 1; inum < sb.ninodes; inum++){
8010163c:	83 3d bc 25 11 80 01 	cmpl   $0x1,0x801125bc
{
80101643:	8b 75 08             	mov    0x8(%ebp),%esi
80101646:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  for(inum = 1; inum < sb.ninodes; inum++){
80101649:	0f 86 91 00 00 00    	jbe    801016e0 <ialloc+0xb0>
8010164f:	bf 01 00 00 00       	mov    $0x1,%edi
80101654:	eb 21                	jmp    80101677 <ialloc+0x47>
80101656:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010165d:	00 
8010165e:	66 90                	xchg   %ax,%ax
    brelse(bp);
80101660:	83 ec 0c             	sub    $0xc,%esp
  for(inum = 1; inum < sb.ninodes; inum++){
80101663:	83 c7 01             	add    $0x1,%edi
    brelse(bp);
80101666:	53                   	push   %ebx
80101667:	e8 84 eb ff ff       	call   801001f0 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
8010166c:	83 c4 10             	add    $0x10,%esp
8010166f:	3b 3d bc 25 11 80    	cmp    0x801125bc,%edi
80101675:	73 69                	jae    801016e0 <ialloc+0xb0>
    bp = bread(dev, IBLOCK(inum, sb));
80101677:	89 f8                	mov    %edi,%eax
80101679:	83 ec 08             	sub    $0x8,%esp
8010167c:	c1 e8 03             	shr    $0x3,%eax
8010167f:	03 05 c8 25 11 80    	add    0x801125c8,%eax
80101685:	50                   	push   %eax
80101686:	56                   	push   %esi
80101687:	e8 44 ea ff ff       	call   801000d0 <bread>
    if(dip->type == 0){  // a free inode
8010168c:	83 c4 10             	add    $0x10,%esp
    bp = bread(dev, IBLOCK(inum, sb));
8010168f:	89 c3                	mov    %eax,%ebx
    dip = (struct dinode*)bp->data + inum%IPB;
80101691:	89 f8                	mov    %edi,%eax
80101693:	83 e0 07             	and    $0x7,%eax
80101696:	c1 e0 06             	shl    $0x6,%eax
80101699:	8d 4c 03 5c          	lea    0x5c(%ebx,%eax,1),%ecx
    if(dip->type == 0){  // a free inode
8010169d:	66 83 39 00          	cmpw   $0x0,(%ecx)
801016a1:	75 bd                	jne    80101660 <ialloc+0x30>
      memset(dip, 0, sizeof(*dip));
801016a3:	83 ec 04             	sub    $0x4,%esp
801016a6:	6a 40                	push   $0x40
801016a8:	6a 00                	push   $0x0
801016aa:	51                   	push   %ecx
801016ab:	89 4d e0             	mov    %ecx,-0x20(%ebp)
801016ae:	e8 3d 31 00 00       	call   801047f0 <memset>
      dip->type = type;
801016b3:	0f b7 45 e4          	movzwl -0x1c(%ebp),%eax
801016b7:	8b 4d e0             	mov    -0x20(%ebp),%ecx
801016ba:	66 89 01             	mov    %ax,(%ecx)
      log_write(bp);   // mark it allocated on the disk
801016bd:	89 1c 24             	mov    %ebx,(%esp)
801016c0:	e8 cb 18 00 00       	call   80102f90 <log_write>
      brelse(bp);
801016c5:	89 1c 24             	mov    %ebx,(%esp)
801016c8:	e8 23 eb ff ff       	call   801001f0 <brelse>
      return iget(dev, inum);
801016cd:	83 c4 10             	add    $0x10,%esp
}
801016d0:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return iget(dev, inum);
801016d3:	89 fa                	mov    %edi,%edx
}
801016d5:	5b                   	pop    %ebx
      return iget(dev, inum);
801016d6:	89 f0                	mov    %esi,%eax
}
801016d8:	5e                   	pop    %esi
801016d9:	5f                   	pop    %edi
801016da:	5d                   	pop    %ebp
      return iget(dev, inum);
801016db:	e9 10 fc ff ff       	jmp    801012f0 <iget>
  panic("ialloc: no inodes");
801016e0:	83 ec 0c             	sub    $0xc,%esp
801016e3:	68 27 79 10 80       	push   $0x80107927
801016e8:	e8 93 ec ff ff       	call   80100380 <panic>
801016ed:	8d 76 00             	lea    0x0(%esi),%esi

801016f0 <iupdate>:
{
801016f0:	55                   	push   %ebp
801016f1:	89 e5                	mov    %esp,%ebp
801016f3:	56                   	push   %esi
801016f4:	53                   	push   %ebx
801016f5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801016f8:	8b 43 04             	mov    0x4(%ebx),%eax
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
801016fb:	83 c3 5c             	add    $0x5c,%ebx
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801016fe:	83 ec 08             	sub    $0x8,%esp
80101701:	c1 e8 03             	shr    $0x3,%eax
80101704:	03 05 c8 25 11 80    	add    0x801125c8,%eax
8010170a:	50                   	push   %eax
8010170b:	ff 73 a4             	push   -0x5c(%ebx)
8010170e:	e8 bd e9 ff ff       	call   801000d0 <bread>
  dip->type = ip->type;
80101713:	0f b7 53 f4          	movzwl -0xc(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
80101717:	83 c4 0c             	add    $0xc,%esp
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
8010171a:	89 c6                	mov    %eax,%esi
  dip = (struct dinode*)bp->data + ip->inum%IPB;
8010171c:	8b 43 a8             	mov    -0x58(%ebx),%eax
8010171f:	83 e0 07             	and    $0x7,%eax
80101722:	c1 e0 06             	shl    $0x6,%eax
80101725:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
  dip->type = ip->type;
80101729:	66 89 10             	mov    %dx,(%eax)
  dip->major = ip->major;
8010172c:	0f b7 53 f6          	movzwl -0xa(%ebx),%edx
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
80101730:	83 c0 0c             	add    $0xc,%eax
  dip->major = ip->major;
80101733:	66 89 50 f6          	mov    %dx,-0xa(%eax)
  dip->minor = ip->minor;
80101737:	0f b7 53 f8          	movzwl -0x8(%ebx),%edx
8010173b:	66 89 50 f8          	mov    %dx,-0x8(%eax)
  dip->nlink = ip->nlink;
8010173f:	0f b7 53 fa          	movzwl -0x6(%ebx),%edx
80101743:	66 89 50 fa          	mov    %dx,-0x6(%eax)
  dip->size = ip->size;
80101747:	8b 53 fc             	mov    -0x4(%ebx),%edx
8010174a:	89 50 fc             	mov    %edx,-0x4(%eax)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
8010174d:	6a 34                	push   $0x34
8010174f:	53                   	push   %ebx
80101750:	50                   	push   %eax
80101751:	e8 2a 31 00 00       	call   80104880 <memmove>
  log_write(bp);
80101756:	89 34 24             	mov    %esi,(%esp)
80101759:	e8 32 18 00 00       	call   80102f90 <log_write>
  brelse(bp);
8010175e:	83 c4 10             	add    $0x10,%esp
80101761:	89 75 08             	mov    %esi,0x8(%ebp)
}
80101764:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101767:	5b                   	pop    %ebx
80101768:	5e                   	pop    %esi
80101769:	5d                   	pop    %ebp
  brelse(bp);
8010176a:	e9 81 ea ff ff       	jmp    801001f0 <brelse>
8010176f:	90                   	nop

80101770 <idup>:
{
80101770:	55                   	push   %ebp
80101771:	89 e5                	mov    %esp,%ebp
80101773:	53                   	push   %ebx
80101774:	83 ec 10             	sub    $0x10,%esp
80101777:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&icache.lock);
8010177a:	68 60 09 11 80       	push   $0x80110960
8010177f:	e8 6c 2f 00 00       	call   801046f0 <acquire>
  ip->ref++;
80101784:	83 43 08 01          	addl   $0x1,0x8(%ebx)
  release(&icache.lock);
80101788:	c7 04 24 60 09 11 80 	movl   $0x80110960,(%esp)
8010178f:	e8 fc 2e 00 00       	call   80104690 <release>
}
80101794:	89 d8                	mov    %ebx,%eax
80101796:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80101799:	c9                   	leave
8010179a:	c3                   	ret
8010179b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801017a0 <ilock>:
{
801017a0:	55                   	push   %ebp
801017a1:	89 e5                	mov    %esp,%ebp
801017a3:	56                   	push   %esi
801017a4:	53                   	push   %ebx
801017a5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || ip->ref < 1)
801017a8:	85 db                	test   %ebx,%ebx
801017aa:	0f 84 b7 00 00 00    	je     80101867 <ilock+0xc7>
801017b0:	8b 53 08             	mov    0x8(%ebx),%edx
801017b3:	85 d2                	test   %edx,%edx
801017b5:	0f 8e ac 00 00 00    	jle    80101867 <ilock+0xc7>
  acquiresleep(&ip->lock);
801017bb:	83 ec 0c             	sub    $0xc,%esp
801017be:	8d 43 0c             	lea    0xc(%ebx),%eax
801017c1:	50                   	push   %eax
801017c2:	e8 49 2c 00 00       	call   80104410 <acquiresleep>
  if(ip->valid == 0){
801017c7:	8b 43 4c             	mov    0x4c(%ebx),%eax
801017ca:	83 c4 10             	add    $0x10,%esp
801017cd:	85 c0                	test   %eax,%eax
801017cf:	74 0f                	je     801017e0 <ilock+0x40>
}
801017d1:	8d 65 f8             	lea    -0x8(%ebp),%esp
801017d4:	5b                   	pop    %ebx
801017d5:	5e                   	pop    %esi
801017d6:	5d                   	pop    %ebp
801017d7:	c3                   	ret
801017d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801017df:	00 
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017e0:	8b 43 04             	mov    0x4(%ebx),%eax
801017e3:	83 ec 08             	sub    $0x8,%esp
801017e6:	c1 e8 03             	shr    $0x3,%eax
801017e9:	03 05 c8 25 11 80    	add    0x801125c8,%eax
801017ef:	50                   	push   %eax
801017f0:	ff 33                	push   (%ebx)
801017f2:	e8 d9 e8 ff ff       	call   801000d0 <bread>
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
801017f7:	83 c4 0c             	add    $0xc,%esp
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
801017fa:	89 c6                	mov    %eax,%esi
    dip = (struct dinode*)bp->data + ip->inum%IPB;
801017fc:	8b 43 04             	mov    0x4(%ebx),%eax
801017ff:	83 e0 07             	and    $0x7,%eax
80101802:	c1 e0 06             	shl    $0x6,%eax
80101805:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    ip->type = dip->type;
80101809:	0f b7 10             	movzwl (%eax),%edx
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
8010180c:	83 c0 0c             	add    $0xc,%eax
    ip->type = dip->type;
8010180f:	66 89 53 50          	mov    %dx,0x50(%ebx)
    ip->major = dip->major;
80101813:	0f b7 50 f6          	movzwl -0xa(%eax),%edx
80101817:	66 89 53 52          	mov    %dx,0x52(%ebx)
    ip->minor = dip->minor;
8010181b:	0f b7 50 f8          	movzwl -0x8(%eax),%edx
8010181f:	66 89 53 54          	mov    %dx,0x54(%ebx)
    ip->nlink = dip->nlink;
80101823:	0f b7 50 fa          	movzwl -0x6(%eax),%edx
80101827:	66 89 53 56          	mov    %dx,0x56(%ebx)
    ip->size = dip->size;
8010182b:	8b 50 fc             	mov    -0x4(%eax),%edx
8010182e:	89 53 58             	mov    %edx,0x58(%ebx)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
80101831:	6a 34                	push   $0x34
80101833:	50                   	push   %eax
80101834:	8d 43 5c             	lea    0x5c(%ebx),%eax
80101837:	50                   	push   %eax
80101838:	e8 43 30 00 00       	call   80104880 <memmove>
    brelse(bp);
8010183d:	89 34 24             	mov    %esi,(%esp)
80101840:	e8 ab e9 ff ff       	call   801001f0 <brelse>
    if(ip->type == 0)
80101845:	83 c4 10             	add    $0x10,%esp
80101848:	66 83 7b 50 00       	cmpw   $0x0,0x50(%ebx)
    ip->valid = 1;
8010184d:	c7 43 4c 01 00 00 00 	movl   $0x1,0x4c(%ebx)
    if(ip->type == 0)
80101854:	0f 85 77 ff ff ff    	jne    801017d1 <ilock+0x31>
      panic("ilock: no type");
8010185a:	83 ec 0c             	sub    $0xc,%esp
8010185d:	68 3f 79 10 80       	push   $0x8010793f
80101862:	e8 19 eb ff ff       	call   80100380 <panic>
    panic("ilock");
80101867:	83 ec 0c             	sub    $0xc,%esp
8010186a:	68 39 79 10 80       	push   $0x80107939
8010186f:	e8 0c eb ff ff       	call   80100380 <panic>
80101874:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010187b:	00 
8010187c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101880 <iunlock>:
{
80101880:	55                   	push   %ebp
80101881:	89 e5                	mov    %esp,%ebp
80101883:	56                   	push   %esi
80101884:	53                   	push   %ebx
80101885:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101888:	85 db                	test   %ebx,%ebx
8010188a:	74 28                	je     801018b4 <iunlock+0x34>
8010188c:	83 ec 0c             	sub    $0xc,%esp
8010188f:	8d 73 0c             	lea    0xc(%ebx),%esi
80101892:	56                   	push   %esi
80101893:	e8 18 2c 00 00       	call   801044b0 <holdingsleep>
80101898:	83 c4 10             	add    $0x10,%esp
8010189b:	85 c0                	test   %eax,%eax
8010189d:	74 15                	je     801018b4 <iunlock+0x34>
8010189f:	8b 43 08             	mov    0x8(%ebx),%eax
801018a2:	85 c0                	test   %eax,%eax
801018a4:	7e 0e                	jle    801018b4 <iunlock+0x34>
  releasesleep(&ip->lock);
801018a6:	89 75 08             	mov    %esi,0x8(%ebp)
}
801018a9:	8d 65 f8             	lea    -0x8(%ebp),%esp
801018ac:	5b                   	pop    %ebx
801018ad:	5e                   	pop    %esi
801018ae:	5d                   	pop    %ebp
  releasesleep(&ip->lock);
801018af:	e9 bc 2b 00 00       	jmp    80104470 <releasesleep>
    panic("iunlock");
801018b4:	83 ec 0c             	sub    $0xc,%esp
801018b7:	68 4e 79 10 80       	push   $0x8010794e
801018bc:	e8 bf ea ff ff       	call   80100380 <panic>
801018c1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801018c8:	00 
801018c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801018d0 <iput>:
{
801018d0:	55                   	push   %ebp
801018d1:	89 e5                	mov    %esp,%ebp
801018d3:	57                   	push   %edi
801018d4:	56                   	push   %esi
801018d5:	53                   	push   %ebx
801018d6:	83 ec 28             	sub    $0x28,%esp
801018d9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquiresleep(&ip->lock);
801018dc:	8d 7b 0c             	lea    0xc(%ebx),%edi
801018df:	57                   	push   %edi
801018e0:	e8 2b 2b 00 00       	call   80104410 <acquiresleep>
  if(ip->valid && ip->nlink == 0){
801018e5:	8b 53 4c             	mov    0x4c(%ebx),%edx
801018e8:	83 c4 10             	add    $0x10,%esp
801018eb:	85 d2                	test   %edx,%edx
801018ed:	74 07                	je     801018f6 <iput+0x26>
801018ef:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
801018f4:	74 32                	je     80101928 <iput+0x58>
  releasesleep(&ip->lock);
801018f6:	83 ec 0c             	sub    $0xc,%esp
801018f9:	57                   	push   %edi
801018fa:	e8 71 2b 00 00       	call   80104470 <releasesleep>
  acquire(&icache.lock);
801018ff:	c7 04 24 60 09 11 80 	movl   $0x80110960,(%esp)
80101906:	e8 e5 2d 00 00       	call   801046f0 <acquire>
  ip->ref--;
8010190b:	83 6b 08 01          	subl   $0x1,0x8(%ebx)
  release(&icache.lock);
8010190f:	83 c4 10             	add    $0x10,%esp
80101912:	c7 45 08 60 09 11 80 	movl   $0x80110960,0x8(%ebp)
}
80101919:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010191c:	5b                   	pop    %ebx
8010191d:	5e                   	pop    %esi
8010191e:	5f                   	pop    %edi
8010191f:	5d                   	pop    %ebp
  release(&icache.lock);
80101920:	e9 6b 2d 00 00       	jmp    80104690 <release>
80101925:	8d 76 00             	lea    0x0(%esi),%esi
    acquire(&icache.lock);
80101928:	83 ec 0c             	sub    $0xc,%esp
8010192b:	68 60 09 11 80       	push   $0x80110960
80101930:	e8 bb 2d 00 00       	call   801046f0 <acquire>
    int r = ip->ref;
80101935:	8b 73 08             	mov    0x8(%ebx),%esi
    release(&icache.lock);
80101938:	c7 04 24 60 09 11 80 	movl   $0x80110960,(%esp)
8010193f:	e8 4c 2d 00 00       	call   80104690 <release>
    if(r == 1){
80101944:	83 c4 10             	add    $0x10,%esp
80101947:	83 fe 01             	cmp    $0x1,%esi
8010194a:	75 aa                	jne    801018f6 <iput+0x26>
8010194c:	8d 8b 8c 00 00 00    	lea    0x8c(%ebx),%ecx
80101952:	89 7d e4             	mov    %edi,-0x1c(%ebp)
80101955:	8d 73 5c             	lea    0x5c(%ebx),%esi
80101958:	89 df                	mov    %ebx,%edi
8010195a:	89 cb                	mov    %ecx,%ebx
8010195c:	eb 09                	jmp    80101967 <iput+0x97>
8010195e:	66 90                	xchg   %ax,%ax
{
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
80101960:	83 c6 04             	add    $0x4,%esi
80101963:	39 de                	cmp    %ebx,%esi
80101965:	74 19                	je     80101980 <iput+0xb0>
    if(ip->addrs[i]){
80101967:	8b 16                	mov    (%esi),%edx
80101969:	85 d2                	test   %edx,%edx
8010196b:	74 f3                	je     80101960 <iput+0x90>
      bfree(ip->dev, ip->addrs[i]);
8010196d:	8b 07                	mov    (%edi),%eax
8010196f:	e8 7c fa ff ff       	call   801013f0 <bfree>
      ip->addrs[i] = 0;
80101974:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
8010197a:	eb e4                	jmp    80101960 <iput+0x90>
8010197c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    }
  }

  if(ip->addrs[NDIRECT]){
80101980:	89 fb                	mov    %edi,%ebx
80101982:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80101985:	8b 83 8c 00 00 00    	mov    0x8c(%ebx),%eax
8010198b:	85 c0                	test   %eax,%eax
8010198d:	75 2d                	jne    801019bc <iput+0xec>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
  iupdate(ip);
8010198f:	83 ec 0c             	sub    $0xc,%esp
  ip->size = 0;
80101992:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  iupdate(ip);
80101999:	53                   	push   %ebx
8010199a:	e8 51 fd ff ff       	call   801016f0 <iupdate>
      ip->type = 0;
8010199f:	31 c0                	xor    %eax,%eax
801019a1:	66 89 43 50          	mov    %ax,0x50(%ebx)
      iupdate(ip);
801019a5:	89 1c 24             	mov    %ebx,(%esp)
801019a8:	e8 43 fd ff ff       	call   801016f0 <iupdate>
      ip->valid = 0;
801019ad:	c7 43 4c 00 00 00 00 	movl   $0x0,0x4c(%ebx)
801019b4:	83 c4 10             	add    $0x10,%esp
801019b7:	e9 3a ff ff ff       	jmp    801018f6 <iput+0x26>
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
801019bc:	83 ec 08             	sub    $0x8,%esp
801019bf:	50                   	push   %eax
801019c0:	ff 33                	push   (%ebx)
801019c2:	e8 09 e7 ff ff       	call   801000d0 <bread>
    for(j = 0; j < NINDIRECT; j++){
801019c7:	83 c4 10             	add    $0x10,%esp
801019ca:	89 7d e4             	mov    %edi,-0x1c(%ebp)
801019cd:	8d 88 5c 02 00 00    	lea    0x25c(%eax),%ecx
801019d3:	89 45 e0             	mov    %eax,-0x20(%ebp)
801019d6:	8d 70 5c             	lea    0x5c(%eax),%esi
801019d9:	89 cf                	mov    %ecx,%edi
801019db:	eb 0a                	jmp    801019e7 <iput+0x117>
801019dd:	8d 76 00             	lea    0x0(%esi),%esi
801019e0:	83 c6 04             	add    $0x4,%esi
801019e3:	39 fe                	cmp    %edi,%esi
801019e5:	74 0f                	je     801019f6 <iput+0x126>
      if(a[j])
801019e7:	8b 16                	mov    (%esi),%edx
801019e9:	85 d2                	test   %edx,%edx
801019eb:	74 f3                	je     801019e0 <iput+0x110>
        bfree(ip->dev, a[j]);
801019ed:	8b 03                	mov    (%ebx),%eax
801019ef:	e8 fc f9 ff ff       	call   801013f0 <bfree>
801019f4:	eb ea                	jmp    801019e0 <iput+0x110>
    brelse(bp);
801019f6:	8b 45 e0             	mov    -0x20(%ebp),%eax
801019f9:	83 ec 0c             	sub    $0xc,%esp
801019fc:	8b 7d e4             	mov    -0x1c(%ebp),%edi
801019ff:	50                   	push   %eax
80101a00:	e8 eb e7 ff ff       	call   801001f0 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
80101a05:	8b 93 8c 00 00 00    	mov    0x8c(%ebx),%edx
80101a0b:	8b 03                	mov    (%ebx),%eax
80101a0d:	e8 de f9 ff ff       	call   801013f0 <bfree>
    ip->addrs[NDIRECT] = 0;
80101a12:	83 c4 10             	add    $0x10,%esp
80101a15:	c7 83 8c 00 00 00 00 	movl   $0x0,0x8c(%ebx)
80101a1c:	00 00 00 
80101a1f:	e9 6b ff ff ff       	jmp    8010198f <iput+0xbf>
80101a24:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101a2b:	00 
80101a2c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80101a30 <iunlockput>:
{
80101a30:	55                   	push   %ebp
80101a31:	89 e5                	mov    %esp,%ebp
80101a33:	56                   	push   %esi
80101a34:	53                   	push   %ebx
80101a35:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101a38:	85 db                	test   %ebx,%ebx
80101a3a:	74 34                	je     80101a70 <iunlockput+0x40>
80101a3c:	83 ec 0c             	sub    $0xc,%esp
80101a3f:	8d 73 0c             	lea    0xc(%ebx),%esi
80101a42:	56                   	push   %esi
80101a43:	e8 68 2a 00 00       	call   801044b0 <holdingsleep>
80101a48:	83 c4 10             	add    $0x10,%esp
80101a4b:	85 c0                	test   %eax,%eax
80101a4d:	74 21                	je     80101a70 <iunlockput+0x40>
80101a4f:	8b 43 08             	mov    0x8(%ebx),%eax
80101a52:	85 c0                	test   %eax,%eax
80101a54:	7e 1a                	jle    80101a70 <iunlockput+0x40>
  releasesleep(&ip->lock);
80101a56:	83 ec 0c             	sub    $0xc,%esp
80101a59:	56                   	push   %esi
80101a5a:	e8 11 2a 00 00       	call   80104470 <releasesleep>
  iput(ip);
80101a5f:	83 c4 10             	add    $0x10,%esp
80101a62:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
80101a65:	8d 65 f8             	lea    -0x8(%ebp),%esp
80101a68:	5b                   	pop    %ebx
80101a69:	5e                   	pop    %esi
80101a6a:	5d                   	pop    %ebp
  iput(ip);
80101a6b:	e9 60 fe ff ff       	jmp    801018d0 <iput>
    panic("iunlock");
80101a70:	83 ec 0c             	sub    $0xc,%esp
80101a73:	68 4e 79 10 80       	push   $0x8010794e
80101a78:	e8 03 e9 ff ff       	call   80100380 <panic>
80101a7d:	8d 76 00             	lea    0x0(%esi),%esi

80101a80 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
80101a80:	55                   	push   %ebp
80101a81:	89 e5                	mov    %esp,%ebp
80101a83:	8b 55 08             	mov    0x8(%ebp),%edx
80101a86:	8b 45 0c             	mov    0xc(%ebp),%eax
  st->dev = ip->dev;
80101a89:	8b 0a                	mov    (%edx),%ecx
80101a8b:	89 48 04             	mov    %ecx,0x4(%eax)
  st->ino = ip->inum;
80101a8e:	8b 4a 04             	mov    0x4(%edx),%ecx
80101a91:	89 48 08             	mov    %ecx,0x8(%eax)
  st->type = ip->type;
80101a94:	0f b7 4a 50          	movzwl 0x50(%edx),%ecx
80101a98:	66 89 08             	mov    %cx,(%eax)
  st->nlink = ip->nlink;
80101a9b:	0f b7 4a 56          	movzwl 0x56(%edx),%ecx
80101a9f:	66 89 48 0c          	mov    %cx,0xc(%eax)
  st->size = ip->size;
80101aa3:	8b 52 58             	mov    0x58(%edx),%edx
80101aa6:	89 50 10             	mov    %edx,0x10(%eax)
}
80101aa9:	5d                   	pop    %ebp
80101aaa:	c3                   	ret
80101aab:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80101ab0 <readi>:
//PAGEBREAK!
// Read data from inode.
// Caller must hold ip->lock.
int
readi(struct inode *ip, char *dst, uint off, uint n)
{
80101ab0:	55                   	push   %ebp
80101ab1:	89 e5                	mov    %esp,%ebp
80101ab3:	57                   	push   %edi
80101ab4:	56                   	push   %esi
80101ab5:	53                   	push   %ebx
80101ab6:	83 ec 1c             	sub    $0x1c,%esp
80101ab9:	8b 75 08             	mov    0x8(%ebp),%esi
80101abc:	8b 45 0c             	mov    0xc(%ebp),%eax
80101abf:	8b 7d 10             	mov    0x10(%ebp),%edi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101ac2:	66 83 7e 50 03       	cmpw   $0x3,0x50(%esi)
{
80101ac7:	89 45 e0             	mov    %eax,-0x20(%ebp)
80101aca:	89 75 d8             	mov    %esi,-0x28(%ebp)
80101acd:	8b 45 14             	mov    0x14(%ebp),%eax
  if(ip->type == T_DEV){
80101ad0:	0f 84 aa 00 00 00    	je     80101b80 <readi+0xd0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
      return -1;
    return devsw[ip->major].read(ip, dst, n);
  }

  if(off > ip->size || off + n < off)
80101ad6:	8b 75 d8             	mov    -0x28(%ebp),%esi
80101ad9:	8b 56 58             	mov    0x58(%esi),%edx
80101adc:	39 fa                	cmp    %edi,%edx
80101ade:	0f 82 bd 00 00 00    	jb     80101ba1 <readi+0xf1>
80101ae4:	89 f9                	mov    %edi,%ecx
80101ae6:	31 db                	xor    %ebx,%ebx
80101ae8:	01 c1                	add    %eax,%ecx
80101aea:	0f 92 c3             	setb   %bl
80101aed:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
80101af0:	0f 82 ab 00 00 00    	jb     80101ba1 <readi+0xf1>
    return -1;
  if(off + n > ip->size)
    n = ip->size - off;
80101af6:	89 d3                	mov    %edx,%ebx
80101af8:	29 fb                	sub    %edi,%ebx
80101afa:	39 ca                	cmp    %ecx,%edx
80101afc:	0f 42 c3             	cmovb  %ebx,%eax

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101aff:	85 c0                	test   %eax,%eax
80101b01:	74 73                	je     80101b76 <readi+0xc6>
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80101b03:	8b 75 e4             	mov    -0x1c(%ebp),%esi
80101b06:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80101b09:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101b10:	8b 5d d8             	mov    -0x28(%ebp),%ebx
80101b13:	89 fa                	mov    %edi,%edx
80101b15:	c1 ea 09             	shr    $0x9,%edx
80101b18:	89 d8                	mov    %ebx,%eax
80101b1a:	e8 51 f9 ff ff       	call   80101470 <bmap>
80101b1f:	83 ec 08             	sub    $0x8,%esp
80101b22:	50                   	push   %eax
80101b23:	ff 33                	push   (%ebx)
80101b25:	e8 a6 e5 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101b2a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101b2d:	b9 00 02 00 00       	mov    $0x200,%ecx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101b32:	89 c2                	mov    %eax,%edx
    m = min(n - tot, BSIZE - off%BSIZE);
80101b34:	89 f8                	mov    %edi,%eax
80101b36:	25 ff 01 00 00       	and    $0x1ff,%eax
80101b3b:	29 f3                	sub    %esi,%ebx
80101b3d:	29 c1                	sub    %eax,%ecx
    memmove(dst, bp->data + off%BSIZE, m);
80101b3f:	8d 44 02 5c          	lea    0x5c(%edx,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101b43:	39 d9                	cmp    %ebx,%ecx
80101b45:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(dst, bp->data + off%BSIZE, m);
80101b48:	83 c4 0c             	add    $0xc,%esp
80101b4b:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101b4c:	01 de                	add    %ebx,%esi
80101b4e:	01 df                	add    %ebx,%edi
    memmove(dst, bp->data + off%BSIZE, m);
80101b50:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101b53:	50                   	push   %eax
80101b54:	ff 75 e0             	push   -0x20(%ebp)
80101b57:	e8 24 2d 00 00       	call   80104880 <memmove>
    brelse(bp);
80101b5c:	8b 55 dc             	mov    -0x24(%ebp),%edx
80101b5f:	89 14 24             	mov    %edx,(%esp)
80101b62:	e8 89 e6 ff ff       	call   801001f0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
80101b67:	01 5d e0             	add    %ebx,-0x20(%ebp)
80101b6a:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80101b6d:	83 c4 10             	add    $0x10,%esp
80101b70:	39 de                	cmp    %ebx,%esi
80101b72:	72 9c                	jb     80101b10 <readi+0x60>
80101b74:	89 d8                	mov    %ebx,%eax
  }
  return n;
}
80101b76:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101b79:	5b                   	pop    %ebx
80101b7a:	5e                   	pop    %esi
80101b7b:	5f                   	pop    %edi
80101b7c:	5d                   	pop    %ebp
80101b7d:	c3                   	ret
80101b7e:	66 90                	xchg   %ax,%ax
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].read)
80101b80:	0f bf 56 52          	movswl 0x52(%esi),%edx
80101b84:	66 83 fa 09          	cmp    $0x9,%dx
80101b88:	77 17                	ja     80101ba1 <readi+0xf1>
80101b8a:	8b 14 d5 00 09 11 80 	mov    -0x7feef700(,%edx,8),%edx
80101b91:	85 d2                	test   %edx,%edx
80101b93:	74 0c                	je     80101ba1 <readi+0xf1>
    return devsw[ip->major].read(ip, dst, n);
80101b95:	89 45 10             	mov    %eax,0x10(%ebp)
}
80101b98:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101b9b:	5b                   	pop    %ebx
80101b9c:	5e                   	pop    %esi
80101b9d:	5f                   	pop    %edi
80101b9e:	5d                   	pop    %ebp
    return devsw[ip->major].read(ip, dst, n);
80101b9f:	ff e2                	jmp    *%edx
      return -1;
80101ba1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101ba6:	eb ce                	jmp    80101b76 <readi+0xc6>
80101ba8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101baf:	00 

80101bb0 <writei>:
// PAGEBREAK!
// Write data to inode.
// Caller must hold ip->lock.
int
writei(struct inode *ip, char *src, uint off, uint n)
{
80101bb0:	55                   	push   %ebp
80101bb1:	89 e5                	mov    %esp,%ebp
80101bb3:	57                   	push   %edi
80101bb4:	56                   	push   %esi
80101bb5:	53                   	push   %ebx
80101bb6:	83 ec 1c             	sub    $0x1c,%esp
80101bb9:	8b 45 08             	mov    0x8(%ebp),%eax
80101bbc:	8b 7d 0c             	mov    0xc(%ebp),%edi
80101bbf:	8b 75 14             	mov    0x14(%ebp),%esi
  uint tot, m;
  struct buf *bp;

  if(ip->type == T_DEV){
80101bc2:	66 83 78 50 03       	cmpw   $0x3,0x50(%eax)
{
80101bc7:	89 7d dc             	mov    %edi,-0x24(%ebp)
80101bca:	89 75 e0             	mov    %esi,-0x20(%ebp)
80101bcd:	8b 7d 10             	mov    0x10(%ebp),%edi
  if(ip->type == T_DEV){
80101bd0:	0f 84 ba 00 00 00    	je     80101c90 <writei+0xe0>
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
      return -1;
    return devsw[ip->major].write(ip, src, n);
  }

  if(off > ip->size || off + n < off)
80101bd6:	39 78 58             	cmp    %edi,0x58(%eax)
80101bd9:	0f 82 ea 00 00 00    	jb     80101cc9 <writei+0x119>
    return -1;
  if(off + n > MAXFILE*BSIZE)
80101bdf:	8b 75 e0             	mov    -0x20(%ebp),%esi
80101be2:	89 f2                	mov    %esi,%edx
80101be4:	01 fa                	add    %edi,%edx
80101be6:	0f 82 dd 00 00 00    	jb     80101cc9 <writei+0x119>
80101bec:	81 fa 00 18 01 00    	cmp    $0x11800,%edx
80101bf2:	0f 87 d1 00 00 00    	ja     80101cc9 <writei+0x119>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101bf8:	85 f6                	test   %esi,%esi
80101bfa:	0f 84 85 00 00 00    	je     80101c85 <writei+0xd5>
80101c00:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
    m = min(n - tot, BSIZE - off%BSIZE);
80101c07:	89 45 d8             	mov    %eax,-0x28(%ebp)
80101c0a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101c10:	8b 75 d8             	mov    -0x28(%ebp),%esi
80101c13:	89 fa                	mov    %edi,%edx
80101c15:	c1 ea 09             	shr    $0x9,%edx
80101c18:	89 f0                	mov    %esi,%eax
80101c1a:	e8 51 f8 ff ff       	call   80101470 <bmap>
80101c1f:	83 ec 08             	sub    $0x8,%esp
80101c22:	50                   	push   %eax
80101c23:	ff 36                	push   (%esi)
80101c25:	e8 a6 e4 ff ff       	call   801000d0 <bread>
    m = min(n - tot, BSIZE - off%BSIZE);
80101c2a:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80101c2d:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80101c30:	b9 00 02 00 00       	mov    $0x200,%ecx
    bp = bread(ip->dev, bmap(ip, off/BSIZE));
80101c35:	89 c6                	mov    %eax,%esi
    m = min(n - tot, BSIZE - off%BSIZE);
80101c37:	89 f8                	mov    %edi,%eax
80101c39:	25 ff 01 00 00       	and    $0x1ff,%eax
80101c3e:	29 d3                	sub    %edx,%ebx
80101c40:	29 c1                	sub    %eax,%ecx
    memmove(bp->data + off%BSIZE, src, m);
80101c42:	8d 44 06 5c          	lea    0x5c(%esi,%eax,1),%eax
    m = min(n - tot, BSIZE - off%BSIZE);
80101c46:	39 d9                	cmp    %ebx,%ecx
80101c48:	0f 46 d9             	cmovbe %ecx,%ebx
    memmove(bp->data + off%BSIZE, src, m);
80101c4b:	83 c4 0c             	add    $0xc,%esp
80101c4e:	53                   	push   %ebx
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101c4f:	01 df                	add    %ebx,%edi
    memmove(bp->data + off%BSIZE, src, m);
80101c51:	ff 75 dc             	push   -0x24(%ebp)
80101c54:	50                   	push   %eax
80101c55:	e8 26 2c 00 00       	call   80104880 <memmove>
    log_write(bp);
80101c5a:	89 34 24             	mov    %esi,(%esp)
80101c5d:	e8 2e 13 00 00       	call   80102f90 <log_write>
    brelse(bp);
80101c62:	89 34 24             	mov    %esi,(%esp)
80101c65:	e8 86 e5 ff ff       	call   801001f0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
80101c6a:	01 5d e4             	add    %ebx,-0x1c(%ebp)
80101c6d:	8b 45 e4             	mov    -0x1c(%ebp),%eax
80101c70:	83 c4 10             	add    $0x10,%esp
80101c73:	01 5d dc             	add    %ebx,-0x24(%ebp)
80101c76:	8b 5d e0             	mov    -0x20(%ebp),%ebx
80101c79:	39 d8                	cmp    %ebx,%eax
80101c7b:	72 93                	jb     80101c10 <writei+0x60>
  }

  if(n > 0 && off > ip->size){
80101c7d:	8b 45 d8             	mov    -0x28(%ebp),%eax
80101c80:	39 78 58             	cmp    %edi,0x58(%eax)
80101c83:	72 33                	jb     80101cb8 <writei+0x108>
    ip->size = off;
    iupdate(ip);
  }
  return n;
80101c85:	8b 45 e0             	mov    -0x20(%ebp),%eax
}
80101c88:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101c8b:	5b                   	pop    %ebx
80101c8c:	5e                   	pop    %esi
80101c8d:	5f                   	pop    %edi
80101c8e:	5d                   	pop    %ebp
80101c8f:	c3                   	ret
    if(ip->major < 0 || ip->major >= NDEV || !devsw[ip->major].write)
80101c90:	0f bf 40 52          	movswl 0x52(%eax),%eax
80101c94:	66 83 f8 09          	cmp    $0x9,%ax
80101c98:	77 2f                	ja     80101cc9 <writei+0x119>
80101c9a:	8b 04 c5 04 09 11 80 	mov    -0x7feef6fc(,%eax,8),%eax
80101ca1:	85 c0                	test   %eax,%eax
80101ca3:	74 24                	je     80101cc9 <writei+0x119>
    return devsw[ip->major].write(ip, src, n);
80101ca5:	89 75 10             	mov    %esi,0x10(%ebp)
}
80101ca8:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101cab:	5b                   	pop    %ebx
80101cac:	5e                   	pop    %esi
80101cad:	5f                   	pop    %edi
80101cae:	5d                   	pop    %ebp
    return devsw[ip->major].write(ip, src, n);
80101caf:	ff e0                	jmp    *%eax
80101cb1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    iupdate(ip);
80101cb8:	83 ec 0c             	sub    $0xc,%esp
    ip->size = off;
80101cbb:	89 78 58             	mov    %edi,0x58(%eax)
    iupdate(ip);
80101cbe:	50                   	push   %eax
80101cbf:	e8 2c fa ff ff       	call   801016f0 <iupdate>
80101cc4:	83 c4 10             	add    $0x10,%esp
80101cc7:	eb bc                	jmp    80101c85 <writei+0xd5>
      return -1;
80101cc9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80101cce:	eb b8                	jmp    80101c88 <writei+0xd8>

80101cd0 <namecmp>:
//PAGEBREAK!
// Directories

int
namecmp(const char *s, const char *t)
{
80101cd0:	55                   	push   %ebp
80101cd1:	89 e5                	mov    %esp,%ebp
80101cd3:	83 ec 0c             	sub    $0xc,%esp
  return strncmp(s, t, DIRSIZ);
80101cd6:	6a 0e                	push   $0xe
80101cd8:	ff 75 0c             	push   0xc(%ebp)
80101cdb:	ff 75 08             	push   0x8(%ebp)
80101cde:	e8 0d 2c 00 00       	call   801048f0 <strncmp>
}
80101ce3:	c9                   	leave
80101ce4:	c3                   	ret
80101ce5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80101cec:	00 
80101ced:	8d 76 00             	lea    0x0(%esi),%esi

80101cf0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
80101cf0:	55                   	push   %ebp
80101cf1:	89 e5                	mov    %esp,%ebp
80101cf3:	57                   	push   %edi
80101cf4:	56                   	push   %esi
80101cf5:	53                   	push   %ebx
80101cf6:	83 ec 1c             	sub    $0x1c,%esp
80101cf9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
80101cfc:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80101d01:	0f 85 85 00 00 00    	jne    80101d8c <dirlookup+0x9c>
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
80101d07:	8b 53 58             	mov    0x58(%ebx),%edx
80101d0a:	31 ff                	xor    %edi,%edi
80101d0c:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101d0f:	85 d2                	test   %edx,%edx
80101d11:	74 3e                	je     80101d51 <dirlookup+0x61>
80101d13:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101d18:	6a 10                	push   $0x10
80101d1a:	57                   	push   %edi
80101d1b:	56                   	push   %esi
80101d1c:	53                   	push   %ebx
80101d1d:	e8 8e fd ff ff       	call   80101ab0 <readi>
80101d22:	83 c4 10             	add    $0x10,%esp
80101d25:	83 f8 10             	cmp    $0x10,%eax
80101d28:	75 55                	jne    80101d7f <dirlookup+0x8f>
      panic("dirlookup read");
    if(de.inum == 0)
80101d2a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
80101d2f:	74 18                	je     80101d49 <dirlookup+0x59>
  return strncmp(s, t, DIRSIZ);
80101d31:	83 ec 04             	sub    $0x4,%esp
80101d34:	8d 45 da             	lea    -0x26(%ebp),%eax
80101d37:	6a 0e                	push   $0xe
80101d39:	50                   	push   %eax
80101d3a:	ff 75 0c             	push   0xc(%ebp)
80101d3d:	e8 ae 2b 00 00       	call   801048f0 <strncmp>
      continue;
    if(namecmp(name, de.name) == 0){
80101d42:	83 c4 10             	add    $0x10,%esp
80101d45:	85 c0                	test   %eax,%eax
80101d47:	74 17                	je     80101d60 <dirlookup+0x70>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101d49:	83 c7 10             	add    $0x10,%edi
80101d4c:	3b 7b 58             	cmp    0x58(%ebx),%edi
80101d4f:	72 c7                	jb     80101d18 <dirlookup+0x28>
      return iget(dp->dev, inum);
    }
  }

  return 0;
}
80101d51:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80101d54:	31 c0                	xor    %eax,%eax
}
80101d56:	5b                   	pop    %ebx
80101d57:	5e                   	pop    %esi
80101d58:	5f                   	pop    %edi
80101d59:	5d                   	pop    %ebp
80101d5a:	c3                   	ret
80101d5b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(poff)
80101d60:	8b 45 10             	mov    0x10(%ebp),%eax
80101d63:	85 c0                	test   %eax,%eax
80101d65:	74 05                	je     80101d6c <dirlookup+0x7c>
        *poff = off;
80101d67:	8b 45 10             	mov    0x10(%ebp),%eax
80101d6a:	89 38                	mov    %edi,(%eax)
      inum = de.inum;
80101d6c:	0f b7 55 d8          	movzwl -0x28(%ebp),%edx
      return iget(dp->dev, inum);
80101d70:	8b 03                	mov    (%ebx),%eax
80101d72:	e8 79 f5 ff ff       	call   801012f0 <iget>
}
80101d77:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101d7a:	5b                   	pop    %ebx
80101d7b:	5e                   	pop    %esi
80101d7c:	5f                   	pop    %edi
80101d7d:	5d                   	pop    %ebp
80101d7e:	c3                   	ret
      panic("dirlookup read");
80101d7f:	83 ec 0c             	sub    $0xc,%esp
80101d82:	68 68 79 10 80       	push   $0x80107968
80101d87:	e8 f4 e5 ff ff       	call   80100380 <panic>
    panic("dirlookup not DIR");
80101d8c:	83 ec 0c             	sub    $0xc,%esp
80101d8f:	68 56 79 10 80       	push   $0x80107956
80101d94:	e8 e7 e5 ff ff       	call   80100380 <panic>
80101d99:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80101da0 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
80101da0:	55                   	push   %ebp
80101da1:	89 e5                	mov    %esp,%ebp
80101da3:	57                   	push   %edi
80101da4:	56                   	push   %esi
80101da5:	53                   	push   %ebx
80101da6:	89 c3                	mov    %eax,%ebx
80101da8:	83 ec 1c             	sub    $0x1c,%esp
  struct inode *ip, *next;

  if(*path == '/')
80101dab:	80 38 2f             	cmpb   $0x2f,(%eax)
{
80101dae:	89 55 dc             	mov    %edx,-0x24(%ebp)
80101db1:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
  if(*path == '/')
80101db4:	0f 84 9e 01 00 00    	je     80101f58 <namex+0x1b8>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
80101dba:	e8 31 1c 00 00       	call   801039f0 <myproc>
  acquire(&icache.lock);
80101dbf:	83 ec 0c             	sub    $0xc,%esp
    ip = idup(myproc()->cwd);
80101dc2:	8b 70 68             	mov    0x68(%eax),%esi
  acquire(&icache.lock);
80101dc5:	68 60 09 11 80       	push   $0x80110960
80101dca:	e8 21 29 00 00       	call   801046f0 <acquire>
  ip->ref++;
80101dcf:	83 46 08 01          	addl   $0x1,0x8(%esi)
  release(&icache.lock);
80101dd3:	c7 04 24 60 09 11 80 	movl   $0x80110960,(%esp)
80101dda:	e8 b1 28 00 00       	call   80104690 <release>
80101ddf:	83 c4 10             	add    $0x10,%esp
80101de2:	eb 07                	jmp    80101deb <namex+0x4b>
80101de4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    path++;
80101de8:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101deb:	0f b6 03             	movzbl (%ebx),%eax
80101dee:	3c 2f                	cmp    $0x2f,%al
80101df0:	74 f6                	je     80101de8 <namex+0x48>
  if(*path == 0)
80101df2:	84 c0                	test   %al,%al
80101df4:	0f 84 06 01 00 00    	je     80101f00 <namex+0x160>
  while(*path != '/' && *path != 0)
80101dfa:	0f b6 03             	movzbl (%ebx),%eax
80101dfd:	84 c0                	test   %al,%al
80101dff:	0f 84 10 01 00 00    	je     80101f15 <namex+0x175>
80101e05:	89 df                	mov    %ebx,%edi
80101e07:	3c 2f                	cmp    $0x2f,%al
80101e09:	0f 84 06 01 00 00    	je     80101f15 <namex+0x175>
80101e0f:	90                   	nop
80101e10:	0f b6 47 01          	movzbl 0x1(%edi),%eax
    path++;
80101e14:	83 c7 01             	add    $0x1,%edi
  while(*path != '/' && *path != 0)
80101e17:	3c 2f                	cmp    $0x2f,%al
80101e19:	74 04                	je     80101e1f <namex+0x7f>
80101e1b:	84 c0                	test   %al,%al
80101e1d:	75 f1                	jne    80101e10 <namex+0x70>
  len = path - s;
80101e1f:	89 f8                	mov    %edi,%eax
80101e21:	29 d8                	sub    %ebx,%eax
  if(len >= DIRSIZ)
80101e23:	83 f8 0d             	cmp    $0xd,%eax
80101e26:	0f 8e ac 00 00 00    	jle    80101ed8 <namex+0x138>
    memmove(name, s, DIRSIZ);
80101e2c:	83 ec 04             	sub    $0x4,%esp
80101e2f:	6a 0e                	push   $0xe
80101e31:	53                   	push   %ebx
80101e32:	89 fb                	mov    %edi,%ebx
80101e34:	ff 75 e4             	push   -0x1c(%ebp)
80101e37:	e8 44 2a 00 00       	call   80104880 <memmove>
80101e3c:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101e3f:	80 3f 2f             	cmpb   $0x2f,(%edi)
80101e42:	75 0c                	jne    80101e50 <namex+0xb0>
80101e44:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    path++;
80101e48:	83 c3 01             	add    $0x1,%ebx
  while(*path == '/')
80101e4b:	80 3b 2f             	cmpb   $0x2f,(%ebx)
80101e4e:	74 f8                	je     80101e48 <namex+0xa8>

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
80101e50:	83 ec 0c             	sub    $0xc,%esp
80101e53:	56                   	push   %esi
80101e54:	e8 47 f9 ff ff       	call   801017a0 <ilock>
    if(ip->type != T_DIR){
80101e59:	83 c4 10             	add    $0x10,%esp
80101e5c:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80101e61:	0f 85 b7 00 00 00    	jne    80101f1e <namex+0x17e>
      iunlockput(ip);
      return 0;
    }
    if(nameiparent && *path == '\0'){
80101e67:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101e6a:	85 c0                	test   %eax,%eax
80101e6c:	74 09                	je     80101e77 <namex+0xd7>
80101e6e:	80 3b 00             	cmpb   $0x0,(%ebx)
80101e71:	0f 84 f7 00 00 00    	je     80101f6e <namex+0x1ce>
      // Stop one level early.
      iunlock(ip);
      return ip;
    }
    if((next = dirlookup(ip, name, 0)) == 0){
80101e77:	83 ec 04             	sub    $0x4,%esp
80101e7a:	6a 00                	push   $0x0
80101e7c:	ff 75 e4             	push   -0x1c(%ebp)
80101e7f:	56                   	push   %esi
80101e80:	e8 6b fe ff ff       	call   80101cf0 <dirlookup>
80101e85:	83 c4 10             	add    $0x10,%esp
80101e88:	89 c7                	mov    %eax,%edi
80101e8a:	85 c0                	test   %eax,%eax
80101e8c:	0f 84 8c 00 00 00    	je     80101f1e <namex+0x17e>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101e92:	83 ec 0c             	sub    $0xc,%esp
80101e95:	8d 4e 0c             	lea    0xc(%esi),%ecx
80101e98:	51                   	push   %ecx
80101e99:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80101e9c:	e8 0f 26 00 00       	call   801044b0 <holdingsleep>
80101ea1:	83 c4 10             	add    $0x10,%esp
80101ea4:	85 c0                	test   %eax,%eax
80101ea6:	0f 84 02 01 00 00    	je     80101fae <namex+0x20e>
80101eac:	8b 56 08             	mov    0x8(%esi),%edx
80101eaf:	85 d2                	test   %edx,%edx
80101eb1:	0f 8e f7 00 00 00    	jle    80101fae <namex+0x20e>
  releasesleep(&ip->lock);
80101eb7:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80101eba:	83 ec 0c             	sub    $0xc,%esp
80101ebd:	51                   	push   %ecx
80101ebe:	e8 ad 25 00 00       	call   80104470 <releasesleep>
  iput(ip);
80101ec3:	89 34 24             	mov    %esi,(%esp)
      iunlockput(ip);
      return 0;
    }
    iunlockput(ip);
    ip = next;
80101ec6:	89 fe                	mov    %edi,%esi
  iput(ip);
80101ec8:	e8 03 fa ff ff       	call   801018d0 <iput>
80101ecd:	83 c4 10             	add    $0x10,%esp
  while(*path == '/')
80101ed0:	e9 16 ff ff ff       	jmp    80101deb <namex+0x4b>
80101ed5:	8d 76 00             	lea    0x0(%esi),%esi
    name[len] = 0;
80101ed8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80101edb:	8d 0c 02             	lea    (%edx,%eax,1),%ecx
    memmove(name, s, len);
80101ede:	83 ec 04             	sub    $0x4,%esp
80101ee1:	89 4d e0             	mov    %ecx,-0x20(%ebp)
80101ee4:	50                   	push   %eax
80101ee5:	53                   	push   %ebx
    name[len] = 0;
80101ee6:	89 fb                	mov    %edi,%ebx
    memmove(name, s, len);
80101ee8:	ff 75 e4             	push   -0x1c(%ebp)
80101eeb:	e8 90 29 00 00       	call   80104880 <memmove>
    name[len] = 0;
80101ef0:	8b 4d e0             	mov    -0x20(%ebp),%ecx
80101ef3:	83 c4 10             	add    $0x10,%esp
80101ef6:	c6 01 00             	movb   $0x0,(%ecx)
80101ef9:	e9 41 ff ff ff       	jmp    80101e3f <namex+0x9f>
80101efe:	66 90                	xchg   %ax,%ax
  }
  if(nameiparent){
80101f00:	8b 45 dc             	mov    -0x24(%ebp),%eax
80101f03:	85 c0                	test   %eax,%eax
80101f05:	0f 85 93 00 00 00    	jne    80101f9e <namex+0x1fe>
    iput(ip);
    return 0;
  }
  return ip;
}
80101f0b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101f0e:	89 f0                	mov    %esi,%eax
80101f10:	5b                   	pop    %ebx
80101f11:	5e                   	pop    %esi
80101f12:	5f                   	pop    %edi
80101f13:	5d                   	pop    %ebp
80101f14:	c3                   	ret
  while(*path != '/' && *path != 0)
80101f15:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80101f18:	89 df                	mov    %ebx,%edi
80101f1a:	31 c0                	xor    %eax,%eax
80101f1c:	eb c0                	jmp    80101ede <namex+0x13e>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101f1e:	83 ec 0c             	sub    $0xc,%esp
80101f21:	8d 5e 0c             	lea    0xc(%esi),%ebx
80101f24:	53                   	push   %ebx
80101f25:	e8 86 25 00 00       	call   801044b0 <holdingsleep>
80101f2a:	83 c4 10             	add    $0x10,%esp
80101f2d:	85 c0                	test   %eax,%eax
80101f2f:	74 7d                	je     80101fae <namex+0x20e>
80101f31:	8b 4e 08             	mov    0x8(%esi),%ecx
80101f34:	85 c9                	test   %ecx,%ecx
80101f36:	7e 76                	jle    80101fae <namex+0x20e>
  releasesleep(&ip->lock);
80101f38:	83 ec 0c             	sub    $0xc,%esp
80101f3b:	53                   	push   %ebx
80101f3c:	e8 2f 25 00 00       	call   80104470 <releasesleep>
  iput(ip);
80101f41:	89 34 24             	mov    %esi,(%esp)
      return 0;
80101f44:	31 f6                	xor    %esi,%esi
  iput(ip);
80101f46:	e8 85 f9 ff ff       	call   801018d0 <iput>
      return 0;
80101f4b:	83 c4 10             	add    $0x10,%esp
}
80101f4e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101f51:	89 f0                	mov    %esi,%eax
80101f53:	5b                   	pop    %ebx
80101f54:	5e                   	pop    %esi
80101f55:	5f                   	pop    %edi
80101f56:	5d                   	pop    %ebp
80101f57:	c3                   	ret
    ip = iget(ROOTDEV, ROOTINO);
80101f58:	ba 01 00 00 00       	mov    $0x1,%edx
80101f5d:	b8 01 00 00 00       	mov    $0x1,%eax
80101f62:	e8 89 f3 ff ff       	call   801012f0 <iget>
80101f67:	89 c6                	mov    %eax,%esi
80101f69:	e9 7d fe ff ff       	jmp    80101deb <namex+0x4b>
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
80101f6e:	83 ec 0c             	sub    $0xc,%esp
80101f71:	8d 5e 0c             	lea    0xc(%esi),%ebx
80101f74:	53                   	push   %ebx
80101f75:	e8 36 25 00 00       	call   801044b0 <holdingsleep>
80101f7a:	83 c4 10             	add    $0x10,%esp
80101f7d:	85 c0                	test   %eax,%eax
80101f7f:	74 2d                	je     80101fae <namex+0x20e>
80101f81:	8b 7e 08             	mov    0x8(%esi),%edi
80101f84:	85 ff                	test   %edi,%edi
80101f86:	7e 26                	jle    80101fae <namex+0x20e>
  releasesleep(&ip->lock);
80101f88:	83 ec 0c             	sub    $0xc,%esp
80101f8b:	53                   	push   %ebx
80101f8c:	e8 df 24 00 00       	call   80104470 <releasesleep>
}
80101f91:	83 c4 10             	add    $0x10,%esp
}
80101f94:	8d 65 f4             	lea    -0xc(%ebp),%esp
80101f97:	89 f0                	mov    %esi,%eax
80101f99:	5b                   	pop    %ebx
80101f9a:	5e                   	pop    %esi
80101f9b:	5f                   	pop    %edi
80101f9c:	5d                   	pop    %ebp
80101f9d:	c3                   	ret
    iput(ip);
80101f9e:	83 ec 0c             	sub    $0xc,%esp
80101fa1:	56                   	push   %esi
      return 0;
80101fa2:	31 f6                	xor    %esi,%esi
    iput(ip);
80101fa4:	e8 27 f9 ff ff       	call   801018d0 <iput>
    return 0;
80101fa9:	83 c4 10             	add    $0x10,%esp
80101fac:	eb a0                	jmp    80101f4e <namex+0x1ae>
    panic("iunlock");
80101fae:	83 ec 0c             	sub    $0xc,%esp
80101fb1:	68 4e 79 10 80       	push   $0x8010794e
80101fb6:	e8 c5 e3 ff ff       	call   80100380 <panic>
80101fbb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80101fc0 <dirlink>:
{
80101fc0:	55                   	push   %ebp
80101fc1:	89 e5                	mov    %esp,%ebp
80101fc3:	57                   	push   %edi
80101fc4:	56                   	push   %esi
80101fc5:	53                   	push   %ebx
80101fc6:	83 ec 20             	sub    $0x20,%esp
80101fc9:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if((ip = dirlookup(dp, name, 0)) != 0){
80101fcc:	6a 00                	push   $0x0
80101fce:	ff 75 0c             	push   0xc(%ebp)
80101fd1:	53                   	push   %ebx
80101fd2:	e8 19 fd ff ff       	call   80101cf0 <dirlookup>
80101fd7:	83 c4 10             	add    $0x10,%esp
80101fda:	85 c0                	test   %eax,%eax
80101fdc:	75 67                	jne    80102045 <dirlink+0x85>
  for(off = 0; off < dp->size; off += sizeof(de)){
80101fde:	8b 7b 58             	mov    0x58(%ebx),%edi
80101fe1:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101fe4:	85 ff                	test   %edi,%edi
80101fe6:	74 29                	je     80102011 <dirlink+0x51>
80101fe8:	31 ff                	xor    %edi,%edi
80101fea:	8d 75 d8             	lea    -0x28(%ebp),%esi
80101fed:	eb 09                	jmp    80101ff8 <dirlink+0x38>
80101fef:	90                   	nop
80101ff0:	83 c7 10             	add    $0x10,%edi
80101ff3:	3b 7b 58             	cmp    0x58(%ebx),%edi
80101ff6:	73 19                	jae    80102011 <dirlink+0x51>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80101ff8:	6a 10                	push   $0x10
80101ffa:	57                   	push   %edi
80101ffb:	56                   	push   %esi
80101ffc:	53                   	push   %ebx
80101ffd:	e8 ae fa ff ff       	call   80101ab0 <readi>
80102002:	83 c4 10             	add    $0x10,%esp
80102005:	83 f8 10             	cmp    $0x10,%eax
80102008:	75 4e                	jne    80102058 <dirlink+0x98>
    if(de.inum == 0)
8010200a:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
8010200f:	75 df                	jne    80101ff0 <dirlink+0x30>
  strncpy(de.name, name, DIRSIZ);
80102011:	83 ec 04             	sub    $0x4,%esp
80102014:	8d 45 da             	lea    -0x26(%ebp),%eax
80102017:	6a 0e                	push   $0xe
80102019:	ff 75 0c             	push   0xc(%ebp)
8010201c:	50                   	push   %eax
8010201d:	e8 1e 29 00 00       	call   80104940 <strncpy>
  de.inum = inum;
80102022:	8b 45 10             	mov    0x10(%ebp),%eax
80102025:	66 89 45 d8          	mov    %ax,-0x28(%ebp)
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80102029:	6a 10                	push   $0x10
8010202b:	57                   	push   %edi
8010202c:	56                   	push   %esi
8010202d:	53                   	push   %ebx
8010202e:	e8 7d fb ff ff       	call   80101bb0 <writei>
80102033:	83 c4 20             	add    $0x20,%esp
80102036:	83 f8 10             	cmp    $0x10,%eax
80102039:	75 2a                	jne    80102065 <dirlink+0xa5>
  return 0;
8010203b:	31 c0                	xor    %eax,%eax
}
8010203d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102040:	5b                   	pop    %ebx
80102041:	5e                   	pop    %esi
80102042:	5f                   	pop    %edi
80102043:	5d                   	pop    %ebp
80102044:	c3                   	ret
    iput(ip);
80102045:	83 ec 0c             	sub    $0xc,%esp
80102048:	50                   	push   %eax
80102049:	e8 82 f8 ff ff       	call   801018d0 <iput>
    return -1;
8010204e:	83 c4 10             	add    $0x10,%esp
80102051:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80102056:	eb e5                	jmp    8010203d <dirlink+0x7d>
      panic("dirlink read");
80102058:	83 ec 0c             	sub    $0xc,%esp
8010205b:	68 77 79 10 80       	push   $0x80107977
80102060:	e8 1b e3 ff ff       	call   80100380 <panic>
    panic("dirlink");
80102065:	83 ec 0c             	sub    $0xc,%esp
80102068:	68 d3 7b 10 80       	push   $0x80107bd3
8010206d:	e8 0e e3 ff ff       	call   80100380 <panic>
80102072:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102079:	00 
8010207a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80102080 <namei>:

struct inode*
namei(char *path)
{
80102080:	55                   	push   %ebp
  char name[DIRSIZ];
  return namex(path, 0, name);
80102081:	31 d2                	xor    %edx,%edx
{
80102083:	89 e5                	mov    %esp,%ebp
80102085:	83 ec 18             	sub    $0x18,%esp
  return namex(path, 0, name);
80102088:	8b 45 08             	mov    0x8(%ebp),%eax
8010208b:	8d 4d ea             	lea    -0x16(%ebp),%ecx
8010208e:	e8 0d fd ff ff       	call   80101da0 <namex>
}
80102093:	c9                   	leave
80102094:	c3                   	ret
80102095:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010209c:	00 
8010209d:	8d 76 00             	lea    0x0(%esi),%esi

801020a0 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
801020a0:	55                   	push   %ebp
  return namex(path, 1, name);
801020a1:	ba 01 00 00 00       	mov    $0x1,%edx
{
801020a6:	89 e5                	mov    %esp,%ebp
  return namex(path, 1, name);
801020a8:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801020ab:	8b 45 08             	mov    0x8(%ebp),%eax
}
801020ae:	5d                   	pop    %ebp
  return namex(path, 1, name);
801020af:	e9 ec fc ff ff       	jmp    80101da0 <namex>
801020b4:	66 90                	xchg   %ax,%ax
801020b6:	66 90                	xchg   %ax,%ax
801020b8:	66 90                	xchg   %ax,%ax
801020ba:	66 90                	xchg   %ax,%ax
801020bc:	66 90                	xchg   %ax,%ax
801020be:	66 90                	xchg   %ax,%ax

801020c0 <idestart>:
}

// Start the request for b.  Caller must hold idelock.
static void
idestart(struct buf *b)
{
801020c0:	55                   	push   %ebp
801020c1:	89 e5                	mov    %esp,%ebp
801020c3:	57                   	push   %edi
801020c4:	56                   	push   %esi
801020c5:	53                   	push   %ebx
801020c6:	83 ec 0c             	sub    $0xc,%esp
  if(b == 0)
801020c9:	85 c0                	test   %eax,%eax
801020cb:	0f 84 b4 00 00 00    	je     80102185 <idestart+0xc5>
    panic("idestart");
  if(b->blockno >= FSSIZE)
801020d1:	8b 70 08             	mov    0x8(%eax),%esi
801020d4:	89 c3                	mov    %eax,%ebx
801020d6:	81 fe e7 03 00 00    	cmp    $0x3e7,%esi
801020dc:	0f 87 96 00 00 00    	ja     80102178 <idestart+0xb8>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801020e2:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
801020e7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801020ee:	00 
801020ef:	90                   	nop
801020f0:	89 ca                	mov    %ecx,%edx
801020f2:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
801020f3:	83 e0 c0             	and    $0xffffffc0,%eax
801020f6:	3c 40                	cmp    $0x40,%al
801020f8:	75 f6                	jne    801020f0 <idestart+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801020fa:	31 ff                	xor    %edi,%edi
801020fc:	ba f6 03 00 00       	mov    $0x3f6,%edx
80102101:	89 f8                	mov    %edi,%eax
80102103:	ee                   	out    %al,(%dx)
80102104:	b8 01 00 00 00       	mov    $0x1,%eax
80102109:	ba f2 01 00 00       	mov    $0x1f2,%edx
8010210e:	ee                   	out    %al,(%dx)
8010210f:	ba f3 01 00 00       	mov    $0x1f3,%edx
80102114:	89 f0                	mov    %esi,%eax
80102116:	ee                   	out    %al,(%dx)

  idewait(0);
  outb(0x3f6, 0);  // generate interrupt
  outb(0x1f2, sector_per_block);  // number of sectors
  outb(0x1f3, sector & 0xff);
  outb(0x1f4, (sector >> 8) & 0xff);
80102117:	89 f0                	mov    %esi,%eax
80102119:	ba f4 01 00 00       	mov    $0x1f4,%edx
8010211e:	c1 f8 08             	sar    $0x8,%eax
80102121:	ee                   	out    %al,(%dx)
80102122:	ba f5 01 00 00       	mov    $0x1f5,%edx
80102127:	89 f8                	mov    %edi,%eax
80102129:	ee                   	out    %al,(%dx)
  outb(0x1f5, (sector >> 16) & 0xff);
  outb(0x1f6, 0xe0 | ((b->dev&1)<<4) | ((sector>>24)&0x0f));
8010212a:	0f b6 43 04          	movzbl 0x4(%ebx),%eax
8010212e:	ba f6 01 00 00       	mov    $0x1f6,%edx
80102133:	c1 e0 04             	shl    $0x4,%eax
80102136:	83 e0 10             	and    $0x10,%eax
80102139:	83 c8 e0             	or     $0xffffffe0,%eax
8010213c:	ee                   	out    %al,(%dx)
  if(b->flags & B_DIRTY){
8010213d:	f6 03 04             	testb  $0x4,(%ebx)
80102140:	75 16                	jne    80102158 <idestart+0x98>
80102142:	b8 20 00 00 00       	mov    $0x20,%eax
80102147:	89 ca                	mov    %ecx,%edx
80102149:	ee                   	out    %al,(%dx)
    outb(0x1f7, write_cmd);
    outsl(0x1f0, b->data, BSIZE/4);
  } else {
    outb(0x1f7, read_cmd);
  }
}
8010214a:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010214d:	5b                   	pop    %ebx
8010214e:	5e                   	pop    %esi
8010214f:	5f                   	pop    %edi
80102150:	5d                   	pop    %ebp
80102151:	c3                   	ret
80102152:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80102158:	b8 30 00 00 00       	mov    $0x30,%eax
8010215d:	89 ca                	mov    %ecx,%edx
8010215f:	ee                   	out    %al,(%dx)
  asm volatile("cld; rep outsl" :
80102160:	b9 80 00 00 00       	mov    $0x80,%ecx
    outsl(0x1f0, b->data, BSIZE/4);
80102165:	8d 73 5c             	lea    0x5c(%ebx),%esi
80102168:	ba f0 01 00 00       	mov    $0x1f0,%edx
8010216d:	fc                   	cld
8010216e:	f3 6f                	rep outsl %ds:(%esi),(%dx)
}
80102170:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102173:	5b                   	pop    %ebx
80102174:	5e                   	pop    %esi
80102175:	5f                   	pop    %edi
80102176:	5d                   	pop    %ebp
80102177:	c3                   	ret
    panic("incorrect blockno");
80102178:	83 ec 0c             	sub    $0xc,%esp
8010217b:	68 8d 79 10 80       	push   $0x8010798d
80102180:	e8 fb e1 ff ff       	call   80100380 <panic>
    panic("idestart");
80102185:	83 ec 0c             	sub    $0xc,%esp
80102188:	68 84 79 10 80       	push   $0x80107984
8010218d:	e8 ee e1 ff ff       	call   80100380 <panic>
80102192:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102199:	00 
8010219a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801021a0 <ideinit>:
{
801021a0:	55                   	push   %ebp
801021a1:	89 e5                	mov    %esp,%ebp
801021a3:	83 ec 10             	sub    $0x10,%esp
  initlock(&idelock, "ide");
801021a6:	68 9f 79 10 80       	push   $0x8010799f
801021ab:	68 00 26 11 80       	push   $0x80112600
801021b0:	e8 4b 23 00 00       	call   80104500 <initlock>
  ioapicenable(IRQ_IDE, ncpu - 1);
801021b5:	58                   	pop    %eax
801021b6:	a1 a4 27 11 80       	mov    0x801127a4,%eax
801021bb:	5a                   	pop    %edx
801021bc:	83 e8 01             	sub    $0x1,%eax
801021bf:	50                   	push   %eax
801021c0:	6a 0e                	push   $0xe
801021c2:	e8 99 02 00 00       	call   80102460 <ioapicenable>
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
801021c7:	83 c4 10             	add    $0x10,%esp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801021ca:	b9 f7 01 00 00       	mov    $0x1f7,%ecx
801021cf:	90                   	nop
801021d0:	89 ca                	mov    %ecx,%edx
801021d2:	ec                   	in     (%dx),%al
801021d3:	83 e0 c0             	and    $0xffffffc0,%eax
801021d6:	3c 40                	cmp    $0x40,%al
801021d8:	75 f6                	jne    801021d0 <ideinit+0x30>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
801021da:	b8 f0 ff ff ff       	mov    $0xfffffff0,%eax
801021df:	ba f6 01 00 00       	mov    $0x1f6,%edx
801021e4:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
801021e5:	89 ca                	mov    %ecx,%edx
801021e7:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
801021e8:	84 c0                	test   %al,%al
801021ea:	75 1e                	jne    8010220a <ideinit+0x6a>
801021ec:	b9 e8 03 00 00       	mov    $0x3e8,%ecx
801021f1:	ba f7 01 00 00       	mov    $0x1f7,%edx
801021f6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801021fd:	00 
801021fe:	66 90                	xchg   %ax,%ax
  for(i=0; i<1000; i++){
80102200:	83 e9 01             	sub    $0x1,%ecx
80102203:	74 0f                	je     80102214 <ideinit+0x74>
80102205:	ec                   	in     (%dx),%al
    if(inb(0x1f7) != 0){
80102206:	84 c0                	test   %al,%al
80102208:	74 f6                	je     80102200 <ideinit+0x60>
      havedisk1 = 1;
8010220a:	c7 05 e0 25 11 80 01 	movl   $0x1,0x801125e0
80102211:	00 00 00 
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102214:	b8 e0 ff ff ff       	mov    $0xffffffe0,%eax
80102219:	ba f6 01 00 00       	mov    $0x1f6,%edx
8010221e:	ee                   	out    %al,(%dx)
}
8010221f:	c9                   	leave
80102220:	c3                   	ret
80102221:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102228:	00 
80102229:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102230 <ideintr>:

// Interrupt handler.
void
ideintr(void)
{
80102230:	55                   	push   %ebp
80102231:	89 e5                	mov    %esp,%ebp
80102233:	57                   	push   %edi
80102234:	56                   	push   %esi
80102235:	53                   	push   %ebx
80102236:	83 ec 18             	sub    $0x18,%esp
  struct buf *b;

  // First queued buffer is the active request.
  acquire(&idelock);
80102239:	68 00 26 11 80       	push   $0x80112600
8010223e:	e8 ad 24 00 00       	call   801046f0 <acquire>

  if((b = idequeue) == 0){
80102243:	8b 1d e4 25 11 80    	mov    0x801125e4,%ebx
80102249:	83 c4 10             	add    $0x10,%esp
8010224c:	85 db                	test   %ebx,%ebx
8010224e:	74 63                	je     801022b3 <ideintr+0x83>
    release(&idelock);
    return;
  }
  idequeue = b->qnext;
80102250:	8b 43 58             	mov    0x58(%ebx),%eax
80102253:	a3 e4 25 11 80       	mov    %eax,0x801125e4

  // Read data if needed.
  if(!(b->flags & B_DIRTY) && idewait(1) >= 0)
80102258:	8b 33                	mov    (%ebx),%esi
8010225a:	f7 c6 04 00 00 00    	test   $0x4,%esi
80102260:	75 2f                	jne    80102291 <ideintr+0x61>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102262:	ba f7 01 00 00       	mov    $0x1f7,%edx
80102267:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010226e:	00 
8010226f:	90                   	nop
80102270:	ec                   	in     (%dx),%al
  while(((r = inb(0x1f7)) & (IDE_BSY|IDE_DRDY)) != IDE_DRDY)
80102271:	89 c1                	mov    %eax,%ecx
80102273:	83 e1 c0             	and    $0xffffffc0,%ecx
80102276:	80 f9 40             	cmp    $0x40,%cl
80102279:	75 f5                	jne    80102270 <ideintr+0x40>
  if(checkerr && (r & (IDE_DF|IDE_ERR)) != 0)
8010227b:	a8 21                	test   $0x21,%al
8010227d:	75 12                	jne    80102291 <ideintr+0x61>
    insl(0x1f0, b->data, BSIZE/4);
8010227f:	8d 7b 5c             	lea    0x5c(%ebx),%edi
  asm volatile("cld; rep insl" :
80102282:	b9 80 00 00 00       	mov    $0x80,%ecx
80102287:	ba f0 01 00 00       	mov    $0x1f0,%edx
8010228c:	fc                   	cld
8010228d:	f3 6d                	rep insl (%dx),%es:(%edi)

  // Wake process waiting for this buf.
  b->flags |= B_VALID;
8010228f:	8b 33                	mov    (%ebx),%esi
  b->flags &= ~B_DIRTY;
80102291:	83 e6 fb             	and    $0xfffffffb,%esi
  wakeup(b);
80102294:	83 ec 0c             	sub    $0xc,%esp
  b->flags &= ~B_DIRTY;
80102297:	83 ce 02             	or     $0x2,%esi
8010229a:	89 33                	mov    %esi,(%ebx)
  wakeup(b);
8010229c:	53                   	push   %ebx
8010229d:	e8 0e 1f 00 00       	call   801041b0 <wakeup>

  // Start disk on next buf in queue.
  if(idequeue != 0)
801022a2:	a1 e4 25 11 80       	mov    0x801125e4,%eax
801022a7:	83 c4 10             	add    $0x10,%esp
801022aa:	85 c0                	test   %eax,%eax
801022ac:	74 05                	je     801022b3 <ideintr+0x83>
    idestart(idequeue);
801022ae:	e8 0d fe ff ff       	call   801020c0 <idestart>
    release(&idelock);
801022b3:	83 ec 0c             	sub    $0xc,%esp
801022b6:	68 00 26 11 80       	push   $0x80112600
801022bb:	e8 d0 23 00 00       	call   80104690 <release>

  release(&idelock);
}
801022c0:	8d 65 f4             	lea    -0xc(%ebp),%esp
801022c3:	5b                   	pop    %ebx
801022c4:	5e                   	pop    %esi
801022c5:	5f                   	pop    %edi
801022c6:	5d                   	pop    %ebp
801022c7:	c3                   	ret
801022c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801022cf:	00 

801022d0 <iderw>:
// Sync buf with disk.
// If B_DIRTY is set, write buf to disk, clear B_DIRTY, set B_VALID.
// Else if B_VALID is not set, read buf from disk, set B_VALID.
void
iderw(struct buf *b)
{
801022d0:	55                   	push   %ebp
801022d1:	89 e5                	mov    %esp,%ebp
801022d3:	53                   	push   %ebx
801022d4:	83 ec 10             	sub    $0x10,%esp
801022d7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct buf **pp;

  if(!holdingsleep(&b->lock))
801022da:	8d 43 0c             	lea    0xc(%ebx),%eax
801022dd:	50                   	push   %eax
801022de:	e8 cd 21 00 00       	call   801044b0 <holdingsleep>
801022e3:	83 c4 10             	add    $0x10,%esp
801022e6:	85 c0                	test   %eax,%eax
801022e8:	0f 84 c3 00 00 00    	je     801023b1 <iderw+0xe1>
    panic("iderw: buf not locked");
  if((b->flags & (B_VALID|B_DIRTY)) == B_VALID)
801022ee:	8b 03                	mov    (%ebx),%eax
801022f0:	83 e0 06             	and    $0x6,%eax
801022f3:	83 f8 02             	cmp    $0x2,%eax
801022f6:	0f 84 a8 00 00 00    	je     801023a4 <iderw+0xd4>
    panic("iderw: nothing to do");
  if(b->dev != 0 && !havedisk1)
801022fc:	8b 53 04             	mov    0x4(%ebx),%edx
801022ff:	85 d2                	test   %edx,%edx
80102301:	74 0d                	je     80102310 <iderw+0x40>
80102303:	a1 e0 25 11 80       	mov    0x801125e0,%eax
80102308:	85 c0                	test   %eax,%eax
8010230a:	0f 84 87 00 00 00    	je     80102397 <iderw+0xc7>
    panic("iderw: ide disk 1 not present");

  acquire(&idelock);  //DOC:acquire-lock
80102310:	83 ec 0c             	sub    $0xc,%esp
80102313:	68 00 26 11 80       	push   $0x80112600
80102318:	e8 d3 23 00 00       	call   801046f0 <acquire>

  // Append b to idequeue.
  b->qnext = 0;
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
8010231d:	a1 e4 25 11 80       	mov    0x801125e4,%eax
  b->qnext = 0;
80102322:	c7 43 58 00 00 00 00 	movl   $0x0,0x58(%ebx)
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102329:	83 c4 10             	add    $0x10,%esp
8010232c:	85 c0                	test   %eax,%eax
8010232e:	74 60                	je     80102390 <iderw+0xc0>
80102330:	89 c2                	mov    %eax,%edx
80102332:	8b 40 58             	mov    0x58(%eax),%eax
80102335:	85 c0                	test   %eax,%eax
80102337:	75 f7                	jne    80102330 <iderw+0x60>
80102339:	83 c2 58             	add    $0x58,%edx
    ;
  *pp = b;
8010233c:	89 1a                	mov    %ebx,(%edx)

  // Start disk if necessary.
  if(idequeue == b)
8010233e:	39 1d e4 25 11 80    	cmp    %ebx,0x801125e4
80102344:	74 3a                	je     80102380 <iderw+0xb0>
    idestart(b);

  // Wait for request to finish.
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
80102346:	8b 03                	mov    (%ebx),%eax
80102348:	83 e0 06             	and    $0x6,%eax
8010234b:	83 f8 02             	cmp    $0x2,%eax
8010234e:	74 1b                	je     8010236b <iderw+0x9b>
    sleep(b, &idelock);
80102350:	83 ec 08             	sub    $0x8,%esp
80102353:	68 00 26 11 80       	push   $0x80112600
80102358:	53                   	push   %ebx
80102359:	e8 92 1d 00 00       	call   801040f0 <sleep>
  while((b->flags & (B_VALID|B_DIRTY)) != B_VALID){
8010235e:	8b 03                	mov    (%ebx),%eax
80102360:	83 c4 10             	add    $0x10,%esp
80102363:	83 e0 06             	and    $0x6,%eax
80102366:	83 f8 02             	cmp    $0x2,%eax
80102369:	75 e5                	jne    80102350 <iderw+0x80>
  }


  release(&idelock);
8010236b:	c7 45 08 00 26 11 80 	movl   $0x80112600,0x8(%ebp)
}
80102372:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102375:	c9                   	leave
  release(&idelock);
80102376:	e9 15 23 00 00       	jmp    80104690 <release>
8010237b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    idestart(b);
80102380:	89 d8                	mov    %ebx,%eax
80102382:	e8 39 fd ff ff       	call   801020c0 <idestart>
80102387:	eb bd                	jmp    80102346 <iderw+0x76>
80102389:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  for(pp=&idequeue; *pp; pp=&(*pp)->qnext)  //DOC:insert-queue
80102390:	ba e4 25 11 80       	mov    $0x801125e4,%edx
80102395:	eb a5                	jmp    8010233c <iderw+0x6c>
    panic("iderw: ide disk 1 not present");
80102397:	83 ec 0c             	sub    $0xc,%esp
8010239a:	68 ce 79 10 80       	push   $0x801079ce
8010239f:	e8 dc df ff ff       	call   80100380 <panic>
    panic("iderw: nothing to do");
801023a4:	83 ec 0c             	sub    $0xc,%esp
801023a7:	68 b9 79 10 80       	push   $0x801079b9
801023ac:	e8 cf df ff ff       	call   80100380 <panic>
    panic("iderw: buf not locked");
801023b1:	83 ec 0c             	sub    $0xc,%esp
801023b4:	68 a3 79 10 80       	push   $0x801079a3
801023b9:	e8 c2 df ff ff       	call   80100380 <panic>
801023be:	66 90                	xchg   %ax,%ax

801023c0 <ioapicinit>:
  ioapic->data = data;
}

void
ioapicinit(void)
{
801023c0:	55                   	push   %ebp
801023c1:	89 e5                	mov    %esp,%ebp
801023c3:	56                   	push   %esi
801023c4:	53                   	push   %ebx
  int i, id, maxintr;

  ioapic = (volatile struct ioapic*)IOAPIC;
801023c5:	c7 05 34 26 11 80 00 	movl   $0xfec00000,0x80112634
801023cc:	00 c0 fe 
  ioapic->reg = reg;
801023cf:	c7 05 00 00 c0 fe 01 	movl   $0x1,0xfec00000
801023d6:	00 00 00 
  return ioapic->data;
801023d9:	8b 15 34 26 11 80    	mov    0x80112634,%edx
801023df:	8b 72 10             	mov    0x10(%edx),%esi
  ioapic->reg = reg;
801023e2:	c7 02 00 00 00 00    	movl   $0x0,(%edx)
  return ioapic->data;
801023e8:	8b 1d 34 26 11 80    	mov    0x80112634,%ebx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
  id = ioapicread(REG_ID) >> 24;
  if(id != ioapicid)
801023ee:	0f b6 15 a0 27 11 80 	movzbl 0x801127a0,%edx
  maxintr = (ioapicread(REG_VER) >> 16) & 0xFF;
801023f5:	c1 ee 10             	shr    $0x10,%esi
801023f8:	89 f0                	mov    %esi,%eax
801023fa:	0f b6 f0             	movzbl %al,%esi
  return ioapic->data;
801023fd:	8b 43 10             	mov    0x10(%ebx),%eax
  id = ioapicread(REG_ID) >> 24;
80102400:	c1 e8 18             	shr    $0x18,%eax
  if(id != ioapicid)
80102403:	39 c2                	cmp    %eax,%edx
80102405:	74 16                	je     8010241d <ioapicinit+0x5d>
    cprintf("ioapicinit: id isn't equal to ioapicid; not a MP\n");
80102407:	83 ec 0c             	sub    $0xc,%esp
8010240a:	68 b4 7d 10 80       	push   $0x80107db4
8010240f:	e8 9c e2 ff ff       	call   801006b0 <cprintf>
  ioapic->reg = reg;
80102414:	8b 1d 34 26 11 80    	mov    0x80112634,%ebx
8010241a:	83 c4 10             	add    $0x10,%esp
{
8010241d:	ba 10 00 00 00       	mov    $0x10,%edx
80102422:	31 c0                	xor    %eax,%eax
80102424:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  ioapic->reg = reg;
80102428:	89 13                	mov    %edx,(%ebx)
8010242a:	8d 48 20             	lea    0x20(%eax),%ecx
  ioapic->data = data;
8010242d:	8b 1d 34 26 11 80    	mov    0x80112634,%ebx

  // Mark all interrupts edge-triggered, active high, disabled,
  // and not routed to any CPUs.
  for(i = 0; i <= maxintr; i++){
80102433:	83 c0 01             	add    $0x1,%eax
80102436:	81 c9 00 00 01 00    	or     $0x10000,%ecx
  ioapic->data = data;
8010243c:	89 4b 10             	mov    %ecx,0x10(%ebx)
  ioapic->reg = reg;
8010243f:	8d 4a 01             	lea    0x1(%edx),%ecx
  for(i = 0; i <= maxintr; i++){
80102442:	83 c2 02             	add    $0x2,%edx
  ioapic->reg = reg;
80102445:	89 0b                	mov    %ecx,(%ebx)
  ioapic->data = data;
80102447:	8b 1d 34 26 11 80    	mov    0x80112634,%ebx
8010244d:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
  for(i = 0; i <= maxintr; i++){
80102454:	39 c6                	cmp    %eax,%esi
80102456:	7d d0                	jge    80102428 <ioapicinit+0x68>
    ioapicwrite(REG_TABLE+2*i, INT_DISABLED | (T_IRQ0 + i));
    ioapicwrite(REG_TABLE+2*i+1, 0);
  }
}
80102458:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010245b:	5b                   	pop    %ebx
8010245c:	5e                   	pop    %esi
8010245d:	5d                   	pop    %ebp
8010245e:	c3                   	ret
8010245f:	90                   	nop

80102460 <ioapicenable>:

void
ioapicenable(int irq, int cpunum)
{
80102460:	55                   	push   %ebp
  ioapic->reg = reg;
80102461:	8b 0d 34 26 11 80    	mov    0x80112634,%ecx
{
80102467:	89 e5                	mov    %esp,%ebp
80102469:	8b 45 08             	mov    0x8(%ebp),%eax
  // Mark interrupt edge-triggered, active high,
  // enabled, and routed to the given cpunum,
  // which happens to be that cpu's APIC ID.
  ioapicwrite(REG_TABLE+2*irq, T_IRQ0 + irq);
8010246c:	8d 50 20             	lea    0x20(%eax),%edx
8010246f:	8d 44 00 10          	lea    0x10(%eax,%eax,1),%eax
  ioapic->reg = reg;
80102473:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102475:	8b 0d 34 26 11 80    	mov    0x80112634,%ecx
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010247b:	83 c0 01             	add    $0x1,%eax
  ioapic->data = data;
8010247e:	89 51 10             	mov    %edx,0x10(%ecx)
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
80102481:	8b 55 0c             	mov    0xc(%ebp),%edx
  ioapic->reg = reg;
80102484:	89 01                	mov    %eax,(%ecx)
  ioapic->data = data;
80102486:	a1 34 26 11 80       	mov    0x80112634,%eax
  ioapicwrite(REG_TABLE+2*irq+1, cpunum << 24);
8010248b:	c1 e2 18             	shl    $0x18,%edx
  ioapic->data = data;
8010248e:	89 50 10             	mov    %edx,0x10(%eax)
}
80102491:	5d                   	pop    %ebp
80102492:	c3                   	ret
80102493:	66 90                	xchg   %ax,%ax
80102495:	66 90                	xchg   %ax,%ax
80102497:	66 90                	xchg   %ax,%ax
80102499:	66 90                	xchg   %ax,%ax
8010249b:	66 90                	xchg   %ax,%ax
8010249d:	66 90                	xchg   %ax,%ax
8010249f:	90                   	nop

801024a0 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
801024a0:	55                   	push   %ebp
801024a1:	89 e5                	mov    %esp,%ebp
801024a3:	53                   	push   %ebx
801024a4:	83 ec 04             	sub    $0x4,%esp
801024a7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
801024aa:	f7 c3 ff 0f 00 00    	test   $0xfff,%ebx
801024b0:	0f 85 82 00 00 00    	jne    80102538 <kfree+0x98>
801024b6:	81 fb 80 68 11 80    	cmp    $0x80116880,%ebx
801024bc:	72 7a                	jb     80102538 <kfree+0x98>
801024be:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
801024c4:	3d ff ff ff 0d       	cmp    $0xdffffff,%eax
801024c9:	77 6d                	ja     80102538 <kfree+0x98>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);
801024cb:	83 ec 04             	sub    $0x4,%esp
801024ce:	68 00 10 00 00       	push   $0x1000
801024d3:	6a 01                	push   $0x1
801024d5:	53                   	push   %ebx
801024d6:	e8 15 23 00 00       	call   801047f0 <memset>

  if(kmem.use_lock)
801024db:	8b 15 94 26 11 80    	mov    0x80112694,%edx
801024e1:	83 c4 10             	add    $0x10,%esp
801024e4:	85 d2                	test   %edx,%edx
801024e6:	75 28                	jne    80102510 <kfree+0x70>
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
801024e8:	a1 98 26 11 80       	mov    0x80112698,%eax
801024ed:	89 03                	mov    %eax,(%ebx)
  kmem.freelist = r;
  free_pages_count++;
  if(kmem.use_lock)
801024ef:	a1 94 26 11 80       	mov    0x80112694,%eax
  free_pages_count++;
801024f4:	83 05 40 26 11 80 01 	addl   $0x1,0x80112640
  kmem.freelist = r;
801024fb:	89 1d 98 26 11 80    	mov    %ebx,0x80112698
  if(kmem.use_lock)
80102501:	85 c0                	test   %eax,%eax
80102503:	75 23                	jne    80102528 <kfree+0x88>
    release(&kmem.lock);
}
80102505:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102508:	c9                   	leave
80102509:	c3                   	ret
8010250a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    acquire(&kmem.lock);
80102510:	83 ec 0c             	sub    $0xc,%esp
80102513:	68 60 26 11 80       	push   $0x80112660
80102518:	e8 d3 21 00 00       	call   801046f0 <acquire>
8010251d:	83 c4 10             	add    $0x10,%esp
80102520:	eb c6                	jmp    801024e8 <kfree+0x48>
80102522:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    release(&kmem.lock);
80102528:	c7 45 08 60 26 11 80 	movl   $0x80112660,0x8(%ebp)
}
8010252f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102532:	c9                   	leave
    release(&kmem.lock);
80102533:	e9 58 21 00 00       	jmp    80104690 <release>
    panic("kfree");
80102538:	83 ec 0c             	sub    $0xc,%esp
8010253b:	68 ec 79 10 80       	push   $0x801079ec
80102540:	e8 3b de ff ff       	call   80100380 <panic>
80102545:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010254c:	00 
8010254d:	8d 76 00             	lea    0x0(%esi),%esi

80102550 <freerange>:
{
80102550:	55                   	push   %ebp
80102551:	89 e5                	mov    %esp,%ebp
80102553:	56                   	push   %esi
80102554:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
80102555:	8b 45 08             	mov    0x8(%ebp),%eax
{
80102558:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
8010255b:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102561:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102567:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010256d:	39 de                	cmp    %ebx,%esi
8010256f:	72 23                	jb     80102594 <freerange+0x44>
80102571:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    kfree(p);
80102578:	83 ec 0c             	sub    $0xc,%esp
8010257b:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102581:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
80102587:	50                   	push   %eax
80102588:	e8 13 ff ff ff       	call   801024a0 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
8010258d:	83 c4 10             	add    $0x10,%esp
80102590:	39 de                	cmp    %ebx,%esi
80102592:	73 e4                	jae    80102578 <freerange+0x28>
}
80102594:	8d 65 f8             	lea    -0x8(%ebp),%esp
80102597:	5b                   	pop    %ebx
80102598:	5e                   	pop    %esi
80102599:	5d                   	pop    %ebp
8010259a:	c3                   	ret
8010259b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801025a0 <kinit2>:
{
801025a0:	55                   	push   %ebp
801025a1:	89 e5                	mov    %esp,%ebp
801025a3:	56                   	push   %esi
801025a4:	53                   	push   %ebx
  p = (char*)PGROUNDUP((uint)vstart);
801025a5:	8b 45 08             	mov    0x8(%ebp),%eax
{
801025a8:	8b 75 0c             	mov    0xc(%ebp),%esi
  p = (char*)PGROUNDUP((uint)vstart);
801025ab:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
801025b1:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801025b7:	81 c3 00 10 00 00    	add    $0x1000,%ebx
801025bd:	39 de                	cmp    %ebx,%esi
801025bf:	72 23                	jb     801025e4 <kinit2+0x44>
801025c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    kfree(p);
801025c8:	83 ec 0c             	sub    $0xc,%esp
801025cb:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801025d1:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
801025d7:	50                   	push   %eax
801025d8:	e8 c3 fe ff ff       	call   801024a0 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
801025dd:	83 c4 10             	add    $0x10,%esp
801025e0:	39 de                	cmp    %ebx,%esi
801025e2:	73 e4                	jae    801025c8 <kinit2+0x28>
  kmem.use_lock = 1;
801025e4:	c7 05 94 26 11 80 01 	movl   $0x1,0x80112694
801025eb:	00 00 00 
}
801025ee:	8d 65 f8             	lea    -0x8(%ebp),%esp
801025f1:	5b                   	pop    %ebx
801025f2:	5e                   	pop    %esi
801025f3:	5d                   	pop    %ebp
801025f4:	c3                   	ret
801025f5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801025fc:	00 
801025fd:	8d 76 00             	lea    0x0(%esi),%esi

80102600 <kinit1>:
{
80102600:	55                   	push   %ebp
80102601:	89 e5                	mov    %esp,%ebp
80102603:	56                   	push   %esi
80102604:	53                   	push   %ebx
80102605:	8b 75 0c             	mov    0xc(%ebp),%esi
  initlock(&kmem.lock, "kmem");
80102608:	83 ec 08             	sub    $0x8,%esp
8010260b:	68 f2 79 10 80       	push   $0x801079f2
80102610:	68 60 26 11 80       	push   $0x80112660
80102615:	e8 e6 1e 00 00       	call   80104500 <initlock>
  p = (char*)PGROUNDUP((uint)vstart);
8010261a:	8b 45 08             	mov    0x8(%ebp),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
8010261d:	83 c4 10             	add    $0x10,%esp
  kmem.use_lock = 0;
80102620:	c7 05 94 26 11 80 00 	movl   $0x0,0x80112694
80102627:	00 00 00 
  p = (char*)PGROUNDUP((uint)vstart);
8010262a:	8d 98 ff 0f 00 00    	lea    0xfff(%eax),%ebx
80102630:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102636:	81 c3 00 10 00 00    	add    $0x1000,%ebx
8010263c:	39 de                	cmp    %ebx,%esi
8010263e:	72 1c                	jb     8010265c <kinit1+0x5c>
    kfree(p);
80102640:	83 ec 0c             	sub    $0xc,%esp
80102643:	8d 83 00 f0 ff ff    	lea    -0x1000(%ebx),%eax
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102649:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    kfree(p);
8010264f:	50                   	push   %eax
80102650:	e8 4b fe ff ff       	call   801024a0 <kfree>
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
80102655:	83 c4 10             	add    $0x10,%esp
80102658:	39 de                	cmp    %ebx,%esi
8010265a:	73 e4                	jae    80102640 <kinit1+0x40>
}
8010265c:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010265f:	5b                   	pop    %ebx
80102660:	5e                   	pop    %esi
80102661:	5d                   	pop    %ebp
80102662:	c3                   	ret
80102663:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010266a:	00 
8010266b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102670 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
80102670:	55                   	push   %ebp
80102671:	89 e5                	mov    %esp,%ebp
80102673:	53                   	push   %ebx
80102674:	83 ec 04             	sub    $0x4,%esp
  struct run *r;

  if(kmem.use_lock)
80102677:	a1 94 26 11 80       	mov    0x80112694,%eax
8010267c:	85 c0                	test   %eax,%eax
8010267e:	75 20                	jne    801026a0 <kalloc+0x30>
    acquire(&kmem.lock);
  r = kmem.freelist;
80102680:	8b 1d 98 26 11 80    	mov    0x80112698,%ebx
  if(r){
80102686:	85 db                	test   %ebx,%ebx
80102688:	74 0e                	je     80102698 <kalloc+0x28>
    kmem.freelist = r->next;
8010268a:	8b 03                	mov    (%ebx),%eax
    free_pages_count--;
8010268c:	83 2d 40 26 11 80 01 	subl   $0x1,0x80112640
    kmem.freelist = r->next;
80102693:	a3 98 26 11 80       	mov    %eax,0x80112698
  }
  if(kmem.use_lock)
    release(&kmem.lock);
  return (char*)r;
}
80102698:	89 d8                	mov    %ebx,%eax
8010269a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010269d:	c9                   	leave
8010269e:	c3                   	ret
8010269f:	90                   	nop
    acquire(&kmem.lock);
801026a0:	83 ec 0c             	sub    $0xc,%esp
801026a3:	68 60 26 11 80       	push   $0x80112660
801026a8:	e8 43 20 00 00       	call   801046f0 <acquire>
  r = kmem.freelist;
801026ad:	8b 1d 98 26 11 80    	mov    0x80112698,%ebx
  if(kmem.use_lock)
801026b3:	a1 94 26 11 80       	mov    0x80112694,%eax
  if(r){
801026b8:	83 c4 10             	add    $0x10,%esp
801026bb:	85 db                	test   %ebx,%ebx
801026bd:	74 0f                	je     801026ce <kalloc+0x5e>
    kmem.freelist = r->next;
801026bf:	8b 13                	mov    (%ebx),%edx
    free_pages_count--;
801026c1:	83 2d 40 26 11 80 01 	subl   $0x1,0x80112640
    kmem.freelist = r->next;
801026c8:	89 15 98 26 11 80    	mov    %edx,0x80112698
  if(kmem.use_lock)
801026ce:	85 c0                	test   %eax,%eax
801026d0:	74 c6                	je     80102698 <kalloc+0x28>
    release(&kmem.lock);
801026d2:	83 ec 0c             	sub    $0xc,%esp
801026d5:	68 60 26 11 80       	push   $0x80112660
801026da:	e8 b1 1f 00 00       	call   80104690 <release>
}
801026df:	89 d8                	mov    %ebx,%eax
    release(&kmem.lock);
801026e1:	83 c4 10             	add    $0x10,%esp
}
801026e4:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801026e7:	c9                   	leave
801026e8:	c3                   	ret
801026e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801026f0 <freepages>:

int
freepages(void)
{
801026f0:	55                   	push   %ebp
801026f1:	89 e5                	mov    %esp,%ebp
801026f3:	53                   	push   %ebx
801026f4:	83 ec 04             	sub    $0x4,%esp
  int count;
  if(kmem.use_lock)
801026f7:	8b 15 94 26 11 80    	mov    0x80112694,%edx
    acquire(&kmem.lock);
  count = free_pages_count;
801026fd:	8b 1d 40 26 11 80    	mov    0x80112640,%ebx
  if(kmem.use_lock)
80102703:	85 d2                	test   %edx,%edx
80102705:	75 09                	jne    80102710 <freepages+0x20>
  if(kmem.use_lock)
    release(&kmem.lock);
  return count;
}
80102707:	89 d8                	mov    %ebx,%eax
80102709:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010270c:	c9                   	leave
8010270d:	c3                   	ret
8010270e:	66 90                	xchg   %ax,%ax
    acquire(&kmem.lock);
80102710:	83 ec 0c             	sub    $0xc,%esp
80102713:	68 60 26 11 80       	push   $0x80112660
80102718:	e8 d3 1f 00 00       	call   801046f0 <acquire>
  if(kmem.use_lock)
8010271d:	a1 94 26 11 80       	mov    0x80112694,%eax
  count = free_pages_count;
80102722:	8b 1d 40 26 11 80    	mov    0x80112640,%ebx
  if(kmem.use_lock)
80102728:	83 c4 10             	add    $0x10,%esp
8010272b:	85 c0                	test   %eax,%eax
8010272d:	74 d8                	je     80102707 <freepages+0x17>
    release(&kmem.lock);
8010272f:	83 ec 0c             	sub    $0xc,%esp
80102732:	68 60 26 11 80       	push   $0x80112660
80102737:	e8 54 1f 00 00       	call   80104690 <release>
}
8010273c:	89 d8                	mov    %ebx,%eax
    release(&kmem.lock);
8010273e:	83 c4 10             	add    $0x10,%esp
}
80102741:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102744:	c9                   	leave
80102745:	c3                   	ret
80102746:	66 90                	xchg   %ax,%ax
80102748:	66 90                	xchg   %ax,%ax
8010274a:	66 90                	xchg   %ax,%ax
8010274c:	66 90                	xchg   %ax,%ax
8010274e:	66 90                	xchg   %ax,%ax

80102750 <kbdgetc>:
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102750:	ba 64 00 00 00       	mov    $0x64,%edx
80102755:	ec                   	in     (%dx),%al
    normalmap, shiftmap, ctlmap, ctlmap
  };
  uint st, data, c;

  st = inb(KBSTATP);
  if((st & KBS_DIB) == 0)
80102756:	a8 01                	test   $0x1,%al
80102758:	0f 84 c2 00 00 00    	je     80102820 <kbdgetc+0xd0>
{
8010275e:	55                   	push   %ebp
8010275f:	ba 60 00 00 00       	mov    $0x60,%edx
80102764:	89 e5                	mov    %esp,%ebp
80102766:	53                   	push   %ebx
80102767:	ec                   	in     (%dx),%al
    return -1;
  data = inb(KBDATAP);

  if(data == 0xE0){
    shift |= E0ESC;
80102768:	8b 1d 9c 26 11 80    	mov    0x8011269c,%ebx
  data = inb(KBDATAP);
8010276e:	0f b6 c8             	movzbl %al,%ecx
  if(data == 0xE0){
80102771:	3c e0                	cmp    $0xe0,%al
80102773:	74 5b                	je     801027d0 <kbdgetc+0x80>
    return 0;
  } else if(data & 0x80){
    // Key released
    data = (shift & E0ESC ? data : data & 0x7F);
80102775:	89 da                	mov    %ebx,%edx
80102777:	83 e2 40             	and    $0x40,%edx
  } else if(data & 0x80){
8010277a:	84 c0                	test   %al,%al
8010277c:	78 62                	js     801027e0 <kbdgetc+0x90>
    shift &= ~(shiftcode[data] | E0ESC);
    return 0;
  } else if(shift & E0ESC){
8010277e:	85 d2                	test   %edx,%edx
80102780:	74 09                	je     8010278b <kbdgetc+0x3b>
    // Last character was an E0 escape; or with 0x80
    data |= 0x80;
80102782:	83 c8 80             	or     $0xffffff80,%eax
    shift &= ~E0ESC;
80102785:	83 e3 bf             	and    $0xffffffbf,%ebx
    data |= 0x80;
80102788:	0f b6 c8             	movzbl %al,%ecx
  }

  shift |= shiftcode[data];
8010278b:	0f b6 91 60 80 10 80 	movzbl -0x7fef7fa0(%ecx),%edx
  shift ^= togglecode[data];
80102792:	0f b6 81 60 7f 10 80 	movzbl -0x7fef80a0(%ecx),%eax
  shift |= shiftcode[data];
80102799:	09 da                	or     %ebx,%edx
  shift ^= togglecode[data];
8010279b:	31 c2                	xor    %eax,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
8010279d:	89 d0                	mov    %edx,%eax
  shift ^= togglecode[data];
8010279f:	89 15 9c 26 11 80    	mov    %edx,0x8011269c
  c = charcode[shift & (CTL | SHIFT)][data];
801027a5:	83 e0 03             	and    $0x3,%eax
  if(shift & CAPSLOCK){
801027a8:	83 e2 08             	and    $0x8,%edx
  c = charcode[shift & (CTL | SHIFT)][data];
801027ab:	8b 04 85 40 7f 10 80 	mov    -0x7fef80c0(,%eax,4),%eax
801027b2:	0f b6 04 08          	movzbl (%eax,%ecx,1),%eax
  if(shift & CAPSLOCK){
801027b6:	74 0b                	je     801027c3 <kbdgetc+0x73>
    if('a' <= c && c <= 'z')
801027b8:	8d 50 9f             	lea    -0x61(%eax),%edx
801027bb:	83 fa 19             	cmp    $0x19,%edx
801027be:	77 48                	ja     80102808 <kbdgetc+0xb8>
      c += 'A' - 'a';
801027c0:	83 e8 20             	sub    $0x20,%eax
    else if('A' <= c && c <= 'Z')
      c += 'a' - 'A';
  }
  return c;
}
801027c3:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801027c6:	c9                   	leave
801027c7:	c3                   	ret
801027c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801027cf:	00 
    shift |= E0ESC;
801027d0:	83 cb 40             	or     $0x40,%ebx
    return 0;
801027d3:	31 c0                	xor    %eax,%eax
    shift |= E0ESC;
801027d5:	89 1d 9c 26 11 80    	mov    %ebx,0x8011269c
}
801027db:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801027de:	c9                   	leave
801027df:	c3                   	ret
    data = (shift & E0ESC ? data : data & 0x7F);
801027e0:	83 e0 7f             	and    $0x7f,%eax
801027e3:	85 d2                	test   %edx,%edx
801027e5:	0f 44 c8             	cmove  %eax,%ecx
    shift &= ~(shiftcode[data] | E0ESC);
801027e8:	0f b6 81 60 80 10 80 	movzbl -0x7fef7fa0(%ecx),%eax
801027ef:	83 c8 40             	or     $0x40,%eax
801027f2:	0f b6 c0             	movzbl %al,%eax
801027f5:	f7 d0                	not    %eax
801027f7:	21 d8                	and    %ebx,%eax
801027f9:	a3 9c 26 11 80       	mov    %eax,0x8011269c
    return 0;
801027fe:	31 c0                	xor    %eax,%eax
80102800:	eb d9                	jmp    801027db <kbdgetc+0x8b>
80102802:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    else if('A' <= c && c <= 'Z')
80102808:	8d 48 bf             	lea    -0x41(%eax),%ecx
      c += 'a' - 'A';
8010280b:	8d 50 20             	lea    0x20(%eax),%edx
}
8010280e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102811:	c9                   	leave
      c += 'a' - 'A';
80102812:	83 f9 1a             	cmp    $0x1a,%ecx
80102815:	0f 42 c2             	cmovb  %edx,%eax
}
80102818:	c3                   	ret
80102819:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80102820:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80102825:	c3                   	ret
80102826:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010282d:	00 
8010282e:	66 90                	xchg   %ax,%ax

80102830 <kbdintr>:

void
kbdintr(void)
{
80102830:	55                   	push   %ebp
80102831:	89 e5                	mov    %esp,%ebp
80102833:	83 ec 14             	sub    $0x14,%esp
  consoleintr(kbdgetc);
80102836:	68 50 27 10 80       	push   $0x80102750
8010283b:	e8 60 e0 ff ff       	call   801008a0 <consoleintr>
}
80102840:	83 c4 10             	add    $0x10,%esp
80102843:	c9                   	leave
80102844:	c3                   	ret
80102845:	66 90                	xchg   %ax,%ax
80102847:	66 90                	xchg   %ax,%ax
80102849:	66 90                	xchg   %ax,%ax
8010284b:	66 90                	xchg   %ax,%ax
8010284d:	66 90                	xchg   %ax,%ax
8010284f:	90                   	nop

80102850 <lapicinit>:
}

void
lapicinit(void)
{
  if(!lapic)
80102850:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102855:	85 c0                	test   %eax,%eax
80102857:	0f 84 c3 00 00 00    	je     80102920 <lapicinit+0xd0>
  lapic[index] = value;
8010285d:	c7 80 f0 00 00 00 3f 	movl   $0x13f,0xf0(%eax)
80102864:	01 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102867:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
8010286a:	c7 80 e0 03 00 00 0b 	movl   $0xb,0x3e0(%eax)
80102871:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102874:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102877:	c7 80 20 03 00 00 20 	movl   $0x20020,0x320(%eax)
8010287e:	00 02 00 
  lapic[ID];  // wait for write to finish, by reading
80102881:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102884:	c7 80 80 03 00 00 80 	movl   $0x989680,0x380(%eax)
8010288b:	96 98 00 
  lapic[ID];  // wait for write to finish, by reading
8010288e:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102891:	c7 80 50 03 00 00 00 	movl   $0x10000,0x350(%eax)
80102898:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
8010289b:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
8010289e:	c7 80 60 03 00 00 00 	movl   $0x10000,0x360(%eax)
801028a5:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
801028a8:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(LINT0, MASKED);
  lapicw(LINT1, MASKED);

  // Disable performance counter overflow interrupts
  // on machines that provide that interrupt entry.
  if(((lapic[VER]>>16) & 0xFF) >= 4)
801028ab:	8b 50 30             	mov    0x30(%eax),%edx
801028ae:	81 e2 00 00 fc 00    	and    $0xfc0000,%edx
801028b4:	75 72                	jne    80102928 <lapicinit+0xd8>
  lapic[index] = value;
801028b6:	c7 80 70 03 00 00 33 	movl   $0x33,0x370(%eax)
801028bd:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801028c0:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801028c3:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801028ca:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801028cd:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801028d0:	c7 80 80 02 00 00 00 	movl   $0x0,0x280(%eax)
801028d7:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801028da:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801028dd:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
801028e4:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801028e7:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801028ea:	c7 80 10 03 00 00 00 	movl   $0x0,0x310(%eax)
801028f1:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
801028f4:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
801028f7:	c7 80 00 03 00 00 00 	movl   $0x88500,0x300(%eax)
801028fe:	85 08 00 
  lapic[ID];  // wait for write to finish, by reading
80102901:	8b 50 20             	mov    0x20(%eax),%edx
  lapicw(EOI, 0);

  // Send an Init Level De-Assert to synchronise arbitration ID's.
  lapicw(ICRHI, 0);
  lapicw(ICRLO, BCAST | INIT | LEVEL);
  while(lapic[ICRLO] & DELIVS)
80102904:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102908:	8b 90 00 03 00 00    	mov    0x300(%eax),%edx
8010290e:	80 e6 10             	and    $0x10,%dh
80102911:	75 f5                	jne    80102908 <lapicinit+0xb8>
  lapic[index] = value;
80102913:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%eax)
8010291a:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
8010291d:	8b 40 20             	mov    0x20(%eax),%eax
    ;

  // Enable interrupts on the APIC (but not on the processor).
  lapicw(TPR, 0);
}
80102920:	c3                   	ret
80102921:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  lapic[index] = value;
80102928:	c7 80 40 03 00 00 00 	movl   $0x10000,0x340(%eax)
8010292f:	00 01 00 
  lapic[ID];  // wait for write to finish, by reading
80102932:	8b 50 20             	mov    0x20(%eax),%edx
}
80102935:	e9 7c ff ff ff       	jmp    801028b6 <lapicinit+0x66>
8010293a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80102940 <lapicid>:

int
lapicid(void)
{
  if (!lapic)
80102940:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102945:	85 c0                	test   %eax,%eax
80102947:	74 07                	je     80102950 <lapicid+0x10>
    return 0;
  return lapic[ID] >> 24;
80102949:	8b 40 20             	mov    0x20(%eax),%eax
8010294c:	c1 e8 18             	shr    $0x18,%eax
8010294f:	c3                   	ret
    return 0;
80102950:	31 c0                	xor    %eax,%eax
}
80102952:	c3                   	ret
80102953:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010295a:	00 
8010295b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102960 <lapiceoi>:

// Acknowledge interrupt.
void
lapiceoi(void)
{
  if(lapic)
80102960:	a1 a0 26 11 80       	mov    0x801126a0,%eax
80102965:	85 c0                	test   %eax,%eax
80102967:	74 0d                	je     80102976 <lapiceoi+0x16>
  lapic[index] = value;
80102969:	c7 80 b0 00 00 00 00 	movl   $0x0,0xb0(%eax)
80102970:	00 00 00 
  lapic[ID];  // wait for write to finish, by reading
80102973:	8b 40 20             	mov    0x20(%eax),%eax
    lapicw(EOI, 0);
}
80102976:	c3                   	ret
80102977:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010297e:	00 
8010297f:	90                   	nop

80102980 <microdelay>:
// Spin for a given number of microseconds.
// On real hardware would want to tune this dynamically.
void
microdelay(int us)
{
}
80102980:	c3                   	ret
80102981:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102988:	00 
80102989:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102990 <lapicstartap>:

// Start additional processor running entry code at addr.
// See Appendix B of MultiProcessor Specification.
void
lapicstartap(uchar apicid, uint addr)
{
80102990:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102991:	b8 0f 00 00 00       	mov    $0xf,%eax
80102996:	ba 70 00 00 00       	mov    $0x70,%edx
8010299b:	89 e5                	mov    %esp,%ebp
8010299d:	53                   	push   %ebx
8010299e:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801029a1:	8b 5d 08             	mov    0x8(%ebp),%ebx
801029a4:	ee                   	out    %al,(%dx)
801029a5:	b8 0a 00 00 00       	mov    $0xa,%eax
801029aa:	ba 71 00 00 00       	mov    $0x71,%edx
801029af:	ee                   	out    %al,(%dx)
  // and the warm reset vector (DWORD based at 40:67) to point at
  // the AP startup code prior to the [universal startup algorithm]."
  outb(CMOS_PORT, 0xF);  // offset 0xF is shutdown code
  outb(CMOS_PORT+1, 0x0A);
  wrv = (ushort*)P2V((0x40<<4 | 0x67));  // Warm reset vector
  wrv[0] = 0;
801029b0:	31 c0                	xor    %eax,%eax
  lapic[index] = value;
801029b2:	c1 e3 18             	shl    $0x18,%ebx
  wrv[0] = 0;
801029b5:	66 a3 67 04 00 80    	mov    %ax,0x80000467
  wrv[1] = addr >> 4;
801029bb:	89 c8                	mov    %ecx,%eax
  // when it is in the halted state due to an INIT.  So the second
  // should be ignored, but it is part of the official Intel algorithm.
  // Bochs complains about the second one.  Too bad for Bochs.
  for(i = 0; i < 2; i++){
    lapicw(ICRHI, apicid<<24);
    lapicw(ICRLO, STARTUP | (addr>>12));
801029bd:	c1 e9 0c             	shr    $0xc,%ecx
  lapic[index] = value;
801029c0:	89 da                	mov    %ebx,%edx
  wrv[1] = addr >> 4;
801029c2:	c1 e8 04             	shr    $0x4,%eax
    lapicw(ICRLO, STARTUP | (addr>>12));
801029c5:	80 cd 06             	or     $0x6,%ch
  wrv[1] = addr >> 4;
801029c8:	66 a3 69 04 00 80    	mov    %ax,0x80000469
  lapic[index] = value;
801029ce:	a1 a0 26 11 80       	mov    0x801126a0,%eax
801029d3:	89 98 10 03 00 00    	mov    %ebx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
801029d9:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
801029dc:	c7 80 00 03 00 00 00 	movl   $0xc500,0x300(%eax)
801029e3:	c5 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029e6:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
801029e9:	c7 80 00 03 00 00 00 	movl   $0x8500,0x300(%eax)
801029f0:	85 00 00 
  lapic[ID];  // wait for write to finish, by reading
801029f3:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
801029f6:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
801029fc:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
801029ff:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102a05:	8b 58 20             	mov    0x20(%eax),%ebx
  lapic[index] = value;
80102a08:	89 90 10 03 00 00    	mov    %edx,0x310(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102a0e:	8b 50 20             	mov    0x20(%eax),%edx
  lapic[index] = value;
80102a11:	89 88 00 03 00 00    	mov    %ecx,0x300(%eax)
  lapic[ID];  // wait for write to finish, by reading
80102a17:	8b 40 20             	mov    0x20(%eax),%eax
    microdelay(200);
  }
}
80102a1a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102a1d:	c9                   	leave
80102a1e:	c3                   	ret
80102a1f:	90                   	nop

80102a20 <cmostime>:
}

// qemu seems to use 24-hour GWT and the values are BCD encoded
void
cmostime(struct rtcdate *r)
{
80102a20:	55                   	push   %ebp
80102a21:	b8 0b 00 00 00       	mov    $0xb,%eax
80102a26:	ba 70 00 00 00       	mov    $0x70,%edx
80102a2b:	89 e5                	mov    %esp,%ebp
80102a2d:	57                   	push   %edi
80102a2e:	56                   	push   %esi
80102a2f:	53                   	push   %ebx
80102a30:	83 ec 4c             	sub    $0x4c,%esp
80102a33:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a34:	ba 71 00 00 00       	mov    $0x71,%edx
80102a39:	ec                   	in     (%dx),%al
  struct rtcdate t1, t2;
  int sb, bcd;

  sb = cmos_read(CMOS_STATB);

  bcd = (sb & (1 << 2)) == 0;
80102a3a:	83 e0 04             	and    $0x4,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a3d:	bf 70 00 00 00       	mov    $0x70,%edi
80102a42:	88 45 b3             	mov    %al,-0x4d(%ebp)
80102a45:	8d 76 00             	lea    0x0(%esi),%esi
80102a48:	31 c0                	xor    %eax,%eax
80102a4a:	89 fa                	mov    %edi,%edx
80102a4c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a4d:	b9 71 00 00 00       	mov    $0x71,%ecx
80102a52:	89 ca                	mov    %ecx,%edx
80102a54:	ec                   	in     (%dx),%al
80102a55:	88 45 b7             	mov    %al,-0x49(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a58:	89 fa                	mov    %edi,%edx
80102a5a:	b8 02 00 00 00       	mov    $0x2,%eax
80102a5f:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a60:	89 ca                	mov    %ecx,%edx
80102a62:	ec                   	in     (%dx),%al
80102a63:	88 45 b6             	mov    %al,-0x4a(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a66:	89 fa                	mov    %edi,%edx
80102a68:	b8 04 00 00 00       	mov    $0x4,%eax
80102a6d:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a6e:	89 ca                	mov    %ecx,%edx
80102a70:	ec                   	in     (%dx),%al
80102a71:	88 45 b5             	mov    %al,-0x4b(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a74:	89 fa                	mov    %edi,%edx
80102a76:	b8 07 00 00 00       	mov    $0x7,%eax
80102a7b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a7c:	89 ca                	mov    %ecx,%edx
80102a7e:	ec                   	in     (%dx),%al
80102a7f:	88 45 b4             	mov    %al,-0x4c(%ebp)
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a82:	89 fa                	mov    %edi,%edx
80102a84:	b8 08 00 00 00       	mov    $0x8,%eax
80102a89:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a8a:	89 ca                	mov    %ecx,%edx
80102a8c:	ec                   	in     (%dx),%al
80102a8d:	89 c6                	mov    %eax,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a8f:	89 fa                	mov    %edi,%edx
80102a91:	b8 09 00 00 00       	mov    $0x9,%eax
80102a96:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102a97:	89 ca                	mov    %ecx,%edx
80102a99:	ec                   	in     (%dx),%al
80102a9a:	0f b6 d8             	movzbl %al,%ebx
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102a9d:	89 fa                	mov    %edi,%edx
80102a9f:	b8 0a 00 00 00       	mov    $0xa,%eax
80102aa4:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102aa5:	89 ca                	mov    %ecx,%edx
80102aa7:	ec                   	in     (%dx),%al

  // make sure CMOS doesn't modify time while we read it
  for(;;) {
    fill_rtcdate(&t1);
    if(cmos_read(CMOS_STATA) & CMOS_UIP)
80102aa8:	84 c0                	test   %al,%al
80102aaa:	78 9c                	js     80102a48 <cmostime+0x28>
  return inb(CMOS_RETURN);
80102aac:	0f b6 45 b7          	movzbl -0x49(%ebp),%eax
80102ab0:	89 f2                	mov    %esi,%edx
80102ab2:	89 5d cc             	mov    %ebx,-0x34(%ebp)
80102ab5:	0f b6 f2             	movzbl %dl,%esi
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ab8:	89 fa                	mov    %edi,%edx
80102aba:	89 45 b8             	mov    %eax,-0x48(%ebp)
80102abd:	0f b6 45 b6          	movzbl -0x4a(%ebp),%eax
80102ac1:	89 75 c8             	mov    %esi,-0x38(%ebp)
80102ac4:	89 45 bc             	mov    %eax,-0x44(%ebp)
80102ac7:	0f b6 45 b5          	movzbl -0x4b(%ebp),%eax
80102acb:	89 45 c0             	mov    %eax,-0x40(%ebp)
80102ace:	0f b6 45 b4          	movzbl -0x4c(%ebp),%eax
80102ad2:	89 45 c4             	mov    %eax,-0x3c(%ebp)
80102ad5:	31 c0                	xor    %eax,%eax
80102ad7:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102ad8:	89 ca                	mov    %ecx,%edx
80102ada:	ec                   	in     (%dx),%al
80102adb:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102ade:	89 fa                	mov    %edi,%edx
80102ae0:	89 45 d0             	mov    %eax,-0x30(%ebp)
80102ae3:	b8 02 00 00 00       	mov    $0x2,%eax
80102ae8:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102ae9:	89 ca                	mov    %ecx,%edx
80102aeb:	ec                   	in     (%dx),%al
80102aec:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102aef:	89 fa                	mov    %edi,%edx
80102af1:	89 45 d4             	mov    %eax,-0x2c(%ebp)
80102af4:	b8 04 00 00 00       	mov    $0x4,%eax
80102af9:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102afa:	89 ca                	mov    %ecx,%edx
80102afc:	ec                   	in     (%dx),%al
80102afd:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b00:	89 fa                	mov    %edi,%edx
80102b02:	89 45 d8             	mov    %eax,-0x28(%ebp)
80102b05:	b8 07 00 00 00       	mov    $0x7,%eax
80102b0a:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b0b:	89 ca                	mov    %ecx,%edx
80102b0d:	ec                   	in     (%dx),%al
80102b0e:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b11:	89 fa                	mov    %edi,%edx
80102b13:	89 45 dc             	mov    %eax,-0x24(%ebp)
80102b16:	b8 08 00 00 00       	mov    $0x8,%eax
80102b1b:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b1c:	89 ca                	mov    %ecx,%edx
80102b1e:	ec                   	in     (%dx),%al
80102b1f:	0f b6 c0             	movzbl %al,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80102b22:	89 fa                	mov    %edi,%edx
80102b24:	89 45 e0             	mov    %eax,-0x20(%ebp)
80102b27:	b8 09 00 00 00       	mov    $0x9,%eax
80102b2c:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80102b2d:	89 ca                	mov    %ecx,%edx
80102b2f:	ec                   	in     (%dx),%al
80102b30:	0f b6 c0             	movzbl %al,%eax
        continue;
    fill_rtcdate(&t2);
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102b33:	83 ec 04             	sub    $0x4,%esp
  return inb(CMOS_RETURN);
80102b36:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    if(memcmp(&t1, &t2, sizeof(t1)) == 0)
80102b39:	8d 45 d0             	lea    -0x30(%ebp),%eax
80102b3c:	6a 18                	push   $0x18
80102b3e:	50                   	push   %eax
80102b3f:	8d 45 b8             	lea    -0x48(%ebp),%eax
80102b42:	50                   	push   %eax
80102b43:	e8 e8 1c 00 00       	call   80104830 <memcmp>
80102b48:	83 c4 10             	add    $0x10,%esp
80102b4b:	85 c0                	test   %eax,%eax
80102b4d:	0f 85 f5 fe ff ff    	jne    80102a48 <cmostime+0x28>
      break;
  }

  // convert
  if(bcd) {
80102b53:	0f b6 75 b3          	movzbl -0x4d(%ebp),%esi
80102b57:	8b 5d 08             	mov    0x8(%ebp),%ebx
80102b5a:	89 f0                	mov    %esi,%eax
80102b5c:	84 c0                	test   %al,%al
80102b5e:	75 78                	jne    80102bd8 <cmostime+0x1b8>
#define    CONV(x)     (t1.x = ((t1.x >> 4) * 10) + (t1.x & 0xf))
    CONV(second);
80102b60:	8b 45 b8             	mov    -0x48(%ebp),%eax
80102b63:	89 c2                	mov    %eax,%edx
80102b65:	83 e0 0f             	and    $0xf,%eax
80102b68:	c1 ea 04             	shr    $0x4,%edx
80102b6b:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102b6e:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102b71:	89 45 b8             	mov    %eax,-0x48(%ebp)
    CONV(minute);
80102b74:	8b 45 bc             	mov    -0x44(%ebp),%eax
80102b77:	89 c2                	mov    %eax,%edx
80102b79:	83 e0 0f             	and    $0xf,%eax
80102b7c:	c1 ea 04             	shr    $0x4,%edx
80102b7f:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102b82:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102b85:	89 45 bc             	mov    %eax,-0x44(%ebp)
    CONV(hour  );
80102b88:	8b 45 c0             	mov    -0x40(%ebp),%eax
80102b8b:	89 c2                	mov    %eax,%edx
80102b8d:	83 e0 0f             	and    $0xf,%eax
80102b90:	c1 ea 04             	shr    $0x4,%edx
80102b93:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102b96:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102b99:	89 45 c0             	mov    %eax,-0x40(%ebp)
    CONV(day   );
80102b9c:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80102b9f:	89 c2                	mov    %eax,%edx
80102ba1:	83 e0 0f             	and    $0xf,%eax
80102ba4:	c1 ea 04             	shr    $0x4,%edx
80102ba7:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102baa:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102bad:	89 45 c4             	mov    %eax,-0x3c(%ebp)
    CONV(month );
80102bb0:	8b 45 c8             	mov    -0x38(%ebp),%eax
80102bb3:	89 c2                	mov    %eax,%edx
80102bb5:	83 e0 0f             	and    $0xf,%eax
80102bb8:	c1 ea 04             	shr    $0x4,%edx
80102bbb:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102bbe:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102bc1:	89 45 c8             	mov    %eax,-0x38(%ebp)
    CONV(year  );
80102bc4:	8b 45 cc             	mov    -0x34(%ebp),%eax
80102bc7:	89 c2                	mov    %eax,%edx
80102bc9:	83 e0 0f             	and    $0xf,%eax
80102bcc:	c1 ea 04             	shr    $0x4,%edx
80102bcf:	8d 14 92             	lea    (%edx,%edx,4),%edx
80102bd2:	8d 04 50             	lea    (%eax,%edx,2),%eax
80102bd5:	89 45 cc             	mov    %eax,-0x34(%ebp)
#undef     CONV
  }

  *r = t1;
80102bd8:	8b 45 b8             	mov    -0x48(%ebp),%eax
80102bdb:	89 03                	mov    %eax,(%ebx)
80102bdd:	8b 45 bc             	mov    -0x44(%ebp),%eax
80102be0:	89 43 04             	mov    %eax,0x4(%ebx)
80102be3:	8b 45 c0             	mov    -0x40(%ebp),%eax
80102be6:	89 43 08             	mov    %eax,0x8(%ebx)
80102be9:	8b 45 c4             	mov    -0x3c(%ebp),%eax
80102bec:	89 43 0c             	mov    %eax,0xc(%ebx)
80102bef:	8b 45 c8             	mov    -0x38(%ebp),%eax
80102bf2:	89 43 10             	mov    %eax,0x10(%ebx)
80102bf5:	8b 45 cc             	mov    -0x34(%ebp),%eax
80102bf8:	89 43 14             	mov    %eax,0x14(%ebx)
  r->year += 2000;
80102bfb:	81 43 14 d0 07 00 00 	addl   $0x7d0,0x14(%ebx)
}
80102c02:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102c05:	5b                   	pop    %ebx
80102c06:	5e                   	pop    %esi
80102c07:	5f                   	pop    %edi
80102c08:	5d                   	pop    %ebp
80102c09:	c3                   	ret
80102c0a:	66 90                	xchg   %ax,%ax
80102c0c:	66 90                	xchg   %ax,%ax
80102c0e:	66 90                	xchg   %ax,%ax

80102c10 <install_trans>:
static void
install_trans(void)
{
  int tail;

  for (tail = 0; tail < log.lh.n; tail++) {
80102c10:	8b 0d 08 27 11 80    	mov    0x80112708,%ecx
80102c16:	85 c9                	test   %ecx,%ecx
80102c18:	0f 8e 8a 00 00 00    	jle    80102ca8 <install_trans+0x98>
{
80102c1e:	55                   	push   %ebp
80102c1f:	89 e5                	mov    %esp,%ebp
80102c21:	57                   	push   %edi
  for (tail = 0; tail < log.lh.n; tail++) {
80102c22:	31 ff                	xor    %edi,%edi
{
80102c24:	56                   	push   %esi
80102c25:	53                   	push   %ebx
80102c26:	83 ec 0c             	sub    $0xc,%esp
80102c29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
80102c30:	a1 f4 26 11 80       	mov    0x801126f4,%eax
80102c35:	83 ec 08             	sub    $0x8,%esp
80102c38:	01 f8                	add    %edi,%eax
80102c3a:	83 c0 01             	add    $0x1,%eax
80102c3d:	50                   	push   %eax
80102c3e:	ff 35 04 27 11 80    	push   0x80112704
80102c44:	e8 87 d4 ff ff       	call   801000d0 <bread>
80102c49:	89 c6                	mov    %eax,%esi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102c4b:	58                   	pop    %eax
80102c4c:	5a                   	pop    %edx
80102c4d:	ff 34 bd 0c 27 11 80 	push   -0x7feed8f4(,%edi,4)
80102c54:	ff 35 04 27 11 80    	push   0x80112704
  for (tail = 0; tail < log.lh.n; tail++) {
80102c5a:	83 c7 01             	add    $0x1,%edi
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102c5d:	e8 6e d4 ff ff       	call   801000d0 <bread>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102c62:	83 c4 0c             	add    $0xc,%esp
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
80102c65:	89 c3                	mov    %eax,%ebx
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
80102c67:	8d 46 5c             	lea    0x5c(%esi),%eax
80102c6a:	68 00 02 00 00       	push   $0x200
80102c6f:	50                   	push   %eax
80102c70:	8d 43 5c             	lea    0x5c(%ebx),%eax
80102c73:	50                   	push   %eax
80102c74:	e8 07 1c 00 00       	call   80104880 <memmove>
    bwrite(dbuf);  // write dst to disk
80102c79:	89 1c 24             	mov    %ebx,(%esp)
80102c7c:	e8 2f d5 ff ff       	call   801001b0 <bwrite>
    brelse(lbuf);
80102c81:	89 34 24             	mov    %esi,(%esp)
80102c84:	e8 67 d5 ff ff       	call   801001f0 <brelse>
    brelse(dbuf);
80102c89:	89 1c 24             	mov    %ebx,(%esp)
80102c8c:	e8 5f d5 ff ff       	call   801001f0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80102c91:	83 c4 10             	add    $0x10,%esp
80102c94:	39 3d 08 27 11 80    	cmp    %edi,0x80112708
80102c9a:	7f 94                	jg     80102c30 <install_trans+0x20>
  }
}
80102c9c:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102c9f:	5b                   	pop    %ebx
80102ca0:	5e                   	pop    %esi
80102ca1:	5f                   	pop    %edi
80102ca2:	5d                   	pop    %ebp
80102ca3:	c3                   	ret
80102ca4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80102ca8:	c3                   	ret
80102ca9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102cb0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
80102cb0:	55                   	push   %ebp
80102cb1:	89 e5                	mov    %esp,%ebp
80102cb3:	53                   	push   %ebx
80102cb4:	83 ec 0c             	sub    $0xc,%esp
  struct buf *buf = bread(log.dev, log.start);
80102cb7:	ff 35 f4 26 11 80    	push   0x801126f4
80102cbd:	ff 35 04 27 11 80    	push   0x80112704
80102cc3:	e8 08 d4 ff ff       	call   801000d0 <bread>
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
  for (i = 0; i < log.lh.n; i++) {
80102cc8:	83 c4 10             	add    $0x10,%esp
  struct buf *buf = bread(log.dev, log.start);
80102ccb:	89 c3                	mov    %eax,%ebx
  hb->n = log.lh.n;
80102ccd:	a1 08 27 11 80       	mov    0x80112708,%eax
80102cd2:	89 43 5c             	mov    %eax,0x5c(%ebx)
  for (i = 0; i < log.lh.n; i++) {
80102cd5:	85 c0                	test   %eax,%eax
80102cd7:	7e 19                	jle    80102cf2 <write_head+0x42>
80102cd9:	31 d2                	xor    %edx,%edx
80102cdb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    hb->block[i] = log.lh.block[i];
80102ce0:	8b 0c 95 0c 27 11 80 	mov    -0x7feed8f4(,%edx,4),%ecx
80102ce7:	89 4c 93 60          	mov    %ecx,0x60(%ebx,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
80102ceb:	83 c2 01             	add    $0x1,%edx
80102cee:	39 d0                	cmp    %edx,%eax
80102cf0:	75 ee                	jne    80102ce0 <write_head+0x30>
  }
  bwrite(buf);
80102cf2:	83 ec 0c             	sub    $0xc,%esp
80102cf5:	53                   	push   %ebx
80102cf6:	e8 b5 d4 ff ff       	call   801001b0 <bwrite>
  brelse(buf);
80102cfb:	89 1c 24             	mov    %ebx,(%esp)
80102cfe:	e8 ed d4 ff ff       	call   801001f0 <brelse>
}
80102d03:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102d06:	83 c4 10             	add    $0x10,%esp
80102d09:	c9                   	leave
80102d0a:	c3                   	ret
80102d0b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80102d10 <initlog>:
{
80102d10:	55                   	push   %ebp
80102d11:	89 e5                	mov    %esp,%ebp
80102d13:	53                   	push   %ebx
80102d14:	83 ec 2c             	sub    $0x2c,%esp
80102d17:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&log.lock, "log");
80102d1a:	68 f7 79 10 80       	push   $0x801079f7
80102d1f:	68 c0 26 11 80       	push   $0x801126c0
80102d24:	e8 d7 17 00 00       	call   80104500 <initlock>
  readsb(dev, &sb);
80102d29:	58                   	pop    %eax
80102d2a:	8d 45 dc             	lea    -0x24(%ebp),%eax
80102d2d:	5a                   	pop    %edx
80102d2e:	50                   	push   %eax
80102d2f:	53                   	push   %ebx
80102d30:	e8 0b e8 ff ff       	call   80101540 <readsb>
  log.start = sb.logstart;
80102d35:	8b 45 ec             	mov    -0x14(%ebp),%eax
  struct buf *buf = bread(log.dev, log.start);
80102d38:	59                   	pop    %ecx
  log.dev = dev;
80102d39:	89 1d 04 27 11 80    	mov    %ebx,0x80112704
  log.size = sb.nlog;
80102d3f:	8b 55 e8             	mov    -0x18(%ebp),%edx
  log.start = sb.logstart;
80102d42:	a3 f4 26 11 80       	mov    %eax,0x801126f4
  log.size = sb.nlog;
80102d47:	89 15 f8 26 11 80    	mov    %edx,0x801126f8
  struct buf *buf = bread(log.dev, log.start);
80102d4d:	5a                   	pop    %edx
80102d4e:	50                   	push   %eax
80102d4f:	53                   	push   %ebx
80102d50:	e8 7b d3 ff ff       	call   801000d0 <bread>
  for (i = 0; i < log.lh.n; i++) {
80102d55:	83 c4 10             	add    $0x10,%esp
  log.lh.n = lh->n;
80102d58:	8b 58 5c             	mov    0x5c(%eax),%ebx
80102d5b:	89 1d 08 27 11 80    	mov    %ebx,0x80112708
  for (i = 0; i < log.lh.n; i++) {
80102d61:	85 db                	test   %ebx,%ebx
80102d63:	7e 1d                	jle    80102d82 <initlog+0x72>
80102d65:	31 d2                	xor    %edx,%edx
80102d67:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102d6e:	00 
80102d6f:	90                   	nop
    log.lh.block[i] = lh->block[i];
80102d70:	8b 4c 90 60          	mov    0x60(%eax,%edx,4),%ecx
80102d74:	89 0c 95 0c 27 11 80 	mov    %ecx,-0x7feed8f4(,%edx,4)
  for (i = 0; i < log.lh.n; i++) {
80102d7b:	83 c2 01             	add    $0x1,%edx
80102d7e:	39 d3                	cmp    %edx,%ebx
80102d80:	75 ee                	jne    80102d70 <initlog+0x60>
  brelse(buf);
80102d82:	83 ec 0c             	sub    $0xc,%esp
80102d85:	50                   	push   %eax
80102d86:	e8 65 d4 ff ff       	call   801001f0 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(); // if committed, copy from log to disk
80102d8b:	e8 80 fe ff ff       	call   80102c10 <install_trans>
  log.lh.n = 0;
80102d90:	c7 05 08 27 11 80 00 	movl   $0x0,0x80112708
80102d97:	00 00 00 
  write_head(); // clear the log
80102d9a:	e8 11 ff ff ff       	call   80102cb0 <write_head>
}
80102d9f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80102da2:	83 c4 10             	add    $0x10,%esp
80102da5:	c9                   	leave
80102da6:	c3                   	ret
80102da7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102dae:	00 
80102daf:	90                   	nop

80102db0 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
80102db0:	55                   	push   %ebp
80102db1:	89 e5                	mov    %esp,%ebp
80102db3:	83 ec 14             	sub    $0x14,%esp
  acquire(&log.lock);
80102db6:	68 c0 26 11 80       	push   $0x801126c0
80102dbb:	e8 30 19 00 00       	call   801046f0 <acquire>
80102dc0:	83 c4 10             	add    $0x10,%esp
80102dc3:	eb 18                	jmp    80102ddd <begin_op+0x2d>
80102dc5:	8d 76 00             	lea    0x0(%esi),%esi
  while(1){
    if(log.committing){
      sleep(&log, &log.lock);
80102dc8:	83 ec 08             	sub    $0x8,%esp
80102dcb:	68 c0 26 11 80       	push   $0x801126c0
80102dd0:	68 c0 26 11 80       	push   $0x801126c0
80102dd5:	e8 16 13 00 00       	call   801040f0 <sleep>
80102dda:	83 c4 10             	add    $0x10,%esp
    if(log.committing){
80102ddd:	a1 00 27 11 80       	mov    0x80112700,%eax
80102de2:	85 c0                	test   %eax,%eax
80102de4:	75 e2                	jne    80102dc8 <begin_op+0x18>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
80102de6:	a1 fc 26 11 80       	mov    0x801126fc,%eax
80102deb:	8b 15 08 27 11 80    	mov    0x80112708,%edx
80102df1:	83 c0 01             	add    $0x1,%eax
80102df4:	8d 0c 80             	lea    (%eax,%eax,4),%ecx
80102df7:	8d 14 4a             	lea    (%edx,%ecx,2),%edx
80102dfa:	83 fa 1e             	cmp    $0x1e,%edx
80102dfd:	7f c9                	jg     80102dc8 <begin_op+0x18>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    } else {
      log.outstanding += 1;
      release(&log.lock);
80102dff:	83 ec 0c             	sub    $0xc,%esp
      log.outstanding += 1;
80102e02:	a3 fc 26 11 80       	mov    %eax,0x801126fc
      release(&log.lock);
80102e07:	68 c0 26 11 80       	push   $0x801126c0
80102e0c:	e8 7f 18 00 00       	call   80104690 <release>
      break;
    }
  }
}
80102e11:	83 c4 10             	add    $0x10,%esp
80102e14:	c9                   	leave
80102e15:	c3                   	ret
80102e16:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102e1d:	00 
80102e1e:	66 90                	xchg   %ax,%ax

80102e20 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
80102e20:	55                   	push   %ebp
80102e21:	89 e5                	mov    %esp,%ebp
80102e23:	57                   	push   %edi
80102e24:	56                   	push   %esi
80102e25:	53                   	push   %ebx
80102e26:	83 ec 18             	sub    $0x18,%esp
  int do_commit = 0;

  acquire(&log.lock);
80102e29:	68 c0 26 11 80       	push   $0x801126c0
80102e2e:	e8 bd 18 00 00       	call   801046f0 <acquire>
  log.outstanding -= 1;
80102e33:	a1 fc 26 11 80       	mov    0x801126fc,%eax
  if(log.committing)
80102e38:	8b 35 00 27 11 80    	mov    0x80112700,%esi
80102e3e:	83 c4 10             	add    $0x10,%esp
  log.outstanding -= 1;
80102e41:	8d 58 ff             	lea    -0x1(%eax),%ebx
80102e44:	89 1d fc 26 11 80    	mov    %ebx,0x801126fc
  if(log.committing)
80102e4a:	85 f6                	test   %esi,%esi
80102e4c:	0f 85 22 01 00 00    	jne    80102f74 <end_op+0x154>
    panic("log.committing");
  if(log.outstanding == 0){
80102e52:	85 db                	test   %ebx,%ebx
80102e54:	0f 85 f6 00 00 00    	jne    80102f50 <end_op+0x130>
    do_commit = 1;
    log.committing = 1;
80102e5a:	c7 05 00 27 11 80 01 	movl   $0x1,0x80112700
80102e61:	00 00 00 
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
80102e64:	83 ec 0c             	sub    $0xc,%esp
80102e67:	68 c0 26 11 80       	push   $0x801126c0
80102e6c:	e8 1f 18 00 00       	call   80104690 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
80102e71:	8b 0d 08 27 11 80    	mov    0x80112708,%ecx
80102e77:	83 c4 10             	add    $0x10,%esp
80102e7a:	85 c9                	test   %ecx,%ecx
80102e7c:	7f 42                	jg     80102ec0 <end_op+0xa0>
    acquire(&log.lock);
80102e7e:	83 ec 0c             	sub    $0xc,%esp
80102e81:	68 c0 26 11 80       	push   $0x801126c0
80102e86:	e8 65 18 00 00       	call   801046f0 <acquire>
    log.committing = 0;
80102e8b:	c7 05 00 27 11 80 00 	movl   $0x0,0x80112700
80102e92:	00 00 00 
    wakeup(&log);
80102e95:	c7 04 24 c0 26 11 80 	movl   $0x801126c0,(%esp)
80102e9c:	e8 0f 13 00 00       	call   801041b0 <wakeup>
    release(&log.lock);
80102ea1:	c7 04 24 c0 26 11 80 	movl   $0x801126c0,(%esp)
80102ea8:	e8 e3 17 00 00       	call   80104690 <release>
80102ead:	83 c4 10             	add    $0x10,%esp
}
80102eb0:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102eb3:	5b                   	pop    %ebx
80102eb4:	5e                   	pop    %esi
80102eb5:	5f                   	pop    %edi
80102eb6:	5d                   	pop    %ebp
80102eb7:	c3                   	ret
80102eb8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102ebf:	00 
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
80102ec0:	a1 f4 26 11 80       	mov    0x801126f4,%eax
80102ec5:	83 ec 08             	sub    $0x8,%esp
80102ec8:	01 d8                	add    %ebx,%eax
80102eca:	83 c0 01             	add    $0x1,%eax
80102ecd:	50                   	push   %eax
80102ece:	ff 35 04 27 11 80    	push   0x80112704
80102ed4:	e8 f7 d1 ff ff       	call   801000d0 <bread>
80102ed9:	89 c6                	mov    %eax,%esi
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80102edb:	58                   	pop    %eax
80102edc:	5a                   	pop    %edx
80102edd:	ff 34 9d 0c 27 11 80 	push   -0x7feed8f4(,%ebx,4)
80102ee4:	ff 35 04 27 11 80    	push   0x80112704
  for (tail = 0; tail < log.lh.n; tail++) {
80102eea:	83 c3 01             	add    $0x1,%ebx
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80102eed:	e8 de d1 ff ff       	call   801000d0 <bread>
    memmove(to->data, from->data, BSIZE);
80102ef2:	83 c4 0c             	add    $0xc,%esp
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
80102ef5:	89 c7                	mov    %eax,%edi
    memmove(to->data, from->data, BSIZE);
80102ef7:	8d 40 5c             	lea    0x5c(%eax),%eax
80102efa:	68 00 02 00 00       	push   $0x200
80102eff:	50                   	push   %eax
80102f00:	8d 46 5c             	lea    0x5c(%esi),%eax
80102f03:	50                   	push   %eax
80102f04:	e8 77 19 00 00       	call   80104880 <memmove>
    bwrite(to);  // write the log
80102f09:	89 34 24             	mov    %esi,(%esp)
80102f0c:	e8 9f d2 ff ff       	call   801001b0 <bwrite>
    brelse(from);
80102f11:	89 3c 24             	mov    %edi,(%esp)
80102f14:	e8 d7 d2 ff ff       	call   801001f0 <brelse>
    brelse(to);
80102f19:	89 34 24             	mov    %esi,(%esp)
80102f1c:	e8 cf d2 ff ff       	call   801001f0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
80102f21:	83 c4 10             	add    $0x10,%esp
80102f24:	3b 1d 08 27 11 80    	cmp    0x80112708,%ebx
80102f2a:	7c 94                	jl     80102ec0 <end_op+0xa0>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
80102f2c:	e8 7f fd ff ff       	call   80102cb0 <write_head>
    install_trans(); // Now install writes to home locations
80102f31:	e8 da fc ff ff       	call   80102c10 <install_trans>
    log.lh.n = 0;
80102f36:	c7 05 08 27 11 80 00 	movl   $0x0,0x80112708
80102f3d:	00 00 00 
    write_head();    // Erase the transaction from the log
80102f40:	e8 6b fd ff ff       	call   80102cb0 <write_head>
80102f45:	e9 34 ff ff ff       	jmp    80102e7e <end_op+0x5e>
80102f4a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    wakeup(&log);
80102f50:	83 ec 0c             	sub    $0xc,%esp
80102f53:	68 c0 26 11 80       	push   $0x801126c0
80102f58:	e8 53 12 00 00       	call   801041b0 <wakeup>
  release(&log.lock);
80102f5d:	c7 04 24 c0 26 11 80 	movl   $0x801126c0,(%esp)
80102f64:	e8 27 17 00 00       	call   80104690 <release>
80102f69:	83 c4 10             	add    $0x10,%esp
}
80102f6c:	8d 65 f4             	lea    -0xc(%ebp),%esp
80102f6f:	5b                   	pop    %ebx
80102f70:	5e                   	pop    %esi
80102f71:	5f                   	pop    %edi
80102f72:	5d                   	pop    %ebp
80102f73:	c3                   	ret
    panic("log.committing");
80102f74:	83 ec 0c             	sub    $0xc,%esp
80102f77:	68 fb 79 10 80       	push   $0x801079fb
80102f7c:	e8 ff d3 ff ff       	call   80100380 <panic>
80102f81:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80102f88:	00 
80102f89:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80102f90 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
80102f90:	55                   	push   %ebp
80102f91:	89 e5                	mov    %esp,%ebp
80102f93:	53                   	push   %ebx
80102f94:	83 ec 04             	sub    $0x4,%esp
  int i;

  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80102f97:	8b 15 08 27 11 80    	mov    0x80112708,%edx
{
80102f9d:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
80102fa0:	83 fa 1d             	cmp    $0x1d,%edx
80102fa3:	7f 7d                	jg     80103022 <log_write+0x92>
80102fa5:	a1 f8 26 11 80       	mov    0x801126f8,%eax
80102faa:	83 e8 01             	sub    $0x1,%eax
80102fad:	39 c2                	cmp    %eax,%edx
80102faf:	7d 71                	jge    80103022 <log_write+0x92>
    panic("too big a transaction");
  if (log.outstanding < 1)
80102fb1:	a1 fc 26 11 80       	mov    0x801126fc,%eax
80102fb6:	85 c0                	test   %eax,%eax
80102fb8:	7e 75                	jle    8010302f <log_write+0x9f>
    panic("log_write outside of trans");

  acquire(&log.lock);
80102fba:	83 ec 0c             	sub    $0xc,%esp
80102fbd:	68 c0 26 11 80       	push   $0x801126c0
80102fc2:	e8 29 17 00 00       	call   801046f0 <acquire>
  for (i = 0; i < log.lh.n; i++) {
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80102fc7:	8b 4b 08             	mov    0x8(%ebx),%ecx
  for (i = 0; i < log.lh.n; i++) {
80102fca:	83 c4 10             	add    $0x10,%esp
80102fcd:	31 c0                	xor    %eax,%eax
80102fcf:	8b 15 08 27 11 80    	mov    0x80112708,%edx
80102fd5:	85 d2                	test   %edx,%edx
80102fd7:	7f 0e                	jg     80102fe7 <log_write+0x57>
80102fd9:	eb 15                	jmp    80102ff0 <log_write+0x60>
80102fdb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80102fe0:	83 c0 01             	add    $0x1,%eax
80102fe3:	39 c2                	cmp    %eax,%edx
80102fe5:	74 29                	je     80103010 <log_write+0x80>
    if (log.lh.block[i] == b->blockno)   // log absorbtion
80102fe7:	39 0c 85 0c 27 11 80 	cmp    %ecx,-0x7feed8f4(,%eax,4)
80102fee:	75 f0                	jne    80102fe0 <log_write+0x50>
      break;
  }
  log.lh.block[i] = b->blockno;
80102ff0:	89 0c 85 0c 27 11 80 	mov    %ecx,-0x7feed8f4(,%eax,4)
  if (i == log.lh.n)
80102ff7:	39 c2                	cmp    %eax,%edx
80102ff9:	74 1c                	je     80103017 <log_write+0x87>
    log.lh.n++;
  b->flags |= B_DIRTY; // prevent eviction
80102ffb:	83 0b 04             	orl    $0x4,(%ebx)
  release(&log.lock);
}
80102ffe:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  release(&log.lock);
80103001:	c7 45 08 c0 26 11 80 	movl   $0x801126c0,0x8(%ebp)
}
80103008:	c9                   	leave
  release(&log.lock);
80103009:	e9 82 16 00 00       	jmp    80104690 <release>
8010300e:	66 90                	xchg   %ax,%ax
  log.lh.block[i] = b->blockno;
80103010:	89 0c 95 0c 27 11 80 	mov    %ecx,-0x7feed8f4(,%edx,4)
    log.lh.n++;
80103017:	83 c2 01             	add    $0x1,%edx
8010301a:	89 15 08 27 11 80    	mov    %edx,0x80112708
80103020:	eb d9                	jmp    80102ffb <log_write+0x6b>
    panic("too big a transaction");
80103022:	83 ec 0c             	sub    $0xc,%esp
80103025:	68 0a 7a 10 80       	push   $0x80107a0a
8010302a:	e8 51 d3 ff ff       	call   80100380 <panic>
    panic("log_write outside of trans");
8010302f:	83 ec 0c             	sub    $0xc,%esp
80103032:	68 20 7a 10 80       	push   $0x80107a20
80103037:	e8 44 d3 ff ff       	call   80100380 <panic>
8010303c:	66 90                	xchg   %ax,%ax
8010303e:	66 90                	xchg   %ax,%ax

80103040 <mpmain>:
}

// Common CPU setup code.
static void
mpmain(void)
{
80103040:	55                   	push   %ebp
80103041:	89 e5                	mov    %esp,%ebp
80103043:	53                   	push   %ebx
80103044:	83 ec 04             	sub    $0x4,%esp
  cprintf("cpu%d: starting %d\n", cpuid(), cpuid());
80103047:	e8 84 09 00 00       	call   801039d0 <cpuid>
8010304c:	89 c3                	mov    %eax,%ebx
8010304e:	e8 7d 09 00 00       	call   801039d0 <cpuid>
80103053:	83 ec 04             	sub    $0x4,%esp
80103056:	53                   	push   %ebx
80103057:	50                   	push   %eax
80103058:	68 3b 7a 10 80       	push   $0x80107a3b
8010305d:	e8 4e d6 ff ff       	call   801006b0 <cprintf>
  idtinit();       // load idt register
80103062:	e8 69 2b 00 00       	call   80105bd0 <idtinit>
  xchg(&(mycpu()->started), 1); // tell startothers() we're up
80103067:	e8 04 09 00 00       	call   80103970 <mycpu>
8010306c:	89 c2                	mov    %eax,%edx
xchg(volatile uint *addr, uint newval)
{
  uint result;

  // The + in "+m" denotes a read-modify-write operand.
  asm volatile("lock; xchgl %0, %1" :
8010306e:	b8 01 00 00 00       	mov    $0x1,%eax
80103073:	f0 87 82 a0 00 00 00 	lock xchg %eax,0xa0(%edx)
  scheduler();     // start running processes
8010307a:	e8 21 0c 00 00       	call   80103ca0 <scheduler>
8010307f:	90                   	nop

80103080 <mpenter>:
{
80103080:	55                   	push   %ebp
80103081:	89 e5                	mov    %esp,%ebp
80103083:	83 ec 08             	sub    $0x8,%esp
  switchkvm();
80103086:	e8 c5 3c 00 00       	call   80106d50 <switchkvm>
  seginit();
8010308b:	e8 40 3b 00 00       	call   80106bd0 <seginit>
  lapicinit();
80103090:	e8 bb f7 ff ff       	call   80102850 <lapicinit>
  mpmain();
80103095:	e8 a6 ff ff ff       	call   80103040 <mpmain>
8010309a:	66 90                	xchg   %ax,%ax
8010309c:	66 90                	xchg   %ax,%ax
8010309e:	66 90                	xchg   %ax,%ax

801030a0 <main>:
{
801030a0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
801030a4:	83 e4 f0             	and    $0xfffffff0,%esp
801030a7:	ff 71 fc             	push   -0x4(%ecx)
801030aa:	55                   	push   %ebp
801030ab:	89 e5                	mov    %esp,%ebp
801030ad:	53                   	push   %ebx
801030ae:	51                   	push   %ecx
  kinit1(end, P2V(4*1024*1024)); // phys page allocator
801030af:	83 ec 08             	sub    $0x8,%esp
801030b2:	68 00 00 40 80       	push   $0x80400000
801030b7:	68 80 68 11 80       	push   $0x80116880
801030bc:	e8 3f f5 ff ff       	call   80102600 <kinit1>
  kvmalloc();      // kernel page table
801030c1:	e8 4a 41 00 00       	call   80107210 <kvmalloc>
  mpinit();        // detect other processors
801030c6:	e8 85 01 00 00       	call   80103250 <mpinit>
  lapicinit();     // interrupt controller
801030cb:	e8 80 f7 ff ff       	call   80102850 <lapicinit>
  seginit();       // segment descriptors
801030d0:	e8 fb 3a 00 00       	call   80106bd0 <seginit>
  picinit();       // disable pic
801030d5:	e8 86 03 00 00       	call   80103460 <picinit>
  ioapicinit();    // another interrupt controller
801030da:	e8 e1 f2 ff ff       	call   801023c0 <ioapicinit>
  consoleinit();   // console hardware
801030df:	e8 7c d9 ff ff       	call   80100a60 <consoleinit>
  uartinit();      // serial port
801030e4:	e8 67 2e 00 00       	call   80105f50 <uartinit>
  pinit();         // process table
801030e9:	e8 62 08 00 00       	call   80103950 <pinit>
  tvinit();        // trap vectors
801030ee:	e8 5d 2a 00 00       	call   80105b50 <tvinit>
  seminit();
801030f3:	e8 58 45 00 00       	call   80107650 <seminit>
  binit();         // buffer cache
801030f8:	e8 43 cf ff ff       	call   80100040 <binit>
  fileinit();      // file table
801030fd:	e8 2e dd ff ff       	call   80100e30 <fileinit>
  ideinit();       // disk 
80103102:	e8 99 f0 ff ff       	call   801021a0 <ideinit>

  // Write entry code to unused memory at 0x7000.
  // The linker has placed the image of entryother.S in
  // _binary_entryother_start.
  code = P2V(0x7000);
  memmove(code, _binary_entryother_start, (uint)_binary_entryother_size);
80103107:	83 c4 0c             	add    $0xc,%esp
8010310a:	68 8a 00 00 00       	push   $0x8a
8010310f:	68 8c b4 10 80       	push   $0x8010b48c
80103114:	68 00 70 00 80       	push   $0x80007000
80103119:	e8 62 17 00 00       	call   80104880 <memmove>

  for(c = cpus; c < cpus+ncpu; c++){
8010311e:	83 c4 10             	add    $0x10,%esp
80103121:	69 05 a4 27 11 80 b0 	imul   $0xb0,0x801127a4,%eax
80103128:	00 00 00 
8010312b:	05 c0 27 11 80       	add    $0x801127c0,%eax
80103130:	3d c0 27 11 80       	cmp    $0x801127c0,%eax
80103135:	76 79                	jbe    801031b0 <main+0x110>
80103137:	bb c0 27 11 80       	mov    $0x801127c0,%ebx
8010313c:	eb 1b                	jmp    80103159 <main+0xb9>
8010313e:	66 90                	xchg   %ax,%ax
80103140:	69 05 a4 27 11 80 b0 	imul   $0xb0,0x801127a4,%eax
80103147:	00 00 00 
8010314a:	81 c3 b0 00 00 00    	add    $0xb0,%ebx
80103150:	05 c0 27 11 80       	add    $0x801127c0,%eax
80103155:	39 c3                	cmp    %eax,%ebx
80103157:	73 57                	jae    801031b0 <main+0x110>
    if(c == mycpu())  // We've started already.
80103159:	e8 12 08 00 00       	call   80103970 <mycpu>
8010315e:	39 c3                	cmp    %eax,%ebx
80103160:	74 de                	je     80103140 <main+0xa0>
      continue;

    // Tell entryother.S what stack to use, where to enter, and what
    // pgdir to use. We cannot use kpgdir yet, because the AP processor
    // is running in low  memory, so we use entrypgdir for the APs too.
    stack = kalloc();
80103162:	e8 09 f5 ff ff       	call   80102670 <kalloc>
    *(void**)(code-4) = stack + KSTACKSIZE;
    *(void(**)(void))(code-8) = mpenter;
    *(int**)(code-12) = (void *) V2P(entrypgdir);

    lapicstartap(c->apicid, V2P(code));
80103167:	83 ec 08             	sub    $0x8,%esp
    *(void(**)(void))(code-8) = mpenter;
8010316a:	c7 05 f8 6f 00 80 80 	movl   $0x80103080,0x80006ff8
80103171:	30 10 80 
    *(int**)(code-12) = (void *) V2P(entrypgdir);
80103174:	c7 05 f4 6f 00 80 00 	movl   $0x10a000,0x80006ff4
8010317b:	a0 10 00 
    *(void**)(code-4) = stack + KSTACKSIZE;
8010317e:	05 00 10 00 00       	add    $0x1000,%eax
80103183:	a3 fc 6f 00 80       	mov    %eax,0x80006ffc
    lapicstartap(c->apicid, V2P(code));
80103188:	0f b6 03             	movzbl (%ebx),%eax
8010318b:	68 00 70 00 00       	push   $0x7000
80103190:	50                   	push   %eax
80103191:	e8 fa f7 ff ff       	call   80102990 <lapicstartap>

    // wait for cpu to finish mpmain()
    while(c->started == 0)
80103196:	83 c4 10             	add    $0x10,%esp
80103199:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801031a0:	8b 83 a0 00 00 00    	mov    0xa0(%ebx),%eax
801031a6:	85 c0                	test   %eax,%eax
801031a8:	74 f6                	je     801031a0 <main+0x100>
801031aa:	eb 94                	jmp    80103140 <main+0xa0>
801031ac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  kinit2(P2V(4*1024*1024), P2V(PHYSTOP)); // must come after startothers()
801031b0:	83 ec 08             	sub    $0x8,%esp
801031b3:	68 00 00 00 8e       	push   $0x8e000000
801031b8:	68 00 00 40 80       	push   $0x80400000
801031bd:	e8 de f3 ff ff       	call   801025a0 <kinit2>
  userinit();      // first user process
801031c2:	e8 59 08 00 00       	call   80103a20 <userinit>
  mpmain();        // finish this processor's setup
801031c7:	e8 74 fe ff ff       	call   80103040 <mpmain>
801031cc:	66 90                	xchg   %ax,%ax
801031ce:	66 90                	xchg   %ax,%ax

801031d0 <mpsearch1>:
}

// Look for an MP structure in the len bytes at addr.
static struct mp*
mpsearch1(uint a, int len)
{
801031d0:	55                   	push   %ebp
801031d1:	89 e5                	mov    %esp,%ebp
801031d3:	57                   	push   %edi
801031d4:	56                   	push   %esi
  uchar *e, *p, *addr;

  addr = P2V(a);
801031d5:	8d b0 00 00 00 80    	lea    -0x80000000(%eax),%esi
{
801031db:	53                   	push   %ebx
  e = addr+len;
801031dc:	8d 1c 16             	lea    (%esi,%edx,1),%ebx
{
801031df:	83 ec 0c             	sub    $0xc,%esp
  for(p = addr; p < e; p += sizeof(struct mp))
801031e2:	39 de                	cmp    %ebx,%esi
801031e4:	72 10                	jb     801031f6 <mpsearch1+0x26>
801031e6:	eb 50                	jmp    80103238 <mpsearch1+0x68>
801031e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801031ef:	00 
801031f0:	89 fe                	mov    %edi,%esi
801031f2:	39 df                	cmp    %ebx,%edi
801031f4:	73 42                	jae    80103238 <mpsearch1+0x68>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
801031f6:	83 ec 04             	sub    $0x4,%esp
801031f9:	8d 7e 10             	lea    0x10(%esi),%edi
801031fc:	6a 04                	push   $0x4
801031fe:	68 4f 7a 10 80       	push   $0x80107a4f
80103203:	56                   	push   %esi
80103204:	e8 27 16 00 00       	call   80104830 <memcmp>
80103209:	83 c4 10             	add    $0x10,%esp
8010320c:	85 c0                	test   %eax,%eax
8010320e:	75 e0                	jne    801031f0 <mpsearch1+0x20>
80103210:	89 f2                	mov    %esi,%edx
80103212:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    sum += addr[i];
80103218:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
8010321b:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
8010321e:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
80103220:	39 fa                	cmp    %edi,%edx
80103222:	75 f4                	jne    80103218 <mpsearch1+0x48>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
80103224:	84 c0                	test   %al,%al
80103226:	75 c8                	jne    801031f0 <mpsearch1+0x20>
      return (struct mp*)p;
  return 0;
}
80103228:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010322b:	89 f0                	mov    %esi,%eax
8010322d:	5b                   	pop    %ebx
8010322e:	5e                   	pop    %esi
8010322f:	5f                   	pop    %edi
80103230:	5d                   	pop    %ebp
80103231:	c3                   	ret
80103232:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80103238:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
8010323b:	31 f6                	xor    %esi,%esi
}
8010323d:	5b                   	pop    %ebx
8010323e:	89 f0                	mov    %esi,%eax
80103240:	5e                   	pop    %esi
80103241:	5f                   	pop    %edi
80103242:	5d                   	pop    %ebp
80103243:	c3                   	ret
80103244:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010324b:	00 
8010324c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80103250 <mpinit>:
  return conf;
}

void
mpinit(void)
{
80103250:	55                   	push   %ebp
80103251:	89 e5                	mov    %esp,%ebp
80103253:	57                   	push   %edi
80103254:	56                   	push   %esi
80103255:	53                   	push   %ebx
80103256:	83 ec 1c             	sub    $0x1c,%esp
  if((p = ((bda[0x0F]<<8)| bda[0x0E]) << 4)){
80103259:	0f b6 05 0f 04 00 80 	movzbl 0x8000040f,%eax
80103260:	0f b6 15 0e 04 00 80 	movzbl 0x8000040e,%edx
80103267:	c1 e0 08             	shl    $0x8,%eax
8010326a:	09 d0                	or     %edx,%eax
8010326c:	c1 e0 04             	shl    $0x4,%eax
8010326f:	75 1b                	jne    8010328c <mpinit+0x3c>
    p = ((bda[0x14]<<8)|bda[0x13])*1024;
80103271:	0f b6 05 14 04 00 80 	movzbl 0x80000414,%eax
80103278:	0f b6 15 13 04 00 80 	movzbl 0x80000413,%edx
8010327f:	c1 e0 08             	shl    $0x8,%eax
80103282:	09 d0                	or     %edx,%eax
80103284:	c1 e0 0a             	shl    $0xa,%eax
    if((mp = mpsearch1(p-1024, 1024)))
80103287:	2d 00 04 00 00       	sub    $0x400,%eax
    if((mp = mpsearch1(p, 1024)))
8010328c:	ba 00 04 00 00       	mov    $0x400,%edx
80103291:	e8 3a ff ff ff       	call   801031d0 <mpsearch1>
80103296:	89 c3                	mov    %eax,%ebx
80103298:	85 c0                	test   %eax,%eax
8010329a:	0f 84 58 01 00 00    	je     801033f8 <mpinit+0x1a8>
  if((mp = mpsearch()) == 0 || mp->physaddr == 0)
801032a0:	8b 73 04             	mov    0x4(%ebx),%esi
801032a3:	85 f6                	test   %esi,%esi
801032a5:	0f 84 3d 01 00 00    	je     801033e8 <mpinit+0x198>
  if(memcmp(conf, "PCMP", 4) != 0)
801032ab:	83 ec 04             	sub    $0x4,%esp
  conf = (struct mpconf*) P2V((uint) mp->physaddr);
801032ae:	8d 86 00 00 00 80    	lea    -0x80000000(%esi),%eax
801032b4:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  if(memcmp(conf, "PCMP", 4) != 0)
801032b7:	6a 04                	push   $0x4
801032b9:	68 54 7a 10 80       	push   $0x80107a54
801032be:	50                   	push   %eax
801032bf:	e8 6c 15 00 00       	call   80104830 <memcmp>
801032c4:	83 c4 10             	add    $0x10,%esp
801032c7:	85 c0                	test   %eax,%eax
801032c9:	0f 85 19 01 00 00    	jne    801033e8 <mpinit+0x198>
  if(conf->version != 1 && conf->version != 4)
801032cf:	0f b6 86 06 00 00 80 	movzbl -0x7ffffffa(%esi),%eax
801032d6:	3c 01                	cmp    $0x1,%al
801032d8:	74 08                	je     801032e2 <mpinit+0x92>
801032da:	3c 04                	cmp    $0x4,%al
801032dc:	0f 85 06 01 00 00    	jne    801033e8 <mpinit+0x198>
  if(sum((uchar*)conf, conf->length) != 0)
801032e2:	0f b7 96 04 00 00 80 	movzwl -0x7ffffffc(%esi),%edx
  for(i=0; i<len; i++)
801032e9:	66 85 d2             	test   %dx,%dx
801032ec:	74 22                	je     80103310 <mpinit+0xc0>
801032ee:	8d 3c 32             	lea    (%edx,%esi,1),%edi
801032f1:	89 f0                	mov    %esi,%eax
  sum = 0;
801032f3:	31 d2                	xor    %edx,%edx
801032f5:	8d 76 00             	lea    0x0(%esi),%esi
    sum += addr[i];
801032f8:	0f b6 88 00 00 00 80 	movzbl -0x80000000(%eax),%ecx
  for(i=0; i<len; i++)
801032ff:	83 c0 01             	add    $0x1,%eax
    sum += addr[i];
80103302:	01 ca                	add    %ecx,%edx
  for(i=0; i<len; i++)
80103304:	39 f8                	cmp    %edi,%eax
80103306:	75 f0                	jne    801032f8 <mpinit+0xa8>
  if(sum((uchar*)conf, conf->length) != 0)
80103308:	84 d2                	test   %dl,%dl
8010330a:	0f 85 d8 00 00 00    	jne    801033e8 <mpinit+0x198>
  struct mpioapic *ioapic;

  if((conf = mpconfig(&mp)) == 0)
    panic("Expect to run on an SMP");
  ismp = 1;
  lapic = (uint*)conf->lapicaddr;
80103310:	8b 86 24 00 00 80    	mov    -0x7fffffdc(%esi),%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103316:	8b 7d e4             	mov    -0x1c(%ebp),%edi
80103319:	89 5d e4             	mov    %ebx,-0x1c(%ebp)
  lapic = (uint*)conf->lapicaddr;
8010331c:	a3 a0 26 11 80       	mov    %eax,0x801126a0
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103321:	0f b7 96 04 00 00 80 	movzwl -0x7ffffffc(%esi),%edx
80103328:	8d 86 2c 00 00 80    	lea    -0x7fffffd4(%esi),%eax
8010332e:	01 d7                	add    %edx,%edi
80103330:	89 fa                	mov    %edi,%edx
  ismp = 1;
80103332:	bf 01 00 00 00       	mov    $0x1,%edi
80103337:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010333e:	00 
8010333f:	90                   	nop
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103340:	39 d0                	cmp    %edx,%eax
80103342:	73 19                	jae    8010335d <mpinit+0x10d>
    switch(*p){
80103344:	0f b6 08             	movzbl (%eax),%ecx
80103347:	80 f9 02             	cmp    $0x2,%cl
8010334a:	0f 84 80 00 00 00    	je     801033d0 <mpinit+0x180>
80103350:	77 6e                	ja     801033c0 <mpinit+0x170>
80103352:	84 c9                	test   %cl,%cl
80103354:	74 3a                	je     80103390 <mpinit+0x140>
      p += sizeof(struct mpioapic);
      continue;
    case MPBUS:
    case MPIOINTR:
    case MPLINTR:
      p += 8;
80103356:	83 c0 08             	add    $0x8,%eax
  for(p=(uchar*)(conf+1), e=(uchar*)conf+conf->length; p<e; ){
80103359:	39 d0                	cmp    %edx,%eax
8010335b:	72 e7                	jb     80103344 <mpinit+0xf4>
    default:
      ismp = 0;
      break;
    }
  }
  if(!ismp)
8010335d:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80103360:	85 ff                	test   %edi,%edi
80103362:	0f 84 dd 00 00 00    	je     80103445 <mpinit+0x1f5>
    panic("Didn't find a suitable machine");

  if(mp->imcrp){
80103368:	80 7b 0c 00          	cmpb   $0x0,0xc(%ebx)
8010336c:	74 15                	je     80103383 <mpinit+0x133>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
8010336e:	b8 70 00 00 00       	mov    $0x70,%eax
80103373:	ba 22 00 00 00       	mov    $0x22,%edx
80103378:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80103379:	ba 23 00 00 00       	mov    $0x23,%edx
8010337e:	ec                   	in     (%dx),%al
    // Bochs doesn't support IMCR, so this doesn't run on Bochs.
    // But it would on real hardware.
    outb(0x22, 0x70);   // Select IMCR
    outb(0x23, inb(0x23) | 1);  // Mask external interrupts.
8010337f:	83 c8 01             	or     $0x1,%eax
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80103382:	ee                   	out    %al,(%dx)
  }
}
80103383:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103386:	5b                   	pop    %ebx
80103387:	5e                   	pop    %esi
80103388:	5f                   	pop    %edi
80103389:	5d                   	pop    %ebp
8010338a:	c3                   	ret
8010338b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(ncpu < NCPU) {
80103390:	8b 0d a4 27 11 80    	mov    0x801127a4,%ecx
80103396:	83 f9 07             	cmp    $0x7,%ecx
80103399:	7f 19                	jg     801033b4 <mpinit+0x164>
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
8010339b:	69 f1 b0 00 00 00    	imul   $0xb0,%ecx,%esi
801033a1:	0f b6 58 01          	movzbl 0x1(%eax),%ebx
        ncpu++;
801033a5:	83 c1 01             	add    $0x1,%ecx
801033a8:	89 0d a4 27 11 80    	mov    %ecx,0x801127a4
        cpus[ncpu].apicid = proc->apicid;  // apicid may differ from ncpu
801033ae:	88 9e c0 27 11 80    	mov    %bl,-0x7feed840(%esi)
      p += sizeof(struct mpproc);
801033b4:	83 c0 14             	add    $0x14,%eax
      continue;
801033b7:	eb 87                	jmp    80103340 <mpinit+0xf0>
801033b9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    switch(*p){
801033c0:	83 e9 03             	sub    $0x3,%ecx
801033c3:	80 f9 01             	cmp    $0x1,%cl
801033c6:	76 8e                	jbe    80103356 <mpinit+0x106>
801033c8:	31 ff                	xor    %edi,%edi
801033ca:	e9 71 ff ff ff       	jmp    80103340 <mpinit+0xf0>
801033cf:	90                   	nop
      ioapicid = ioapic->apicno;
801033d0:	0f b6 48 01          	movzbl 0x1(%eax),%ecx
      p += sizeof(struct mpioapic);
801033d4:	83 c0 08             	add    $0x8,%eax
      ioapicid = ioapic->apicno;
801033d7:	88 0d a0 27 11 80    	mov    %cl,0x801127a0
      continue;
801033dd:	e9 5e ff ff ff       	jmp    80103340 <mpinit+0xf0>
801033e2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    panic("Expect to run on an SMP");
801033e8:	83 ec 0c             	sub    $0xc,%esp
801033eb:	68 59 7a 10 80       	push   $0x80107a59
801033f0:	e8 8b cf ff ff       	call   80100380 <panic>
801033f5:	8d 76 00             	lea    0x0(%esi),%esi
{
801033f8:	bb 00 00 0f 80       	mov    $0x800f0000,%ebx
801033fd:	eb 0b                	jmp    8010340a <mpinit+0x1ba>
801033ff:	90                   	nop
  for(p = addr; p < e; p += sizeof(struct mp))
80103400:	89 f3                	mov    %esi,%ebx
80103402:	81 fe 00 00 10 80    	cmp    $0x80100000,%esi
80103408:	74 de                	je     801033e8 <mpinit+0x198>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
8010340a:	83 ec 04             	sub    $0x4,%esp
8010340d:	8d 73 10             	lea    0x10(%ebx),%esi
80103410:	6a 04                	push   $0x4
80103412:	68 4f 7a 10 80       	push   $0x80107a4f
80103417:	53                   	push   %ebx
80103418:	e8 13 14 00 00       	call   80104830 <memcmp>
8010341d:	83 c4 10             	add    $0x10,%esp
80103420:	85 c0                	test   %eax,%eax
80103422:	75 dc                	jne    80103400 <mpinit+0x1b0>
80103424:	89 da                	mov    %ebx,%edx
80103426:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010342d:	00 
8010342e:	66 90                	xchg   %ax,%ax
    sum += addr[i];
80103430:	0f b6 0a             	movzbl (%edx),%ecx
  for(i=0; i<len; i++)
80103433:	83 c2 01             	add    $0x1,%edx
    sum += addr[i];
80103436:	01 c8                	add    %ecx,%eax
  for(i=0; i<len; i++)
80103438:	39 d6                	cmp    %edx,%esi
8010343a:	75 f4                	jne    80103430 <mpinit+0x1e0>
    if(memcmp(p, "_MP_", 4) == 0 && sum(p, sizeof(struct mp)) == 0)
8010343c:	84 c0                	test   %al,%al
8010343e:	75 c0                	jne    80103400 <mpinit+0x1b0>
80103440:	e9 5b fe ff ff       	jmp    801032a0 <mpinit+0x50>
    panic("Didn't find a suitable machine");
80103445:	83 ec 0c             	sub    $0xc,%esp
80103448:	68 e8 7d 10 80       	push   $0x80107de8
8010344d:	e8 2e cf ff ff       	call   80100380 <panic>
80103452:	66 90                	xchg   %ax,%ax
80103454:	66 90                	xchg   %ax,%ax
80103456:	66 90                	xchg   %ax,%ax
80103458:	66 90                	xchg   %ax,%ax
8010345a:	66 90                	xchg   %ax,%ax
8010345c:	66 90                	xchg   %ax,%ax
8010345e:	66 90                	xchg   %ax,%ax

80103460 <picinit>:
80103460:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103465:	ba 21 00 00 00       	mov    $0x21,%edx
8010346a:	ee                   	out    %al,(%dx)
8010346b:	ba a1 00 00 00       	mov    $0xa1,%edx
80103470:	ee                   	out    %al,(%dx)
picinit(void)
{
  // mask all interrupts
  outb(IO_PIC1+1, 0xFF);
  outb(IO_PIC2+1, 0xFF);
}
80103471:	c3                   	ret
80103472:	66 90                	xchg   %ax,%ax
80103474:	66 90                	xchg   %ax,%ax
80103476:	66 90                	xchg   %ax,%ax
80103478:	66 90                	xchg   %ax,%ax
8010347a:	66 90                	xchg   %ax,%ax
8010347c:	66 90                	xchg   %ax,%ax
8010347e:	66 90                	xchg   %ax,%ax

80103480 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
80103480:	55                   	push   %ebp
80103481:	89 e5                	mov    %esp,%ebp
80103483:	57                   	push   %edi
80103484:	56                   	push   %esi
80103485:	53                   	push   %ebx
80103486:	83 ec 0c             	sub    $0xc,%esp
80103489:	8b 75 08             	mov    0x8(%ebp),%esi
8010348c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  struct pipe *p;

  p = 0;
  *f0 = *f1 = 0;
8010348f:	c7 07 00 00 00 00    	movl   $0x0,(%edi)
80103495:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
8010349b:	e8 b0 d9 ff ff       	call   80100e50 <filealloc>
801034a0:	89 06                	mov    %eax,(%esi)
801034a2:	85 c0                	test   %eax,%eax
801034a4:	0f 84 a5 00 00 00    	je     8010354f <pipealloc+0xcf>
801034aa:	e8 a1 d9 ff ff       	call   80100e50 <filealloc>
801034af:	89 07                	mov    %eax,(%edi)
801034b1:	85 c0                	test   %eax,%eax
801034b3:	0f 84 84 00 00 00    	je     8010353d <pipealloc+0xbd>
    goto bad;
  if((p = (struct pipe*)kalloc()) == 0)
801034b9:	e8 b2 f1 ff ff       	call   80102670 <kalloc>
801034be:	89 c3                	mov    %eax,%ebx
801034c0:	85 c0                	test   %eax,%eax
801034c2:	0f 84 a0 00 00 00    	je     80103568 <pipealloc+0xe8>
    goto bad;
  p->readopen = 1;
801034c8:	c7 80 3c 02 00 00 01 	movl   $0x1,0x23c(%eax)
801034cf:	00 00 00 
  p->writeopen = 1;
  p->nwrite = 0;
  p->nread = 0;
  initlock(&p->lock, "pipe");
801034d2:	83 ec 08             	sub    $0x8,%esp
  p->writeopen = 1;
801034d5:	c7 80 40 02 00 00 01 	movl   $0x1,0x240(%eax)
801034dc:	00 00 00 
  p->nwrite = 0;
801034df:	c7 80 38 02 00 00 00 	movl   $0x0,0x238(%eax)
801034e6:	00 00 00 
  p->nread = 0;
801034e9:	c7 80 34 02 00 00 00 	movl   $0x0,0x234(%eax)
801034f0:	00 00 00 
  initlock(&p->lock, "pipe");
801034f3:	68 71 7a 10 80       	push   $0x80107a71
801034f8:	50                   	push   %eax
801034f9:	e8 02 10 00 00       	call   80104500 <initlock>
  (*f0)->type = FD_PIPE;
801034fe:	8b 06                	mov    (%esi),%eax
  (*f0)->pipe = p;
  (*f1)->type = FD_PIPE;
  (*f1)->readable = 0;
  (*f1)->writable = 1;
  (*f1)->pipe = p;
  return 0;
80103500:	83 c4 10             	add    $0x10,%esp
  (*f0)->type = FD_PIPE;
80103503:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f0)->readable = 1;
80103509:	8b 06                	mov    (%esi),%eax
8010350b:	c6 40 08 01          	movb   $0x1,0x8(%eax)
  (*f0)->writable = 0;
8010350f:	8b 06                	mov    (%esi),%eax
80103511:	c6 40 09 00          	movb   $0x0,0x9(%eax)
  (*f0)->pipe = p;
80103515:	8b 06                	mov    (%esi),%eax
80103517:	89 58 0c             	mov    %ebx,0xc(%eax)
  (*f1)->type = FD_PIPE;
8010351a:	8b 07                	mov    (%edi),%eax
8010351c:	c7 00 01 00 00 00    	movl   $0x1,(%eax)
  (*f1)->readable = 0;
80103522:	8b 07                	mov    (%edi),%eax
80103524:	c6 40 08 00          	movb   $0x0,0x8(%eax)
  (*f1)->writable = 1;
80103528:	8b 07                	mov    (%edi),%eax
8010352a:	c6 40 09 01          	movb   $0x1,0x9(%eax)
  (*f1)->pipe = p;
8010352e:	8b 07                	mov    (%edi),%eax
80103530:	89 58 0c             	mov    %ebx,0xc(%eax)
  return 0;
80103533:	31 c0                	xor    %eax,%eax
  if(*f0)
    fileclose(*f0);
  if(*f1)
    fileclose(*f1);
  return -1;
}
80103535:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103538:	5b                   	pop    %ebx
80103539:	5e                   	pop    %esi
8010353a:	5f                   	pop    %edi
8010353b:	5d                   	pop    %ebp
8010353c:	c3                   	ret
  if(*f0)
8010353d:	8b 06                	mov    (%esi),%eax
8010353f:	85 c0                	test   %eax,%eax
80103541:	74 1e                	je     80103561 <pipealloc+0xe1>
    fileclose(*f0);
80103543:	83 ec 0c             	sub    $0xc,%esp
80103546:	50                   	push   %eax
80103547:	e8 c4 d9 ff ff       	call   80100f10 <fileclose>
8010354c:	83 c4 10             	add    $0x10,%esp
  if(*f1)
8010354f:	8b 07                	mov    (%edi),%eax
80103551:	85 c0                	test   %eax,%eax
80103553:	74 0c                	je     80103561 <pipealloc+0xe1>
    fileclose(*f1);
80103555:	83 ec 0c             	sub    $0xc,%esp
80103558:	50                   	push   %eax
80103559:	e8 b2 d9 ff ff       	call   80100f10 <fileclose>
8010355e:	83 c4 10             	add    $0x10,%esp
  return -1;
80103561:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103566:	eb cd                	jmp    80103535 <pipealloc+0xb5>
  if(*f0)
80103568:	8b 06                	mov    (%esi),%eax
8010356a:	85 c0                	test   %eax,%eax
8010356c:	75 d5                	jne    80103543 <pipealloc+0xc3>
8010356e:	eb df                	jmp    8010354f <pipealloc+0xcf>

80103570 <pipeclose>:

void
pipeclose(struct pipe *p, int writable)
{
80103570:	55                   	push   %ebp
80103571:	89 e5                	mov    %esp,%ebp
80103573:	56                   	push   %esi
80103574:	53                   	push   %ebx
80103575:	8b 5d 08             	mov    0x8(%ebp),%ebx
80103578:	8b 75 0c             	mov    0xc(%ebp),%esi
  acquire(&p->lock);
8010357b:	83 ec 0c             	sub    $0xc,%esp
8010357e:	53                   	push   %ebx
8010357f:	e8 6c 11 00 00       	call   801046f0 <acquire>
  if(writable){
80103584:	83 c4 10             	add    $0x10,%esp
80103587:	85 f6                	test   %esi,%esi
80103589:	74 65                	je     801035f0 <pipeclose+0x80>
    p->writeopen = 0;
    wakeup(&p->nread);
8010358b:	83 ec 0c             	sub    $0xc,%esp
8010358e:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
    p->writeopen = 0;
80103594:	c7 83 40 02 00 00 00 	movl   $0x0,0x240(%ebx)
8010359b:	00 00 00 
    wakeup(&p->nread);
8010359e:	50                   	push   %eax
8010359f:	e8 0c 0c 00 00       	call   801041b0 <wakeup>
801035a4:	83 c4 10             	add    $0x10,%esp
  } else {
    p->readopen = 0;
    wakeup(&p->nwrite);
  }
  if(p->readopen == 0 && p->writeopen == 0){
801035a7:	8b 93 3c 02 00 00    	mov    0x23c(%ebx),%edx
801035ad:	85 d2                	test   %edx,%edx
801035af:	75 0a                	jne    801035bb <pipeclose+0x4b>
801035b1:	8b 83 40 02 00 00    	mov    0x240(%ebx),%eax
801035b7:	85 c0                	test   %eax,%eax
801035b9:	74 15                	je     801035d0 <pipeclose+0x60>
    release(&p->lock);
    kfree((char*)p);
  } else
    release(&p->lock);
801035bb:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801035be:	8d 65 f8             	lea    -0x8(%ebp),%esp
801035c1:	5b                   	pop    %ebx
801035c2:	5e                   	pop    %esi
801035c3:	5d                   	pop    %ebp
    release(&p->lock);
801035c4:	e9 c7 10 00 00       	jmp    80104690 <release>
801035c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    release(&p->lock);
801035d0:	83 ec 0c             	sub    $0xc,%esp
801035d3:	53                   	push   %ebx
801035d4:	e8 b7 10 00 00       	call   80104690 <release>
    kfree((char*)p);
801035d9:	83 c4 10             	add    $0x10,%esp
801035dc:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
801035df:	8d 65 f8             	lea    -0x8(%ebp),%esp
801035e2:	5b                   	pop    %ebx
801035e3:	5e                   	pop    %esi
801035e4:	5d                   	pop    %ebp
    kfree((char*)p);
801035e5:	e9 b6 ee ff ff       	jmp    801024a0 <kfree>
801035ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    wakeup(&p->nwrite);
801035f0:	83 ec 0c             	sub    $0xc,%esp
801035f3:	8d 83 38 02 00 00    	lea    0x238(%ebx),%eax
    p->readopen = 0;
801035f9:	c7 83 3c 02 00 00 00 	movl   $0x0,0x23c(%ebx)
80103600:	00 00 00 
    wakeup(&p->nwrite);
80103603:	50                   	push   %eax
80103604:	e8 a7 0b 00 00       	call   801041b0 <wakeup>
80103609:	83 c4 10             	add    $0x10,%esp
8010360c:	eb 99                	jmp    801035a7 <pipeclose+0x37>
8010360e:	66 90                	xchg   %ax,%ax

80103610 <pipewrite>:

//PAGEBREAK: 40
int
pipewrite(struct pipe *p, char *addr, int n)
{
80103610:	55                   	push   %ebp
80103611:	89 e5                	mov    %esp,%ebp
80103613:	57                   	push   %edi
80103614:	56                   	push   %esi
80103615:	53                   	push   %ebx
80103616:	83 ec 28             	sub    $0x28,%esp
80103619:	8b 5d 08             	mov    0x8(%ebp),%ebx
8010361c:	8b 7d 10             	mov    0x10(%ebp),%edi
  int i;

  acquire(&p->lock);
8010361f:	53                   	push   %ebx
80103620:	e8 cb 10 00 00       	call   801046f0 <acquire>
  for(i = 0; i < n; i++){
80103625:	83 c4 10             	add    $0x10,%esp
80103628:	85 ff                	test   %edi,%edi
8010362a:	0f 8e ce 00 00 00    	jle    801036fe <pipewrite+0xee>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103630:	8b 83 38 02 00 00    	mov    0x238(%ebx),%eax
80103636:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80103639:	89 7d 10             	mov    %edi,0x10(%ebp)
8010363c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
8010363f:	8d 34 39             	lea    (%ecx,%edi,1),%esi
80103642:	89 75 e0             	mov    %esi,-0x20(%ebp)
      if(p->readopen == 0 || myproc()->killed){
        release(&p->lock);
        return -1;
      }
      wakeup(&p->nread);
80103645:	8d b3 34 02 00 00    	lea    0x234(%ebx),%esi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010364b:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80103651:	8d bb 38 02 00 00    	lea    0x238(%ebx),%edi
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
80103657:	8d 90 00 02 00 00    	lea    0x200(%eax),%edx
8010365d:	39 55 e4             	cmp    %edx,-0x1c(%ebp)
80103660:	0f 85 b6 00 00 00    	jne    8010371c <pipewrite+0x10c>
80103666:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80103669:	eb 3b                	jmp    801036a6 <pipewrite+0x96>
8010366b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      if(p->readopen == 0 || myproc()->killed){
80103670:	e8 7b 03 00 00       	call   801039f0 <myproc>
80103675:	8b 48 24             	mov    0x24(%eax),%ecx
80103678:	85 c9                	test   %ecx,%ecx
8010367a:	75 34                	jne    801036b0 <pipewrite+0xa0>
      wakeup(&p->nread);
8010367c:	83 ec 0c             	sub    $0xc,%esp
8010367f:	56                   	push   %esi
80103680:	e8 2b 0b 00 00       	call   801041b0 <wakeup>
      sleep(&p->nwrite, &p->lock);  //DOC: pipewrite-sleep
80103685:	58                   	pop    %eax
80103686:	5a                   	pop    %edx
80103687:	53                   	push   %ebx
80103688:	57                   	push   %edi
80103689:	e8 62 0a 00 00       	call   801040f0 <sleep>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010368e:	8b 83 34 02 00 00    	mov    0x234(%ebx),%eax
80103694:	8b 93 38 02 00 00    	mov    0x238(%ebx),%edx
8010369a:	83 c4 10             	add    $0x10,%esp
8010369d:	05 00 02 00 00       	add    $0x200,%eax
801036a2:	39 c2                	cmp    %eax,%edx
801036a4:	75 2a                	jne    801036d0 <pipewrite+0xc0>
      if(p->readopen == 0 || myproc()->killed){
801036a6:	8b 83 3c 02 00 00    	mov    0x23c(%ebx),%eax
801036ac:	85 c0                	test   %eax,%eax
801036ae:	75 c0                	jne    80103670 <pipewrite+0x60>
        release(&p->lock);
801036b0:	83 ec 0c             	sub    $0xc,%esp
801036b3:	53                   	push   %ebx
801036b4:	e8 d7 0f 00 00       	call   80104690 <release>
        return -1;
801036b9:	83 c4 10             	add    $0x10,%esp
801036bc:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
  }
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
  release(&p->lock);
  return n;
}
801036c1:	8d 65 f4             	lea    -0xc(%ebp),%esp
801036c4:	5b                   	pop    %ebx
801036c5:	5e                   	pop    %esi
801036c6:	5f                   	pop    %edi
801036c7:	5d                   	pop    %ebp
801036c8:	c3                   	ret
801036c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
801036d0:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
801036d3:	8d 42 01             	lea    0x1(%edx),%eax
801036d6:	81 e2 ff 01 00 00    	and    $0x1ff,%edx
  for(i = 0; i < n; i++){
801036dc:	83 c1 01             	add    $0x1,%ecx
    p->data[p->nwrite++ % PIPESIZE] = addr[i];
801036df:	89 83 38 02 00 00    	mov    %eax,0x238(%ebx)
801036e5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
801036e8:	0f b6 41 ff          	movzbl -0x1(%ecx),%eax
801036ec:	88 44 13 34          	mov    %al,0x34(%ebx,%edx,1)
  for(i = 0; i < n; i++){
801036f0:	8b 45 e0             	mov    -0x20(%ebp),%eax
801036f3:	39 c1                	cmp    %eax,%ecx
801036f5:	0f 85 50 ff ff ff    	jne    8010364b <pipewrite+0x3b>
801036fb:	8b 7d 10             	mov    0x10(%ebp),%edi
  wakeup(&p->nread);  //DOC: pipewrite-wakeup1
801036fe:	83 ec 0c             	sub    $0xc,%esp
80103701:	8d 83 34 02 00 00    	lea    0x234(%ebx),%eax
80103707:	50                   	push   %eax
80103708:	e8 a3 0a 00 00       	call   801041b0 <wakeup>
  release(&p->lock);
8010370d:	89 1c 24             	mov    %ebx,(%esp)
80103710:	e8 7b 0f 00 00       	call   80104690 <release>
  return n;
80103715:	83 c4 10             	add    $0x10,%esp
80103718:	89 f8                	mov    %edi,%eax
8010371a:	eb a5                	jmp    801036c1 <pipewrite+0xb1>
    while(p->nwrite == p->nread + PIPESIZE){  //DOC: pipewrite-full
8010371c:	8b 55 e4             	mov    -0x1c(%ebp),%edx
8010371f:	eb b2                	jmp    801036d3 <pipewrite+0xc3>
80103721:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103728:	00 
80103729:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80103730 <piperead>:

int
piperead(struct pipe *p, char *addr, int n)
{
80103730:	55                   	push   %ebp
80103731:	89 e5                	mov    %esp,%ebp
80103733:	57                   	push   %edi
80103734:	56                   	push   %esi
80103735:	53                   	push   %ebx
80103736:	83 ec 18             	sub    $0x18,%esp
80103739:	8b 75 08             	mov    0x8(%ebp),%esi
8010373c:	8b 7d 0c             	mov    0xc(%ebp),%edi
  int i;

  acquire(&p->lock);
8010373f:	56                   	push   %esi
80103740:	8d 9e 34 02 00 00    	lea    0x234(%esi),%ebx
80103746:	e8 a5 0f 00 00       	call   801046f0 <acquire>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
8010374b:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103751:	83 c4 10             	add    $0x10,%esp
80103754:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
8010375a:	74 2f                	je     8010378b <piperead+0x5b>
8010375c:	eb 37                	jmp    80103795 <piperead+0x65>
8010375e:	66 90                	xchg   %ax,%ax
    if(myproc()->killed){
80103760:	e8 8b 02 00 00       	call   801039f0 <myproc>
80103765:	8b 40 24             	mov    0x24(%eax),%eax
80103768:	85 c0                	test   %eax,%eax
8010376a:	0f 85 80 00 00 00    	jne    801037f0 <piperead+0xc0>
      release(&p->lock);
      return -1;
    }
    sleep(&p->nread, &p->lock); //DOC: piperead-sleep
80103770:	83 ec 08             	sub    $0x8,%esp
80103773:	56                   	push   %esi
80103774:	53                   	push   %ebx
80103775:	e8 76 09 00 00       	call   801040f0 <sleep>
  while(p->nread == p->nwrite && p->writeopen){  //DOC: pipe-empty
8010377a:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
80103780:	83 c4 10             	add    $0x10,%esp
80103783:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
80103789:	75 0a                	jne    80103795 <piperead+0x65>
8010378b:	8b 96 40 02 00 00    	mov    0x240(%esi),%edx
80103791:	85 d2                	test   %edx,%edx
80103793:	75 cb                	jne    80103760 <piperead+0x30>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
80103795:	8b 4d 10             	mov    0x10(%ebp),%ecx
80103798:	31 db                	xor    %ebx,%ebx
8010379a:	85 c9                	test   %ecx,%ecx
8010379c:	7f 26                	jg     801037c4 <piperead+0x94>
8010379e:	eb 2c                	jmp    801037cc <piperead+0x9c>
    if(p->nread == p->nwrite)
      break;
    addr[i] = p->data[p->nread++ % PIPESIZE];
801037a0:	8d 48 01             	lea    0x1(%eax),%ecx
801037a3:	25 ff 01 00 00       	and    $0x1ff,%eax
801037a8:	89 8e 34 02 00 00    	mov    %ecx,0x234(%esi)
801037ae:	0f b6 44 06 34       	movzbl 0x34(%esi,%eax,1),%eax
801037b3:	88 04 1f             	mov    %al,(%edi,%ebx,1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
801037b6:	83 c3 01             	add    $0x1,%ebx
801037b9:	39 5d 10             	cmp    %ebx,0x10(%ebp)
801037bc:	74 0e                	je     801037cc <piperead+0x9c>
801037be:	8b 86 34 02 00 00    	mov    0x234(%esi),%eax
    if(p->nread == p->nwrite)
801037c4:	3b 86 38 02 00 00    	cmp    0x238(%esi),%eax
801037ca:	75 d4                	jne    801037a0 <piperead+0x70>
  }
  wakeup(&p->nwrite);  //DOC: piperead-wakeup
801037cc:	83 ec 0c             	sub    $0xc,%esp
801037cf:	8d 86 38 02 00 00    	lea    0x238(%esi),%eax
801037d5:	50                   	push   %eax
801037d6:	e8 d5 09 00 00       	call   801041b0 <wakeup>
  release(&p->lock);
801037db:	89 34 24             	mov    %esi,(%esp)
801037de:	e8 ad 0e 00 00       	call   80104690 <release>
  return i;
801037e3:	83 c4 10             	add    $0x10,%esp
}
801037e6:	8d 65 f4             	lea    -0xc(%ebp),%esp
801037e9:	89 d8                	mov    %ebx,%eax
801037eb:	5b                   	pop    %ebx
801037ec:	5e                   	pop    %esi
801037ed:	5f                   	pop    %edi
801037ee:	5d                   	pop    %ebp
801037ef:	c3                   	ret
      release(&p->lock);
801037f0:	83 ec 0c             	sub    $0xc,%esp
      return -1;
801037f3:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
      release(&p->lock);
801037f8:	56                   	push   %esi
801037f9:	e8 92 0e 00 00       	call   80104690 <release>
      return -1;
801037fe:	83 c4 10             	add    $0x10,%esp
}
80103801:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103804:	89 d8                	mov    %ebx,%eax
80103806:	5b                   	pop    %ebx
80103807:	5e                   	pop    %esi
80103808:	5f                   	pop    %edi
80103809:	5d                   	pop    %ebp
8010380a:	c3                   	ret
8010380b:	66 90                	xchg   %ax,%ax
8010380d:	66 90                	xchg   %ax,%ax
8010380f:	90                   	nop

80103810 <allocproc>:
// If found, change state to EMBRYO and initialize
// state required to run in the kernel.
// Otherwise return 0.
static struct proc*
allocproc(void)
{
80103810:	55                   	push   %ebp
80103811:	89 e5                	mov    %esp,%ebp
80103813:	53                   	push   %ebx
  struct proc *p;
  char *sp;

  acquire(&ptable.lock);

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103814:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
{
80103819:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);
8010381c:	68 40 2d 11 80       	push   $0x80112d40
80103821:	e8 ca 0e 00 00       	call   801046f0 <acquire>
80103826:	83 c4 10             	add    $0x10,%esp
80103829:	eb 17                	jmp    80103842 <allocproc+0x32>
8010382b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103830:	81 c3 88 00 00 00    	add    $0x88,%ebx
80103836:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
8010383c:	0f 84 96 00 00 00    	je     801038d8 <allocproc+0xc8>
    if(p->state == UNUSED)
80103842:	8b 43 0c             	mov    0xc(%ebx),%eax
80103845:	85 c0                	test   %eax,%eax
80103847:	75 e7                	jne    80103830 <allocproc+0x20>
  release(&ptable.lock);
  return 0;

found:
  p->state = EMBRYO;
  p->pid = nextpid++;
80103849:	a1 04 b0 10 80       	mov    0x8010b004,%eax
  p->faults = 0;
  p->ctime = ticks;
  p->burst_time = 0;

  release(&ptable.lock);
8010384e:	83 ec 0c             	sub    $0xc,%esp
  p->state = EMBRYO;
80103851:	c7 43 0c 01 00 00 00 	movl   $0x1,0xc(%ebx)
  p->faults = 0;
80103858:	c7 43 7c 00 00 00 00 	movl   $0x0,0x7c(%ebx)
  p->pid = nextpid++;
8010385f:	8d 50 01             	lea    0x1(%eax),%edx
80103862:	89 43 10             	mov    %eax,0x10(%ebx)
  p->ctime = ticks;
80103865:	a1 80 4f 11 80       	mov    0x80114f80,%eax
  p->burst_time = 0;
8010386a:	c7 83 84 00 00 00 00 	movl   $0x0,0x84(%ebx)
80103871:	00 00 00 
  p->ctime = ticks;
80103874:	89 83 80 00 00 00    	mov    %eax,0x80(%ebx)
  release(&ptable.lock);
8010387a:	68 40 2d 11 80       	push   $0x80112d40
  p->pid = nextpid++;
8010387f:	89 15 04 b0 10 80    	mov    %edx,0x8010b004
  release(&ptable.lock);
80103885:	e8 06 0e 00 00       	call   80104690 <release>

  // Allocate kernel stack.
  if((p->kstack = kalloc()) == 0){
8010388a:	e8 e1 ed ff ff       	call   80102670 <kalloc>
8010388f:	83 c4 10             	add    $0x10,%esp
80103892:	89 43 08             	mov    %eax,0x8(%ebx)
80103895:	85 c0                	test   %eax,%eax
80103897:	74 58                	je     801038f1 <allocproc+0xe1>
    return 0;
  }
  sp = p->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *p->tf;
80103899:	8d 90 b4 0f 00 00    	lea    0xfb4(%eax),%edx
  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *p->context;
  p->context = (struct context*)sp;
  memset(p->context, 0, sizeof *p->context);
8010389f:	83 ec 04             	sub    $0x4,%esp
  sp -= sizeof *p->context;
801038a2:	05 9c 0f 00 00       	add    $0xf9c,%eax
  sp -= sizeof *p->tf;
801038a7:	89 53 18             	mov    %edx,0x18(%ebx)
  *(uint*)sp = (uint)trapret;
801038aa:	c7 40 14 37 5b 10 80 	movl   $0x80105b37,0x14(%eax)
  p->context = (struct context*)sp;
801038b1:	89 43 1c             	mov    %eax,0x1c(%ebx)
  memset(p->context, 0, sizeof *p->context);
801038b4:	6a 14                	push   $0x14
801038b6:	6a 00                	push   $0x0
801038b8:	50                   	push   %eax
801038b9:	e8 32 0f 00 00       	call   801047f0 <memset>
  p->context->eip = (uint)forkret;
801038be:	8b 43 1c             	mov    0x1c(%ebx),%eax

  return p;
801038c1:	83 c4 10             	add    $0x10,%esp
  p->context->eip = (uint)forkret;
801038c4:	c7 40 10 00 39 10 80 	movl   $0x80103900,0x10(%eax)
}
801038cb:	89 d8                	mov    %ebx,%eax
801038cd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801038d0:	c9                   	leave
801038d1:	c3                   	ret
801038d2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  release(&ptable.lock);
801038d8:	83 ec 0c             	sub    $0xc,%esp
  return 0;
801038db:	31 db                	xor    %ebx,%ebx
  release(&ptable.lock);
801038dd:	68 40 2d 11 80       	push   $0x80112d40
801038e2:	e8 a9 0d 00 00       	call   80104690 <release>
  return 0;
801038e7:	83 c4 10             	add    $0x10,%esp
}
801038ea:	89 d8                	mov    %ebx,%eax
801038ec:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801038ef:	c9                   	leave
801038f0:	c3                   	ret
    p->state = UNUSED;
801038f1:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  return 0;
801038f8:	31 db                	xor    %ebx,%ebx
801038fa:	eb ee                	jmp    801038ea <allocproc+0xda>
801038fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80103900 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch here.  "Return" to user space.
void
forkret(void)
{
80103900:	55                   	push   %ebp
80103901:	89 e5                	mov    %esp,%ebp
80103903:	83 ec 14             	sub    $0x14,%esp
  static int first = 1;
  // Still holding ptable.lock from scheduler.
  release(&ptable.lock);
80103906:	68 40 2d 11 80       	push   $0x80112d40
8010390b:	e8 80 0d 00 00       	call   80104690 <release>

  if (first) {
80103910:	a1 00 b0 10 80       	mov    0x8010b000,%eax
80103915:	83 c4 10             	add    $0x10,%esp
80103918:	85 c0                	test   %eax,%eax
8010391a:	75 04                	jne    80103920 <forkret+0x20>
    iinit(ROOTDEV);
    initlog(ROOTDEV);
  }

  // Return to "caller", actually trapret (see allocproc).
}
8010391c:	c9                   	leave
8010391d:	c3                   	ret
8010391e:	66 90                	xchg   %ax,%ax
    first = 0;
80103920:	c7 05 00 b0 10 80 00 	movl   $0x0,0x8010b000
80103927:	00 00 00 
    iinit(ROOTDEV);
8010392a:	83 ec 0c             	sub    $0xc,%esp
8010392d:	6a 01                	push   $0x1
8010392f:	e8 4c dc ff ff       	call   80101580 <iinit>
    initlog(ROOTDEV);
80103934:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
8010393b:	e8 d0 f3 ff ff       	call   80102d10 <initlog>
}
80103940:	83 c4 10             	add    $0x10,%esp
80103943:	c9                   	leave
80103944:	c3                   	ret
80103945:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010394c:	00 
8010394d:	8d 76 00             	lea    0x0(%esi),%esi

80103950 <pinit>:
{
80103950:	55                   	push   %ebp
80103951:	89 e5                	mov    %esp,%ebp
80103953:	83 ec 10             	sub    $0x10,%esp
  initlock(&ptable.lock, "ptable");
80103956:	68 76 7a 10 80       	push   $0x80107a76
8010395b:	68 40 2d 11 80       	push   $0x80112d40
80103960:	e8 9b 0b 00 00       	call   80104500 <initlock>
}
80103965:	83 c4 10             	add    $0x10,%esp
80103968:	c9                   	leave
80103969:	c3                   	ret
8010396a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80103970 <mycpu>:
{
80103970:	55                   	push   %ebp
80103971:	89 e5                	mov    %esp,%ebp
80103973:	56                   	push   %esi
80103974:	53                   	push   %ebx
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103975:	9c                   	pushf
80103976:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103977:	f6 c4 02             	test   $0x2,%ah
8010397a:	75 46                	jne    801039c2 <mycpu+0x52>
  apicid = lapicid();
8010397c:	e8 bf ef ff ff       	call   80102940 <lapicid>
  for (i = 0; i < ncpu; ++i) {
80103981:	8b 35 a4 27 11 80    	mov    0x801127a4,%esi
80103987:	85 f6                	test   %esi,%esi
80103989:	7e 2a                	jle    801039b5 <mycpu+0x45>
8010398b:	31 d2                	xor    %edx,%edx
8010398d:	eb 08                	jmp    80103997 <mycpu+0x27>
8010398f:	90                   	nop
80103990:	83 c2 01             	add    $0x1,%edx
80103993:	39 f2                	cmp    %esi,%edx
80103995:	74 1e                	je     801039b5 <mycpu+0x45>
    if (cpus[i].apicid == apicid)
80103997:	69 ca b0 00 00 00    	imul   $0xb0,%edx,%ecx
8010399d:	0f b6 99 c0 27 11 80 	movzbl -0x7feed840(%ecx),%ebx
801039a4:	39 c3                	cmp    %eax,%ebx
801039a6:	75 e8                	jne    80103990 <mycpu+0x20>
}
801039a8:	8d 65 f8             	lea    -0x8(%ebp),%esp
      return &cpus[i];
801039ab:	8d 81 c0 27 11 80    	lea    -0x7feed840(%ecx),%eax
}
801039b1:	5b                   	pop    %ebx
801039b2:	5e                   	pop    %esi
801039b3:	5d                   	pop    %ebp
801039b4:	c3                   	ret
  panic("unknown apicid\n");
801039b5:	83 ec 0c             	sub    $0xc,%esp
801039b8:	68 7d 7a 10 80       	push   $0x80107a7d
801039bd:	e8 be c9 ff ff       	call   80100380 <panic>
    panic("mycpu called with interrupts enabled\n");
801039c2:	83 ec 0c             	sub    $0xc,%esp
801039c5:	68 08 7e 10 80       	push   $0x80107e08
801039ca:	e8 b1 c9 ff ff       	call   80100380 <panic>
801039cf:	90                   	nop

801039d0 <cpuid>:
cpuid() {
801039d0:	55                   	push   %ebp
801039d1:	89 e5                	mov    %esp,%ebp
801039d3:	83 ec 08             	sub    $0x8,%esp
  return mycpu()-cpus;
801039d6:	e8 95 ff ff ff       	call   80103970 <mycpu>
}
801039db:	c9                   	leave
  return mycpu()-cpus;
801039dc:	2d c0 27 11 80       	sub    $0x801127c0,%eax
801039e1:	c1 f8 04             	sar    $0x4,%eax
801039e4:	69 c0 a3 8b 2e ba    	imul   $0xba2e8ba3,%eax,%eax
}
801039ea:	c3                   	ret
801039eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801039f0 <myproc>:
myproc(void) {
801039f0:	55                   	push   %ebp
801039f1:	89 e5                	mov    %esp,%ebp
801039f3:	53                   	push   %ebx
801039f4:	83 ec 04             	sub    $0x4,%esp
  pushcli();
801039f7:	e8 a4 0b 00 00       	call   801045a0 <pushcli>
  c = mycpu();
801039fc:	e8 6f ff ff ff       	call   80103970 <mycpu>
  p = c->proc;
80103a01:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103a07:	e8 e4 0b 00 00       	call   801045f0 <popcli>
}
80103a0c:	89 d8                	mov    %ebx,%eax
80103a0e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103a11:	c9                   	leave
80103a12:	c3                   	ret
80103a13:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103a1a:	00 
80103a1b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103a20 <userinit>:
{
80103a20:	55                   	push   %ebp
80103a21:	89 e5                	mov    %esp,%ebp
80103a23:	53                   	push   %ebx
80103a24:	83 ec 04             	sub    $0x4,%esp
  p = allocproc();
80103a27:	e8 e4 fd ff ff       	call   80103810 <allocproc>
80103a2c:	89 c3                	mov    %eax,%ebx
  initproc = p;
80103a2e:	a3 74 4f 11 80       	mov    %eax,0x80114f74
  if((p->pgdir = setupkvm()) == 0)
80103a33:	e8 58 37 00 00       	call   80107190 <setupkvm>
80103a38:	89 43 04             	mov    %eax,0x4(%ebx)
80103a3b:	85 c0                	test   %eax,%eax
80103a3d:	0f 84 bd 00 00 00    	je     80103b00 <userinit+0xe0>
  inituvm(p->pgdir, _binary_initcode_start, (int)_binary_initcode_size);
80103a43:	83 ec 04             	sub    $0x4,%esp
80103a46:	68 2c 00 00 00       	push   $0x2c
80103a4b:	68 60 b4 10 80       	push   $0x8010b460
80103a50:	50                   	push   %eax
80103a51:	e8 1a 34 00 00       	call   80106e70 <inituvm>
  memset(p->tf, 0, sizeof(*p->tf));
80103a56:	83 c4 0c             	add    $0xc,%esp
  p->sz = PGSIZE;
80103a59:	c7 03 00 10 00 00    	movl   $0x1000,(%ebx)
  memset(p->tf, 0, sizeof(*p->tf));
80103a5f:	6a 4c                	push   $0x4c
80103a61:	6a 00                	push   $0x0
80103a63:	ff 73 18             	push   0x18(%ebx)
80103a66:	e8 85 0d 00 00       	call   801047f0 <memset>
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80103a6b:	8b 43 18             	mov    0x18(%ebx),%eax
80103a6e:	ba 1b 00 00 00       	mov    $0x1b,%edx
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103a73:	83 c4 0c             	add    $0xc,%esp
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80103a76:	b9 23 00 00 00       	mov    $0x23,%ecx
  p->tf->cs = (SEG_UCODE << 3) | DPL_USER;
80103a7b:	66 89 50 3c          	mov    %dx,0x3c(%eax)
  p->tf->ds = (SEG_UDATA << 3) | DPL_USER;
80103a7f:	8b 43 18             	mov    0x18(%ebx),%eax
80103a82:	66 89 48 2c          	mov    %cx,0x2c(%eax)
  p->tf->es = p->tf->ds;
80103a86:	8b 43 18             	mov    0x18(%ebx),%eax
80103a89:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80103a8d:	66 89 50 28          	mov    %dx,0x28(%eax)
  p->tf->ss = p->tf->ds;
80103a91:	8b 43 18             	mov    0x18(%ebx),%eax
80103a94:	0f b7 50 2c          	movzwl 0x2c(%eax),%edx
80103a98:	66 89 50 48          	mov    %dx,0x48(%eax)
  p->tf->eflags = FL_IF;
80103a9c:	8b 43 18             	mov    0x18(%ebx),%eax
80103a9f:	c7 40 40 00 02 00 00 	movl   $0x200,0x40(%eax)
  p->tf->esp = PGSIZE;
80103aa6:	8b 43 18             	mov    0x18(%ebx),%eax
80103aa9:	c7 40 44 00 10 00 00 	movl   $0x1000,0x44(%eax)
  p->tf->eip = 0;  // beginning of initcode.S
80103ab0:	8b 43 18             	mov    0x18(%ebx),%eax
80103ab3:	c7 40 38 00 00 00 00 	movl   $0x0,0x38(%eax)
  safestrcpy(p->name, "initcode", sizeof(p->name));
80103aba:	8d 43 6c             	lea    0x6c(%ebx),%eax
80103abd:	6a 10                	push   $0x10
80103abf:	68 a6 7a 10 80       	push   $0x80107aa6
80103ac4:	50                   	push   %eax
80103ac5:	e8 d6 0e 00 00       	call   801049a0 <safestrcpy>
  p->cwd = namei("/");
80103aca:	c7 04 24 af 7a 10 80 	movl   $0x80107aaf,(%esp)
80103ad1:	e8 aa e5 ff ff       	call   80102080 <namei>
80103ad6:	89 43 68             	mov    %eax,0x68(%ebx)
  acquire(&ptable.lock);
80103ad9:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103ae0:	e8 0b 0c 00 00       	call   801046f0 <acquire>
  p->state = RUNNABLE;
80103ae5:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  release(&ptable.lock);
80103aec:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103af3:	e8 98 0b 00 00       	call   80104690 <release>
}
80103af8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80103afb:	83 c4 10             	add    $0x10,%esp
80103afe:	c9                   	leave
80103aff:	c3                   	ret
    panic("userinit: out of memory?");
80103b00:	83 ec 0c             	sub    $0xc,%esp
80103b03:	68 8d 7a 10 80       	push   $0x80107a8d
80103b08:	e8 73 c8 ff ff       	call   80100380 <panic>
80103b0d:	8d 76 00             	lea    0x0(%esi),%esi

80103b10 <growproc>:
{
80103b10:	55                   	push   %ebp
80103b11:	89 e5                	mov    %esp,%ebp
80103b13:	56                   	push   %esi
80103b14:	53                   	push   %ebx
80103b15:	8b 75 08             	mov    0x8(%ebp),%esi
  pushcli();
80103b18:	e8 83 0a 00 00       	call   801045a0 <pushcli>
  c = mycpu();
80103b1d:	e8 4e fe ff ff       	call   80103970 <mycpu>
  p = c->proc;
80103b22:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103b28:	e8 c3 0a 00 00       	call   801045f0 <popcli>
  sz = curproc->sz;
80103b2d:	8b 03                	mov    (%ebx),%eax
  if(n > 0){
80103b2f:	85 f6                	test   %esi,%esi
80103b31:	7f 1d                	jg     80103b50 <growproc+0x40>
  } else if(n < 0){
80103b33:	75 3b                	jne    80103b70 <growproc+0x60>
  switchuvm(curproc);
80103b35:	83 ec 0c             	sub    $0xc,%esp
  curproc->sz = sz;
80103b38:	89 03                	mov    %eax,(%ebx)
  switchuvm(curproc);
80103b3a:	53                   	push   %ebx
80103b3b:	e8 20 32 00 00       	call   80106d60 <switchuvm>
  return 0;
80103b40:	83 c4 10             	add    $0x10,%esp
80103b43:	31 c0                	xor    %eax,%eax
}
80103b45:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103b48:	5b                   	pop    %ebx
80103b49:	5e                   	pop    %esi
80103b4a:	5d                   	pop    %ebp
80103b4b:	c3                   	ret
80103b4c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if((sz = allocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103b50:	83 ec 04             	sub    $0x4,%esp
80103b53:	01 c6                	add    %eax,%esi
80103b55:	56                   	push   %esi
80103b56:	50                   	push   %eax
80103b57:	ff 73 04             	push   0x4(%ebx)
80103b5a:	e8 61 34 00 00       	call   80106fc0 <allocuvm>
80103b5f:	83 c4 10             	add    $0x10,%esp
80103b62:	85 c0                	test   %eax,%eax
80103b64:	75 cf                	jne    80103b35 <growproc+0x25>
      return -1;
80103b66:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80103b6b:	eb d8                	jmp    80103b45 <growproc+0x35>
80103b6d:	8d 76 00             	lea    0x0(%esi),%esi
    if((sz = deallocuvm(curproc->pgdir, sz, sz + n)) == 0)
80103b70:	83 ec 04             	sub    $0x4,%esp
80103b73:	01 c6                	add    %eax,%esi
80103b75:	56                   	push   %esi
80103b76:	50                   	push   %eax
80103b77:	ff 73 04             	push   0x4(%ebx)
80103b7a:	e8 61 35 00 00       	call   801070e0 <deallocuvm>
80103b7f:	83 c4 10             	add    $0x10,%esp
80103b82:	85 c0                	test   %eax,%eax
80103b84:	75 af                	jne    80103b35 <growproc+0x25>
80103b86:	eb de                	jmp    80103b66 <growproc+0x56>
80103b88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103b8f:	00 

80103b90 <fork>:
{
80103b90:	55                   	push   %ebp
80103b91:	89 e5                	mov    %esp,%ebp
80103b93:	57                   	push   %edi
80103b94:	56                   	push   %esi
80103b95:	53                   	push   %ebx
80103b96:	83 ec 1c             	sub    $0x1c,%esp
  pushcli();
80103b99:	e8 02 0a 00 00       	call   801045a0 <pushcli>
  c = mycpu();
80103b9e:	e8 cd fd ff ff       	call   80103970 <mycpu>
  p = c->proc;
80103ba3:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103ba9:	e8 42 0a 00 00       	call   801045f0 <popcli>
  if((np = allocproc()) == 0){
80103bae:	e8 5d fc ff ff       	call   80103810 <allocproc>
80103bb3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80103bb6:	85 c0                	test   %eax,%eax
80103bb8:	0f 84 d6 00 00 00    	je     80103c94 <fork+0x104>
  if((np->pgdir = copyuvm(curproc->pgdir, curproc->sz)) == 0){
80103bbe:	83 ec 08             	sub    $0x8,%esp
80103bc1:	ff 33                	push   (%ebx)
80103bc3:	89 c7                	mov    %eax,%edi
80103bc5:	ff 73 04             	push   0x4(%ebx)
80103bc8:	e8 b3 36 00 00       	call   80107280 <copyuvm>
80103bcd:	83 c4 10             	add    $0x10,%esp
80103bd0:	89 47 04             	mov    %eax,0x4(%edi)
80103bd3:	85 c0                	test   %eax,%eax
80103bd5:	0f 84 9a 00 00 00    	je     80103c75 <fork+0xe5>
  np->sz = curproc->sz;
80103bdb:	8b 03                	mov    (%ebx),%eax
80103bdd:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80103be0:	89 01                	mov    %eax,(%ecx)
  *np->tf = *curproc->tf;
80103be2:	8b 79 18             	mov    0x18(%ecx),%edi
  np->parent = curproc;
80103be5:	89 c8                	mov    %ecx,%eax
80103be7:	89 59 14             	mov    %ebx,0x14(%ecx)
  *np->tf = *curproc->tf;
80103bea:	b9 13 00 00 00       	mov    $0x13,%ecx
80103bef:	8b 73 18             	mov    0x18(%ebx),%esi
80103bf2:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  for(i = 0; i < NOFILE; i++)
80103bf4:	31 f6                	xor    %esi,%esi
  np->tf->eax = 0;
80103bf6:	8b 40 18             	mov    0x18(%eax),%eax
80103bf9:	c7 40 1c 00 00 00 00 	movl   $0x0,0x1c(%eax)
    if(curproc->ofile[i])
80103c00:	8b 44 b3 28          	mov    0x28(%ebx,%esi,4),%eax
80103c04:	85 c0                	test   %eax,%eax
80103c06:	74 13                	je     80103c1b <fork+0x8b>
      np->ofile[i] = filedup(curproc->ofile[i]);
80103c08:	83 ec 0c             	sub    $0xc,%esp
80103c0b:	50                   	push   %eax
80103c0c:	e8 af d2 ff ff       	call   80100ec0 <filedup>
80103c11:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80103c14:	83 c4 10             	add    $0x10,%esp
80103c17:	89 44 b2 28          	mov    %eax,0x28(%edx,%esi,4)
  for(i = 0; i < NOFILE; i++)
80103c1b:	83 c6 01             	add    $0x1,%esi
80103c1e:	83 fe 10             	cmp    $0x10,%esi
80103c21:	75 dd                	jne    80103c00 <fork+0x70>
  np->cwd = idup(curproc->cwd);
80103c23:	83 ec 0c             	sub    $0xc,%esp
80103c26:	ff 73 68             	push   0x68(%ebx)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103c29:	83 c3 6c             	add    $0x6c,%ebx
  np->cwd = idup(curproc->cwd);
80103c2c:	e8 3f db ff ff       	call   80101770 <idup>
80103c31:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103c34:	83 c4 0c             	add    $0xc,%esp
  np->cwd = idup(curproc->cwd);
80103c37:	89 47 68             	mov    %eax,0x68(%edi)
  safestrcpy(np->name, curproc->name, sizeof(curproc->name));
80103c3a:	8d 47 6c             	lea    0x6c(%edi),%eax
80103c3d:	6a 10                	push   $0x10
80103c3f:	53                   	push   %ebx
80103c40:	50                   	push   %eax
80103c41:	e8 5a 0d 00 00       	call   801049a0 <safestrcpy>
  pid = np->pid;
80103c46:	8b 5f 10             	mov    0x10(%edi),%ebx
  acquire(&ptable.lock);
80103c49:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103c50:	e8 9b 0a 00 00       	call   801046f0 <acquire>
  np->state = RUNNABLE;
80103c55:	c7 47 0c 03 00 00 00 	movl   $0x3,0xc(%edi)
  release(&ptable.lock);
80103c5c:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103c63:	e8 28 0a 00 00       	call   80104690 <release>
  return pid;
80103c68:	83 c4 10             	add    $0x10,%esp
}
80103c6b:	8d 65 f4             	lea    -0xc(%ebp),%esp
80103c6e:	89 d8                	mov    %ebx,%eax
80103c70:	5b                   	pop    %ebx
80103c71:	5e                   	pop    %esi
80103c72:	5f                   	pop    %edi
80103c73:	5d                   	pop    %ebp
80103c74:	c3                   	ret
    kfree(np->kstack);
80103c75:	8b 5d e4             	mov    -0x1c(%ebp),%ebx
80103c78:	83 ec 0c             	sub    $0xc,%esp
80103c7b:	ff 73 08             	push   0x8(%ebx)
80103c7e:	e8 1d e8 ff ff       	call   801024a0 <kfree>
    np->kstack = 0;
80103c83:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
    return -1;
80103c8a:	83 c4 10             	add    $0x10,%esp
    np->state = UNUSED;
80103c8d:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
    return -1;
80103c94:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
80103c99:	eb d0                	jmp    80103c6b <fork+0xdb>
80103c9b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80103ca0 <scheduler>:
{
80103ca0:	55                   	push   %ebp
80103ca1:	89 e5                	mov    %esp,%ebp
80103ca3:	57                   	push   %edi
80103ca4:	56                   	push   %esi
80103ca5:	53                   	push   %ebx
80103ca6:	83 ec 0c             	sub    $0xc,%esp
  struct cpu *c = mycpu();
80103ca9:	e8 c2 fc ff ff       	call   80103970 <mycpu>
  c->proc = 0;
80103cae:	c7 80 ac 00 00 00 00 	movl   $0x0,0xac(%eax)
80103cb5:	00 00 00 
  struct cpu *c = mycpu();
80103cb8:	89 c3                	mov    %eax,%ebx
  c->proc = 0;
80103cba:	8d 70 04             	lea    0x4(%eax),%esi
80103cbd:	8d 76 00             	lea    0x0(%esi),%esi
  asm volatile("sti");
80103cc0:	fb                   	sti
    acquire(&ptable.lock);
80103cc1:	83 ec 0c             	sub    $0xc,%esp
    struct proc *shortest = 0;
80103cc4:	31 ff                	xor    %edi,%edi
    acquire(&ptable.lock);
80103cc6:	68 40 2d 11 80       	push   $0x80112d40
80103ccb:	e8 20 0a 00 00       	call   801046f0 <acquire>
80103cd0:	83 c4 10             	add    $0x10,%esp
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103cd3:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
80103cd8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103cdf:	00 
      if(p->state != RUNNABLE)
80103ce0:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
80103ce4:	75 1e                	jne    80103d04 <scheduler+0x64>
      if(shortest == 0){
80103ce6:	85 ff                	test   %edi,%edi
80103ce8:	74 18                	je     80103d02 <scheduler+0x62>
      } else if(p->burst_time > 0){
80103cea:	8b 90 84 00 00 00    	mov    0x84(%eax),%edx
80103cf0:	85 d2                	test   %edx,%edx
80103cf2:	7e 10                	jle    80103d04 <scheduler+0x64>
      	if(shortest->burst_time <= 0 || p->burst_time < shortest->burst_time){
80103cf4:	8b 8f 84 00 00 00    	mov    0x84(%edi),%ecx
80103cfa:	39 ca                	cmp    %ecx,%edx
80103cfc:	7c 04                	jl     80103d02 <scheduler+0x62>
80103cfe:	85 c9                	test   %ecx,%ecx
80103d00:	7f 5e                	jg     80103d60 <scheduler+0xc0>
      	shortest = p;
80103d02:	89 c7                	mov    %eax,%edi
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103d04:	05 88 00 00 00       	add    $0x88,%eax
80103d09:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103d0e:	75 d0                	jne    80103ce0 <scheduler+0x40>
   if(shortest != 0){
80103d10:	85 ff                	test   %edi,%edi
80103d12:	74 33                	je     80103d47 <scheduler+0xa7>
      switchuvm(p);
80103d14:	83 ec 0c             	sub    $0xc,%esp
      c->proc = p;
80103d17:	89 bb ac 00 00 00    	mov    %edi,0xac(%ebx)
      switchuvm(p);
80103d1d:	57                   	push   %edi
80103d1e:	e8 3d 30 00 00       	call   80106d60 <switchuvm>
      p->state = RUNNING;
80103d23:	c7 47 0c 04 00 00 00 	movl   $0x4,0xc(%edi)
      swtch(&(c->scheduler), p->context);
80103d2a:	58                   	pop    %eax
80103d2b:	5a                   	pop    %edx
80103d2c:	ff 77 1c             	push   0x1c(%edi)
80103d2f:	56                   	push   %esi
80103d30:	e8 c6 0c 00 00       	call   801049fb <swtch>
      switchkvm();
80103d35:	e8 16 30 00 00       	call   80106d50 <switchkvm>
      c->proc = 0;
80103d3a:	83 c4 10             	add    $0x10,%esp
80103d3d:	c7 83 ac 00 00 00 00 	movl   $0x0,0xac(%ebx)
80103d44:	00 00 00 
    release(&ptable.lock);
80103d47:	83 ec 0c             	sub    $0xc,%esp
80103d4a:	68 40 2d 11 80       	push   $0x80112d40
80103d4f:	e8 3c 09 00 00       	call   80104690 <release>
  for(;;){
80103d54:	83 c4 10             	add    $0x10,%esp
80103d57:	e9 64 ff ff ff       	jmp    80103cc0 <scheduler+0x20>
80103d5c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103d60:	05 88 00 00 00       	add    $0x88,%eax
80103d65:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103d6a:	74 a8                	je     80103d14 <scheduler+0x74>
      if(p->state != RUNNABLE)
80103d6c:	83 78 0c 03          	cmpl   $0x3,0xc(%eax)
80103d70:	0f 84 74 ff ff ff    	je     80103cea <scheduler+0x4a>
80103d76:	eb 8c                	jmp    80103d04 <scheduler+0x64>
80103d78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103d7f:	00 

80103d80 <sched>:
{
80103d80:	55                   	push   %ebp
80103d81:	89 e5                	mov    %esp,%ebp
80103d83:	56                   	push   %esi
80103d84:	53                   	push   %ebx
  pushcli();
80103d85:	e8 16 08 00 00       	call   801045a0 <pushcli>
  c = mycpu();
80103d8a:	e8 e1 fb ff ff       	call   80103970 <mycpu>
  p = c->proc;
80103d8f:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103d95:	e8 56 08 00 00       	call   801045f0 <popcli>
  if(!holding(&ptable.lock))
80103d9a:	83 ec 0c             	sub    $0xc,%esp
80103d9d:	68 40 2d 11 80       	push   $0x80112d40
80103da2:	e8 a9 08 00 00       	call   80104650 <holding>
80103da7:	83 c4 10             	add    $0x10,%esp
80103daa:	85 c0                	test   %eax,%eax
80103dac:	74 4f                	je     80103dfd <sched+0x7d>
  if(mycpu()->ncli != 1)
80103dae:	e8 bd fb ff ff       	call   80103970 <mycpu>
80103db3:	83 b8 a4 00 00 00 01 	cmpl   $0x1,0xa4(%eax)
80103dba:	75 68                	jne    80103e24 <sched+0xa4>
  if(p->state == RUNNING)
80103dbc:	83 7b 0c 04          	cmpl   $0x4,0xc(%ebx)
80103dc0:	74 55                	je     80103e17 <sched+0x97>
  asm volatile("pushfl; popl %0" : "=r" (eflags));
80103dc2:	9c                   	pushf
80103dc3:	58                   	pop    %eax
  if(readeflags()&FL_IF)
80103dc4:	f6 c4 02             	test   $0x2,%ah
80103dc7:	75 41                	jne    80103e0a <sched+0x8a>
  intena = mycpu()->intena;
80103dc9:	e8 a2 fb ff ff       	call   80103970 <mycpu>
  swtch(&p->context, mycpu()->scheduler);
80103dce:	83 c3 1c             	add    $0x1c,%ebx
  intena = mycpu()->intena;
80103dd1:	8b b0 a8 00 00 00    	mov    0xa8(%eax),%esi
  swtch(&p->context, mycpu()->scheduler);
80103dd7:	e8 94 fb ff ff       	call   80103970 <mycpu>
80103ddc:	83 ec 08             	sub    $0x8,%esp
80103ddf:	ff 70 04             	push   0x4(%eax)
80103de2:	53                   	push   %ebx
80103de3:	e8 13 0c 00 00       	call   801049fb <swtch>
  mycpu()->intena = intena;
80103de8:	e8 83 fb ff ff       	call   80103970 <mycpu>
}
80103ded:	83 c4 10             	add    $0x10,%esp
  mycpu()->intena = intena;
80103df0:	89 b0 a8 00 00 00    	mov    %esi,0xa8(%eax)
}
80103df6:	8d 65 f8             	lea    -0x8(%ebp),%esp
80103df9:	5b                   	pop    %ebx
80103dfa:	5e                   	pop    %esi
80103dfb:	5d                   	pop    %ebp
80103dfc:	c3                   	ret
    panic("sched ptable.lock");
80103dfd:	83 ec 0c             	sub    $0xc,%esp
80103e00:	68 b1 7a 10 80       	push   $0x80107ab1
80103e05:	e8 76 c5 ff ff       	call   80100380 <panic>
    panic("sched interruptible");
80103e0a:	83 ec 0c             	sub    $0xc,%esp
80103e0d:	68 dd 7a 10 80       	push   $0x80107add
80103e12:	e8 69 c5 ff ff       	call   80100380 <panic>
    panic("sched running");
80103e17:	83 ec 0c             	sub    $0xc,%esp
80103e1a:	68 cf 7a 10 80       	push   $0x80107acf
80103e1f:	e8 5c c5 ff ff       	call   80100380 <panic>
    panic("sched locks");
80103e24:	83 ec 0c             	sub    $0xc,%esp
80103e27:	68 c3 7a 10 80       	push   $0x80107ac3
80103e2c:	e8 4f c5 ff ff       	call   80100380 <panic>
80103e31:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103e38:	00 
80103e39:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80103e40 <exit>:
{
80103e40:	55                   	push   %ebp
80103e41:	89 e5                	mov    %esp,%ebp
80103e43:	57                   	push   %edi
80103e44:	56                   	push   %esi
80103e45:	53                   	push   %ebx
80103e46:	83 ec 0c             	sub    $0xc,%esp
  struct proc *curproc = myproc();
80103e49:	e8 a2 fb ff ff       	call   801039f0 <myproc>
  if(curproc == initproc)
80103e4e:	39 05 74 4f 11 80    	cmp    %eax,0x80114f74
80103e54:	0f 84 07 01 00 00    	je     80103f61 <exit+0x121>
80103e5a:	89 c3                	mov    %eax,%ebx
80103e5c:	8d 70 28             	lea    0x28(%eax),%esi
80103e5f:	8d 78 68             	lea    0x68(%eax),%edi
80103e62:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(curproc->ofile[fd]){
80103e68:	8b 06                	mov    (%esi),%eax
80103e6a:	85 c0                	test   %eax,%eax
80103e6c:	74 12                	je     80103e80 <exit+0x40>
      fileclose(curproc->ofile[fd]);
80103e6e:	83 ec 0c             	sub    $0xc,%esp
80103e71:	50                   	push   %eax
80103e72:	e8 99 d0 ff ff       	call   80100f10 <fileclose>
      curproc->ofile[fd] = 0;
80103e77:	c7 06 00 00 00 00    	movl   $0x0,(%esi)
80103e7d:	83 c4 10             	add    $0x10,%esp
  for(fd = 0; fd < NOFILE; fd++){
80103e80:	83 c6 04             	add    $0x4,%esi
80103e83:	39 f7                	cmp    %esi,%edi
80103e85:	75 e1                	jne    80103e68 <exit+0x28>
  begin_op();
80103e87:	e8 24 ef ff ff       	call   80102db0 <begin_op>
  iput(curproc->cwd);
80103e8c:	83 ec 0c             	sub    $0xc,%esp
80103e8f:	ff 73 68             	push   0x68(%ebx)
80103e92:	e8 39 da ff ff       	call   801018d0 <iput>
  end_op();
80103e97:	e8 84 ef ff ff       	call   80102e20 <end_op>
  curproc->cwd = 0;
80103e9c:	c7 43 68 00 00 00 00 	movl   $0x0,0x68(%ebx)
  acquire(&ptable.lock);
80103ea3:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80103eaa:	e8 41 08 00 00       	call   801046f0 <acquire>
  wakeup1(curproc->parent);
80103eaf:	8b 53 14             	mov    0x14(%ebx),%edx
80103eb2:	83 c4 10             	add    $0x10,%esp
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103eb5:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
80103eba:	eb 10                	jmp    80103ecc <exit+0x8c>
80103ebc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80103ec0:	05 88 00 00 00       	add    $0x88,%eax
80103ec5:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103eca:	74 1e                	je     80103eea <exit+0xaa>
    if(p->state == SLEEPING && p->chan == chan)
80103ecc:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103ed0:	75 ee                	jne    80103ec0 <exit+0x80>
80103ed2:	3b 50 20             	cmp    0x20(%eax),%edx
80103ed5:	75 e9                	jne    80103ec0 <exit+0x80>
      p->state = RUNNABLE;
80103ed7:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103ede:	05 88 00 00 00       	add    $0x88,%eax
80103ee3:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103ee8:	75 e2                	jne    80103ecc <exit+0x8c>
      p->parent = initproc;
80103eea:	8b 0d 74 4f 11 80    	mov    0x80114f74,%ecx
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103ef0:	ba 74 2d 11 80       	mov    $0x80112d74,%edx
80103ef5:	eb 17                	jmp    80103f0e <exit+0xce>
80103ef7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80103efe:	00 
80103eff:	90                   	nop
80103f00:	81 c2 88 00 00 00    	add    $0x88,%edx
80103f06:	81 fa 74 4f 11 80    	cmp    $0x80114f74,%edx
80103f0c:	74 3a                	je     80103f48 <exit+0x108>
    if(p->parent == curproc){
80103f0e:	39 5a 14             	cmp    %ebx,0x14(%edx)
80103f11:	75 ed                	jne    80103f00 <exit+0xc0>
      if(p->state == ZOMBIE)
80103f13:	83 7a 0c 05          	cmpl   $0x5,0xc(%edx)
      p->parent = initproc;
80103f17:	89 4a 14             	mov    %ecx,0x14(%edx)
      if(p->state == ZOMBIE)
80103f1a:	75 e4                	jne    80103f00 <exit+0xc0>
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
80103f1c:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
80103f21:	eb 11                	jmp    80103f34 <exit+0xf4>
80103f23:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103f28:	05 88 00 00 00       	add    $0x88,%eax
80103f2d:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
80103f32:	74 cc                	je     80103f00 <exit+0xc0>
    if(p->state == SLEEPING && p->chan == chan)
80103f34:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
80103f38:	75 ee                	jne    80103f28 <exit+0xe8>
80103f3a:	3b 48 20             	cmp    0x20(%eax),%ecx
80103f3d:	75 e9                	jne    80103f28 <exit+0xe8>
      p->state = RUNNABLE;
80103f3f:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
80103f46:	eb e0                	jmp    80103f28 <exit+0xe8>
  curproc->state = ZOMBIE;
80103f48:	c7 43 0c 05 00 00 00 	movl   $0x5,0xc(%ebx)
  sched();
80103f4f:	e8 2c fe ff ff       	call   80103d80 <sched>
  panic("zombie exit");
80103f54:	83 ec 0c             	sub    $0xc,%esp
80103f57:	68 fe 7a 10 80       	push   $0x80107afe
80103f5c:	e8 1f c4 ff ff       	call   80100380 <panic>
    panic("init exiting");
80103f61:	83 ec 0c             	sub    $0xc,%esp
80103f64:	68 f1 7a 10 80       	push   $0x80107af1
80103f69:	e8 12 c4 ff ff       	call   80100380 <panic>
80103f6e:	66 90                	xchg   %ax,%ax

80103f70 <wait>:
{
80103f70:	55                   	push   %ebp
80103f71:	89 e5                	mov    %esp,%ebp
80103f73:	56                   	push   %esi
80103f74:	53                   	push   %ebx
  pushcli();
80103f75:	e8 26 06 00 00       	call   801045a0 <pushcli>
  c = mycpu();
80103f7a:	e8 f1 f9 ff ff       	call   80103970 <mycpu>
  p = c->proc;
80103f7f:	8b b0 ac 00 00 00    	mov    0xac(%eax),%esi
  popcli();
80103f85:	e8 66 06 00 00       	call   801045f0 <popcli>
  acquire(&ptable.lock);
80103f8a:	83 ec 0c             	sub    $0xc,%esp
80103f8d:	68 40 2d 11 80       	push   $0x80112d40
80103f92:	e8 59 07 00 00       	call   801046f0 <acquire>
80103f97:	83 c4 10             	add    $0x10,%esp
    havekids = 0;
80103f9a:	31 c0                	xor    %eax,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103f9c:	bb 74 2d 11 80       	mov    $0x80112d74,%ebx
80103fa1:	eb 13                	jmp    80103fb6 <wait+0x46>
80103fa3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80103fa8:	81 c3 88 00 00 00    	add    $0x88,%ebx
80103fae:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
80103fb4:	74 1e                	je     80103fd4 <wait+0x64>
      if(p->parent != curproc)
80103fb6:	39 73 14             	cmp    %esi,0x14(%ebx)
80103fb9:	75 ed                	jne    80103fa8 <wait+0x38>
      if(p->state == ZOMBIE){
80103fbb:	83 7b 0c 05          	cmpl   $0x5,0xc(%ebx)
80103fbf:	74 5f                	je     80104020 <wait+0xb0>
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103fc1:	81 c3 88 00 00 00    	add    $0x88,%ebx
      havekids = 1;
80103fc7:	b8 01 00 00 00       	mov    $0x1,%eax
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80103fcc:	81 fb 74 4f 11 80    	cmp    $0x80114f74,%ebx
80103fd2:	75 e2                	jne    80103fb6 <wait+0x46>
    if(!havekids || curproc->killed){
80103fd4:	85 c0                	test   %eax,%eax
80103fd6:	0f 84 9a 00 00 00    	je     80104076 <wait+0x106>
80103fdc:	8b 46 24             	mov    0x24(%esi),%eax
80103fdf:	85 c0                	test   %eax,%eax
80103fe1:	0f 85 8f 00 00 00    	jne    80104076 <wait+0x106>
  pushcli();
80103fe7:	e8 b4 05 00 00       	call   801045a0 <pushcli>
  c = mycpu();
80103fec:	e8 7f f9 ff ff       	call   80103970 <mycpu>
  p = c->proc;
80103ff1:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
80103ff7:	e8 f4 05 00 00       	call   801045f0 <popcli>
  if(p == 0)
80103ffc:	85 db                	test   %ebx,%ebx
80103ffe:	0f 84 89 00 00 00    	je     8010408d <wait+0x11d>
  p->chan = chan;
80104004:	89 73 20             	mov    %esi,0x20(%ebx)
  p->state = SLEEPING;
80104007:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
8010400e:	e8 6d fd ff ff       	call   80103d80 <sched>
  p->chan = 0;
80104013:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
8010401a:	e9 7b ff ff ff       	jmp    80103f9a <wait+0x2a>
8010401f:	90                   	nop
        kfree(p->kstack);
80104020:	83 ec 0c             	sub    $0xc,%esp
        pid = p->pid;
80104023:	8b 73 10             	mov    0x10(%ebx),%esi
        kfree(p->kstack);
80104026:	ff 73 08             	push   0x8(%ebx)
80104029:	e8 72 e4 ff ff       	call   801024a0 <kfree>
        p->kstack = 0;
8010402e:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
        freevm(p->pgdir);
80104035:	5a                   	pop    %edx
80104036:	ff 73 04             	push   0x4(%ebx)
80104039:	e8 d2 30 00 00       	call   80107110 <freevm>
        p->pid = 0;
8010403e:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%ebx)
        p->parent = 0;
80104045:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%ebx)
        p->name[0] = 0;
8010404c:	c6 43 6c 00          	movb   $0x0,0x6c(%ebx)
        p->killed = 0;
80104050:	c7 43 24 00 00 00 00 	movl   $0x0,0x24(%ebx)
        p->state = UNUSED;
80104057:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
        release(&ptable.lock);
8010405e:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
80104065:	e8 26 06 00 00       	call   80104690 <release>
        return pid;
8010406a:	83 c4 10             	add    $0x10,%esp
}
8010406d:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104070:	89 f0                	mov    %esi,%eax
80104072:	5b                   	pop    %ebx
80104073:	5e                   	pop    %esi
80104074:	5d                   	pop    %ebp
80104075:	c3                   	ret
      release(&ptable.lock);
80104076:	83 ec 0c             	sub    $0xc,%esp
      return -1;
80104079:	be ff ff ff ff       	mov    $0xffffffff,%esi
      release(&ptable.lock);
8010407e:	68 40 2d 11 80       	push   $0x80112d40
80104083:	e8 08 06 00 00       	call   80104690 <release>
      return -1;
80104088:	83 c4 10             	add    $0x10,%esp
8010408b:	eb e0                	jmp    8010406d <wait+0xfd>
    panic("sleep");
8010408d:	83 ec 0c             	sub    $0xc,%esp
80104090:	68 0a 7b 10 80       	push   $0x80107b0a
80104095:	e8 e6 c2 ff ff       	call   80100380 <panic>
8010409a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801040a0 <yield>:
{
801040a0:	55                   	push   %ebp
801040a1:	89 e5                	mov    %esp,%ebp
801040a3:	53                   	push   %ebx
801040a4:	83 ec 10             	sub    $0x10,%esp
  acquire(&ptable.lock);  //DOC: yieldlock
801040a7:	68 40 2d 11 80       	push   $0x80112d40
801040ac:	e8 3f 06 00 00       	call   801046f0 <acquire>
  pushcli();
801040b1:	e8 ea 04 00 00       	call   801045a0 <pushcli>
  c = mycpu();
801040b6:	e8 b5 f8 ff ff       	call   80103970 <mycpu>
  p = c->proc;
801040bb:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
801040c1:	e8 2a 05 00 00       	call   801045f0 <popcli>
  myproc()->state = RUNNABLE;
801040c6:	c7 43 0c 03 00 00 00 	movl   $0x3,0xc(%ebx)
  sched();
801040cd:	e8 ae fc ff ff       	call   80103d80 <sched>
  release(&ptable.lock);
801040d2:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
801040d9:	e8 b2 05 00 00       	call   80104690 <release>
}
801040de:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801040e1:	83 c4 10             	add    $0x10,%esp
801040e4:	c9                   	leave
801040e5:	c3                   	ret
801040e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801040ed:	00 
801040ee:	66 90                	xchg   %ax,%ax

801040f0 <sleep>:
{
801040f0:	55                   	push   %ebp
801040f1:	89 e5                	mov    %esp,%ebp
801040f3:	57                   	push   %edi
801040f4:	56                   	push   %esi
801040f5:	53                   	push   %ebx
801040f6:	83 ec 0c             	sub    $0xc,%esp
801040f9:	8b 7d 08             	mov    0x8(%ebp),%edi
801040fc:	8b 75 0c             	mov    0xc(%ebp),%esi
  pushcli();
801040ff:	e8 9c 04 00 00       	call   801045a0 <pushcli>
  c = mycpu();
80104104:	e8 67 f8 ff ff       	call   80103970 <mycpu>
  p = c->proc;
80104109:	8b 98 ac 00 00 00    	mov    0xac(%eax),%ebx
  popcli();
8010410f:	e8 dc 04 00 00       	call   801045f0 <popcli>
  if(p == 0)
80104114:	85 db                	test   %ebx,%ebx
80104116:	0f 84 87 00 00 00    	je     801041a3 <sleep+0xb3>
  if(lk == 0)
8010411c:	85 f6                	test   %esi,%esi
8010411e:	74 76                	je     80104196 <sleep+0xa6>
  if(lk != &ptable.lock){  //DOC: sleeplock0
80104120:	81 fe 40 2d 11 80    	cmp    $0x80112d40,%esi
80104126:	74 50                	je     80104178 <sleep+0x88>
    acquire(&ptable.lock);  //DOC: sleeplock1
80104128:	83 ec 0c             	sub    $0xc,%esp
8010412b:	68 40 2d 11 80       	push   $0x80112d40
80104130:	e8 bb 05 00 00       	call   801046f0 <acquire>
    release(lk);
80104135:	89 34 24             	mov    %esi,(%esp)
80104138:	e8 53 05 00 00       	call   80104690 <release>
  p->chan = chan;
8010413d:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
80104140:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104147:	e8 34 fc ff ff       	call   80103d80 <sched>
  p->chan = 0;
8010414c:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
    release(&ptable.lock);
80104153:	c7 04 24 40 2d 11 80 	movl   $0x80112d40,(%esp)
8010415a:	e8 31 05 00 00       	call   80104690 <release>
    acquire(lk);
8010415f:	83 c4 10             	add    $0x10,%esp
80104162:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104165:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104168:	5b                   	pop    %ebx
80104169:	5e                   	pop    %esi
8010416a:	5f                   	pop    %edi
8010416b:	5d                   	pop    %ebp
    acquire(lk);
8010416c:	e9 7f 05 00 00       	jmp    801046f0 <acquire>
80104171:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  p->chan = chan;
80104178:	89 7b 20             	mov    %edi,0x20(%ebx)
  p->state = SLEEPING;
8010417b:	c7 43 0c 02 00 00 00 	movl   $0x2,0xc(%ebx)
  sched();
80104182:	e8 f9 fb ff ff       	call   80103d80 <sched>
  p->chan = 0;
80104187:	c7 43 20 00 00 00 00 	movl   $0x0,0x20(%ebx)
}
8010418e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104191:	5b                   	pop    %ebx
80104192:	5e                   	pop    %esi
80104193:	5f                   	pop    %edi
80104194:	5d                   	pop    %ebp
80104195:	c3                   	ret
    panic("sleep without lk");
80104196:	83 ec 0c             	sub    $0xc,%esp
80104199:	68 10 7b 10 80       	push   $0x80107b10
8010419e:	e8 dd c1 ff ff       	call   80100380 <panic>
    panic("sleep");
801041a3:	83 ec 0c             	sub    $0xc,%esp
801041a6:	68 0a 7b 10 80       	push   $0x80107b0a
801041ab:	e8 d0 c1 ff ff       	call   80100380 <panic>

801041b0 <wakeup>:
}

// Wake up all processes sleeping on chan.
void
wakeup(void *chan)
{
801041b0:	55                   	push   %ebp
801041b1:	89 e5                	mov    %esp,%ebp
801041b3:	53                   	push   %ebx
801041b4:	83 ec 10             	sub    $0x10,%esp
801041b7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&ptable.lock);
801041ba:	68 40 2d 11 80       	push   $0x80112d40
801041bf:	e8 2c 05 00 00       	call   801046f0 <acquire>
801041c4:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801041c7:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
801041cc:	eb 0e                	jmp    801041dc <wakeup+0x2c>
801041ce:	66 90                	xchg   %ax,%ax
801041d0:	05 88 00 00 00       	add    $0x88,%eax
801041d5:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
801041da:	74 1e                	je     801041fa <wakeup+0x4a>
    if(p->state == SLEEPING && p->chan == chan)
801041dc:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
801041e0:	75 ee                	jne    801041d0 <wakeup+0x20>
801041e2:	3b 58 20             	cmp    0x20(%eax),%ebx
801041e5:	75 e9                	jne    801041d0 <wakeup+0x20>
      p->state = RUNNABLE;
801041e7:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
801041ee:	05 88 00 00 00       	add    $0x88,%eax
801041f3:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
801041f8:	75 e2                	jne    801041dc <wakeup+0x2c>
  wakeup1(chan);
  release(&ptable.lock);
801041fa:	c7 45 08 40 2d 11 80 	movl   $0x80112d40,0x8(%ebp)
}
80104201:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104204:	c9                   	leave
  release(&ptable.lock);
80104205:	e9 86 04 00 00       	jmp    80104690 <release>
8010420a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104210 <kill>:
// Kill the process with the given pid.
// Process won't exit until it returns
// to user space (see trap in trap.c).
int
kill(int pid)
{
80104210:	55                   	push   %ebp
80104211:	89 e5                	mov    %esp,%ebp
80104213:	53                   	push   %ebx
80104214:	83 ec 10             	sub    $0x10,%esp
80104217:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
8010421a:	68 40 2d 11 80       	push   $0x80112d40
8010421f:	e8 cc 04 00 00       	call   801046f0 <acquire>
80104224:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104227:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
8010422c:	eb 0e                	jmp    8010423c <kill+0x2c>
8010422e:	66 90                	xchg   %ax,%ax
80104230:	05 88 00 00 00       	add    $0x88,%eax
80104235:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
8010423a:	74 34                	je     80104270 <kill+0x60>
    if(p->pid == pid){
8010423c:	39 58 10             	cmp    %ebx,0x10(%eax)
8010423f:	75 ef                	jne    80104230 <kill+0x20>
      p->killed = 1;
      // Wake process from sleep if necessary.
      if(p->state == SLEEPING)
80104241:	83 78 0c 02          	cmpl   $0x2,0xc(%eax)
      p->killed = 1;
80104245:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
      if(p->state == SLEEPING)
8010424c:	75 07                	jne    80104255 <kill+0x45>
        p->state = RUNNABLE;
8010424e:	c7 40 0c 03 00 00 00 	movl   $0x3,0xc(%eax)
      release(&ptable.lock);
80104255:	83 ec 0c             	sub    $0xc,%esp
80104258:	68 40 2d 11 80       	push   $0x80112d40
8010425d:	e8 2e 04 00 00       	call   80104690 <release>
      return 0;
    }
  }
  release(&ptable.lock);
  return -1;
}
80104262:	8b 5d fc             	mov    -0x4(%ebp),%ebx
      return 0;
80104265:	83 c4 10             	add    $0x10,%esp
80104268:	31 c0                	xor    %eax,%eax
}
8010426a:	c9                   	leave
8010426b:	c3                   	ret
8010426c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  release(&ptable.lock);
80104270:	83 ec 0c             	sub    $0xc,%esp
80104273:	68 40 2d 11 80       	push   $0x80112d40
80104278:	e8 13 04 00 00       	call   80104690 <release>
}
8010427d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1;
80104280:	83 c4 10             	add    $0x10,%esp
80104283:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104288:	c9                   	leave
80104289:	c3                   	ret
8010428a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104290 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
80104290:	55                   	push   %ebp
80104291:	89 e5                	mov    %esp,%ebp
80104293:	57                   	push   %edi
80104294:	56                   	push   %esi
80104295:	8d 75 e8             	lea    -0x18(%ebp),%esi
80104298:	53                   	push   %ebx
80104299:	bb e0 2d 11 80       	mov    $0x80112de0,%ebx
8010429e:	83 ec 3c             	sub    $0x3c,%esp
801042a1:	eb 27                	jmp    801042ca <procdump+0x3a>
801042a3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(p->state == SLEEPING){
      getcallerpcs((uint*)p->context->ebp+2, pc);
      for(i=0; i<10 && pc[i] != 0; i++)
        cprintf(" %p", pc[i]);
    }
    cprintf("\n");
801042a8:	83 ec 0c             	sub    $0xc,%esp
801042ab:	68 e4 7c 10 80       	push   $0x80107ce4
801042b0:	e8 fb c3 ff ff       	call   801006b0 <cprintf>
801042b5:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
801042b8:	81 c3 88 00 00 00    	add    $0x88,%ebx
801042be:	81 fb e0 4f 11 80    	cmp    $0x80114fe0,%ebx
801042c4:	0f 84 7e 00 00 00    	je     80104348 <procdump+0xb8>
    if(p->state == UNUSED)
801042ca:	8b 43 a0             	mov    -0x60(%ebx),%eax
801042cd:	85 c0                	test   %eax,%eax
801042cf:	74 e7                	je     801042b8 <procdump+0x28>
      state = "???";
801042d1:	ba 21 7b 10 80       	mov    $0x80107b21,%edx
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
801042d6:	83 f8 05             	cmp    $0x5,%eax
801042d9:	77 11                	ja     801042ec <procdump+0x5c>
801042db:	8b 14 85 60 81 10 80 	mov    -0x7fef7ea0(,%eax,4),%edx
      state = "???";
801042e2:	b8 21 7b 10 80       	mov    $0x80107b21,%eax
801042e7:	85 d2                	test   %edx,%edx
801042e9:	0f 44 d0             	cmove  %eax,%edx
    cprintf("%d %s %s", p->pid, state, p->name);
801042ec:	53                   	push   %ebx
801042ed:	52                   	push   %edx
801042ee:	ff 73 a4             	push   -0x5c(%ebx)
801042f1:	68 25 7b 10 80       	push   $0x80107b25
801042f6:	e8 b5 c3 ff ff       	call   801006b0 <cprintf>
    if(p->state == SLEEPING){
801042fb:	83 c4 10             	add    $0x10,%esp
801042fe:	83 7b a0 02          	cmpl   $0x2,-0x60(%ebx)
80104302:	75 a4                	jne    801042a8 <procdump+0x18>
      getcallerpcs((uint*)p->context->ebp+2, pc);
80104304:	83 ec 08             	sub    $0x8,%esp
80104307:	8d 45 c0             	lea    -0x40(%ebp),%eax
8010430a:	8d 7d c0             	lea    -0x40(%ebp),%edi
8010430d:	50                   	push   %eax
8010430e:	8b 43 b0             	mov    -0x50(%ebx),%eax
80104311:	8b 40 0c             	mov    0xc(%eax),%eax
80104314:	83 c0 08             	add    $0x8,%eax
80104317:	50                   	push   %eax
80104318:	e8 03 02 00 00       	call   80104520 <getcallerpcs>
      for(i=0; i<10 && pc[i] != 0; i++)
8010431d:	83 c4 10             	add    $0x10,%esp
80104320:	8b 17                	mov    (%edi),%edx
80104322:	85 d2                	test   %edx,%edx
80104324:	74 82                	je     801042a8 <procdump+0x18>
        cprintf(" %p", pc[i]);
80104326:	83 ec 08             	sub    $0x8,%esp
      for(i=0; i<10 && pc[i] != 0; i++)
80104329:	83 c7 04             	add    $0x4,%edi
        cprintf(" %p", pc[i]);
8010432c:	52                   	push   %edx
8010432d:	68 61 78 10 80       	push   $0x80107861
80104332:	e8 79 c3 ff ff       	call   801006b0 <cprintf>
      for(i=0; i<10 && pc[i] != 0; i++)
80104337:	83 c4 10             	add    $0x10,%esp
8010433a:	39 f7                	cmp    %esi,%edi
8010433c:	75 e2                	jne    80104320 <procdump+0x90>
8010433e:	e9 65 ff ff ff       	jmp    801042a8 <procdump+0x18>
80104343:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  }
}
80104348:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010434b:	5b                   	pop    %ebx
8010434c:	5e                   	pop    %esi
8010434d:	5f                   	pop    %edi
8010434e:	5d                   	pop    %ebp
8010434f:	c3                   	ret

80104350 <set_burst>:

int
set_burst(int pid, int bt)
{	
80104350:	55                   	push   %ebp
80104351:	89 e5                	mov    %esp,%ebp
80104353:	53                   	push   %ebx
80104354:	83 ec 10             	sub    $0x10,%esp
80104357:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *p;

  acquire(&ptable.lock);
8010435a:	68 40 2d 11 80       	push   $0x80112d40
8010435f:	e8 8c 03 00 00       	call   801046f0 <acquire>
80104364:	83 c4 10             	add    $0x10,%esp
  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
80104367:	b8 74 2d 11 80       	mov    $0x80112d74,%eax
8010436c:	eb 0e                	jmp    8010437c <set_burst+0x2c>
8010436e:	66 90                	xchg   %ax,%ax
80104370:	05 88 00 00 00       	add    $0x88,%eax
80104375:	3d 74 4f 11 80       	cmp    $0x80114f74,%eax
8010437a:	74 2c                	je     801043a8 <set_burst+0x58>
    if(p->pid == pid){
8010437c:	39 58 10             	cmp    %ebx,0x10(%eax)
8010437f:	75 ef                	jne    80104370 <set_burst+0x20>
      p->burst_time = bt;
80104381:	8b 55 0c             	mov    0xc(%ebp),%edx
      release(&ptable.lock);
80104384:	83 ec 0c             	sub    $0xc,%esp
      p->burst_time = bt;
80104387:	89 90 84 00 00 00    	mov    %edx,0x84(%eax)
      release(&ptable.lock);
8010438d:	68 40 2d 11 80       	push   $0x80112d40
80104392:	e8 f9 02 00 00       	call   80104690 <release>
      return 0; // Success
    }
  }
  release(&ptable.lock);
  return -1; // PID not found
}		
80104397:	8b 5d fc             	mov    -0x4(%ebp),%ebx
      return 0; // Success
8010439a:	83 c4 10             	add    $0x10,%esp
8010439d:	31 c0                	xor    %eax,%eax
}		
8010439f:	c9                   	leave
801043a0:	c3                   	ret
801043a1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  release(&ptable.lock);
801043a8:	83 ec 0c             	sub    $0xc,%esp
801043ab:	68 40 2d 11 80       	push   $0x80112d40
801043b0:	e8 db 02 00 00       	call   80104690 <release>
}		
801043b5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return -1; // PID not found
801043b8:	83 c4 10             	add    $0x10,%esp
801043bb:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}		
801043c0:	c9                   	leave
801043c1:	c3                   	ret
801043c2:	66 90                	xchg   %ax,%ax
801043c4:	66 90                	xchg   %ax,%ax
801043c6:	66 90                	xchg   %ax,%ax
801043c8:	66 90                	xchg   %ax,%ax
801043ca:	66 90                	xchg   %ax,%ax
801043cc:	66 90                	xchg   %ax,%ax
801043ce:	66 90                	xchg   %ax,%ax

801043d0 <initsleeplock>:
#include "spinlock.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
801043d0:	55                   	push   %ebp
801043d1:	89 e5                	mov    %esp,%ebp
801043d3:	53                   	push   %ebx
801043d4:	83 ec 0c             	sub    $0xc,%esp
801043d7:	8b 5d 08             	mov    0x8(%ebp),%ebx
  initlock(&lk->lk, "sleep lock");
801043da:	68 58 7b 10 80       	push   $0x80107b58
801043df:	8d 43 04             	lea    0x4(%ebx),%eax
801043e2:	50                   	push   %eax
801043e3:	e8 18 01 00 00       	call   80104500 <initlock>
  lk->name = name;
801043e8:	8b 45 0c             	mov    0xc(%ebp),%eax
  lk->locked = 0;
801043eb:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
}
801043f1:	83 c4 10             	add    $0x10,%esp
  lk->pid = 0;
801043f4:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  lk->name = name;
801043fb:	89 43 38             	mov    %eax,0x38(%ebx)
}
801043fe:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104401:	c9                   	leave
80104402:	c3                   	ret
80104403:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010440a:	00 
8010440b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104410 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
80104410:	55                   	push   %ebp
80104411:	89 e5                	mov    %esp,%ebp
80104413:	56                   	push   %esi
80104414:	53                   	push   %ebx
80104415:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104418:	8d 73 04             	lea    0x4(%ebx),%esi
8010441b:	83 ec 0c             	sub    $0xc,%esp
8010441e:	56                   	push   %esi
8010441f:	e8 cc 02 00 00       	call   801046f0 <acquire>
  while (lk->locked) {
80104424:	8b 13                	mov    (%ebx),%edx
80104426:	83 c4 10             	add    $0x10,%esp
80104429:	85 d2                	test   %edx,%edx
8010442b:	74 16                	je     80104443 <acquiresleep+0x33>
8010442d:	8d 76 00             	lea    0x0(%esi),%esi
    sleep(lk, &lk->lk);
80104430:	83 ec 08             	sub    $0x8,%esp
80104433:	56                   	push   %esi
80104434:	53                   	push   %ebx
80104435:	e8 b6 fc ff ff       	call   801040f0 <sleep>
  while (lk->locked) {
8010443a:	8b 03                	mov    (%ebx),%eax
8010443c:	83 c4 10             	add    $0x10,%esp
8010443f:	85 c0                	test   %eax,%eax
80104441:	75 ed                	jne    80104430 <acquiresleep+0x20>
  }
  lk->locked = 1;
80104443:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  lk->pid = myproc()->pid;
80104449:	e8 a2 f5 ff ff       	call   801039f0 <myproc>
8010444e:	8b 40 10             	mov    0x10(%eax),%eax
80104451:	89 43 3c             	mov    %eax,0x3c(%ebx)
  release(&lk->lk);
80104454:	89 75 08             	mov    %esi,0x8(%ebp)
}
80104457:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010445a:	5b                   	pop    %ebx
8010445b:	5e                   	pop    %esi
8010445c:	5d                   	pop    %ebp
  release(&lk->lk);
8010445d:	e9 2e 02 00 00       	jmp    80104690 <release>
80104462:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104469:	00 
8010446a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104470 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
80104470:	55                   	push   %ebp
80104471:	89 e5                	mov    %esp,%ebp
80104473:	56                   	push   %esi
80104474:	53                   	push   %ebx
80104475:	8b 5d 08             	mov    0x8(%ebp),%ebx
  acquire(&lk->lk);
80104478:	8d 73 04             	lea    0x4(%ebx),%esi
8010447b:	83 ec 0c             	sub    $0xc,%esp
8010447e:	56                   	push   %esi
8010447f:	e8 6c 02 00 00       	call   801046f0 <acquire>
  lk->locked = 0;
80104484:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
  lk->pid = 0;
8010448a:	c7 43 3c 00 00 00 00 	movl   $0x0,0x3c(%ebx)
  wakeup(lk);
80104491:	89 1c 24             	mov    %ebx,(%esp)
80104494:	e8 17 fd ff ff       	call   801041b0 <wakeup>
  release(&lk->lk);
80104499:	83 c4 10             	add    $0x10,%esp
8010449c:	89 75 08             	mov    %esi,0x8(%ebp)
}
8010449f:	8d 65 f8             	lea    -0x8(%ebp),%esp
801044a2:	5b                   	pop    %ebx
801044a3:	5e                   	pop    %esi
801044a4:	5d                   	pop    %ebp
  release(&lk->lk);
801044a5:	e9 e6 01 00 00       	jmp    80104690 <release>
801044aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801044b0 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
801044b0:	55                   	push   %ebp
801044b1:	89 e5                	mov    %esp,%ebp
801044b3:	57                   	push   %edi
801044b4:	31 ff                	xor    %edi,%edi
801044b6:	56                   	push   %esi
801044b7:	53                   	push   %ebx
801044b8:	83 ec 18             	sub    $0x18,%esp
801044bb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  int r;
  
  acquire(&lk->lk);
801044be:	8d 73 04             	lea    0x4(%ebx),%esi
801044c1:	56                   	push   %esi
801044c2:	e8 29 02 00 00       	call   801046f0 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
801044c7:	8b 03                	mov    (%ebx),%eax
801044c9:	83 c4 10             	add    $0x10,%esp
801044cc:	85 c0                	test   %eax,%eax
801044ce:	75 18                	jne    801044e8 <holdingsleep+0x38>
  release(&lk->lk);
801044d0:	83 ec 0c             	sub    $0xc,%esp
801044d3:	56                   	push   %esi
801044d4:	e8 b7 01 00 00       	call   80104690 <release>
  return r;
}
801044d9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801044dc:	89 f8                	mov    %edi,%eax
801044de:	5b                   	pop    %ebx
801044df:	5e                   	pop    %esi
801044e0:	5f                   	pop    %edi
801044e1:	5d                   	pop    %ebp
801044e2:	c3                   	ret
801044e3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  r = lk->locked && (lk->pid == myproc()->pid);
801044e8:	8b 5b 3c             	mov    0x3c(%ebx),%ebx
801044eb:	e8 00 f5 ff ff       	call   801039f0 <myproc>
801044f0:	39 58 10             	cmp    %ebx,0x10(%eax)
801044f3:	0f 94 c0             	sete   %al
801044f6:	0f b6 c0             	movzbl %al,%eax
801044f9:	89 c7                	mov    %eax,%edi
801044fb:	eb d3                	jmp    801044d0 <holdingsleep+0x20>
801044fd:	66 90                	xchg   %ax,%ax
801044ff:	90                   	nop

80104500 <initlock>:
#include "proc.h"
#include "spinlock.h"

void
initlock(struct spinlock *lk, char *name)
{
80104500:	55                   	push   %ebp
80104501:	89 e5                	mov    %esp,%ebp
80104503:	8b 45 08             	mov    0x8(%ebp),%eax
  lk->name = name;
80104506:	8b 55 0c             	mov    0xc(%ebp),%edx
  lk->locked = 0;
80104509:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  lk->name = name;
8010450f:	89 50 04             	mov    %edx,0x4(%eax)
  lk->cpu = 0;
80104512:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%eax)
}
80104519:	5d                   	pop    %ebp
8010451a:	c3                   	ret
8010451b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104520 <getcallerpcs>:
}

// Record the current call stack in pcs[] by following the %ebp chain.
void
getcallerpcs(void *v, uint pcs[])
{
80104520:	55                   	push   %ebp
80104521:	89 e5                	mov    %esp,%ebp
80104523:	53                   	push   %ebx
80104524:	8b 45 08             	mov    0x8(%ebp),%eax
80104527:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  uint *ebp;
  int i;

  ebp = (uint*)v - 2;
8010452a:	8d 50 f8             	lea    -0x8(%eax),%edx
  for(i = 0; i < 10; i++){
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
8010452d:	05 f8 ff ff 7f       	add    $0x7ffffff8,%eax
80104532:	3d fe ff ff 7f       	cmp    $0x7ffffffe,%eax
  for(i = 0; i < 10; i++){
80104537:	b8 00 00 00 00       	mov    $0x0,%eax
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
8010453c:	76 10                	jbe    8010454e <getcallerpcs+0x2e>
8010453e:	eb 28                	jmp    80104568 <getcallerpcs+0x48>
80104540:	8d 9a 00 00 00 80    	lea    -0x80000000(%edx),%ebx
80104546:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
8010454c:	77 1a                	ja     80104568 <getcallerpcs+0x48>
      break;
    pcs[i] = ebp[1];     // saved %eip
8010454e:	8b 5a 04             	mov    0x4(%edx),%ebx
80104551:	89 1c 81             	mov    %ebx,(%ecx,%eax,4)
  for(i = 0; i < 10; i++){
80104554:	83 c0 01             	add    $0x1,%eax
    ebp = (uint*)ebp[0]; // saved %ebp
80104557:	8b 12                	mov    (%edx),%edx
  for(i = 0; i < 10; i++){
80104559:	83 f8 0a             	cmp    $0xa,%eax
8010455c:	75 e2                	jne    80104540 <getcallerpcs+0x20>
  }
  for(; i < 10; i++)
    pcs[i] = 0;
}
8010455e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104561:	c9                   	leave
80104562:	c3                   	ret
80104563:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104568:	8d 04 81             	lea    (%ecx,%eax,4),%eax
8010456b:	83 c1 28             	add    $0x28,%ecx
8010456e:	89 ca                	mov    %ecx,%edx
80104570:	29 c2                	sub    %eax,%edx
80104572:	83 e2 04             	and    $0x4,%edx
80104575:	74 11                	je     80104588 <getcallerpcs+0x68>
    pcs[i] = 0;
80104577:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
8010457d:	83 c0 04             	add    $0x4,%eax
80104580:	39 c1                	cmp    %eax,%ecx
80104582:	74 da                	je     8010455e <getcallerpcs+0x3e>
80104584:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    pcs[i] = 0;
80104588:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
8010458e:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
80104591:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
80104598:	39 c1                	cmp    %eax,%ecx
8010459a:	75 ec                	jne    80104588 <getcallerpcs+0x68>
8010459c:	eb c0                	jmp    8010455e <getcallerpcs+0x3e>
8010459e:	66 90                	xchg   %ax,%ax

801045a0 <pushcli>:
// it takes two popcli to undo two pushcli.  Also, if interrupts
// are off, then pushcli, popcli leaves them off.

void
pushcli(void)
{
801045a0:	55                   	push   %ebp
801045a1:	89 e5                	mov    %esp,%ebp
801045a3:	53                   	push   %ebx
801045a4:	83 ec 04             	sub    $0x4,%esp
801045a7:	9c                   	pushf
801045a8:	5b                   	pop    %ebx
  asm volatile("cli");
801045a9:	fa                   	cli
  int eflags;

  eflags = readeflags();
  cli();
  if(mycpu()->ncli == 0)
801045aa:	e8 c1 f3 ff ff       	call   80103970 <mycpu>
801045af:	8b 80 a4 00 00 00    	mov    0xa4(%eax),%eax
801045b5:	85 c0                	test   %eax,%eax
801045b7:	74 17                	je     801045d0 <pushcli+0x30>
    mycpu()->intena = eflags & FL_IF;
  mycpu()->ncli += 1;
801045b9:	e8 b2 f3 ff ff       	call   80103970 <mycpu>
801045be:	83 80 a4 00 00 00 01 	addl   $0x1,0xa4(%eax)
}
801045c5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801045c8:	c9                   	leave
801045c9:	c3                   	ret
801045ca:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    mycpu()->intena = eflags & FL_IF;
801045d0:	e8 9b f3 ff ff       	call   80103970 <mycpu>
801045d5:	81 e3 00 02 00 00    	and    $0x200,%ebx
801045db:	89 98 a8 00 00 00    	mov    %ebx,0xa8(%eax)
801045e1:	eb d6                	jmp    801045b9 <pushcli+0x19>
801045e3:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801045ea:	00 
801045eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801045f0 <popcli>:

void
popcli(void)
{
801045f0:	55                   	push   %ebp
801045f1:	89 e5                	mov    %esp,%ebp
801045f3:	83 ec 08             	sub    $0x8,%esp
  asm volatile("pushfl; popl %0" : "=r" (eflags));
801045f6:	9c                   	pushf
801045f7:	58                   	pop    %eax
  if(readeflags()&FL_IF)
801045f8:	f6 c4 02             	test   $0x2,%ah
801045fb:	75 35                	jne    80104632 <popcli+0x42>
    panic("popcli - interruptible");
  if(--mycpu()->ncli < 0)
801045fd:	e8 6e f3 ff ff       	call   80103970 <mycpu>
80104602:	83 a8 a4 00 00 00 01 	subl   $0x1,0xa4(%eax)
80104609:	78 34                	js     8010463f <popcli+0x4f>
    panic("popcli");
  if(mycpu()->ncli == 0 && mycpu()->intena)
8010460b:	e8 60 f3 ff ff       	call   80103970 <mycpu>
80104610:	8b 90 a4 00 00 00    	mov    0xa4(%eax),%edx
80104616:	85 d2                	test   %edx,%edx
80104618:	74 06                	je     80104620 <popcli+0x30>
    sti();
}
8010461a:	c9                   	leave
8010461b:	c3                   	ret
8010461c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  if(mycpu()->ncli == 0 && mycpu()->intena)
80104620:	e8 4b f3 ff ff       	call   80103970 <mycpu>
80104625:	8b 80 a8 00 00 00    	mov    0xa8(%eax),%eax
8010462b:	85 c0                	test   %eax,%eax
8010462d:	74 eb                	je     8010461a <popcli+0x2a>
  asm volatile("sti");
8010462f:	fb                   	sti
}
80104630:	c9                   	leave
80104631:	c3                   	ret
    panic("popcli - interruptible");
80104632:	83 ec 0c             	sub    $0xc,%esp
80104635:	68 63 7b 10 80       	push   $0x80107b63
8010463a:	e8 41 bd ff ff       	call   80100380 <panic>
    panic("popcli");
8010463f:	83 ec 0c             	sub    $0xc,%esp
80104642:	68 7a 7b 10 80       	push   $0x80107b7a
80104647:	e8 34 bd ff ff       	call   80100380 <panic>
8010464c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80104650 <holding>:
{
80104650:	55                   	push   %ebp
80104651:	89 e5                	mov    %esp,%ebp
80104653:	56                   	push   %esi
80104654:	53                   	push   %ebx
80104655:	8b 75 08             	mov    0x8(%ebp),%esi
80104658:	31 db                	xor    %ebx,%ebx
  pushcli();
8010465a:	e8 41 ff ff ff       	call   801045a0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
8010465f:	8b 06                	mov    (%esi),%eax
80104661:	85 c0                	test   %eax,%eax
80104663:	75 0b                	jne    80104670 <holding+0x20>
  popcli();
80104665:	e8 86 ff ff ff       	call   801045f0 <popcli>
}
8010466a:	89 d8                	mov    %ebx,%eax
8010466c:	5b                   	pop    %ebx
8010466d:	5e                   	pop    %esi
8010466e:	5d                   	pop    %ebp
8010466f:	c3                   	ret
  r = lock->locked && lock->cpu == mycpu();
80104670:	8b 5e 08             	mov    0x8(%esi),%ebx
80104673:	e8 f8 f2 ff ff       	call   80103970 <mycpu>
80104678:	39 c3                	cmp    %eax,%ebx
8010467a:	0f 94 c3             	sete   %bl
  popcli();
8010467d:	e8 6e ff ff ff       	call   801045f0 <popcli>
  r = lock->locked && lock->cpu == mycpu();
80104682:	0f b6 db             	movzbl %bl,%ebx
}
80104685:	89 d8                	mov    %ebx,%eax
80104687:	5b                   	pop    %ebx
80104688:	5e                   	pop    %esi
80104689:	5d                   	pop    %ebp
8010468a:	c3                   	ret
8010468b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80104690 <release>:
{
80104690:	55                   	push   %ebp
80104691:	89 e5                	mov    %esp,%ebp
80104693:	56                   	push   %esi
80104694:	53                   	push   %ebx
80104695:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
80104698:	e8 03 ff ff ff       	call   801045a0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
8010469d:	8b 03                	mov    (%ebx),%eax
8010469f:	85 c0                	test   %eax,%eax
801046a1:	75 15                	jne    801046b8 <release+0x28>
  popcli();
801046a3:	e8 48 ff ff ff       	call   801045f0 <popcli>
    panic("release");
801046a8:	83 ec 0c             	sub    $0xc,%esp
801046ab:	68 81 7b 10 80       	push   $0x80107b81
801046b0:	e8 cb bc ff ff       	call   80100380 <panic>
801046b5:	8d 76 00             	lea    0x0(%esi),%esi
  r = lock->locked && lock->cpu == mycpu();
801046b8:	8b 73 08             	mov    0x8(%ebx),%esi
801046bb:	e8 b0 f2 ff ff       	call   80103970 <mycpu>
801046c0:	39 c6                	cmp    %eax,%esi
801046c2:	75 df                	jne    801046a3 <release+0x13>
  popcli();
801046c4:	e8 27 ff ff ff       	call   801045f0 <popcli>
  lk->pcs[0] = 0;
801046c9:	c7 43 0c 00 00 00 00 	movl   $0x0,0xc(%ebx)
  lk->cpu = 0;
801046d0:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%ebx)
  __sync_synchronize();
801046d7:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  asm volatile("movl $0, %0" : "+m" (lk->locked) : );
801046dc:	c7 03 00 00 00 00    	movl   $0x0,(%ebx)
}
801046e2:	8d 65 f8             	lea    -0x8(%ebp),%esp
801046e5:	5b                   	pop    %ebx
801046e6:	5e                   	pop    %esi
801046e7:	5d                   	pop    %ebp
  popcli();
801046e8:	e9 03 ff ff ff       	jmp    801045f0 <popcli>
801046ed:	8d 76 00             	lea    0x0(%esi),%esi

801046f0 <acquire>:
{
801046f0:	55                   	push   %ebp
801046f1:	89 e5                	mov    %esp,%ebp
801046f3:	53                   	push   %ebx
801046f4:	83 ec 04             	sub    $0x4,%esp
  pushcli(); // disable interrupts to avoid deadlock.
801046f7:	e8 a4 fe ff ff       	call   801045a0 <pushcli>
  if(holding(lk))
801046fc:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pushcli();
801046ff:	e8 9c fe ff ff       	call   801045a0 <pushcli>
  r = lock->locked && lock->cpu == mycpu();
80104704:	8b 03                	mov    (%ebx),%eax
80104706:	85 c0                	test   %eax,%eax
80104708:	0f 85 b2 00 00 00    	jne    801047c0 <acquire+0xd0>
  popcli();
8010470e:	e8 dd fe ff ff       	call   801045f0 <popcli>
  asm volatile("lock; xchgl %0, %1" :
80104713:	b9 01 00 00 00       	mov    $0x1,%ecx
80104718:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010471f:	00 
  while(xchg(&lk->locked, 1) != 0)
80104720:	8b 55 08             	mov    0x8(%ebp),%edx
80104723:	89 c8                	mov    %ecx,%eax
80104725:	f0 87 02             	lock xchg %eax,(%edx)
80104728:	85 c0                	test   %eax,%eax
8010472a:	75 f4                	jne    80104720 <acquire+0x30>
  __sync_synchronize();
8010472c:	f0 83 0c 24 00       	lock orl $0x0,(%esp)
  lk->cpu = mycpu();
80104731:	8b 5d 08             	mov    0x8(%ebp),%ebx
80104734:	e8 37 f2 ff ff       	call   80103970 <mycpu>
  getcallerpcs(&lk, lk->pcs);
80104739:	8b 4d 08             	mov    0x8(%ebp),%ecx
  for(i = 0; i < 10; i++){
8010473c:	31 d2                	xor    %edx,%edx
  lk->cpu = mycpu();
8010473e:	89 43 08             	mov    %eax,0x8(%ebx)
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80104741:	8d 85 00 00 00 80    	lea    -0x80000000(%ebp),%eax
80104747:	3d fe ff ff 7f       	cmp    $0x7ffffffe,%eax
8010474c:	77 32                	ja     80104780 <acquire+0x90>
  ebp = (uint*)v - 2;
8010474e:	89 e8                	mov    %ebp,%eax
80104750:	eb 14                	jmp    80104766 <acquire+0x76>
80104752:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    if(ebp == 0 || ebp < (uint*)KERNBASE || ebp == (uint*)0xffffffff)
80104758:	8d 98 00 00 00 80    	lea    -0x80000000(%eax),%ebx
8010475e:	81 fb fe ff ff 7f    	cmp    $0x7ffffffe,%ebx
80104764:	77 1a                	ja     80104780 <acquire+0x90>
    pcs[i] = ebp[1];     // saved %eip
80104766:	8b 58 04             	mov    0x4(%eax),%ebx
80104769:	89 5c 91 0c          	mov    %ebx,0xc(%ecx,%edx,4)
  for(i = 0; i < 10; i++){
8010476d:	83 c2 01             	add    $0x1,%edx
    ebp = (uint*)ebp[0]; // saved %ebp
80104770:	8b 00                	mov    (%eax),%eax
  for(i = 0; i < 10; i++){
80104772:	83 fa 0a             	cmp    $0xa,%edx
80104775:	75 e1                	jne    80104758 <acquire+0x68>
}
80104777:	8b 5d fc             	mov    -0x4(%ebp),%ebx
8010477a:	c9                   	leave
8010477b:	c3                   	ret
8010477c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80104780:	8d 44 91 0c          	lea    0xc(%ecx,%edx,4),%eax
80104784:	83 c1 34             	add    $0x34,%ecx
80104787:	89 ca                	mov    %ecx,%edx
80104789:	29 c2                	sub    %eax,%edx
8010478b:	83 e2 04             	and    $0x4,%edx
8010478e:	74 10                	je     801047a0 <acquire+0xb0>
    pcs[i] = 0;
80104790:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
80104796:	83 c0 04             	add    $0x4,%eax
80104799:	39 c1                	cmp    %eax,%ecx
8010479b:	74 da                	je     80104777 <acquire+0x87>
8010479d:	8d 76 00             	lea    0x0(%esi),%esi
    pcs[i] = 0;
801047a0:	c7 00 00 00 00 00    	movl   $0x0,(%eax)
  for(; i < 10; i++)
801047a6:	83 c0 08             	add    $0x8,%eax
    pcs[i] = 0;
801047a9:	c7 40 fc 00 00 00 00 	movl   $0x0,-0x4(%eax)
  for(; i < 10; i++)
801047b0:	39 c1                	cmp    %eax,%ecx
801047b2:	75 ec                	jne    801047a0 <acquire+0xb0>
801047b4:	eb c1                	jmp    80104777 <acquire+0x87>
801047b6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801047bd:	00 
801047be:	66 90                	xchg   %ax,%ax
  r = lock->locked && lock->cpu == mycpu();
801047c0:	8b 5b 08             	mov    0x8(%ebx),%ebx
801047c3:	e8 a8 f1 ff ff       	call   80103970 <mycpu>
801047c8:	39 c3                	cmp    %eax,%ebx
801047ca:	0f 85 3e ff ff ff    	jne    8010470e <acquire+0x1e>
  popcli();
801047d0:	e8 1b fe ff ff       	call   801045f0 <popcli>
    panic("acquire");
801047d5:	83 ec 0c             	sub    $0xc,%esp
801047d8:	68 89 7b 10 80       	push   $0x80107b89
801047dd:	e8 9e bb ff ff       	call   80100380 <panic>
801047e2:	66 90                	xchg   %ax,%ax
801047e4:	66 90                	xchg   %ax,%ax
801047e6:	66 90                	xchg   %ax,%ax
801047e8:	66 90                	xchg   %ax,%ax
801047ea:	66 90                	xchg   %ax,%ax
801047ec:	66 90                	xchg   %ax,%ax
801047ee:	66 90                	xchg   %ax,%ax

801047f0 <memset>:
#include "types.h"
#include "x86.h"

void*
memset(void *dst, int c, uint n)
{
801047f0:	55                   	push   %ebp
801047f1:	89 e5                	mov    %esp,%ebp
801047f3:	57                   	push   %edi
801047f4:	8b 55 08             	mov    0x8(%ebp),%edx
801047f7:	8b 4d 10             	mov    0x10(%ebp),%ecx
  if ((int)dst%4 == 0 && n%4 == 0){
801047fa:	89 d0                	mov    %edx,%eax
801047fc:	09 c8                	or     %ecx,%eax
801047fe:	a8 03                	test   $0x3,%al
80104800:	75 1e                	jne    80104820 <memset+0x30>
    c &= 0xFF;
80104802:	0f b6 45 0c          	movzbl 0xc(%ebp),%eax
    stosl(dst, (c<<24)|(c<<16)|(c<<8)|c, n/4);
80104806:	c1 e9 02             	shr    $0x2,%ecx
  asm volatile("cld; rep stosl" :
80104809:	89 d7                	mov    %edx,%edi
8010480b:	69 c0 01 01 01 01    	imul   $0x1010101,%eax,%eax
80104811:	fc                   	cld
80104812:	f3 ab                	rep stos %eax,%es:(%edi)
  } else
    stosb(dst, c, n);
  return dst;
}
80104814:	8b 7d fc             	mov    -0x4(%ebp),%edi
80104817:	89 d0                	mov    %edx,%eax
80104819:	c9                   	leave
8010481a:	c3                   	ret
8010481b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  asm volatile("cld; rep stosb" :
80104820:	8b 45 0c             	mov    0xc(%ebp),%eax
80104823:	89 d7                	mov    %edx,%edi
80104825:	fc                   	cld
80104826:	f3 aa                	rep stos %al,%es:(%edi)
80104828:	8b 7d fc             	mov    -0x4(%ebp),%edi
8010482b:	89 d0                	mov    %edx,%eax
8010482d:	c9                   	leave
8010482e:	c3                   	ret
8010482f:	90                   	nop

80104830 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
80104830:	55                   	push   %ebp
80104831:	89 e5                	mov    %esp,%ebp
80104833:	56                   	push   %esi
80104834:	8b 75 10             	mov    0x10(%ebp),%esi
80104837:	8b 45 08             	mov    0x8(%ebp),%eax
8010483a:	53                   	push   %ebx
8010483b:	8b 55 0c             	mov    0xc(%ebp),%edx
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
8010483e:	85 f6                	test   %esi,%esi
80104840:	74 2e                	je     80104870 <memcmp+0x40>
80104842:	01 c6                	add    %eax,%esi
80104844:	eb 14                	jmp    8010485a <memcmp+0x2a>
80104846:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010484d:	00 
8010484e:	66 90                	xchg   %ax,%ax
    if(*s1 != *s2)
      return *s1 - *s2;
    s1++, s2++;
80104850:	83 c0 01             	add    $0x1,%eax
80104853:	83 c2 01             	add    $0x1,%edx
  while(n-- > 0){
80104856:	39 f0                	cmp    %esi,%eax
80104858:	74 16                	je     80104870 <memcmp+0x40>
    if(*s1 != *s2)
8010485a:	0f b6 08             	movzbl (%eax),%ecx
8010485d:	0f b6 1a             	movzbl (%edx),%ebx
80104860:	38 d9                	cmp    %bl,%cl
80104862:	74 ec                	je     80104850 <memcmp+0x20>
      return *s1 - *s2;
80104864:	0f b6 c1             	movzbl %cl,%eax
80104867:	29 d8                	sub    %ebx,%eax
  }

  return 0;
}
80104869:	5b                   	pop    %ebx
8010486a:	5e                   	pop    %esi
8010486b:	5d                   	pop    %ebp
8010486c:	c3                   	ret
8010486d:	8d 76 00             	lea    0x0(%esi),%esi
80104870:	5b                   	pop    %ebx
  return 0;
80104871:	31 c0                	xor    %eax,%eax
}
80104873:	5e                   	pop    %esi
80104874:	5d                   	pop    %ebp
80104875:	c3                   	ret
80104876:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010487d:	00 
8010487e:	66 90                	xchg   %ax,%ax

80104880 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
80104880:	55                   	push   %ebp
80104881:	89 e5                	mov    %esp,%ebp
80104883:	57                   	push   %edi
80104884:	8b 55 08             	mov    0x8(%ebp),%edx
80104887:	8b 45 10             	mov    0x10(%ebp),%eax
8010488a:	56                   	push   %esi
8010488b:	8b 75 0c             	mov    0xc(%ebp),%esi
  const char *s;
  char *d;

  s = src;
  d = dst;
  if(s < d && s + n > d){
8010488e:	39 d6                	cmp    %edx,%esi
80104890:	73 26                	jae    801048b8 <memmove+0x38>
80104892:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
80104895:	39 ca                	cmp    %ecx,%edx
80104897:	73 1f                	jae    801048b8 <memmove+0x38>
    s += n;
    d += n;
    while(n-- > 0)
80104899:	85 c0                	test   %eax,%eax
8010489b:	74 0f                	je     801048ac <memmove+0x2c>
8010489d:	83 e8 01             	sub    $0x1,%eax
      *--d = *--s;
801048a0:	0f b6 0c 06          	movzbl (%esi,%eax,1),%ecx
801048a4:	88 0c 02             	mov    %cl,(%edx,%eax,1)
    while(n-- > 0)
801048a7:	83 e8 01             	sub    $0x1,%eax
801048aa:	73 f4                	jae    801048a0 <memmove+0x20>
  } else
    while(n-- > 0)
      *d++ = *s++;

  return dst;
}
801048ac:	5e                   	pop    %esi
801048ad:	89 d0                	mov    %edx,%eax
801048af:	5f                   	pop    %edi
801048b0:	5d                   	pop    %ebp
801048b1:	c3                   	ret
801048b2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    while(n-- > 0)
801048b8:	8d 0c 06             	lea    (%esi,%eax,1),%ecx
801048bb:	89 d7                	mov    %edx,%edi
801048bd:	85 c0                	test   %eax,%eax
801048bf:	74 eb                	je     801048ac <memmove+0x2c>
801048c1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      *d++ = *s++;
801048c8:	a4                   	movsb  %ds:(%esi),%es:(%edi)
    while(n-- > 0)
801048c9:	39 ce                	cmp    %ecx,%esi
801048cb:	75 fb                	jne    801048c8 <memmove+0x48>
}
801048cd:	5e                   	pop    %esi
801048ce:	89 d0                	mov    %edx,%eax
801048d0:	5f                   	pop    %edi
801048d1:	5d                   	pop    %ebp
801048d2:	c3                   	ret
801048d3:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801048da:	00 
801048db:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

801048e0 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
801048e0:	eb 9e                	jmp    80104880 <memmove>
801048e2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801048e9:	00 
801048ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801048f0 <strncmp>:
}

int
strncmp(const char *p, const char *q, uint n)
{
801048f0:	55                   	push   %ebp
801048f1:	89 e5                	mov    %esp,%ebp
801048f3:	53                   	push   %ebx
801048f4:	8b 55 10             	mov    0x10(%ebp),%edx
801048f7:	8b 45 08             	mov    0x8(%ebp),%eax
801048fa:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(n > 0 && *p && *p == *q)
801048fd:	85 d2                	test   %edx,%edx
801048ff:	75 16                	jne    80104917 <strncmp+0x27>
80104901:	eb 2d                	jmp    80104930 <strncmp+0x40>
80104903:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104908:	3a 19                	cmp    (%ecx),%bl
8010490a:	75 12                	jne    8010491e <strncmp+0x2e>
    n--, p++, q++;
8010490c:	83 c0 01             	add    $0x1,%eax
8010490f:	83 c1 01             	add    $0x1,%ecx
  while(n > 0 && *p && *p == *q)
80104912:	83 ea 01             	sub    $0x1,%edx
80104915:	74 19                	je     80104930 <strncmp+0x40>
80104917:	0f b6 18             	movzbl (%eax),%ebx
8010491a:	84 db                	test   %bl,%bl
8010491c:	75 ea                	jne    80104908 <strncmp+0x18>
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
8010491e:	0f b6 00             	movzbl (%eax),%eax
80104921:	0f b6 11             	movzbl (%ecx),%edx
}
80104924:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104927:	c9                   	leave
  return (uchar)*p - (uchar)*q;
80104928:	29 d0                	sub    %edx,%eax
}
8010492a:	c3                   	ret
8010492b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104930:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return 0;
80104933:	31 c0                	xor    %eax,%eax
}
80104935:	c9                   	leave
80104936:	c3                   	ret
80104937:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010493e:	00 
8010493f:	90                   	nop

80104940 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
80104940:	55                   	push   %ebp
80104941:	89 e5                	mov    %esp,%ebp
80104943:	57                   	push   %edi
80104944:	56                   	push   %esi
80104945:	8b 75 08             	mov    0x8(%ebp),%esi
80104948:	53                   	push   %ebx
80104949:	8b 55 10             	mov    0x10(%ebp),%edx
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
8010494c:	89 f0                	mov    %esi,%eax
8010494e:	eb 15                	jmp    80104965 <strncpy+0x25>
80104950:	83 45 0c 01          	addl   $0x1,0xc(%ebp)
80104954:	8b 7d 0c             	mov    0xc(%ebp),%edi
80104957:	83 c0 01             	add    $0x1,%eax
8010495a:	0f b6 4f ff          	movzbl -0x1(%edi),%ecx
8010495e:	88 48 ff             	mov    %cl,-0x1(%eax)
80104961:	84 c9                	test   %cl,%cl
80104963:	74 13                	je     80104978 <strncpy+0x38>
80104965:	89 d3                	mov    %edx,%ebx
80104967:	83 ea 01             	sub    $0x1,%edx
8010496a:	85 db                	test   %ebx,%ebx
8010496c:	7f e2                	jg     80104950 <strncpy+0x10>
    ;
  while(n-- > 0)
    *s++ = 0;
  return os;
}
8010496e:	5b                   	pop    %ebx
8010496f:	89 f0                	mov    %esi,%eax
80104971:	5e                   	pop    %esi
80104972:	5f                   	pop    %edi
80104973:	5d                   	pop    %ebp
80104974:	c3                   	ret
80104975:	8d 76 00             	lea    0x0(%esi),%esi
  while(n-- > 0)
80104978:	8d 0c 18             	lea    (%eax,%ebx,1),%ecx
8010497b:	83 e9 01             	sub    $0x1,%ecx
8010497e:	85 d2                	test   %edx,%edx
80104980:	74 ec                	je     8010496e <strncpy+0x2e>
80104982:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    *s++ = 0;
80104988:	83 c0 01             	add    $0x1,%eax
8010498b:	89 ca                	mov    %ecx,%edx
8010498d:	c6 40 ff 00          	movb   $0x0,-0x1(%eax)
  while(n-- > 0)
80104991:	29 c2                	sub    %eax,%edx
80104993:	85 d2                	test   %edx,%edx
80104995:	7f f1                	jg     80104988 <strncpy+0x48>
}
80104997:	5b                   	pop    %ebx
80104998:	89 f0                	mov    %esi,%eax
8010499a:	5e                   	pop    %esi
8010499b:	5f                   	pop    %edi
8010499c:	5d                   	pop    %ebp
8010499d:	c3                   	ret
8010499e:	66 90                	xchg   %ax,%ax

801049a0 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
801049a0:	55                   	push   %ebp
801049a1:	89 e5                	mov    %esp,%ebp
801049a3:	56                   	push   %esi
801049a4:	8b 55 10             	mov    0x10(%ebp),%edx
801049a7:	8b 75 08             	mov    0x8(%ebp),%esi
801049aa:	53                   	push   %ebx
801049ab:	8b 45 0c             	mov    0xc(%ebp),%eax
  char *os;

  os = s;
  if(n <= 0)
801049ae:	85 d2                	test   %edx,%edx
801049b0:	7e 25                	jle    801049d7 <safestrcpy+0x37>
801049b2:	8d 5c 10 ff          	lea    -0x1(%eax,%edx,1),%ebx
801049b6:	89 f2                	mov    %esi,%edx
801049b8:	eb 16                	jmp    801049d0 <safestrcpy+0x30>
801049ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
801049c0:	0f b6 08             	movzbl (%eax),%ecx
801049c3:	83 c0 01             	add    $0x1,%eax
801049c6:	83 c2 01             	add    $0x1,%edx
801049c9:	88 4a ff             	mov    %cl,-0x1(%edx)
801049cc:	84 c9                	test   %cl,%cl
801049ce:	74 04                	je     801049d4 <safestrcpy+0x34>
801049d0:	39 d8                	cmp    %ebx,%eax
801049d2:	75 ec                	jne    801049c0 <safestrcpy+0x20>
    ;
  *s = 0;
801049d4:	c6 02 00             	movb   $0x0,(%edx)
  return os;
}
801049d7:	89 f0                	mov    %esi,%eax
801049d9:	5b                   	pop    %ebx
801049da:	5e                   	pop    %esi
801049db:	5d                   	pop    %ebp
801049dc:	c3                   	ret
801049dd:	8d 76 00             	lea    0x0(%esi),%esi

801049e0 <strlen>:

int
strlen(const char *s)
{
801049e0:	55                   	push   %ebp
  int n;

  for(n = 0; s[n]; n++)
801049e1:	31 c0                	xor    %eax,%eax
{
801049e3:	89 e5                	mov    %esp,%ebp
801049e5:	8b 55 08             	mov    0x8(%ebp),%edx
  for(n = 0; s[n]; n++)
801049e8:	80 3a 00             	cmpb   $0x0,(%edx)
801049eb:	74 0c                	je     801049f9 <strlen+0x19>
801049ed:	8d 76 00             	lea    0x0(%esi),%esi
801049f0:	83 c0 01             	add    $0x1,%eax
801049f3:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
801049f7:	75 f7                	jne    801049f0 <strlen+0x10>
    ;
  return n;
}
801049f9:	5d                   	pop    %ebp
801049fa:	c3                   	ret

801049fb <swtch>:
# a struct context, and save its address in *old.
# Switch stacks to new and pop previously-saved registers.

.globl swtch
swtch:
  movl 4(%esp), %eax
801049fb:	8b 44 24 04          	mov    0x4(%esp),%eax
  movl 8(%esp), %edx
801049ff:	8b 54 24 08          	mov    0x8(%esp),%edx

  # Save old callee-saved registers
  pushl %ebp
80104a03:	55                   	push   %ebp
  pushl %ebx
80104a04:	53                   	push   %ebx
  pushl %esi
80104a05:	56                   	push   %esi
  pushl %edi
80104a06:	57                   	push   %edi

  # Switch stacks
  movl %esp, (%eax)
80104a07:	89 20                	mov    %esp,(%eax)
  movl %edx, %esp
80104a09:	89 d4                	mov    %edx,%esp

  # Load new callee-saved registers
  popl %edi
80104a0b:	5f                   	pop    %edi
  popl %esi
80104a0c:	5e                   	pop    %esi
  popl %ebx
80104a0d:	5b                   	pop    %ebx
  popl %ebp
80104a0e:	5d                   	pop    %ebp
  ret
80104a0f:	c3                   	ret

80104a10 <fetchint>:
// to a saved program counter, and then the first argument.

// Fetch the int at addr from the current process.
int
fetchint(uint addr, int *ip)
{
80104a10:	55                   	push   %ebp
80104a11:	89 e5                	mov    %esp,%ebp
80104a13:	53                   	push   %ebx
80104a14:	83 ec 04             	sub    $0x4,%esp
80104a17:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct proc *curproc = myproc();
80104a1a:	e8 d1 ef ff ff       	call   801039f0 <myproc>

  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104a1f:	8b 00                	mov    (%eax),%eax
80104a21:	39 c3                	cmp    %eax,%ebx
80104a23:	73 1b                	jae    80104a40 <fetchint+0x30>
80104a25:	8d 53 04             	lea    0x4(%ebx),%edx
80104a28:	39 d0                	cmp    %edx,%eax
80104a2a:	72 14                	jb     80104a40 <fetchint+0x30>
    return -1;
  *ip = *(int*)(addr);
80104a2c:	8b 45 0c             	mov    0xc(%ebp),%eax
80104a2f:	8b 13                	mov    (%ebx),%edx
80104a31:	89 10                	mov    %edx,(%eax)
  return 0;
80104a33:	31 c0                	xor    %eax,%eax
}
80104a35:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104a38:	c9                   	leave
80104a39:	c3                   	ret
80104a3a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80104a40:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104a45:	eb ee                	jmp    80104a35 <fetchint+0x25>
80104a47:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a4e:	00 
80104a4f:	90                   	nop

80104a50 <fetchstr>:
// Fetch the nul-terminated string at addr from the current process.
// Doesn't actually copy the string - just sets *pp to point at it.
// Returns length of string, not including nul.
int
fetchstr(uint addr, char **pp)
{
80104a50:	55                   	push   %ebp
80104a51:	89 e5                	mov    %esp,%ebp
80104a53:	53                   	push   %ebx
80104a54:	83 ec 04             	sub    $0x4,%esp
80104a57:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char *s, *ep;
  struct proc *curproc = myproc();
80104a5a:	e8 91 ef ff ff       	call   801039f0 <myproc>

  if(addr >= curproc->sz)
80104a5f:	3b 18                	cmp    (%eax),%ebx
80104a61:	73 2d                	jae    80104a90 <fetchstr+0x40>
    return -1;
  *pp = (char*)addr;
80104a63:	8b 55 0c             	mov    0xc(%ebp),%edx
80104a66:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
80104a68:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
80104a6a:	39 d3                	cmp    %edx,%ebx
80104a6c:	73 22                	jae    80104a90 <fetchstr+0x40>
80104a6e:	89 d8                	mov    %ebx,%eax
80104a70:	eb 0d                	jmp    80104a7f <fetchstr+0x2f>
80104a72:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104a78:	83 c0 01             	add    $0x1,%eax
80104a7b:	39 d0                	cmp    %edx,%eax
80104a7d:	73 11                	jae    80104a90 <fetchstr+0x40>
    if(*s == 0)
80104a7f:	80 38 00             	cmpb   $0x0,(%eax)
80104a82:	75 f4                	jne    80104a78 <fetchstr+0x28>
      return s - *pp;
80104a84:	29 d8                	sub    %ebx,%eax
  }
  return -1;
}
80104a86:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104a89:	c9                   	leave
80104a8a:	c3                   	ret
80104a8b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
80104a90:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
80104a93:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104a98:	c9                   	leave
80104a99:	c3                   	ret
80104a9a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80104aa0 <argint>:

// Fetch the nth 32-bit system call argument.
int
argint(int n, int *ip)
{
80104aa0:	55                   	push   %ebp
80104aa1:	89 e5                	mov    %esp,%ebp
80104aa3:	56                   	push   %esi
80104aa4:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104aa5:	e8 46 ef ff ff       	call   801039f0 <myproc>
80104aaa:	8b 55 08             	mov    0x8(%ebp),%edx
80104aad:	8b 40 18             	mov    0x18(%eax),%eax
80104ab0:	8b 40 44             	mov    0x44(%eax),%eax
80104ab3:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104ab6:	e8 35 ef ff ff       	call   801039f0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104abb:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104abe:	8b 00                	mov    (%eax),%eax
80104ac0:	39 c6                	cmp    %eax,%esi
80104ac2:	73 1c                	jae    80104ae0 <argint+0x40>
80104ac4:	8d 53 08             	lea    0x8(%ebx),%edx
80104ac7:	39 d0                	cmp    %edx,%eax
80104ac9:	72 15                	jb     80104ae0 <argint+0x40>
  *ip = *(int*)(addr);
80104acb:	8b 45 0c             	mov    0xc(%ebp),%eax
80104ace:	8b 53 04             	mov    0x4(%ebx),%edx
80104ad1:	89 10                	mov    %edx,(%eax)
  return 0;
80104ad3:	31 c0                	xor    %eax,%eax
}
80104ad5:	5b                   	pop    %ebx
80104ad6:	5e                   	pop    %esi
80104ad7:	5d                   	pop    %ebp
80104ad8:	c3                   	ret
80104ad9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    return -1;
80104ae0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104ae5:	eb ee                	jmp    80104ad5 <argint+0x35>
80104ae7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104aee:	00 
80104aef:	90                   	nop

80104af0 <argptr>:
// Fetch the nth word-sized system call argument as a pointer
// to a block of memory of size bytes.  Check that the pointer
// lies within the process address space.
int
argptr(int n, char **pp, int size)
{
80104af0:	55                   	push   %ebp
80104af1:	89 e5                	mov    %esp,%ebp
80104af3:	57                   	push   %edi
80104af4:	56                   	push   %esi
80104af5:	53                   	push   %ebx
80104af6:	83 ec 0c             	sub    $0xc,%esp
  int i;
  struct proc *curproc = myproc();
80104af9:	e8 f2 ee ff ff       	call   801039f0 <myproc>
80104afe:	89 c6                	mov    %eax,%esi
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104b00:	e8 eb ee ff ff       	call   801039f0 <myproc>
80104b05:	8b 55 08             	mov    0x8(%ebp),%edx
80104b08:	8b 40 18             	mov    0x18(%eax),%eax
80104b0b:	8b 40 44             	mov    0x44(%eax),%eax
80104b0e:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104b11:	e8 da ee ff ff       	call   801039f0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104b16:	8d 7b 04             	lea    0x4(%ebx),%edi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104b19:	8b 00                	mov    (%eax),%eax
80104b1b:	39 c7                	cmp    %eax,%edi
80104b1d:	73 31                	jae    80104b50 <argptr+0x60>
80104b1f:	8d 4b 08             	lea    0x8(%ebx),%ecx
80104b22:	39 c8                	cmp    %ecx,%eax
80104b24:	72 2a                	jb     80104b50 <argptr+0x60>
 
  if(argint(n, &i) < 0)
    return -1;
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104b26:	8b 55 10             	mov    0x10(%ebp),%edx
  *ip = *(int*)(addr);
80104b29:	8b 43 04             	mov    0x4(%ebx),%eax
  if(size < 0 || (uint)i >= curproc->sz || (uint)i+size > curproc->sz)
80104b2c:	85 d2                	test   %edx,%edx
80104b2e:	78 20                	js     80104b50 <argptr+0x60>
80104b30:	8b 16                	mov    (%esi),%edx
80104b32:	39 d0                	cmp    %edx,%eax
80104b34:	73 1a                	jae    80104b50 <argptr+0x60>
80104b36:	8b 5d 10             	mov    0x10(%ebp),%ebx
80104b39:	01 c3                	add    %eax,%ebx
80104b3b:	39 da                	cmp    %ebx,%edx
80104b3d:	72 11                	jb     80104b50 <argptr+0x60>
    return -1;
  *pp = (char*)i;
80104b3f:	8b 55 0c             	mov    0xc(%ebp),%edx
80104b42:	89 02                	mov    %eax,(%edx)
  return 0;
80104b44:	31 c0                	xor    %eax,%eax
}
80104b46:	83 c4 0c             	add    $0xc,%esp
80104b49:	5b                   	pop    %ebx
80104b4a:	5e                   	pop    %esi
80104b4b:	5f                   	pop    %edi
80104b4c:	5d                   	pop    %ebp
80104b4d:	c3                   	ret
80104b4e:	66 90                	xchg   %ax,%ax
    return -1;
80104b50:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104b55:	eb ef                	jmp    80104b46 <argptr+0x56>
80104b57:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104b5e:	00 
80104b5f:	90                   	nop

80104b60 <argstr>:
// Check that the pointer is valid and the string is nul-terminated.
// (There is no shared writable memory, so the string can't change
// between this check and being used by the kernel.)
int
argstr(int n, char **pp)
{
80104b60:	55                   	push   %ebp
80104b61:	89 e5                	mov    %esp,%ebp
80104b63:	56                   	push   %esi
80104b64:	53                   	push   %ebx
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104b65:	e8 86 ee ff ff       	call   801039f0 <myproc>
80104b6a:	8b 55 08             	mov    0x8(%ebp),%edx
80104b6d:	8b 40 18             	mov    0x18(%eax),%eax
80104b70:	8b 40 44             	mov    0x44(%eax),%eax
80104b73:	8d 1c 90             	lea    (%eax,%edx,4),%ebx
  struct proc *curproc = myproc();
80104b76:	e8 75 ee ff ff       	call   801039f0 <myproc>
  return fetchint((myproc()->tf->esp) + 4 + 4*n, ip);
80104b7b:	8d 73 04             	lea    0x4(%ebx),%esi
  if(addr >= curproc->sz || addr+4 > curproc->sz)
80104b7e:	8b 00                	mov    (%eax),%eax
80104b80:	39 c6                	cmp    %eax,%esi
80104b82:	73 44                	jae    80104bc8 <argstr+0x68>
80104b84:	8d 53 08             	lea    0x8(%ebx),%edx
80104b87:	39 d0                	cmp    %edx,%eax
80104b89:	72 3d                	jb     80104bc8 <argstr+0x68>
  *ip = *(int*)(addr);
80104b8b:	8b 5b 04             	mov    0x4(%ebx),%ebx
  struct proc *curproc = myproc();
80104b8e:	e8 5d ee ff ff       	call   801039f0 <myproc>
  if(addr >= curproc->sz)
80104b93:	3b 18                	cmp    (%eax),%ebx
80104b95:	73 31                	jae    80104bc8 <argstr+0x68>
  *pp = (char*)addr;
80104b97:	8b 55 0c             	mov    0xc(%ebp),%edx
80104b9a:	89 1a                	mov    %ebx,(%edx)
  ep = (char*)curproc->sz;
80104b9c:	8b 10                	mov    (%eax),%edx
  for(s = *pp; s < ep; s++){
80104b9e:	39 d3                	cmp    %edx,%ebx
80104ba0:	73 26                	jae    80104bc8 <argstr+0x68>
80104ba2:	89 d8                	mov    %ebx,%eax
80104ba4:	eb 11                	jmp    80104bb7 <argstr+0x57>
80104ba6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104bad:	00 
80104bae:	66 90                	xchg   %ax,%ax
80104bb0:	83 c0 01             	add    $0x1,%eax
80104bb3:	39 d0                	cmp    %edx,%eax
80104bb5:	73 11                	jae    80104bc8 <argstr+0x68>
    if(*s == 0)
80104bb7:	80 38 00             	cmpb   $0x0,(%eax)
80104bba:	75 f4                	jne    80104bb0 <argstr+0x50>
      return s - *pp;
80104bbc:	29 d8                	sub    %ebx,%eax
  int addr;
  if(argint(n, &addr) < 0)
    return -1;
  return fetchstr(addr, pp);
}
80104bbe:	5b                   	pop    %ebx
80104bbf:	5e                   	pop    %esi
80104bc0:	5d                   	pop    %ebp
80104bc1:	c3                   	ret
80104bc2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
80104bc8:	5b                   	pop    %ebx
    return -1;
80104bc9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80104bce:	5e                   	pop    %esi
80104bcf:	5d                   	pop    %ebp
80104bd0:	c3                   	ret
80104bd1:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104bd8:	00 
80104bd9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80104be0 <syscall>:
[SYS_va2pa] sys_va2pa,
};

void
syscall(void)
{
80104be0:	55                   	push   %ebp
80104be1:	89 e5                	mov    %esp,%ebp
80104be3:	53                   	push   %ebx
80104be4:	83 ec 04             	sub    $0x4,%esp
  int num;
  struct proc *curproc = myproc();
80104be7:	e8 04 ee ff ff       	call   801039f0 <myproc>
80104bec:	89 c3                	mov    %eax,%ebx

  num = curproc->tf->eax;
80104bee:	8b 40 18             	mov    0x18(%eax),%eax
80104bf1:	8b 40 1c             	mov    0x1c(%eax),%eax
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
80104bf4:	8d 50 ff             	lea    -0x1(%eax),%edx
80104bf7:	83 fa 1c             	cmp    $0x1c,%edx
80104bfa:	77 24                	ja     80104c20 <syscall+0x40>
80104bfc:	8b 14 85 80 81 10 80 	mov    -0x7fef7e80(,%eax,4),%edx
80104c03:	85 d2                	test   %edx,%edx
80104c05:	74 19                	je     80104c20 <syscall+0x40>
    curproc->tf->eax = syscalls[num]();
80104c07:	ff d2                	call   *%edx
80104c09:	89 c2                	mov    %eax,%edx
80104c0b:	8b 43 18             	mov    0x18(%ebx),%eax
80104c0e:	89 50 1c             	mov    %edx,0x1c(%eax)
  } else {
    cprintf("%d %s: unknown sys call %d\n",
            curproc->pid, curproc->name, num);
    curproc->tf->eax = -1;
  }
}
80104c11:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104c14:	c9                   	leave
80104c15:	c3                   	ret
80104c16:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104c1d:	00 
80104c1e:	66 90                	xchg   %ax,%ax
    cprintf("%d %s: unknown sys call %d\n",
80104c20:	50                   	push   %eax
            curproc->pid, curproc->name, num);
80104c21:	8d 43 6c             	lea    0x6c(%ebx),%eax
    cprintf("%d %s: unknown sys call %d\n",
80104c24:	50                   	push   %eax
80104c25:	ff 73 10             	push   0x10(%ebx)
80104c28:	68 91 7b 10 80       	push   $0x80107b91
80104c2d:	e8 7e ba ff ff       	call   801006b0 <cprintf>
    curproc->tf->eax = -1;
80104c32:	8b 43 18             	mov    0x18(%ebx),%eax
80104c35:	83 c4 10             	add    $0x10,%esp
80104c38:	c7 40 1c ff ff ff ff 	movl   $0xffffffff,0x1c(%eax)
}
80104c3f:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80104c42:	c9                   	leave
80104c43:	c3                   	ret
80104c44:	66 90                	xchg   %ax,%ax
80104c46:	66 90                	xchg   %ax,%ax
80104c48:	66 90                	xchg   %ax,%ax
80104c4a:	66 90                	xchg   %ax,%ax
80104c4c:	66 90                	xchg   %ax,%ax
80104c4e:	66 90                	xchg   %ax,%ax

80104c50 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
80104c50:	55                   	push   %ebp
80104c51:	89 e5                	mov    %esp,%ebp
80104c53:	57                   	push   %edi
80104c54:	56                   	push   %esi
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
80104c55:	8d 7d da             	lea    -0x26(%ebp),%edi
{
80104c58:	53                   	push   %ebx
80104c59:	83 ec 34             	sub    $0x34,%esp
80104c5c:	89 4d d0             	mov    %ecx,-0x30(%ebp)
80104c5f:	8b 4d 08             	mov    0x8(%ebp),%ecx
80104c62:	89 55 d4             	mov    %edx,-0x2c(%ebp)
80104c65:	89 4d cc             	mov    %ecx,-0x34(%ebp)
  if((dp = nameiparent(path, name)) == 0)
80104c68:	57                   	push   %edi
80104c69:	50                   	push   %eax
80104c6a:	e8 31 d4 ff ff       	call   801020a0 <nameiparent>
80104c6f:	83 c4 10             	add    $0x10,%esp
80104c72:	85 c0                	test   %eax,%eax
80104c74:	74 5e                	je     80104cd4 <create+0x84>
    return 0;
  ilock(dp);
80104c76:	83 ec 0c             	sub    $0xc,%esp
80104c79:	89 c3                	mov    %eax,%ebx
80104c7b:	50                   	push   %eax
80104c7c:	e8 1f cb ff ff       	call   801017a0 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
80104c81:	83 c4 0c             	add    $0xc,%esp
80104c84:	6a 00                	push   $0x0
80104c86:	57                   	push   %edi
80104c87:	53                   	push   %ebx
80104c88:	e8 63 d0 ff ff       	call   80101cf0 <dirlookup>
80104c8d:	83 c4 10             	add    $0x10,%esp
80104c90:	89 c6                	mov    %eax,%esi
80104c92:	85 c0                	test   %eax,%eax
80104c94:	74 4a                	je     80104ce0 <create+0x90>
    iunlockput(dp);
80104c96:	83 ec 0c             	sub    $0xc,%esp
80104c99:	53                   	push   %ebx
80104c9a:	e8 91 cd ff ff       	call   80101a30 <iunlockput>
    ilock(ip);
80104c9f:	89 34 24             	mov    %esi,(%esp)
80104ca2:	e8 f9 ca ff ff       	call   801017a0 <ilock>
    if(type == T_FILE && ip->type == T_FILE)
80104ca7:	83 c4 10             	add    $0x10,%esp
80104caa:	66 83 7d d4 02       	cmpw   $0x2,-0x2c(%ebp)
80104caf:	75 17                	jne    80104cc8 <create+0x78>
80104cb1:	66 83 7e 50 02       	cmpw   $0x2,0x50(%esi)
80104cb6:	75 10                	jne    80104cc8 <create+0x78>
    panic("create: dirlink");

  iunlockput(dp);

  return ip;
}
80104cb8:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104cbb:	89 f0                	mov    %esi,%eax
80104cbd:	5b                   	pop    %ebx
80104cbe:	5e                   	pop    %esi
80104cbf:	5f                   	pop    %edi
80104cc0:	5d                   	pop    %ebp
80104cc1:	c3                   	ret
80104cc2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(ip);
80104cc8:	83 ec 0c             	sub    $0xc,%esp
80104ccb:	56                   	push   %esi
80104ccc:	e8 5f cd ff ff       	call   80101a30 <iunlockput>
    return 0;
80104cd1:	83 c4 10             	add    $0x10,%esp
}
80104cd4:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return 0;
80104cd7:	31 f6                	xor    %esi,%esi
}
80104cd9:	5b                   	pop    %ebx
80104cda:	89 f0                	mov    %esi,%eax
80104cdc:	5e                   	pop    %esi
80104cdd:	5f                   	pop    %edi
80104cde:	5d                   	pop    %ebp
80104cdf:	c3                   	ret
  if((ip = ialloc(dp->dev, type)) == 0)
80104ce0:	0f bf 45 d4          	movswl -0x2c(%ebp),%eax
80104ce4:	83 ec 08             	sub    $0x8,%esp
80104ce7:	50                   	push   %eax
80104ce8:	ff 33                	push   (%ebx)
80104cea:	e8 41 c9 ff ff       	call   80101630 <ialloc>
80104cef:	83 c4 10             	add    $0x10,%esp
80104cf2:	89 c6                	mov    %eax,%esi
80104cf4:	85 c0                	test   %eax,%eax
80104cf6:	0f 84 bc 00 00 00    	je     80104db8 <create+0x168>
  ilock(ip);
80104cfc:	83 ec 0c             	sub    $0xc,%esp
80104cff:	50                   	push   %eax
80104d00:	e8 9b ca ff ff       	call   801017a0 <ilock>
  ip->major = major;
80104d05:	0f b7 45 d0          	movzwl -0x30(%ebp),%eax
80104d09:	66 89 46 52          	mov    %ax,0x52(%esi)
  ip->minor = minor;
80104d0d:	0f b7 45 cc          	movzwl -0x34(%ebp),%eax
80104d11:	66 89 46 54          	mov    %ax,0x54(%esi)
  ip->nlink = 1;
80104d15:	b8 01 00 00 00       	mov    $0x1,%eax
80104d1a:	66 89 46 56          	mov    %ax,0x56(%esi)
  iupdate(ip);
80104d1e:	89 34 24             	mov    %esi,(%esp)
80104d21:	e8 ca c9 ff ff       	call   801016f0 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
80104d26:	83 c4 10             	add    $0x10,%esp
80104d29:	66 83 7d d4 01       	cmpw   $0x1,-0x2c(%ebp)
80104d2e:	74 30                	je     80104d60 <create+0x110>
  if(dirlink(dp, name, ip->inum) < 0)
80104d30:	83 ec 04             	sub    $0x4,%esp
80104d33:	ff 76 04             	push   0x4(%esi)
80104d36:	57                   	push   %edi
80104d37:	53                   	push   %ebx
80104d38:	e8 83 d2 ff ff       	call   80101fc0 <dirlink>
80104d3d:	83 c4 10             	add    $0x10,%esp
80104d40:	85 c0                	test   %eax,%eax
80104d42:	78 67                	js     80104dab <create+0x15b>
  iunlockput(dp);
80104d44:	83 ec 0c             	sub    $0xc,%esp
80104d47:	53                   	push   %ebx
80104d48:	e8 e3 cc ff ff       	call   80101a30 <iunlockput>
  return ip;
80104d4d:	83 c4 10             	add    $0x10,%esp
}
80104d50:	8d 65 f4             	lea    -0xc(%ebp),%esp
80104d53:	89 f0                	mov    %esi,%eax
80104d55:	5b                   	pop    %ebx
80104d56:	5e                   	pop    %esi
80104d57:	5f                   	pop    %edi
80104d58:	5d                   	pop    %ebp
80104d59:	c3                   	ret
80104d5a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iupdate(dp);
80104d60:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink++;  // for ".."
80104d63:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
    iupdate(dp);
80104d68:	53                   	push   %ebx
80104d69:	e8 82 c9 ff ff       	call   801016f0 <iupdate>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
80104d6e:	83 c4 0c             	add    $0xc,%esp
80104d71:	ff 76 04             	push   0x4(%esi)
80104d74:	68 c9 7b 10 80       	push   $0x80107bc9
80104d79:	56                   	push   %esi
80104d7a:	e8 41 d2 ff ff       	call   80101fc0 <dirlink>
80104d7f:	83 c4 10             	add    $0x10,%esp
80104d82:	85 c0                	test   %eax,%eax
80104d84:	78 18                	js     80104d9e <create+0x14e>
80104d86:	83 ec 04             	sub    $0x4,%esp
80104d89:	ff 73 04             	push   0x4(%ebx)
80104d8c:	68 c8 7b 10 80       	push   $0x80107bc8
80104d91:	56                   	push   %esi
80104d92:	e8 29 d2 ff ff       	call   80101fc0 <dirlink>
80104d97:	83 c4 10             	add    $0x10,%esp
80104d9a:	85 c0                	test   %eax,%eax
80104d9c:	79 92                	jns    80104d30 <create+0xe0>
      panic("create dots");
80104d9e:	83 ec 0c             	sub    $0xc,%esp
80104da1:	68 bc 7b 10 80       	push   $0x80107bbc
80104da6:	e8 d5 b5 ff ff       	call   80100380 <panic>
    panic("create: dirlink");
80104dab:	83 ec 0c             	sub    $0xc,%esp
80104dae:	68 cb 7b 10 80       	push   $0x80107bcb
80104db3:	e8 c8 b5 ff ff       	call   80100380 <panic>
    panic("create: ialloc");
80104db8:	83 ec 0c             	sub    $0xc,%esp
80104dbb:	68 ad 7b 10 80       	push   $0x80107bad
80104dc0:	e8 bb b5 ff ff       	call   80100380 <panic>
80104dc5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104dcc:	00 
80104dcd:	8d 76 00             	lea    0x0(%esi),%esi

80104dd0 <sys_dup>:
{
80104dd0:	55                   	push   %ebp
80104dd1:	89 e5                	mov    %esp,%ebp
80104dd3:	56                   	push   %esi
80104dd4:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80104dd5:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80104dd8:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80104ddb:	50                   	push   %eax
80104ddc:	6a 00                	push   $0x0
80104dde:	e8 bd fc ff ff       	call   80104aa0 <argint>
80104de3:	83 c4 10             	add    $0x10,%esp
80104de6:	85 c0                	test   %eax,%eax
80104de8:	78 36                	js     80104e20 <sys_dup+0x50>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80104dea:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104dee:	77 30                	ja     80104e20 <sys_dup+0x50>
80104df0:	e8 fb eb ff ff       	call   801039f0 <myproc>
80104df5:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104df8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80104dfc:	85 f6                	test   %esi,%esi
80104dfe:	74 20                	je     80104e20 <sys_dup+0x50>
  struct proc *curproc = myproc();
80104e00:	e8 eb eb ff ff       	call   801039f0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
80104e05:	31 db                	xor    %ebx,%ebx
80104e07:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80104e0e:	00 
80104e0f:	90                   	nop
    if(curproc->ofile[fd] == 0){
80104e10:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
80104e14:	85 d2                	test   %edx,%edx
80104e16:	74 18                	je     80104e30 <sys_dup+0x60>
  for(fd = 0; fd < NOFILE; fd++){
80104e18:	83 c3 01             	add    $0x1,%ebx
80104e1b:	83 fb 10             	cmp    $0x10,%ebx
80104e1e:	75 f0                	jne    80104e10 <sys_dup+0x40>
}
80104e20:	8d 65 f8             	lea    -0x8(%ebp),%esp
    return -1;
80104e23:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
}
80104e28:	89 d8                	mov    %ebx,%eax
80104e2a:	5b                   	pop    %ebx
80104e2b:	5e                   	pop    %esi
80104e2c:	5d                   	pop    %ebp
80104e2d:	c3                   	ret
80104e2e:	66 90                	xchg   %ax,%ax
  filedup(f);
80104e30:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
80104e33:	89 74 98 28          	mov    %esi,0x28(%eax,%ebx,4)
  filedup(f);
80104e37:	56                   	push   %esi
80104e38:	e8 83 c0 ff ff       	call   80100ec0 <filedup>
  return fd;
80104e3d:	83 c4 10             	add    $0x10,%esp
}
80104e40:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104e43:	89 d8                	mov    %ebx,%eax
80104e45:	5b                   	pop    %ebx
80104e46:	5e                   	pop    %esi
80104e47:	5d                   	pop    %ebp
80104e48:	c3                   	ret
80104e49:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80104e50 <sys_read>:
{
80104e50:	55                   	push   %ebp
80104e51:	89 e5                	mov    %esp,%ebp
80104e53:	56                   	push   %esi
80104e54:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80104e55:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80104e58:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80104e5b:	53                   	push   %ebx
80104e5c:	6a 00                	push   $0x0
80104e5e:	e8 3d fc ff ff       	call   80104aa0 <argint>
80104e63:	83 c4 10             	add    $0x10,%esp
80104e66:	85 c0                	test   %eax,%eax
80104e68:	78 5e                	js     80104ec8 <sys_read+0x78>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80104e6a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104e6e:	77 58                	ja     80104ec8 <sys_read+0x78>
80104e70:	e8 7b eb ff ff       	call   801039f0 <myproc>
80104e75:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104e78:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80104e7c:	85 f6                	test   %esi,%esi
80104e7e:	74 48                	je     80104ec8 <sys_read+0x78>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80104e80:	83 ec 08             	sub    $0x8,%esp
80104e83:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104e86:	50                   	push   %eax
80104e87:	6a 02                	push   $0x2
80104e89:	e8 12 fc ff ff       	call   80104aa0 <argint>
80104e8e:	83 c4 10             	add    $0x10,%esp
80104e91:	85 c0                	test   %eax,%eax
80104e93:	78 33                	js     80104ec8 <sys_read+0x78>
80104e95:	83 ec 04             	sub    $0x4,%esp
80104e98:	ff 75 f0             	push   -0x10(%ebp)
80104e9b:	53                   	push   %ebx
80104e9c:	6a 01                	push   $0x1
80104e9e:	e8 4d fc ff ff       	call   80104af0 <argptr>
80104ea3:	83 c4 10             	add    $0x10,%esp
80104ea6:	85 c0                	test   %eax,%eax
80104ea8:	78 1e                	js     80104ec8 <sys_read+0x78>
  return fileread(f, p, n);
80104eaa:	83 ec 04             	sub    $0x4,%esp
80104ead:	ff 75 f0             	push   -0x10(%ebp)
80104eb0:	ff 75 f4             	push   -0xc(%ebp)
80104eb3:	56                   	push   %esi
80104eb4:	e8 87 c1 ff ff       	call   80101040 <fileread>
80104eb9:	83 c4 10             	add    $0x10,%esp
}
80104ebc:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104ebf:	5b                   	pop    %ebx
80104ec0:	5e                   	pop    %esi
80104ec1:	5d                   	pop    %ebp
80104ec2:	c3                   	ret
80104ec3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80104ec8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104ecd:	eb ed                	jmp    80104ebc <sys_read+0x6c>
80104ecf:	90                   	nop

80104ed0 <sys_write>:
{
80104ed0:	55                   	push   %ebp
80104ed1:	89 e5                	mov    %esp,%ebp
80104ed3:	56                   	push   %esi
80104ed4:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80104ed5:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80104ed8:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80104edb:	53                   	push   %ebx
80104edc:	6a 00                	push   $0x0
80104ede:	e8 bd fb ff ff       	call   80104aa0 <argint>
80104ee3:	83 c4 10             	add    $0x10,%esp
80104ee6:	85 c0                	test   %eax,%eax
80104ee8:	78 5e                	js     80104f48 <sys_write+0x78>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80104eea:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104eee:	77 58                	ja     80104f48 <sys_write+0x78>
80104ef0:	e8 fb ea ff ff       	call   801039f0 <myproc>
80104ef5:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104ef8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80104efc:	85 f6                	test   %esi,%esi
80104efe:	74 48                	je     80104f48 <sys_write+0x78>
  if(argfd(0, 0, &f) < 0 || argint(2, &n) < 0 || argptr(1, &p, n) < 0)
80104f00:	83 ec 08             	sub    $0x8,%esp
80104f03:	8d 45 f0             	lea    -0x10(%ebp),%eax
80104f06:	50                   	push   %eax
80104f07:	6a 02                	push   $0x2
80104f09:	e8 92 fb ff ff       	call   80104aa0 <argint>
80104f0e:	83 c4 10             	add    $0x10,%esp
80104f11:	85 c0                	test   %eax,%eax
80104f13:	78 33                	js     80104f48 <sys_write+0x78>
80104f15:	83 ec 04             	sub    $0x4,%esp
80104f18:	ff 75 f0             	push   -0x10(%ebp)
80104f1b:	53                   	push   %ebx
80104f1c:	6a 01                	push   $0x1
80104f1e:	e8 cd fb ff ff       	call   80104af0 <argptr>
80104f23:	83 c4 10             	add    $0x10,%esp
80104f26:	85 c0                	test   %eax,%eax
80104f28:	78 1e                	js     80104f48 <sys_write+0x78>
  return filewrite(f, p, n);
80104f2a:	83 ec 04             	sub    $0x4,%esp
80104f2d:	ff 75 f0             	push   -0x10(%ebp)
80104f30:	ff 75 f4             	push   -0xc(%ebp)
80104f33:	56                   	push   %esi
80104f34:	e8 97 c1 ff ff       	call   801010d0 <filewrite>
80104f39:	83 c4 10             	add    $0x10,%esp
}
80104f3c:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104f3f:	5b                   	pop    %ebx
80104f40:	5e                   	pop    %esi
80104f41:	5d                   	pop    %ebp
80104f42:	c3                   	ret
80104f43:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    return -1;
80104f48:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104f4d:	eb ed                	jmp    80104f3c <sys_write+0x6c>
80104f4f:	90                   	nop

80104f50 <sys_close>:
{
80104f50:	55                   	push   %ebp
80104f51:	89 e5                	mov    %esp,%ebp
80104f53:	56                   	push   %esi
80104f54:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80104f55:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80104f58:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80104f5b:	50                   	push   %eax
80104f5c:	6a 00                	push   $0x0
80104f5e:	e8 3d fb ff ff       	call   80104aa0 <argint>
80104f63:	83 c4 10             	add    $0x10,%esp
80104f66:	85 c0                	test   %eax,%eax
80104f68:	78 3e                	js     80104fa8 <sys_close+0x58>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80104f6a:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104f6e:	77 38                	ja     80104fa8 <sys_close+0x58>
80104f70:	e8 7b ea ff ff       	call   801039f0 <myproc>
80104f75:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104f78:	8d 5a 08             	lea    0x8(%edx),%ebx
80104f7b:	8b 74 98 08          	mov    0x8(%eax,%ebx,4),%esi
80104f7f:	85 f6                	test   %esi,%esi
80104f81:	74 25                	je     80104fa8 <sys_close+0x58>
  myproc()->ofile[fd] = 0;
80104f83:	e8 68 ea ff ff       	call   801039f0 <myproc>
  fileclose(f);
80104f88:	83 ec 0c             	sub    $0xc,%esp
  myproc()->ofile[fd] = 0;
80104f8b:	c7 44 98 08 00 00 00 	movl   $0x0,0x8(%eax,%ebx,4)
80104f92:	00 
  fileclose(f);
80104f93:	56                   	push   %esi
80104f94:	e8 77 bf ff ff       	call   80100f10 <fileclose>
  return 0;
80104f99:	83 c4 10             	add    $0x10,%esp
80104f9c:	31 c0                	xor    %eax,%eax
}
80104f9e:	8d 65 f8             	lea    -0x8(%ebp),%esp
80104fa1:	5b                   	pop    %ebx
80104fa2:	5e                   	pop    %esi
80104fa3:	5d                   	pop    %ebp
80104fa4:	c3                   	ret
80104fa5:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80104fa8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80104fad:	eb ef                	jmp    80104f9e <sys_close+0x4e>
80104faf:	90                   	nop

80104fb0 <sys_fstat>:
{
80104fb0:	55                   	push   %ebp
80104fb1:	89 e5                	mov    %esp,%ebp
80104fb3:	56                   	push   %esi
80104fb4:	53                   	push   %ebx
  if(argint(n, &fd) < 0)
80104fb5:	8d 5d f4             	lea    -0xc(%ebp),%ebx
{
80104fb8:	83 ec 18             	sub    $0x18,%esp
  if(argint(n, &fd) < 0)
80104fbb:	53                   	push   %ebx
80104fbc:	6a 00                	push   $0x0
80104fbe:	e8 dd fa ff ff       	call   80104aa0 <argint>
80104fc3:	83 c4 10             	add    $0x10,%esp
80104fc6:	85 c0                	test   %eax,%eax
80104fc8:	78 46                	js     80105010 <sys_fstat+0x60>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
80104fca:	83 7d f4 0f          	cmpl   $0xf,-0xc(%ebp)
80104fce:	77 40                	ja     80105010 <sys_fstat+0x60>
80104fd0:	e8 1b ea ff ff       	call   801039f0 <myproc>
80104fd5:	8b 55 f4             	mov    -0xc(%ebp),%edx
80104fd8:	8b 74 90 28          	mov    0x28(%eax,%edx,4),%esi
80104fdc:	85 f6                	test   %esi,%esi
80104fde:	74 30                	je     80105010 <sys_fstat+0x60>
  if(argfd(0, 0, &f) < 0 || argptr(1, (void*)&st, sizeof(*st)) < 0)
80104fe0:	83 ec 04             	sub    $0x4,%esp
80104fe3:	6a 14                	push   $0x14
80104fe5:	53                   	push   %ebx
80104fe6:	6a 01                	push   $0x1
80104fe8:	e8 03 fb ff ff       	call   80104af0 <argptr>
80104fed:	83 c4 10             	add    $0x10,%esp
80104ff0:	85 c0                	test   %eax,%eax
80104ff2:	78 1c                	js     80105010 <sys_fstat+0x60>
  return filestat(f, st);
80104ff4:	83 ec 08             	sub    $0x8,%esp
80104ff7:	ff 75 f4             	push   -0xc(%ebp)
80104ffa:	56                   	push   %esi
80104ffb:	e8 f0 bf ff ff       	call   80100ff0 <filestat>
80105000:	83 c4 10             	add    $0x10,%esp
}
80105003:	8d 65 f8             	lea    -0x8(%ebp),%esp
80105006:	5b                   	pop    %ebx
80105007:	5e                   	pop    %esi
80105008:	5d                   	pop    %ebp
80105009:	c3                   	ret
8010500a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return -1;
80105010:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105015:	eb ec                	jmp    80105003 <sys_fstat+0x53>
80105017:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010501e:	00 
8010501f:	90                   	nop

80105020 <sys_link>:
{
80105020:	55                   	push   %ebp
80105021:	89 e5                	mov    %esp,%ebp
80105023:	57                   	push   %edi
80105024:	56                   	push   %esi
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
80105025:	8d 45 d4             	lea    -0x2c(%ebp),%eax
{
80105028:	53                   	push   %ebx
80105029:	83 ec 34             	sub    $0x34,%esp
  if(argstr(0, &old) < 0 || argstr(1, &new) < 0)
8010502c:	50                   	push   %eax
8010502d:	6a 00                	push   $0x0
8010502f:	e8 2c fb ff ff       	call   80104b60 <argstr>
80105034:	83 c4 10             	add    $0x10,%esp
80105037:	85 c0                	test   %eax,%eax
80105039:	0f 88 fb 00 00 00    	js     8010513a <sys_link+0x11a>
8010503f:	83 ec 08             	sub    $0x8,%esp
80105042:	8d 45 d0             	lea    -0x30(%ebp),%eax
80105045:	50                   	push   %eax
80105046:	6a 01                	push   $0x1
80105048:	e8 13 fb ff ff       	call   80104b60 <argstr>
8010504d:	83 c4 10             	add    $0x10,%esp
80105050:	85 c0                	test   %eax,%eax
80105052:	0f 88 e2 00 00 00    	js     8010513a <sys_link+0x11a>
  begin_op();
80105058:	e8 53 dd ff ff       	call   80102db0 <begin_op>
  if((ip = namei(old)) == 0){
8010505d:	83 ec 0c             	sub    $0xc,%esp
80105060:	ff 75 d4             	push   -0x2c(%ebp)
80105063:	e8 18 d0 ff ff       	call   80102080 <namei>
80105068:	83 c4 10             	add    $0x10,%esp
8010506b:	89 c3                	mov    %eax,%ebx
8010506d:	85 c0                	test   %eax,%eax
8010506f:	0f 84 df 00 00 00    	je     80105154 <sys_link+0x134>
  ilock(ip);
80105075:	83 ec 0c             	sub    $0xc,%esp
80105078:	50                   	push   %eax
80105079:	e8 22 c7 ff ff       	call   801017a0 <ilock>
  if(ip->type == T_DIR){
8010507e:	83 c4 10             	add    $0x10,%esp
80105081:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105086:	0f 84 b5 00 00 00    	je     80105141 <sys_link+0x121>
  iupdate(ip);
8010508c:	83 ec 0c             	sub    $0xc,%esp
  ip->nlink++;
8010508f:	66 83 43 56 01       	addw   $0x1,0x56(%ebx)
  if((dp = nameiparent(new, name)) == 0)
80105094:	8d 7d da             	lea    -0x26(%ebp),%edi
  iupdate(ip);
80105097:	53                   	push   %ebx
80105098:	e8 53 c6 ff ff       	call   801016f0 <iupdate>
  iunlock(ip);
8010509d:	89 1c 24             	mov    %ebx,(%esp)
801050a0:	e8 db c7 ff ff       	call   80101880 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
801050a5:	58                   	pop    %eax
801050a6:	5a                   	pop    %edx
801050a7:	57                   	push   %edi
801050a8:	ff 75 d0             	push   -0x30(%ebp)
801050ab:	e8 f0 cf ff ff       	call   801020a0 <nameiparent>
801050b0:	83 c4 10             	add    $0x10,%esp
801050b3:	89 c6                	mov    %eax,%esi
801050b5:	85 c0                	test   %eax,%eax
801050b7:	74 5b                	je     80105114 <sys_link+0xf4>
  ilock(dp);
801050b9:	83 ec 0c             	sub    $0xc,%esp
801050bc:	50                   	push   %eax
801050bd:	e8 de c6 ff ff       	call   801017a0 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
801050c2:	8b 03                	mov    (%ebx),%eax
801050c4:	83 c4 10             	add    $0x10,%esp
801050c7:	39 06                	cmp    %eax,(%esi)
801050c9:	75 3d                	jne    80105108 <sys_link+0xe8>
801050cb:	83 ec 04             	sub    $0x4,%esp
801050ce:	ff 73 04             	push   0x4(%ebx)
801050d1:	57                   	push   %edi
801050d2:	56                   	push   %esi
801050d3:	e8 e8 ce ff ff       	call   80101fc0 <dirlink>
801050d8:	83 c4 10             	add    $0x10,%esp
801050db:	85 c0                	test   %eax,%eax
801050dd:	78 29                	js     80105108 <sys_link+0xe8>
  iunlockput(dp);
801050df:	83 ec 0c             	sub    $0xc,%esp
801050e2:	56                   	push   %esi
801050e3:	e8 48 c9 ff ff       	call   80101a30 <iunlockput>
  iput(ip);
801050e8:	89 1c 24             	mov    %ebx,(%esp)
801050eb:	e8 e0 c7 ff ff       	call   801018d0 <iput>
  end_op();
801050f0:	e8 2b dd ff ff       	call   80102e20 <end_op>
  return 0;
801050f5:	83 c4 10             	add    $0x10,%esp
801050f8:	31 c0                	xor    %eax,%eax
}
801050fa:	8d 65 f4             	lea    -0xc(%ebp),%esp
801050fd:	5b                   	pop    %ebx
801050fe:	5e                   	pop    %esi
801050ff:	5f                   	pop    %edi
80105100:	5d                   	pop    %ebp
80105101:	c3                   	ret
80105102:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    iunlockput(dp);
80105108:	83 ec 0c             	sub    $0xc,%esp
8010510b:	56                   	push   %esi
8010510c:	e8 1f c9 ff ff       	call   80101a30 <iunlockput>
    goto bad;
80105111:	83 c4 10             	add    $0x10,%esp
  ilock(ip);
80105114:	83 ec 0c             	sub    $0xc,%esp
80105117:	53                   	push   %ebx
80105118:	e8 83 c6 ff ff       	call   801017a0 <ilock>
  ip->nlink--;
8010511d:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
80105122:	89 1c 24             	mov    %ebx,(%esp)
80105125:	e8 c6 c5 ff ff       	call   801016f0 <iupdate>
  iunlockput(ip);
8010512a:	89 1c 24             	mov    %ebx,(%esp)
8010512d:	e8 fe c8 ff ff       	call   80101a30 <iunlockput>
  end_op();
80105132:	e8 e9 dc ff ff       	call   80102e20 <end_op>
  return -1;
80105137:	83 c4 10             	add    $0x10,%esp
    return -1;
8010513a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010513f:	eb b9                	jmp    801050fa <sys_link+0xda>
    iunlockput(ip);
80105141:	83 ec 0c             	sub    $0xc,%esp
80105144:	53                   	push   %ebx
80105145:	e8 e6 c8 ff ff       	call   80101a30 <iunlockput>
    end_op();
8010514a:	e8 d1 dc ff ff       	call   80102e20 <end_op>
    return -1;
8010514f:	83 c4 10             	add    $0x10,%esp
80105152:	eb e6                	jmp    8010513a <sys_link+0x11a>
    end_op();
80105154:	e8 c7 dc ff ff       	call   80102e20 <end_op>
    return -1;
80105159:	eb df                	jmp    8010513a <sys_link+0x11a>
8010515b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80105160 <sys_unlink>:
{
80105160:	55                   	push   %ebp
80105161:	89 e5                	mov    %esp,%ebp
80105163:	57                   	push   %edi
80105164:	56                   	push   %esi
  if(argstr(0, &path) < 0)
80105165:	8d 45 c0             	lea    -0x40(%ebp),%eax
{
80105168:	53                   	push   %ebx
80105169:	83 ec 54             	sub    $0x54,%esp
  if(argstr(0, &path) < 0)
8010516c:	50                   	push   %eax
8010516d:	6a 00                	push   $0x0
8010516f:	e8 ec f9 ff ff       	call   80104b60 <argstr>
80105174:	83 c4 10             	add    $0x10,%esp
80105177:	85 c0                	test   %eax,%eax
80105179:	0f 88 54 01 00 00    	js     801052d3 <sys_unlink+0x173>
  begin_op();
8010517f:	e8 2c dc ff ff       	call   80102db0 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
80105184:	8d 5d ca             	lea    -0x36(%ebp),%ebx
80105187:	83 ec 08             	sub    $0x8,%esp
8010518a:	53                   	push   %ebx
8010518b:	ff 75 c0             	push   -0x40(%ebp)
8010518e:	e8 0d cf ff ff       	call   801020a0 <nameiparent>
80105193:	83 c4 10             	add    $0x10,%esp
80105196:	89 45 b4             	mov    %eax,-0x4c(%ebp)
80105199:	85 c0                	test   %eax,%eax
8010519b:	0f 84 58 01 00 00    	je     801052f9 <sys_unlink+0x199>
  ilock(dp);
801051a1:	8b 7d b4             	mov    -0x4c(%ebp),%edi
801051a4:	83 ec 0c             	sub    $0xc,%esp
801051a7:	57                   	push   %edi
801051a8:	e8 f3 c5 ff ff       	call   801017a0 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
801051ad:	58                   	pop    %eax
801051ae:	5a                   	pop    %edx
801051af:	68 c9 7b 10 80       	push   $0x80107bc9
801051b4:	53                   	push   %ebx
801051b5:	e8 16 cb ff ff       	call   80101cd0 <namecmp>
801051ba:	83 c4 10             	add    $0x10,%esp
801051bd:	85 c0                	test   %eax,%eax
801051bf:	0f 84 fb 00 00 00    	je     801052c0 <sys_unlink+0x160>
801051c5:	83 ec 08             	sub    $0x8,%esp
801051c8:	68 c8 7b 10 80       	push   $0x80107bc8
801051cd:	53                   	push   %ebx
801051ce:	e8 fd ca ff ff       	call   80101cd0 <namecmp>
801051d3:	83 c4 10             	add    $0x10,%esp
801051d6:	85 c0                	test   %eax,%eax
801051d8:	0f 84 e2 00 00 00    	je     801052c0 <sys_unlink+0x160>
  if((ip = dirlookup(dp, name, &off)) == 0)
801051de:	83 ec 04             	sub    $0x4,%esp
801051e1:	8d 45 c4             	lea    -0x3c(%ebp),%eax
801051e4:	50                   	push   %eax
801051e5:	53                   	push   %ebx
801051e6:	57                   	push   %edi
801051e7:	e8 04 cb ff ff       	call   80101cf0 <dirlookup>
801051ec:	83 c4 10             	add    $0x10,%esp
801051ef:	89 c3                	mov    %eax,%ebx
801051f1:	85 c0                	test   %eax,%eax
801051f3:	0f 84 c7 00 00 00    	je     801052c0 <sys_unlink+0x160>
  ilock(ip);
801051f9:	83 ec 0c             	sub    $0xc,%esp
801051fc:	50                   	push   %eax
801051fd:	e8 9e c5 ff ff       	call   801017a0 <ilock>
  if(ip->nlink < 1)
80105202:	83 c4 10             	add    $0x10,%esp
80105205:	66 83 7b 56 00       	cmpw   $0x0,0x56(%ebx)
8010520a:	0f 8e 0a 01 00 00    	jle    8010531a <sys_unlink+0x1ba>
  if(ip->type == T_DIR && !isdirempty(ip)){
80105210:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105215:	8d 7d d8             	lea    -0x28(%ebp),%edi
80105218:	74 66                	je     80105280 <sys_unlink+0x120>
  memset(&de, 0, sizeof(de));
8010521a:	83 ec 04             	sub    $0x4,%esp
8010521d:	6a 10                	push   $0x10
8010521f:	6a 00                	push   $0x0
80105221:	57                   	push   %edi
80105222:	e8 c9 f5 ff ff       	call   801047f0 <memset>
  if(writei(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105227:	6a 10                	push   $0x10
80105229:	ff 75 c4             	push   -0x3c(%ebp)
8010522c:	57                   	push   %edi
8010522d:	ff 75 b4             	push   -0x4c(%ebp)
80105230:	e8 7b c9 ff ff       	call   80101bb0 <writei>
80105235:	83 c4 20             	add    $0x20,%esp
80105238:	83 f8 10             	cmp    $0x10,%eax
8010523b:	0f 85 cc 00 00 00    	jne    8010530d <sys_unlink+0x1ad>
  if(ip->type == T_DIR){
80105241:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
80105246:	0f 84 94 00 00 00    	je     801052e0 <sys_unlink+0x180>
  iunlockput(dp);
8010524c:	83 ec 0c             	sub    $0xc,%esp
8010524f:	ff 75 b4             	push   -0x4c(%ebp)
80105252:	e8 d9 c7 ff ff       	call   80101a30 <iunlockput>
  ip->nlink--;
80105257:	66 83 6b 56 01       	subw   $0x1,0x56(%ebx)
  iupdate(ip);
8010525c:	89 1c 24             	mov    %ebx,(%esp)
8010525f:	e8 8c c4 ff ff       	call   801016f0 <iupdate>
  iunlockput(ip);
80105264:	89 1c 24             	mov    %ebx,(%esp)
80105267:	e8 c4 c7 ff ff       	call   80101a30 <iunlockput>
  end_op();
8010526c:	e8 af db ff ff       	call   80102e20 <end_op>
  return 0;
80105271:	83 c4 10             	add    $0x10,%esp
80105274:	31 c0                	xor    %eax,%eax
}
80105276:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105279:	5b                   	pop    %ebx
8010527a:	5e                   	pop    %esi
8010527b:	5f                   	pop    %edi
8010527c:	5d                   	pop    %ebp
8010527d:	c3                   	ret
8010527e:	66 90                	xchg   %ax,%ax
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
80105280:	83 7b 58 20          	cmpl   $0x20,0x58(%ebx)
80105284:	76 94                	jbe    8010521a <sys_unlink+0xba>
80105286:	be 20 00 00 00       	mov    $0x20,%esi
8010528b:	eb 0b                	jmp    80105298 <sys_unlink+0x138>
8010528d:	8d 76 00             	lea    0x0(%esi),%esi
80105290:	83 c6 10             	add    $0x10,%esi
80105293:	3b 73 58             	cmp    0x58(%ebx),%esi
80105296:	73 82                	jae    8010521a <sys_unlink+0xba>
    if(readi(dp, (char*)&de, off, sizeof(de)) != sizeof(de))
80105298:	6a 10                	push   $0x10
8010529a:	56                   	push   %esi
8010529b:	57                   	push   %edi
8010529c:	53                   	push   %ebx
8010529d:	e8 0e c8 ff ff       	call   80101ab0 <readi>
801052a2:	83 c4 10             	add    $0x10,%esp
801052a5:	83 f8 10             	cmp    $0x10,%eax
801052a8:	75 56                	jne    80105300 <sys_unlink+0x1a0>
    if(de.inum != 0)
801052aa:	66 83 7d d8 00       	cmpw   $0x0,-0x28(%ebp)
801052af:	74 df                	je     80105290 <sys_unlink+0x130>
    iunlockput(ip);
801052b1:	83 ec 0c             	sub    $0xc,%esp
801052b4:	53                   	push   %ebx
801052b5:	e8 76 c7 ff ff       	call   80101a30 <iunlockput>
    goto bad;
801052ba:	83 c4 10             	add    $0x10,%esp
801052bd:	8d 76 00             	lea    0x0(%esi),%esi
  iunlockput(dp);
801052c0:	83 ec 0c             	sub    $0xc,%esp
801052c3:	ff 75 b4             	push   -0x4c(%ebp)
801052c6:	e8 65 c7 ff ff       	call   80101a30 <iunlockput>
  end_op();
801052cb:	e8 50 db ff ff       	call   80102e20 <end_op>
  return -1;
801052d0:	83 c4 10             	add    $0x10,%esp
    return -1;
801052d3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801052d8:	eb 9c                	jmp    80105276 <sys_unlink+0x116>
801052da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    dp->nlink--;
801052e0:	8b 45 b4             	mov    -0x4c(%ebp),%eax
    iupdate(dp);
801052e3:	83 ec 0c             	sub    $0xc,%esp
    dp->nlink--;
801052e6:	66 83 68 56 01       	subw   $0x1,0x56(%eax)
    iupdate(dp);
801052eb:	50                   	push   %eax
801052ec:	e8 ff c3 ff ff       	call   801016f0 <iupdate>
801052f1:	83 c4 10             	add    $0x10,%esp
801052f4:	e9 53 ff ff ff       	jmp    8010524c <sys_unlink+0xec>
    end_op();
801052f9:	e8 22 db ff ff       	call   80102e20 <end_op>
    return -1;
801052fe:	eb d3                	jmp    801052d3 <sys_unlink+0x173>
      panic("isdirempty: readi");
80105300:	83 ec 0c             	sub    $0xc,%esp
80105303:	68 ed 7b 10 80       	push   $0x80107bed
80105308:	e8 73 b0 ff ff       	call   80100380 <panic>
    panic("unlink: writei");
8010530d:	83 ec 0c             	sub    $0xc,%esp
80105310:	68 ff 7b 10 80       	push   $0x80107bff
80105315:	e8 66 b0 ff ff       	call   80100380 <panic>
    panic("unlink: nlink < 1");
8010531a:	83 ec 0c             	sub    $0xc,%esp
8010531d:	68 db 7b 10 80       	push   $0x80107bdb
80105322:	e8 59 b0 ff ff       	call   80100380 <panic>
80105327:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010532e:	00 
8010532f:	90                   	nop

80105330 <sys_open>:

int
sys_open(void)
{
80105330:	55                   	push   %ebp
80105331:	89 e5                	mov    %esp,%ebp
80105333:	57                   	push   %edi
80105334:	56                   	push   %esi
  char *path;
  int fd, omode;
  struct file *f;
  struct inode *ip;

  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
80105335:	8d 45 e0             	lea    -0x20(%ebp),%eax
{
80105338:	53                   	push   %ebx
80105339:	83 ec 24             	sub    $0x24,%esp
  if(argstr(0, &path) < 0 || argint(1, &omode) < 0)
8010533c:	50                   	push   %eax
8010533d:	6a 00                	push   $0x0
8010533f:	e8 1c f8 ff ff       	call   80104b60 <argstr>
80105344:	83 c4 10             	add    $0x10,%esp
80105347:	85 c0                	test   %eax,%eax
80105349:	0f 88 8e 00 00 00    	js     801053dd <sys_open+0xad>
8010534f:	83 ec 08             	sub    $0x8,%esp
80105352:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105355:	50                   	push   %eax
80105356:	6a 01                	push   $0x1
80105358:	e8 43 f7 ff ff       	call   80104aa0 <argint>
8010535d:	83 c4 10             	add    $0x10,%esp
80105360:	85 c0                	test   %eax,%eax
80105362:	78 79                	js     801053dd <sys_open+0xad>
    return -1;

  begin_op();
80105364:	e8 47 da ff ff       	call   80102db0 <begin_op>

  if(omode & O_CREATE){
80105369:	f6 45 e5 02          	testb  $0x2,-0x1b(%ebp)
8010536d:	75 79                	jne    801053e8 <sys_open+0xb8>
    if(ip == 0){
      end_op();
      return -1;
    }
  } else {
    if((ip = namei(path)) == 0){
8010536f:	83 ec 0c             	sub    $0xc,%esp
80105372:	ff 75 e0             	push   -0x20(%ebp)
80105375:	e8 06 cd ff ff       	call   80102080 <namei>
8010537a:	83 c4 10             	add    $0x10,%esp
8010537d:	89 c6                	mov    %eax,%esi
8010537f:	85 c0                	test   %eax,%eax
80105381:	0f 84 7e 00 00 00    	je     80105405 <sys_open+0xd5>
      end_op();
      return -1;
    }
    ilock(ip);
80105387:	83 ec 0c             	sub    $0xc,%esp
8010538a:	50                   	push   %eax
8010538b:	e8 10 c4 ff ff       	call   801017a0 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
80105390:	83 c4 10             	add    $0x10,%esp
80105393:	66 83 7e 50 01       	cmpw   $0x1,0x50(%esi)
80105398:	0f 84 ba 00 00 00    	je     80105458 <sys_open+0x128>
      end_op();
      return -1;
    }
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
8010539e:	e8 ad ba ff ff       	call   80100e50 <filealloc>
801053a3:	89 c7                	mov    %eax,%edi
801053a5:	85 c0                	test   %eax,%eax
801053a7:	74 23                	je     801053cc <sys_open+0x9c>
  struct proc *curproc = myproc();
801053a9:	e8 42 e6 ff ff       	call   801039f0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
801053ae:	31 db                	xor    %ebx,%ebx
    if(curproc->ofile[fd] == 0){
801053b0:	8b 54 98 28          	mov    0x28(%eax,%ebx,4),%edx
801053b4:	85 d2                	test   %edx,%edx
801053b6:	74 58                	je     80105410 <sys_open+0xe0>
  for(fd = 0; fd < NOFILE; fd++){
801053b8:	83 c3 01             	add    $0x1,%ebx
801053bb:	83 fb 10             	cmp    $0x10,%ebx
801053be:	75 f0                	jne    801053b0 <sys_open+0x80>
    if(f)
      fileclose(f);
801053c0:	83 ec 0c             	sub    $0xc,%esp
801053c3:	57                   	push   %edi
801053c4:	e8 47 bb ff ff       	call   80100f10 <fileclose>
801053c9:	83 c4 10             	add    $0x10,%esp
    iunlockput(ip);
801053cc:	83 ec 0c             	sub    $0xc,%esp
801053cf:	56                   	push   %esi
801053d0:	e8 5b c6 ff ff       	call   80101a30 <iunlockput>
    end_op();
801053d5:	e8 46 da ff ff       	call   80102e20 <end_op>
    return -1;
801053da:	83 c4 10             	add    $0x10,%esp
    return -1;
801053dd:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801053e2:	eb 65                	jmp    80105449 <sys_open+0x119>
801053e4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    ip = create(path, T_FILE, 0, 0);
801053e8:	83 ec 0c             	sub    $0xc,%esp
801053eb:	31 c9                	xor    %ecx,%ecx
801053ed:	ba 02 00 00 00       	mov    $0x2,%edx
801053f2:	6a 00                	push   $0x0
801053f4:	8b 45 e0             	mov    -0x20(%ebp),%eax
801053f7:	e8 54 f8 ff ff       	call   80104c50 <create>
    if(ip == 0){
801053fc:	83 c4 10             	add    $0x10,%esp
    ip = create(path, T_FILE, 0, 0);
801053ff:	89 c6                	mov    %eax,%esi
    if(ip == 0){
80105401:	85 c0                	test   %eax,%eax
80105403:	75 99                	jne    8010539e <sys_open+0x6e>
      end_op();
80105405:	e8 16 da ff ff       	call   80102e20 <end_op>
      return -1;
8010540a:	eb d1                	jmp    801053dd <sys_open+0xad>
8010540c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  }
  iunlock(ip);
80105410:	83 ec 0c             	sub    $0xc,%esp
      curproc->ofile[fd] = f;
80105413:	89 7c 98 28          	mov    %edi,0x28(%eax,%ebx,4)
  iunlock(ip);
80105417:	56                   	push   %esi
80105418:	e8 63 c4 ff ff       	call   80101880 <iunlock>
  end_op();
8010541d:	e8 fe d9 ff ff       	call   80102e20 <end_op>

  f->type = FD_INODE;
80105422:	c7 07 02 00 00 00    	movl   $0x2,(%edi)
  f->ip = ip;
  f->off = 0;
  f->readable = !(omode & O_WRONLY);
80105428:	8b 55 e4             	mov    -0x1c(%ebp),%edx
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
8010542b:	83 c4 10             	add    $0x10,%esp
  f->ip = ip;
8010542e:	89 77 10             	mov    %esi,0x10(%edi)
  f->readable = !(omode & O_WRONLY);
80105431:	89 d0                	mov    %edx,%eax
  f->off = 0;
80105433:	c7 47 14 00 00 00 00 	movl   $0x0,0x14(%edi)
  f->readable = !(omode & O_WRONLY);
8010543a:	f7 d0                	not    %eax
8010543c:	83 e0 01             	and    $0x1,%eax
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
8010543f:	83 e2 03             	and    $0x3,%edx
  f->readable = !(omode & O_WRONLY);
80105442:	88 47 08             	mov    %al,0x8(%edi)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
80105445:	0f 95 47 09          	setne  0x9(%edi)
  return fd;
}
80105449:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010544c:	89 d8                	mov    %ebx,%eax
8010544e:	5b                   	pop    %ebx
8010544f:	5e                   	pop    %esi
80105450:	5f                   	pop    %edi
80105451:	5d                   	pop    %ebp
80105452:	c3                   	ret
80105453:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(ip->type == T_DIR && omode != O_RDONLY){
80105458:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
8010545b:	85 c9                	test   %ecx,%ecx
8010545d:	0f 84 3b ff ff ff    	je     8010539e <sys_open+0x6e>
80105463:	e9 64 ff ff ff       	jmp    801053cc <sys_open+0x9c>
80105468:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010546f:	00 

80105470 <sys_mkdir>:

int
sys_mkdir(void)
{
80105470:	55                   	push   %ebp
80105471:	89 e5                	mov    %esp,%ebp
80105473:	83 ec 18             	sub    $0x18,%esp
  char *path;
  struct inode *ip;

  begin_op();
80105476:	e8 35 d9 ff ff       	call   80102db0 <begin_op>
  if(argstr(0, &path) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
8010547b:	83 ec 08             	sub    $0x8,%esp
8010547e:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105481:	50                   	push   %eax
80105482:	6a 00                	push   $0x0
80105484:	e8 d7 f6 ff ff       	call   80104b60 <argstr>
80105489:	83 c4 10             	add    $0x10,%esp
8010548c:	85 c0                	test   %eax,%eax
8010548e:	78 30                	js     801054c0 <sys_mkdir+0x50>
80105490:	83 ec 0c             	sub    $0xc,%esp
80105493:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105496:	31 c9                	xor    %ecx,%ecx
80105498:	ba 01 00 00 00       	mov    $0x1,%edx
8010549d:	6a 00                	push   $0x0
8010549f:	e8 ac f7 ff ff       	call   80104c50 <create>
801054a4:	83 c4 10             	add    $0x10,%esp
801054a7:	85 c0                	test   %eax,%eax
801054a9:	74 15                	je     801054c0 <sys_mkdir+0x50>
    end_op();
    return -1;
  }
  iunlockput(ip);
801054ab:	83 ec 0c             	sub    $0xc,%esp
801054ae:	50                   	push   %eax
801054af:	e8 7c c5 ff ff       	call   80101a30 <iunlockput>
  end_op();
801054b4:	e8 67 d9 ff ff       	call   80102e20 <end_op>
  return 0;
801054b9:	83 c4 10             	add    $0x10,%esp
801054bc:	31 c0                	xor    %eax,%eax
}
801054be:	c9                   	leave
801054bf:	c3                   	ret
    end_op();
801054c0:	e8 5b d9 ff ff       	call   80102e20 <end_op>
    return -1;
801054c5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801054ca:	c9                   	leave
801054cb:	c3                   	ret
801054cc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

801054d0 <sys_mknod>:

int
sys_mknod(void)
{
801054d0:	55                   	push   %ebp
801054d1:	89 e5                	mov    %esp,%ebp
801054d3:	83 ec 18             	sub    $0x18,%esp
  struct inode *ip;
  char *path;
  int major, minor;

  begin_op();
801054d6:	e8 d5 d8 ff ff       	call   80102db0 <begin_op>
  if((argstr(0, &path)) < 0 ||
801054db:	83 ec 08             	sub    $0x8,%esp
801054de:	8d 45 ec             	lea    -0x14(%ebp),%eax
801054e1:	50                   	push   %eax
801054e2:	6a 00                	push   $0x0
801054e4:	e8 77 f6 ff ff       	call   80104b60 <argstr>
801054e9:	83 c4 10             	add    $0x10,%esp
801054ec:	85 c0                	test   %eax,%eax
801054ee:	78 60                	js     80105550 <sys_mknod+0x80>
     argint(1, &major) < 0 ||
801054f0:	83 ec 08             	sub    $0x8,%esp
801054f3:	8d 45 f0             	lea    -0x10(%ebp),%eax
801054f6:	50                   	push   %eax
801054f7:	6a 01                	push   $0x1
801054f9:	e8 a2 f5 ff ff       	call   80104aa0 <argint>
  if((argstr(0, &path)) < 0 ||
801054fe:	83 c4 10             	add    $0x10,%esp
80105501:	85 c0                	test   %eax,%eax
80105503:	78 4b                	js     80105550 <sys_mknod+0x80>
     argint(2, &minor) < 0 ||
80105505:	83 ec 08             	sub    $0x8,%esp
80105508:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010550b:	50                   	push   %eax
8010550c:	6a 02                	push   $0x2
8010550e:	e8 8d f5 ff ff       	call   80104aa0 <argint>
     argint(1, &major) < 0 ||
80105513:	83 c4 10             	add    $0x10,%esp
80105516:	85 c0                	test   %eax,%eax
80105518:	78 36                	js     80105550 <sys_mknod+0x80>
     (ip = create(path, T_DEV, major, minor)) == 0){
8010551a:	0f bf 45 f4          	movswl -0xc(%ebp),%eax
8010551e:	83 ec 0c             	sub    $0xc,%esp
80105521:	0f bf 4d f0          	movswl -0x10(%ebp),%ecx
80105525:	ba 03 00 00 00       	mov    $0x3,%edx
8010552a:	50                   	push   %eax
8010552b:	8b 45 ec             	mov    -0x14(%ebp),%eax
8010552e:	e8 1d f7 ff ff       	call   80104c50 <create>
     argint(2, &minor) < 0 ||
80105533:	83 c4 10             	add    $0x10,%esp
80105536:	85 c0                	test   %eax,%eax
80105538:	74 16                	je     80105550 <sys_mknod+0x80>
    end_op();
    return -1;
  }
  iunlockput(ip);
8010553a:	83 ec 0c             	sub    $0xc,%esp
8010553d:	50                   	push   %eax
8010553e:	e8 ed c4 ff ff       	call   80101a30 <iunlockput>
  end_op();
80105543:	e8 d8 d8 ff ff       	call   80102e20 <end_op>
  return 0;
80105548:	83 c4 10             	add    $0x10,%esp
8010554b:	31 c0                	xor    %eax,%eax
}
8010554d:	c9                   	leave
8010554e:	c3                   	ret
8010554f:	90                   	nop
    end_op();
80105550:	e8 cb d8 ff ff       	call   80102e20 <end_op>
    return -1;
80105555:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
8010555a:	c9                   	leave
8010555b:	c3                   	ret
8010555c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105560 <sys_chdir>:

int
sys_chdir(void)
{
80105560:	55                   	push   %ebp
80105561:	89 e5                	mov    %esp,%ebp
80105563:	56                   	push   %esi
80105564:	53                   	push   %ebx
80105565:	83 ec 10             	sub    $0x10,%esp
  char *path;
  struct inode *ip;
  struct proc *curproc = myproc();
80105568:	e8 83 e4 ff ff       	call   801039f0 <myproc>
8010556d:	89 c6                	mov    %eax,%esi
  
  begin_op();
8010556f:	e8 3c d8 ff ff       	call   80102db0 <begin_op>
  if(argstr(0, &path) < 0 || (ip = namei(path)) == 0){
80105574:	83 ec 08             	sub    $0x8,%esp
80105577:	8d 45 f4             	lea    -0xc(%ebp),%eax
8010557a:	50                   	push   %eax
8010557b:	6a 00                	push   $0x0
8010557d:	e8 de f5 ff ff       	call   80104b60 <argstr>
80105582:	83 c4 10             	add    $0x10,%esp
80105585:	85 c0                	test   %eax,%eax
80105587:	78 77                	js     80105600 <sys_chdir+0xa0>
80105589:	83 ec 0c             	sub    $0xc,%esp
8010558c:	ff 75 f4             	push   -0xc(%ebp)
8010558f:	e8 ec ca ff ff       	call   80102080 <namei>
80105594:	83 c4 10             	add    $0x10,%esp
80105597:	89 c3                	mov    %eax,%ebx
80105599:	85 c0                	test   %eax,%eax
8010559b:	74 63                	je     80105600 <sys_chdir+0xa0>
    end_op();
    return -1;
  }
  ilock(ip);
8010559d:	83 ec 0c             	sub    $0xc,%esp
801055a0:	50                   	push   %eax
801055a1:	e8 fa c1 ff ff       	call   801017a0 <ilock>
  if(ip->type != T_DIR){
801055a6:	83 c4 10             	add    $0x10,%esp
801055a9:	66 83 7b 50 01       	cmpw   $0x1,0x50(%ebx)
801055ae:	75 30                	jne    801055e0 <sys_chdir+0x80>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
801055b0:	83 ec 0c             	sub    $0xc,%esp
801055b3:	53                   	push   %ebx
801055b4:	e8 c7 c2 ff ff       	call   80101880 <iunlock>
  iput(curproc->cwd);
801055b9:	58                   	pop    %eax
801055ba:	ff 76 68             	push   0x68(%esi)
801055bd:	e8 0e c3 ff ff       	call   801018d0 <iput>
  end_op();
801055c2:	e8 59 d8 ff ff       	call   80102e20 <end_op>
  curproc->cwd = ip;
801055c7:	89 5e 68             	mov    %ebx,0x68(%esi)
  return 0;
801055ca:	83 c4 10             	add    $0x10,%esp
801055cd:	31 c0                	xor    %eax,%eax
}
801055cf:	8d 65 f8             	lea    -0x8(%ebp),%esp
801055d2:	5b                   	pop    %ebx
801055d3:	5e                   	pop    %esi
801055d4:	5d                   	pop    %ebp
801055d5:	c3                   	ret
801055d6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801055dd:	00 
801055de:	66 90                	xchg   %ax,%ax
    iunlockput(ip);
801055e0:	83 ec 0c             	sub    $0xc,%esp
801055e3:	53                   	push   %ebx
801055e4:	e8 47 c4 ff ff       	call   80101a30 <iunlockput>
    end_op();
801055e9:	e8 32 d8 ff ff       	call   80102e20 <end_op>
    return -1;
801055ee:	83 c4 10             	add    $0x10,%esp
    return -1;
801055f1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801055f6:	eb d7                	jmp    801055cf <sys_chdir+0x6f>
801055f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801055ff:	00 
    end_op();
80105600:	e8 1b d8 ff ff       	call   80102e20 <end_op>
    return -1;
80105605:	eb ea                	jmp    801055f1 <sys_chdir+0x91>
80105607:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010560e:	00 
8010560f:	90                   	nop

80105610 <sys_exec>:

int
sys_exec(void)
{
80105610:	55                   	push   %ebp
80105611:	89 e5                	mov    %esp,%ebp
80105613:	57                   	push   %edi
80105614:	56                   	push   %esi
  char *path, *argv[MAXARG];
  int i;
  uint uargv, uarg;

  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80105615:	8d 85 5c ff ff ff    	lea    -0xa4(%ebp),%eax
{
8010561b:	53                   	push   %ebx
8010561c:	81 ec a4 00 00 00    	sub    $0xa4,%esp
  if(argstr(0, &path) < 0 || argint(1, (int*)&uargv) < 0){
80105622:	50                   	push   %eax
80105623:	6a 00                	push   $0x0
80105625:	e8 36 f5 ff ff       	call   80104b60 <argstr>
8010562a:	83 c4 10             	add    $0x10,%esp
8010562d:	85 c0                	test   %eax,%eax
8010562f:	0f 88 87 00 00 00    	js     801056bc <sys_exec+0xac>
80105635:	83 ec 08             	sub    $0x8,%esp
80105638:	8d 85 60 ff ff ff    	lea    -0xa0(%ebp),%eax
8010563e:	50                   	push   %eax
8010563f:	6a 01                	push   $0x1
80105641:	e8 5a f4 ff ff       	call   80104aa0 <argint>
80105646:	83 c4 10             	add    $0x10,%esp
80105649:	85 c0                	test   %eax,%eax
8010564b:	78 6f                	js     801056bc <sys_exec+0xac>
    return -1;
  }
  memset(argv, 0, sizeof(argv));
8010564d:	83 ec 04             	sub    $0x4,%esp
80105650:	8d b5 68 ff ff ff    	lea    -0x98(%ebp),%esi
  for(i=0;; i++){
80105656:	31 db                	xor    %ebx,%ebx
  memset(argv, 0, sizeof(argv));
80105658:	68 80 00 00 00       	push   $0x80
8010565d:	6a 00                	push   $0x0
8010565f:	56                   	push   %esi
80105660:	e8 8b f1 ff ff       	call   801047f0 <memset>
80105665:	83 c4 10             	add    $0x10,%esp
80105668:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010566f:	00 
    if(i >= NELEM(argv))
      return -1;
    if(fetchint(uargv+4*i, (int*)&uarg) < 0)
80105670:	83 ec 08             	sub    $0x8,%esp
80105673:	8d 85 64 ff ff ff    	lea    -0x9c(%ebp),%eax
80105679:	8d 3c 9d 00 00 00 00 	lea    0x0(,%ebx,4),%edi
80105680:	50                   	push   %eax
80105681:	8b 85 60 ff ff ff    	mov    -0xa0(%ebp),%eax
80105687:	01 f8                	add    %edi,%eax
80105689:	50                   	push   %eax
8010568a:	e8 81 f3 ff ff       	call   80104a10 <fetchint>
8010568f:	83 c4 10             	add    $0x10,%esp
80105692:	85 c0                	test   %eax,%eax
80105694:	78 26                	js     801056bc <sys_exec+0xac>
      return -1;
    if(uarg == 0){
80105696:	8b 85 64 ff ff ff    	mov    -0x9c(%ebp),%eax
8010569c:	85 c0                	test   %eax,%eax
8010569e:	74 30                	je     801056d0 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    if(fetchstr(uarg, &argv[i]) < 0)
801056a0:	83 ec 08             	sub    $0x8,%esp
801056a3:	8d 14 3e             	lea    (%esi,%edi,1),%edx
801056a6:	52                   	push   %edx
801056a7:	50                   	push   %eax
801056a8:	e8 a3 f3 ff ff       	call   80104a50 <fetchstr>
801056ad:	83 c4 10             	add    $0x10,%esp
801056b0:	85 c0                	test   %eax,%eax
801056b2:	78 08                	js     801056bc <sys_exec+0xac>
  for(i=0;; i++){
801056b4:	83 c3 01             	add    $0x1,%ebx
    if(i >= NELEM(argv))
801056b7:	83 fb 20             	cmp    $0x20,%ebx
801056ba:	75 b4                	jne    80105670 <sys_exec+0x60>
      return -1;
  }
  return exec(path, argv);
}
801056bc:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return -1;
801056bf:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801056c4:	5b                   	pop    %ebx
801056c5:	5e                   	pop    %esi
801056c6:	5f                   	pop    %edi
801056c7:	5d                   	pop    %ebp
801056c8:	c3                   	ret
801056c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
      argv[i] = 0;
801056d0:	c7 84 9d 68 ff ff ff 	movl   $0x0,-0x98(%ebp,%ebx,4)
801056d7:	00 00 00 00 
  return exec(path, argv);
801056db:	83 ec 08             	sub    $0x8,%esp
801056de:	56                   	push   %esi
801056df:	ff b5 5c ff ff ff    	push   -0xa4(%ebp)
801056e5:	e8 c6 b3 ff ff       	call   80100ab0 <exec>
801056ea:	83 c4 10             	add    $0x10,%esp
}
801056ed:	8d 65 f4             	lea    -0xc(%ebp),%esp
801056f0:	5b                   	pop    %ebx
801056f1:	5e                   	pop    %esi
801056f2:	5f                   	pop    %edi
801056f3:	5d                   	pop    %ebp
801056f4:	c3                   	ret
801056f5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801056fc:	00 
801056fd:	8d 76 00             	lea    0x0(%esi),%esi

80105700 <sys_pipe>:

int
sys_pipe(void)
{
80105700:	55                   	push   %ebp
80105701:	89 e5                	mov    %esp,%ebp
80105703:	57                   	push   %edi
80105704:	56                   	push   %esi
  int *fd;
  struct file *rf, *wf;
  int fd0, fd1;

  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
80105705:	8d 45 dc             	lea    -0x24(%ebp),%eax
{
80105708:	53                   	push   %ebx
80105709:	83 ec 20             	sub    $0x20,%esp
  if(argptr(0, (void*)&fd, 2*sizeof(fd[0])) < 0)
8010570c:	6a 08                	push   $0x8
8010570e:	50                   	push   %eax
8010570f:	6a 00                	push   $0x0
80105711:	e8 da f3 ff ff       	call   80104af0 <argptr>
80105716:	83 c4 10             	add    $0x10,%esp
80105719:	85 c0                	test   %eax,%eax
8010571b:	0f 88 8b 00 00 00    	js     801057ac <sys_pipe+0xac>
    return -1;
  if(pipealloc(&rf, &wf) < 0)
80105721:	83 ec 08             	sub    $0x8,%esp
80105724:	8d 45 e4             	lea    -0x1c(%ebp),%eax
80105727:	50                   	push   %eax
80105728:	8d 45 e0             	lea    -0x20(%ebp),%eax
8010572b:	50                   	push   %eax
8010572c:	e8 4f dd ff ff       	call   80103480 <pipealloc>
80105731:	83 c4 10             	add    $0x10,%esp
80105734:	85 c0                	test   %eax,%eax
80105736:	78 74                	js     801057ac <sys_pipe+0xac>
    return -1;
  fd0 = -1;
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105738:	8b 7d e0             	mov    -0x20(%ebp),%edi
  for(fd = 0; fd < NOFILE; fd++){
8010573b:	31 db                	xor    %ebx,%ebx
  struct proc *curproc = myproc();
8010573d:	e8 ae e2 ff ff       	call   801039f0 <myproc>
    if(curproc->ofile[fd] == 0){
80105742:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
80105746:	85 f6                	test   %esi,%esi
80105748:	74 16                	je     80105760 <sys_pipe+0x60>
8010574a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  for(fd = 0; fd < NOFILE; fd++){
80105750:	83 c3 01             	add    $0x1,%ebx
80105753:	83 fb 10             	cmp    $0x10,%ebx
80105756:	74 3d                	je     80105795 <sys_pipe+0x95>
    if(curproc->ofile[fd] == 0){
80105758:	8b 74 98 28          	mov    0x28(%eax,%ebx,4),%esi
8010575c:	85 f6                	test   %esi,%esi
8010575e:	75 f0                	jne    80105750 <sys_pipe+0x50>
      curproc->ofile[fd] = f;
80105760:	8d 73 08             	lea    0x8(%ebx),%esi
80105763:	89 7c b0 08          	mov    %edi,0x8(%eax,%esi,4)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
80105767:	8b 7d e4             	mov    -0x1c(%ebp),%edi
  struct proc *curproc = myproc();
8010576a:	e8 81 e2 ff ff       	call   801039f0 <myproc>
  for(fd = 0; fd < NOFILE; fd++){
8010576f:	31 d2                	xor    %edx,%edx
80105771:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(curproc->ofile[fd] == 0){
80105778:	8b 4c 90 28          	mov    0x28(%eax,%edx,4),%ecx
8010577c:	85 c9                	test   %ecx,%ecx
8010577e:	74 38                	je     801057b8 <sys_pipe+0xb8>
  for(fd = 0; fd < NOFILE; fd++){
80105780:	83 c2 01             	add    $0x1,%edx
80105783:	83 fa 10             	cmp    $0x10,%edx
80105786:	75 f0                	jne    80105778 <sys_pipe+0x78>
    if(fd0 >= 0)
      myproc()->ofile[fd0] = 0;
80105788:	e8 63 e2 ff ff       	call   801039f0 <myproc>
8010578d:	c7 44 b0 08 00 00 00 	movl   $0x0,0x8(%eax,%esi,4)
80105794:	00 
    fileclose(rf);
80105795:	83 ec 0c             	sub    $0xc,%esp
80105798:	ff 75 e0             	push   -0x20(%ebp)
8010579b:	e8 70 b7 ff ff       	call   80100f10 <fileclose>
    fileclose(wf);
801057a0:	58                   	pop    %eax
801057a1:	ff 75 e4             	push   -0x1c(%ebp)
801057a4:	e8 67 b7 ff ff       	call   80100f10 <fileclose>
    return -1;
801057a9:	83 c4 10             	add    $0x10,%esp
    return -1;
801057ac:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801057b1:	eb 16                	jmp    801057c9 <sys_pipe+0xc9>
801057b3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      curproc->ofile[fd] = f;
801057b8:	89 7c 90 28          	mov    %edi,0x28(%eax,%edx,4)
  }
  fd[0] = fd0;
801057bc:	8b 45 dc             	mov    -0x24(%ebp),%eax
801057bf:	89 18                	mov    %ebx,(%eax)
  fd[1] = fd1;
801057c1:	8b 45 dc             	mov    -0x24(%ebp),%eax
801057c4:	89 50 04             	mov    %edx,0x4(%eax)
  return 0;
801057c7:	31 c0                	xor    %eax,%eax
}
801057c9:	8d 65 f4             	lea    -0xc(%ebp),%esp
801057cc:	5b                   	pop    %ebx
801057cd:	5e                   	pop    %esi
801057ce:	5f                   	pop    %edi
801057cf:	5d                   	pop    %ebp
801057d0:	c3                   	ret
801057d1:	66 90                	xchg   %ax,%ax
801057d3:	66 90                	xchg   %ax,%ax
801057d5:	66 90                	xchg   %ax,%ax
801057d7:	66 90                	xchg   %ax,%ax
801057d9:	66 90                	xchg   %ax,%ax
801057db:	66 90                	xchg   %ax,%ax
801057dd:	66 90                	xchg   %ax,%ax
801057df:	90                   	nop

801057e0 <sys_fork>:
#include "proc.h"

int
sys_fork(void)
{
  return fork();
801057e0:	e9 ab e3 ff ff       	jmp    80103b90 <fork>
801057e5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801057ec:	00 
801057ed:	8d 76 00             	lea    0x0(%esi),%esi

801057f0 <sys_exit>:
}

int
sys_exit(void)
{
801057f0:	55                   	push   %ebp
801057f1:	89 e5                	mov    %esp,%ebp
801057f3:	83 ec 08             	sub    $0x8,%esp
  exit();
801057f6:	e8 45 e6 ff ff       	call   80103e40 <exit>
  return 0;  // not reached
}
801057fb:	31 c0                	xor    %eax,%eax
801057fd:	c9                   	leave
801057fe:	c3                   	ret
801057ff:	90                   	nop

80105800 <sys_wait>:

int
sys_wait(void)
{
  return wait();
80105800:	e9 6b e7 ff ff       	jmp    80103f70 <wait>
80105805:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010580c:	00 
8010580d:	8d 76 00             	lea    0x0(%esi),%esi

80105810 <sys_kill>:
}

int
sys_kill(void)
{
80105810:	55                   	push   %ebp
80105811:	89 e5                	mov    %esp,%ebp
80105813:	83 ec 20             	sub    $0x20,%esp
  int pid;

  if(argint(0, &pid) < 0)
80105816:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105819:	50                   	push   %eax
8010581a:	6a 00                	push   $0x0
8010581c:	e8 7f f2 ff ff       	call   80104aa0 <argint>
80105821:	83 c4 10             	add    $0x10,%esp
80105824:	85 c0                	test   %eax,%eax
80105826:	78 18                	js     80105840 <sys_kill+0x30>
    return -1;
  return kill(pid);
80105828:	83 ec 0c             	sub    $0xc,%esp
8010582b:	ff 75 f4             	push   -0xc(%ebp)
8010582e:	e8 dd e9 ff ff       	call   80104210 <kill>
80105833:	83 c4 10             	add    $0x10,%esp
}
80105836:	c9                   	leave
80105837:	c3                   	ret
80105838:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010583f:	00 
80105840:	c9                   	leave
    return -1;
80105841:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105846:	c3                   	ret
80105847:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010584e:	00 
8010584f:	90                   	nop

80105850 <sys_getpid>:

int
sys_getpid(void)
{
80105850:	55                   	push   %ebp
80105851:	89 e5                	mov    %esp,%ebp
80105853:	83 ec 08             	sub    $0x8,%esp
  return myproc()->pid;
80105856:	e8 95 e1 ff ff       	call   801039f0 <myproc>
8010585b:	8b 40 10             	mov    0x10(%eax),%eax
}
8010585e:	c9                   	leave
8010585f:	c3                   	ret

80105860 <sys_sbrk>:

int
sys_sbrk(void)
{
80105860:	55                   	push   %ebp
80105861:	89 e5                	mov    %esp,%ebp
80105863:	53                   	push   %ebx
  int addr;
  int n;

  if(argint(0, &n) < 0)
80105864:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105867:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
8010586a:	50                   	push   %eax
8010586b:	6a 00                	push   $0x0
8010586d:	e8 2e f2 ff ff       	call   80104aa0 <argint>
80105872:	83 c4 10             	add    $0x10,%esp
80105875:	85 c0                	test   %eax,%eax
80105877:	78 27                	js     801058a0 <sys_sbrk+0x40>
    return -1;

  addr = myproc()->sz;
80105879:	e8 72 e1 ff ff       	call   801039f0 <myproc>
8010587e:	8b 18                	mov    (%eax),%ebx

  if(n < 0)
80105880:	8b 45 f4             	mov    -0xc(%ebp),%eax
80105883:	85 c0                	test   %eax,%eax
80105885:	78 19                	js     801058a0 <sys_sbrk+0x40>
    return -1;

  myproc()->sz += n;
80105887:	e8 64 e1 ff ff       	call   801039f0 <myproc>
8010588c:	8b 55 f4             	mov    -0xc(%ebp),%edx
8010588f:	01 10                	add    %edx,(%eax)
  return addr;
}
80105891:	89 d8                	mov    %ebx,%eax
80105893:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105896:	c9                   	leave
80105897:	c3                   	ret
80105898:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010589f:	00 
    return -1;
801058a0:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
801058a5:	eb ea                	jmp    80105891 <sys_sbrk+0x31>
801058a7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801058ae:	00 
801058af:	90                   	nop

801058b0 <sys_sleep>:

int
sys_sleep(void)
{
801058b0:	55                   	push   %ebp
801058b1:	89 e5                	mov    %esp,%ebp
801058b3:	53                   	push   %ebx
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
801058b4:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
801058b7:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &n) < 0)
801058ba:	50                   	push   %eax
801058bb:	6a 00                	push   $0x0
801058bd:	e8 de f1 ff ff       	call   80104aa0 <argint>
801058c2:	83 c4 10             	add    $0x10,%esp
801058c5:	85 c0                	test   %eax,%eax
801058c7:	78 64                	js     8010592d <sys_sleep+0x7d>
    return -1;
  acquire(&tickslock);
801058c9:	83 ec 0c             	sub    $0xc,%esp
801058cc:	68 a0 4f 11 80       	push   $0x80114fa0
801058d1:	e8 1a ee ff ff       	call   801046f0 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
801058d6:	8b 55 f4             	mov    -0xc(%ebp),%edx
  ticks0 = ticks;
801058d9:	8b 1d 80 4f 11 80    	mov    0x80114f80,%ebx
  while(ticks - ticks0 < n){
801058df:	83 c4 10             	add    $0x10,%esp
801058e2:	85 d2                	test   %edx,%edx
801058e4:	75 2b                	jne    80105911 <sys_sleep+0x61>
801058e6:	eb 58                	jmp    80105940 <sys_sleep+0x90>
801058e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801058ef:	00 
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
801058f0:	83 ec 08             	sub    $0x8,%esp
801058f3:	68 a0 4f 11 80       	push   $0x80114fa0
801058f8:	68 80 4f 11 80       	push   $0x80114f80
801058fd:	e8 ee e7 ff ff       	call   801040f0 <sleep>
  while(ticks - ticks0 < n){
80105902:	a1 80 4f 11 80       	mov    0x80114f80,%eax
80105907:	83 c4 10             	add    $0x10,%esp
8010590a:	29 d8                	sub    %ebx,%eax
8010590c:	3b 45 f4             	cmp    -0xc(%ebp),%eax
8010590f:	73 2f                	jae    80105940 <sys_sleep+0x90>
    if(myproc()->killed){
80105911:	e8 da e0 ff ff       	call   801039f0 <myproc>
80105916:	8b 40 24             	mov    0x24(%eax),%eax
80105919:	85 c0                	test   %eax,%eax
8010591b:	74 d3                	je     801058f0 <sys_sleep+0x40>
      release(&tickslock);
8010591d:	83 ec 0c             	sub    $0xc,%esp
80105920:	68 a0 4f 11 80       	push   $0x80114fa0
80105925:	e8 66 ed ff ff       	call   80104690 <release>
      return -1;
8010592a:	83 c4 10             	add    $0x10,%esp
  }
  release(&tickslock);
  return 0;
}
8010592d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    return -1;
80105930:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105935:	c9                   	leave
80105936:	c3                   	ret
80105937:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010593e:	00 
8010593f:	90                   	nop
  release(&tickslock);
80105940:	83 ec 0c             	sub    $0xc,%esp
80105943:	68 a0 4f 11 80       	push   $0x80114fa0
80105948:	e8 43 ed ff ff       	call   80104690 <release>
}
8010594d:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  return 0;
80105950:	83 c4 10             	add    $0x10,%esp
80105953:	31 c0                	xor    %eax,%eax
}
80105955:	c9                   	leave
80105956:	c3                   	ret
80105957:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010595e:	00 
8010595f:	90                   	nop

80105960 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
80105960:	55                   	push   %ebp
80105961:	89 e5                	mov    %esp,%ebp
80105963:	53                   	push   %ebx
80105964:	83 ec 10             	sub    $0x10,%esp
  uint xticks;

  acquire(&tickslock);
80105967:	68 a0 4f 11 80       	push   $0x80114fa0
8010596c:	e8 7f ed ff ff       	call   801046f0 <acquire>
  xticks = ticks;
80105971:	8b 1d 80 4f 11 80    	mov    0x80114f80,%ebx
  release(&tickslock);
80105977:	c7 04 24 a0 4f 11 80 	movl   $0x80114fa0,(%esp)
8010597e:	e8 0d ed ff ff       	call   80104690 <release>
  return xticks;
}
80105983:	89 d8                	mov    %ebx,%eax
80105985:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105988:	c9                   	leave
80105989:	c3                   	ret
8010598a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80105990 <sys_vmprint>:

int
sys_vmprint(void)
{
80105990:	55                   	push   %ebp
80105991:	89 e5                	mov    %esp,%ebp
80105993:	83 ec 08             	sub    $0x8,%esp
  vmprint();
80105996:	e8 15 1b 00 00       	call   801074b0 <vmprint>
  return 0;
}
8010599b:	31 c0                	xor    %eax,%eax
8010599d:	c9                   	leave
8010599e:	c3                   	ret
8010599f:	90                   	nop

801059a0 <sys_getfaults>:

int
sys_getfaults(void)
{
801059a0:	55                   	push   %ebp
801059a1:	89 e5                	mov    %esp,%ebp
801059a3:	83 ec 08             	sub    $0x8,%esp
  return myproc()->faults;
801059a6:	e8 45 e0 ff ff       	call   801039f0 <myproc>
801059ab:	8b 40 7c             	mov    0x7c(%eax),%eax
}
801059ae:	c9                   	leave
801059af:	c3                   	ret

801059b0 <sys_set_burst>:

int
sys_set_burst(void)
{
801059b0:	55                   	push   %ebp
801059b1:	89 e5                	mov    %esp,%ebp
801059b3:	83 ec 20             	sub    $0x20,%esp
  int pid, bt;

  // Fetch 1st argument (index 0) and 2nd argument (index 1)
  if(argint(0, &pid) < 0 || argint(1, &bt) < 0)
801059b6:	8d 45 f0             	lea    -0x10(%ebp),%eax
801059b9:	50                   	push   %eax
801059ba:	6a 00                	push   $0x0
801059bc:	e8 df f0 ff ff       	call   80104aa0 <argint>
801059c1:	83 c4 10             	add    $0x10,%esp
801059c4:	85 c0                	test   %eax,%eax
801059c6:	78 28                	js     801059f0 <sys_set_burst+0x40>
801059c8:	83 ec 08             	sub    $0x8,%esp
801059cb:	8d 45 f4             	lea    -0xc(%ebp),%eax
801059ce:	50                   	push   %eax
801059cf:	6a 01                	push   $0x1
801059d1:	e8 ca f0 ff ff       	call   80104aa0 <argint>
801059d6:	83 c4 10             	add    $0x10,%esp
801059d9:	85 c0                	test   %eax,%eax
801059db:	78 13                	js     801059f0 <sys_set_burst+0x40>
    return -1;

  return set_burst(pid, bt);
801059dd:	83 ec 08             	sub    $0x8,%esp
801059e0:	ff 75 f4             	push   -0xc(%ebp)
801059e3:	ff 75 f0             	push   -0x10(%ebp)
801059e6:	e8 65 e9 ff ff       	call   80104350 <set_burst>
801059eb:	83 c4 10             	add    $0x10,%esp
}
801059ee:	c9                   	leave
801059ef:	c3                   	ret
801059f0:	c9                   	leave
    return -1;
801059f1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
801059f6:	c3                   	ret
801059f7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801059fe:	00 
801059ff:	90                   	nop

80105a00 <sys_sem_init>:

int
sys_sem_init(void)
{
80105a00:	55                   	push   %ebp
80105a01:	89 e5                	mov    %esp,%ebp
80105a03:	83 ec 20             	sub    $0x20,%esp
  int id, value;
  if(argint(0, &id) < 0 || argint(1, &value) < 0)
80105a06:	8d 45 f0             	lea    -0x10(%ebp),%eax
80105a09:	50                   	push   %eax
80105a0a:	6a 00                	push   $0x0
80105a0c:	e8 8f f0 ff ff       	call   80104aa0 <argint>
80105a11:	83 c4 10             	add    $0x10,%esp
80105a14:	85 c0                	test   %eax,%eax
80105a16:	78 28                	js     80105a40 <sys_sem_init+0x40>
80105a18:	83 ec 08             	sub    $0x8,%esp
80105a1b:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105a1e:	50                   	push   %eax
80105a1f:	6a 01                	push   $0x1
80105a21:	e8 7a f0 ff ff       	call   80104aa0 <argint>
80105a26:	83 c4 10             	add    $0x10,%esp
80105a29:	85 c0                	test   %eax,%eax
80105a2b:	78 13                	js     80105a40 <sys_sem_init+0x40>
    return -1;
  return sem_init(id, value);
80105a2d:	83 ec 08             	sub    $0x8,%esp
80105a30:	ff 75 f4             	push   -0xc(%ebp)
80105a33:	ff 75 f0             	push   -0x10(%ebp)
80105a36:	e8 55 1c 00 00       	call   80107690 <sem_init>
80105a3b:	83 c4 10             	add    $0x10,%esp
}
80105a3e:	c9                   	leave
80105a3f:	c3                   	ret
80105a40:	c9                   	leave
    return -1;
80105a41:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105a46:	c3                   	ret
80105a47:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a4e:	00 
80105a4f:	90                   	nop

80105a50 <sys_sem_wait>:

int
sys_sem_wait(void)
{
80105a50:	55                   	push   %ebp
80105a51:	89 e5                	mov    %esp,%ebp
80105a53:	83 ec 20             	sub    $0x20,%esp
  int id;
  if(argint(0, &id) < 0)
80105a56:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105a59:	50                   	push   %eax
80105a5a:	6a 00                	push   $0x0
80105a5c:	e8 3f f0 ff ff       	call   80104aa0 <argint>
80105a61:	83 c4 10             	add    $0x10,%esp
80105a64:	85 c0                	test   %eax,%eax
80105a66:	78 18                	js     80105a80 <sys_sem_wait+0x30>
    return -1;
  return sem_wait(id);
80105a68:	83 ec 0c             	sub    $0xc,%esp
80105a6b:	ff 75 f4             	push   -0xc(%ebp)
80105a6e:	e8 7d 1c 00 00       	call   801076f0 <sem_wait>
80105a73:	83 c4 10             	add    $0x10,%esp
}
80105a76:	c9                   	leave
80105a77:	c3                   	ret
80105a78:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a7f:	00 
80105a80:	c9                   	leave
    return -1;
80105a81:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105a86:	c3                   	ret
80105a87:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105a8e:	00 
80105a8f:	90                   	nop

80105a90 <sys_sem_post>:

int
sys_sem_post(void)
{
80105a90:	55                   	push   %ebp
80105a91:	89 e5                	mov    %esp,%ebp
80105a93:	83 ec 20             	sub    $0x20,%esp
  int id;
  if(argint(0, &id) < 0)
80105a96:	8d 45 f4             	lea    -0xc(%ebp),%eax
80105a99:	50                   	push   %eax
80105a9a:	6a 00                	push   $0x0
80105a9c:	e8 ff ef ff ff       	call   80104aa0 <argint>
80105aa1:	83 c4 10             	add    $0x10,%esp
80105aa4:	85 c0                	test   %eax,%eax
80105aa6:	78 18                	js     80105ac0 <sys_sem_post+0x30>
    return -1;
  return sem_post(id);
80105aa8:	83 ec 0c             	sub    $0xc,%esp
80105aab:	ff 75 f4             	push   -0xc(%ebp)
80105aae:	e8 dd 1c 00 00       	call   80107790 <sem_post>
80105ab3:	83 c4 10             	add    $0x10,%esp
}
80105ab6:	c9                   	leave
80105ab7:	c3                   	ret
80105ab8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105abf:	00 
80105ac0:	c9                   	leave
    return -1;
80105ac1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105ac6:	c3                   	ret
80105ac7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105ace:	00 
80105acf:	90                   	nop

80105ad0 <sys_freepages>:

int
sys_freepages(void)
{
  return freepages();
80105ad0:	e9 1b cc ff ff       	jmp    801026f0 <freepages>
80105ad5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105adc:	00 
80105add:	8d 76 00             	lea    0x0(%esi),%esi

80105ae0 <sys_va2pa>:
}

int
sys_va2pa(void)
{
80105ae0:	55                   	push   %ebp
80105ae1:	89 e5                	mov    %esp,%ebp
80105ae3:	53                   	push   %ebx
  int va;
  if(argint(0, &va) < 0)
80105ae4:	8d 45 f4             	lea    -0xc(%ebp),%eax
{
80105ae7:	83 ec 1c             	sub    $0x1c,%esp
  if(argint(0, &va) < 0)
80105aea:	50                   	push   %eax
80105aeb:	6a 00                	push   $0x0
80105aed:	e8 ae ef ff ff       	call   80104aa0 <argint>
80105af2:	83 c4 10             	add    $0x10,%esp
80105af5:	85 c0                	test   %eax,%eax
80105af7:	78 1f                	js     80105b18 <sys_va2pa+0x38>
    return -1;
  return va2pa(myproc()->pgdir, (uint)va);
80105af9:	8b 5d f4             	mov    -0xc(%ebp),%ebx
80105afc:	e8 ef de ff ff       	call   801039f0 <myproc>
80105b01:	83 ec 08             	sub    $0x8,%esp
80105b04:	53                   	push   %ebx
80105b05:	ff 70 04             	push   0x4(%eax)
80105b08:	e8 d3 1a 00 00       	call   801075e0 <va2pa>
80105b0d:	83 c4 10             	add    $0x10,%esp
}
80105b10:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80105b13:	c9                   	leave
80105b14:	c3                   	ret
80105b15:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80105b18:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80105b1d:	eb f1                	jmp    80105b10 <sys_va2pa+0x30>

80105b1f <alltraps>:

  # vectors.S sends all traps here.
.globl alltraps
alltraps:
  # Build trap frame.
  pushl %ds
80105b1f:	1e                   	push   %ds
  pushl %es
80105b20:	06                   	push   %es
  pushl %fs
80105b21:	0f a0                	push   %fs
  pushl %gs
80105b23:	0f a8                	push   %gs
  pushal
80105b25:	60                   	pusha
  
  # Set up data segments.
  movw $(SEG_KDATA<<3), %ax
80105b26:	66 b8 10 00          	mov    $0x10,%ax
  movw %ax, %ds
80105b2a:	8e d8                	mov    %eax,%ds
  movw %ax, %es
80105b2c:	8e c0                	mov    %eax,%es

  # Call trap(tf), where tf=%esp
  pushl %esp
80105b2e:	54                   	push   %esp
  call trap
80105b2f:	e8 cc 00 00 00       	call   80105c00 <trap>
  addl $4, %esp
80105b34:	83 c4 04             	add    $0x4,%esp

80105b37 <trapret>:

  # Return falls through to trapret...
.globl trapret
trapret:
  popal
80105b37:	61                   	popa
  popl %gs
80105b38:	0f a9                	pop    %gs
  popl %fs
80105b3a:	0f a1                	pop    %fs
  popl %es
80105b3c:	07                   	pop    %es
  popl %ds
80105b3d:	1f                   	pop    %ds
  addl $0x8, %esp  # trapno and errcode
80105b3e:	83 c4 08             	add    $0x8,%esp
  iret
80105b41:	cf                   	iret
80105b42:	66 90                	xchg   %ax,%ax
80105b44:	66 90                	xchg   %ax,%ax
80105b46:	66 90                	xchg   %ax,%ax
80105b48:	66 90                	xchg   %ax,%ax
80105b4a:	66 90                	xchg   %ax,%ax
80105b4c:	66 90                	xchg   %ax,%ax
80105b4e:	66 90                	xchg   %ax,%ax

80105b50 <tvinit>:
struct spinlock tickslock;
uint ticks;

void
tvinit(void)
{
80105b50:	55                   	push   %ebp
  int i;

  for(i = 0; i < 256; i++)
80105b51:	31 c0                	xor    %eax,%eax
{
80105b53:	89 e5                	mov    %esp,%ebp
80105b55:	83 ec 08             	sub    $0x8,%esp
80105b58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105b5f:	00 
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
80105b60:	8b 14 85 08 b0 10 80 	mov    -0x7fef4ff8(,%eax,4),%edx
80105b67:	c7 04 c5 e2 4f 11 80 	movl   $0x8e000008,-0x7feeb01e(,%eax,8)
80105b6e:	08 00 00 8e 
80105b72:	66 89 14 c5 e0 4f 11 	mov    %dx,-0x7feeb020(,%eax,8)
80105b79:	80 
80105b7a:	c1 ea 10             	shr    $0x10,%edx
80105b7d:	66 89 14 c5 e6 4f 11 	mov    %dx,-0x7feeb01a(,%eax,8)
80105b84:	80 
  for(i = 0; i < 256; i++)
80105b85:	83 c0 01             	add    $0x1,%eax
80105b88:	3d 00 01 00 00       	cmp    $0x100,%eax
80105b8d:	75 d1                	jne    80105b60 <tvinit+0x10>
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
80105b8f:	83 ec 08             	sub    $0x8,%esp
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105b92:	a1 08 b1 10 80       	mov    0x8010b108,%eax
80105b97:	c7 05 e2 51 11 80 08 	movl   $0xef000008,0x801151e2
80105b9e:	00 00 ef 
  initlock(&tickslock, "time");
80105ba1:	68 0e 7c 10 80       	push   $0x80107c0e
80105ba6:	68 a0 4f 11 80       	push   $0x80114fa0
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);
80105bab:	66 a3 e0 51 11 80    	mov    %ax,0x801151e0
80105bb1:	c1 e8 10             	shr    $0x10,%eax
80105bb4:	66 a3 e6 51 11 80    	mov    %ax,0x801151e6
  initlock(&tickslock, "time");
80105bba:	e8 41 e9 ff ff       	call   80104500 <initlock>
}
80105bbf:	83 c4 10             	add    $0x10,%esp
80105bc2:	c9                   	leave
80105bc3:	c3                   	ret
80105bc4:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105bcb:	00 
80105bcc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80105bd0 <idtinit>:

void
idtinit(void)
{
80105bd0:	55                   	push   %ebp
  pd[0] = size-1;
80105bd1:	b8 ff 07 00 00       	mov    $0x7ff,%eax
80105bd6:	89 e5                	mov    %esp,%ebp
80105bd8:	83 ec 10             	sub    $0x10,%esp
80105bdb:	66 89 45 fa          	mov    %ax,-0x6(%ebp)
  pd[1] = (uint)p;
80105bdf:	b8 e0 4f 11 80       	mov    $0x80114fe0,%eax
80105be4:	66 89 45 fc          	mov    %ax,-0x4(%ebp)
  pd[2] = (uint)p >> 16;
80105be8:	c1 e8 10             	shr    $0x10,%eax
80105beb:	66 89 45 fe          	mov    %ax,-0x2(%ebp)
  asm volatile("lidt (%0)" : : "r" (pd));
80105bef:	8d 45 fa             	lea    -0x6(%ebp),%eax
80105bf2:	0f 01 18             	lidtl  (%eax)
  lidt(idt, sizeof(idt));
}
80105bf5:	c9                   	leave
80105bf6:	c3                   	ret
80105bf7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105bfe:	00 
80105bff:	90                   	nop

80105c00 <trap>:

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{
80105c00:	55                   	push   %ebp
80105c01:	89 e5                	mov    %esp,%ebp
80105c03:	57                   	push   %edi
80105c04:	56                   	push   %esi
80105c05:	53                   	push   %ebx
80105c06:	83 ec 1c             	sub    $0x1c,%esp
80105c09:	8b 5d 08             	mov    0x8(%ebp),%ebx
    if(tf->trapno == T_SYSCALL){
80105c0c:	8b 43 30             	mov    0x30(%ebx),%eax
80105c0f:	83 f8 40             	cmp    $0x40,%eax
80105c12:	0f 84 80 02 00 00    	je     80105e98 <trap+0x298>
    if(myproc()->killed)
      exit();
    return;
  }

  if(tf->trapno == T_PGFLT){
80105c18:	83 f8 0e             	cmp    $0xe,%eax
80105c1b:	0f 84 d7 01 00 00    	je     80105df8 <trap+0x1f8>
      exit();

    return;
  }

  switch(tf->trapno){
80105c21:	83 e8 20             	sub    $0x20,%eax
80105c24:	83 f8 1f             	cmp    $0x1f,%eax
80105c27:	77 77                	ja     80105ca0 <trap+0xa0>
80105c29:	ff 24 85 f8 81 10 80 	jmp    *-0x7fef7e08(,%eax,4)
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
80105c30:	e8 fb c5 ff ff       	call   80102230 <ideintr>
    lapiceoi();
80105c35:	e8 26 cd ff ff       	call   80102960 <lapiceoi>
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105c3a:	e8 b1 dd ff ff       	call   801039f0 <myproc>
80105c3f:	85 c0                	test   %eax,%eax
80105c41:	74 10                	je     80105c53 <trap+0x53>
80105c43:	e8 a8 dd ff ff       	call   801039f0 <myproc>
80105c48:	8b 50 24             	mov    0x24(%eax),%edx
80105c4b:	85 d2                	test   %edx,%edx
80105c4d:	0f 85 c5 00 00 00    	jne    80105d18 <trap+0x118>
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
80105c53:	e8 98 dd ff ff       	call   801039f0 <myproc>
80105c58:	85 c0                	test   %eax,%eax
80105c5a:	74 0f                	je     80105c6b <trap+0x6b>
80105c5c:	e8 8f dd ff ff       	call   801039f0 <myproc>
80105c61:	83 78 0c 04          	cmpl   $0x4,0xc(%eax)
80105c65:	0f 84 15 02 00 00    	je     80105e80 <trap+0x280>
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105c6b:	e8 80 dd ff ff       	call   801039f0 <myproc>
80105c70:	85 c0                	test   %eax,%eax
80105c72:	74 1a                	je     80105c8e <trap+0x8e>
80105c74:	e8 77 dd ff ff       	call   801039f0 <myproc>
80105c79:	8b 40 24             	mov    0x24(%eax),%eax
80105c7c:	85 c0                	test   %eax,%eax
80105c7e:	74 0e                	je     80105c8e <trap+0x8e>
80105c80:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
80105c84:	f7 d0                	not    %eax
80105c86:	a8 03                	test   $0x3,%al
80105c88:	0f 84 ee 00 00 00    	je     80105d7c <trap+0x17c>
    exit();
}
80105c8e:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105c91:	5b                   	pop    %ebx
80105c92:	5e                   	pop    %esi
80105c93:	5f                   	pop    %edi
80105c94:	5d                   	pop    %ebp
80105c95:	c3                   	ret
80105c96:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105c9d:	00 
80105c9e:	66 90                	xchg   %ax,%ax
    if(myproc() == 0 || (tf->cs&3) == 0){
80105ca0:	e8 4b dd ff ff       	call   801039f0 <myproc>
80105ca5:	8b 7b 38             	mov    0x38(%ebx),%edi
80105ca8:	85 c0                	test   %eax,%eax
80105caa:	0f 84 37 02 00 00    	je     80105ee7 <trap+0x2e7>
80105cb0:	f6 43 3c 03          	testb  $0x3,0x3c(%ebx)
80105cb4:	0f 84 2d 02 00 00    	je     80105ee7 <trap+0x2e7>

static inline uint
rcr2(void)
{
  uint val;
  asm volatile("movl %%cr2,%0" : "=r" (val));
80105cba:	0f 20 d1             	mov    %cr2,%ecx
80105cbd:	89 4d d8             	mov    %ecx,-0x28(%ebp)
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105cc0:	e8 0b dd ff ff       	call   801039d0 <cpuid>
80105cc5:	8b 73 30             	mov    0x30(%ebx),%esi
80105cc8:	89 45 dc             	mov    %eax,-0x24(%ebp)
80105ccb:	8b 43 34             	mov    0x34(%ebx),%eax
80105cce:	89 45 e4             	mov    %eax,-0x1c(%ebp)
            myproc()->pid, myproc()->name, tf->trapno,
80105cd1:	e8 1a dd ff ff       	call   801039f0 <myproc>
80105cd6:	89 45 e0             	mov    %eax,-0x20(%ebp)
80105cd9:	e8 12 dd ff ff       	call   801039f0 <myproc>
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105cde:	8b 4d d8             	mov    -0x28(%ebp),%ecx
80105ce1:	51                   	push   %ecx
80105ce2:	57                   	push   %edi
80105ce3:	8b 55 dc             	mov    -0x24(%ebp),%edx
80105ce6:	52                   	push   %edx
80105ce7:	ff 75 e4             	push   -0x1c(%ebp)
80105cea:	56                   	push   %esi
            myproc()->pid, myproc()->name, tf->trapno,
80105ceb:	8b 75 e0             	mov    -0x20(%ebp),%esi
80105cee:	83 c6 6c             	add    $0x6c,%esi
    cprintf("pid %d %s: trap %d err %d on cpu %d "
80105cf1:	56                   	push   %esi
80105cf2:	ff 70 10             	push   0x10(%eax)
80105cf5:	68 88 7e 10 80       	push   $0x80107e88
80105cfa:	e8 b1 a9 ff ff       	call   801006b0 <cprintf>
    myproc()->killed = 1;
80105cff:	83 c4 20             	add    $0x20,%esp
80105d02:	e8 e9 dc ff ff       	call   801039f0 <myproc>
80105d07:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
80105d0e:	e9 27 ff ff ff       	jmp    80105c3a <trap+0x3a>
80105d13:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
80105d18:	0f b7 43 3c          	movzwl 0x3c(%ebx),%eax
80105d1c:	f7 d0                	not    %eax
80105d1e:	a8 03                	test   $0x3,%al
80105d20:	0f 85 2d ff ff ff    	jne    80105c53 <trap+0x53>
    exit();
80105d26:	e8 15 e1 ff ff       	call   80103e40 <exit>
80105d2b:	e9 23 ff ff ff       	jmp    80105c53 <trap+0x53>
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
80105d30:	8b 7b 38             	mov    0x38(%ebx),%edi
80105d33:	0f b7 73 3c          	movzwl 0x3c(%ebx),%esi
80105d37:	e8 94 dc ff ff       	call   801039d0 <cpuid>
80105d3c:	57                   	push   %edi
80105d3d:	56                   	push   %esi
80105d3e:	50                   	push   %eax
80105d3f:	68 30 7e 10 80       	push   $0x80107e30
80105d44:	e8 67 a9 ff ff       	call   801006b0 <cprintf>
    lapiceoi();
80105d49:	e8 12 cc ff ff       	call   80102960 <lapiceoi>
    break;
80105d4e:	83 c4 10             	add    $0x10,%esp
80105d51:	e9 e4 fe ff ff       	jmp    80105c3a <trap+0x3a>
80105d56:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105d5d:	00 
80105d5e:	66 90                	xchg   %ax,%ax
        myproc()->killed = 1;
80105d60:	e8 8b dc ff ff       	call   801039f0 <myproc>
80105d65:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
    if(myproc()->killed)
80105d6c:	e8 7f dc ff ff       	call   801039f0 <myproc>
80105d71:	8b 48 24             	mov    0x24(%eax),%ecx
80105d74:	85 c9                	test   %ecx,%ecx
80105d76:	0f 84 12 ff ff ff    	je     80105c8e <trap+0x8e>
}
80105d7c:	8d 65 f4             	lea    -0xc(%ebp),%esp
80105d7f:	5b                   	pop    %ebx
80105d80:	5e                   	pop    %esi
80105d81:	5f                   	pop    %edi
80105d82:	5d                   	pop    %ebp
      exit();
80105d83:	e9 b8 e0 ff ff       	jmp    80103e40 <exit>
80105d88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105d8f:	00 
    uartintr();
80105d90:	e8 0b 03 00 00       	call   801060a0 <uartintr>
    lapiceoi();
80105d95:	e8 c6 cb ff ff       	call   80102960 <lapiceoi>
    break;
80105d9a:	e9 9b fe ff ff       	jmp    80105c3a <trap+0x3a>
80105d9f:	90                   	nop
    kbdintr();
80105da0:	e8 8b ca ff ff       	call   80102830 <kbdintr>
    lapiceoi();
80105da5:	e8 b6 cb ff ff       	call   80102960 <lapiceoi>
    break;
80105daa:	e9 8b fe ff ff       	jmp    80105c3a <trap+0x3a>
80105daf:	90                   	nop
    if(cpuid() == 0){
80105db0:	e8 1b dc ff ff       	call   801039d0 <cpuid>
80105db5:	85 c0                	test   %eax,%eax
80105db7:	0f 85 78 fe ff ff    	jne    80105c35 <trap+0x35>
      acquire(&tickslock);
80105dbd:	83 ec 0c             	sub    $0xc,%esp
80105dc0:	68 a0 4f 11 80       	push   $0x80114fa0
80105dc5:	e8 26 e9 ff ff       	call   801046f0 <acquire>
      ticks++;
80105dca:	83 05 80 4f 11 80 01 	addl   $0x1,0x80114f80
      wakeup(&ticks);
80105dd1:	c7 04 24 80 4f 11 80 	movl   $0x80114f80,(%esp)
80105dd8:	e8 d3 e3 ff ff       	call   801041b0 <wakeup>
      release(&tickslock);
80105ddd:	c7 04 24 a0 4f 11 80 	movl   $0x80114fa0,(%esp)
80105de4:	e8 a7 e8 ff ff       	call   80104690 <release>
80105de9:	83 c4 10             	add    $0x10,%esp
    lapiceoi();
80105dec:	e9 44 fe ff ff       	jmp    80105c35 <trap+0x35>
80105df1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(myproc() == 0 || (tf->cs & 3) == 0)
80105df8:	e8 f3 db ff ff       	call   801039f0 <myproc>
80105dfd:	85 c0                	test   %eax,%eax
80105dff:	0f 84 0a 01 00 00    	je     80105f0f <trap+0x30f>
80105e05:	f6 43 3c 03          	testb  $0x3,0x3c(%ebx)
80105e09:	0f 84 00 01 00 00    	je     80105f0f <trap+0x30f>
80105e0f:	0f 20 d3             	mov    %cr2,%ebx
       if(fault_addr >= myproc()->sz){
80105e12:	e8 d9 db ff ff       	call   801039f0 <myproc>
80105e17:	3b 18                	cmp    (%eax),%ebx
80105e19:	0f 83 41 ff ff ff    	jae    80105d60 <trap+0x160>
      mem = kalloc();
80105e1f:	e8 4c c8 ff ff       	call   80102670 <kalloc>
80105e24:	89 c6                	mov    %eax,%esi
      if(mem == 0){
80105e26:	85 c0                	test   %eax,%eax
80105e28:	0f 84 32 ff ff ff    	je     80105d60 <trap+0x160>
        memset(mem, 0, PGSIZE);
80105e2e:	83 ec 04             	sub    $0x4,%esp
            (char*)PGROUNDDOWN(fault_addr),
80105e31:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
        memset(mem, 0, PGSIZE);
80105e37:	68 00 10 00 00       	push   $0x1000
80105e3c:	6a 00                	push   $0x0
80105e3e:	50                   	push   %eax
80105e3f:	e8 ac e9 ff ff       	call   801047f0 <memset>
        if(mappages(myproc()->pgdir,
80105e44:	e8 a7 db ff ff       	call   801039f0 <myproc>
80105e49:	8d 96 00 00 00 80    	lea    -0x80000000(%esi),%edx
80105e4f:	c7 04 24 06 00 00 00 	movl   $0x6,(%esp)
80105e56:	52                   	push   %edx
80105e57:	68 00 10 00 00       	push   $0x1000
80105e5c:	53                   	push   %ebx
80105e5d:	ff 70 04             	push   0x4(%eax)
80105e60:	e8 fb 0d 00 00       	call   80106c60 <mappages>
80105e65:	83 c4 20             	add    $0x20,%esp
80105e68:	85 c0                	test   %eax,%eax
80105e6a:	78 54                	js     80105ec0 <trap+0x2c0>
  	  myproc()->faults++;
80105e6c:	e8 7f db ff ff       	call   801039f0 <myproc>
80105e71:	83 40 7c 01          	addl   $0x1,0x7c(%eax)
    if(myproc()->killed)
80105e75:	e9 f2 fe ff ff       	jmp    80105d6c <trap+0x16c>
80105e7a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  if(myproc() && myproc()->state == RUNNING &&
80105e80:	83 7b 30 20          	cmpl   $0x20,0x30(%ebx)
80105e84:	0f 85 e1 fd ff ff    	jne    80105c6b <trap+0x6b>
    yield();
80105e8a:	e8 11 e2 ff ff       	call   801040a0 <yield>
80105e8f:	e9 d7 fd ff ff       	jmp    80105c6b <trap+0x6b>
80105e94:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(myproc()->killed)
80105e98:	e8 53 db ff ff       	call   801039f0 <myproc>
80105e9d:	8b 70 24             	mov    0x24(%eax),%esi
80105ea0:	85 f6                	test   %esi,%esi
80105ea2:	75 3c                	jne    80105ee0 <trap+0x2e0>
    myproc()->tf = tf;
80105ea4:	e8 47 db ff ff       	call   801039f0 <myproc>
80105ea9:	89 58 18             	mov    %ebx,0x18(%eax)
    syscall();
80105eac:	e8 2f ed ff ff       	call   80104be0 <syscall>
80105eb1:	e9 b6 fe ff ff       	jmp    80105d6c <trap+0x16c>
80105eb6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105ebd:	00 
80105ebe:	66 90                	xchg   %ax,%ax
  		kfree(mem);
80105ec0:	83 ec 0c             	sub    $0xc,%esp
80105ec3:	56                   	push   %esi
80105ec4:	e8 d7 c5 ff ff       	call   801024a0 <kfree>
  		myproc()->killed = 1;
80105ec9:	e8 22 db ff ff       	call   801039f0 <myproc>
80105ece:	83 c4 10             	add    $0x10,%esp
80105ed1:	c7 40 24 01 00 00 00 	movl   $0x1,0x24(%eax)
80105ed8:	e9 8f fe ff ff       	jmp    80105d6c <trap+0x16c>
80105edd:	8d 76 00             	lea    0x0(%esi),%esi
      exit();
80105ee0:	e8 5b df ff ff       	call   80103e40 <exit>
80105ee5:	eb bd                	jmp    80105ea4 <trap+0x2a4>
80105ee7:	0f 20 d6             	mov    %cr2,%esi
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
80105eea:	e8 e1 da ff ff       	call   801039d0 <cpuid>
80105eef:	83 ec 0c             	sub    $0xc,%esp
80105ef2:	56                   	push   %esi
80105ef3:	57                   	push   %edi
80105ef4:	50                   	push   %eax
80105ef5:	ff 73 30             	push   0x30(%ebx)
80105ef8:	68 54 7e 10 80       	push   $0x80107e54
80105efd:	e8 ae a7 ff ff       	call   801006b0 <cprintf>
      panic("trap");
80105f02:	83 c4 14             	add    $0x14,%esp
80105f05:	68 28 7c 10 80       	push   $0x80107c28
80105f0a:	e8 71 a4 ff ff       	call   80100380 <panic>
      panic("page fault in kernel");
80105f0f:	83 ec 0c             	sub    $0xc,%esp
80105f12:	68 13 7c 10 80       	push   $0x80107c13
80105f17:	e8 64 a4 ff ff       	call   80100380 <panic>
80105f1c:	66 90                	xchg   %ax,%ax
80105f1e:	66 90                	xchg   %ax,%ax

80105f20 <uartgetc>:
}

static int
uartgetc(void)
{
  if(!uart)
80105f20:	a1 e0 57 11 80       	mov    0x801157e0,%eax
80105f25:	85 c0                	test   %eax,%eax
80105f27:	74 17                	je     80105f40 <uartgetc+0x20>
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80105f29:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105f2e:	ec                   	in     (%dx),%al
    return -1;
  if(!(inb(COM1+5) & 0x01))
80105f2f:	a8 01                	test   $0x1,%al
80105f31:	74 0d                	je     80105f40 <uartgetc+0x20>
80105f33:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105f38:	ec                   	in     (%dx),%al
    return -1;
  return inb(COM1+0);
80105f39:	0f b6 c0             	movzbl %al,%eax
80105f3c:	c3                   	ret
80105f3d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
80105f40:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80105f45:	c3                   	ret
80105f46:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80105f4d:	00 
80105f4e:	66 90                	xchg   %ax,%ax

80105f50 <uartinit>:
{
80105f50:	55                   	push   %ebp
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80105f51:	31 c9                	xor    %ecx,%ecx
80105f53:	89 c8                	mov    %ecx,%eax
80105f55:	89 e5                	mov    %esp,%ebp
80105f57:	57                   	push   %edi
80105f58:	bf fa 03 00 00       	mov    $0x3fa,%edi
80105f5d:	56                   	push   %esi
80105f5e:	89 fa                	mov    %edi,%edx
80105f60:	53                   	push   %ebx
80105f61:	83 ec 1c             	sub    $0x1c,%esp
80105f64:	ee                   	out    %al,(%dx)
80105f65:	be fb 03 00 00       	mov    $0x3fb,%esi
80105f6a:	b8 80 ff ff ff       	mov    $0xffffff80,%eax
80105f6f:	89 f2                	mov    %esi,%edx
80105f71:	ee                   	out    %al,(%dx)
80105f72:	b8 0c 00 00 00       	mov    $0xc,%eax
80105f77:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105f7c:	ee                   	out    %al,(%dx)
80105f7d:	bb f9 03 00 00       	mov    $0x3f9,%ebx
80105f82:	89 c8                	mov    %ecx,%eax
80105f84:	89 da                	mov    %ebx,%edx
80105f86:	ee                   	out    %al,(%dx)
80105f87:	b8 03 00 00 00       	mov    $0x3,%eax
80105f8c:	89 f2                	mov    %esi,%edx
80105f8e:	ee                   	out    %al,(%dx)
80105f8f:	ba fc 03 00 00       	mov    $0x3fc,%edx
80105f94:	89 c8                	mov    %ecx,%eax
80105f96:	ee                   	out    %al,(%dx)
80105f97:	b8 01 00 00 00       	mov    $0x1,%eax
80105f9c:	89 da                	mov    %ebx,%edx
80105f9e:	ee                   	out    %al,(%dx)
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
80105f9f:	ba fd 03 00 00       	mov    $0x3fd,%edx
80105fa4:	ec                   	in     (%dx),%al
  if(inb(COM1+5) == 0xFF)
80105fa5:	3c ff                	cmp    $0xff,%al
80105fa7:	0f 84 7c 00 00 00    	je     80106029 <uartinit+0xd9>
  uart = 1;
80105fad:	c7 05 e0 57 11 80 01 	movl   $0x1,0x801157e0
80105fb4:	00 00 00 
80105fb7:	89 fa                	mov    %edi,%edx
80105fb9:	ec                   	in     (%dx),%al
80105fba:	ba f8 03 00 00       	mov    $0x3f8,%edx
80105fbf:	ec                   	in     (%dx),%al
  ioapicenable(IRQ_COM1, 0);
80105fc0:	83 ec 08             	sub    $0x8,%esp
  for(p="xv6...\n"; *p; p++)
80105fc3:	bf 2d 7c 10 80       	mov    $0x80107c2d,%edi
80105fc8:	be fd 03 00 00       	mov    $0x3fd,%esi
  ioapicenable(IRQ_COM1, 0);
80105fcd:	6a 00                	push   $0x0
80105fcf:	6a 04                	push   $0x4
80105fd1:	e8 8a c4 ff ff       	call   80102460 <ioapicenable>
80105fd6:	83 c4 10             	add    $0x10,%esp
  for(p="xv6...\n"; *p; p++)
80105fd9:	c6 45 e7 78          	movb   $0x78,-0x19(%ebp)
80105fdd:	8d 76 00             	lea    0x0(%esi),%esi
  if(!uart)
80105fe0:	a1 e0 57 11 80       	mov    0x801157e0,%eax
80105fe5:	85 c0                	test   %eax,%eax
80105fe7:	74 32                	je     8010601b <uartinit+0xcb>
80105fe9:	89 f2                	mov    %esi,%edx
80105feb:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80105fec:	a8 20                	test   $0x20,%al
80105fee:	75 21                	jne    80106011 <uartinit+0xc1>
80105ff0:	bb 80 00 00 00       	mov    $0x80,%ebx
80105ff5:	8d 76 00             	lea    0x0(%esi),%esi
    microdelay(10);
80105ff8:	83 ec 0c             	sub    $0xc,%esp
80105ffb:	6a 0a                	push   $0xa
80105ffd:	e8 7e c9 ff ff       	call   80102980 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106002:	83 c4 10             	add    $0x10,%esp
80106005:	83 eb 01             	sub    $0x1,%ebx
80106008:	74 07                	je     80106011 <uartinit+0xc1>
8010600a:	89 f2                	mov    %esi,%edx
8010600c:	ec                   	in     (%dx),%al
8010600d:	a8 20                	test   $0x20,%al
8010600f:	74 e7                	je     80105ff8 <uartinit+0xa8>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106011:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106016:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
8010601a:	ee                   	out    %al,(%dx)
  for(p="xv6...\n"; *p; p++)
8010601b:	0f b6 47 01          	movzbl 0x1(%edi),%eax
8010601f:	83 c7 01             	add    $0x1,%edi
80106022:	88 45 e7             	mov    %al,-0x19(%ebp)
80106025:	84 c0                	test   %al,%al
80106027:	75 b7                	jne    80105fe0 <uartinit+0x90>
}
80106029:	8d 65 f4             	lea    -0xc(%ebp),%esp
8010602c:	5b                   	pop    %ebx
8010602d:	5e                   	pop    %esi
8010602e:	5f                   	pop    %edi
8010602f:	5d                   	pop    %ebp
80106030:	c3                   	ret
80106031:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106038:	00 
80106039:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

80106040 <uartputc>:
  if(!uart)
80106040:	a1 e0 57 11 80       	mov    0x801157e0,%eax
80106045:	85 c0                	test   %eax,%eax
80106047:	74 4f                	je     80106098 <uartputc+0x58>
{
80106049:	55                   	push   %ebp
  asm volatile("in %1,%0" : "=a" (data) : "d" (port));
8010604a:	ba fd 03 00 00       	mov    $0x3fd,%edx
8010604f:	89 e5                	mov    %esp,%ebp
80106051:	56                   	push   %esi
80106052:	53                   	push   %ebx
80106053:	ec                   	in     (%dx),%al
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106054:	a8 20                	test   $0x20,%al
80106056:	75 29                	jne    80106081 <uartputc+0x41>
80106058:	bb 80 00 00 00       	mov    $0x80,%ebx
8010605d:	be fd 03 00 00       	mov    $0x3fd,%esi
80106062:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    microdelay(10);
80106068:	83 ec 0c             	sub    $0xc,%esp
8010606b:	6a 0a                	push   $0xa
8010606d:	e8 0e c9 ff ff       	call   80102980 <microdelay>
  for(i = 0; i < 128 && !(inb(COM1+5) & 0x20); i++)
80106072:	83 c4 10             	add    $0x10,%esp
80106075:	83 eb 01             	sub    $0x1,%ebx
80106078:	74 07                	je     80106081 <uartputc+0x41>
8010607a:	89 f2                	mov    %esi,%edx
8010607c:	ec                   	in     (%dx),%al
8010607d:	a8 20                	test   $0x20,%al
8010607f:	74 e7                	je     80106068 <uartputc+0x28>
  asm volatile("out %0,%1" : : "a" (data), "d" (port));
80106081:	8b 45 08             	mov    0x8(%ebp),%eax
80106084:	ba f8 03 00 00       	mov    $0x3f8,%edx
80106089:	ee                   	out    %al,(%dx)
}
8010608a:	8d 65 f8             	lea    -0x8(%ebp),%esp
8010608d:	5b                   	pop    %ebx
8010608e:	5e                   	pop    %esi
8010608f:	5d                   	pop    %ebp
80106090:	c3                   	ret
80106091:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
80106098:	c3                   	ret
80106099:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

801060a0 <uartintr>:

void
uartintr(void)
{
801060a0:	55                   	push   %ebp
801060a1:	89 e5                	mov    %esp,%ebp
801060a3:	83 ec 14             	sub    $0x14,%esp
  consoleintr(uartgetc);
801060a6:	68 20 5f 10 80       	push   $0x80105f20
801060ab:	e8 f0 a7 ff ff       	call   801008a0 <consoleintr>
}
801060b0:	83 c4 10             	add    $0x10,%esp
801060b3:	c9                   	leave
801060b4:	c3                   	ret

801060b5 <vector0>:
# generated by vectors.pl - do not edit
# handlers
.globl alltraps
.globl vector0
vector0:
  pushl $0
801060b5:	6a 00                	push   $0x0
  pushl $0
801060b7:	6a 00                	push   $0x0
  jmp alltraps
801060b9:	e9 61 fa ff ff       	jmp    80105b1f <alltraps>

801060be <vector1>:
.globl vector1
vector1:
  pushl $0
801060be:	6a 00                	push   $0x0
  pushl $1
801060c0:	6a 01                	push   $0x1
  jmp alltraps
801060c2:	e9 58 fa ff ff       	jmp    80105b1f <alltraps>

801060c7 <vector2>:
.globl vector2
vector2:
  pushl $0
801060c7:	6a 00                	push   $0x0
  pushl $2
801060c9:	6a 02                	push   $0x2
  jmp alltraps
801060cb:	e9 4f fa ff ff       	jmp    80105b1f <alltraps>

801060d0 <vector3>:
.globl vector3
vector3:
  pushl $0
801060d0:	6a 00                	push   $0x0
  pushl $3
801060d2:	6a 03                	push   $0x3
  jmp alltraps
801060d4:	e9 46 fa ff ff       	jmp    80105b1f <alltraps>

801060d9 <vector4>:
.globl vector4
vector4:
  pushl $0
801060d9:	6a 00                	push   $0x0
  pushl $4
801060db:	6a 04                	push   $0x4
  jmp alltraps
801060dd:	e9 3d fa ff ff       	jmp    80105b1f <alltraps>

801060e2 <vector5>:
.globl vector5
vector5:
  pushl $0
801060e2:	6a 00                	push   $0x0
  pushl $5
801060e4:	6a 05                	push   $0x5
  jmp alltraps
801060e6:	e9 34 fa ff ff       	jmp    80105b1f <alltraps>

801060eb <vector6>:
.globl vector6
vector6:
  pushl $0
801060eb:	6a 00                	push   $0x0
  pushl $6
801060ed:	6a 06                	push   $0x6
  jmp alltraps
801060ef:	e9 2b fa ff ff       	jmp    80105b1f <alltraps>

801060f4 <vector7>:
.globl vector7
vector7:
  pushl $0
801060f4:	6a 00                	push   $0x0
  pushl $7
801060f6:	6a 07                	push   $0x7
  jmp alltraps
801060f8:	e9 22 fa ff ff       	jmp    80105b1f <alltraps>

801060fd <vector8>:
.globl vector8
vector8:
  pushl $8
801060fd:	6a 08                	push   $0x8
  jmp alltraps
801060ff:	e9 1b fa ff ff       	jmp    80105b1f <alltraps>

80106104 <vector9>:
.globl vector9
vector9:
  pushl $0
80106104:	6a 00                	push   $0x0
  pushl $9
80106106:	6a 09                	push   $0x9
  jmp alltraps
80106108:	e9 12 fa ff ff       	jmp    80105b1f <alltraps>

8010610d <vector10>:
.globl vector10
vector10:
  pushl $10
8010610d:	6a 0a                	push   $0xa
  jmp alltraps
8010610f:	e9 0b fa ff ff       	jmp    80105b1f <alltraps>

80106114 <vector11>:
.globl vector11
vector11:
  pushl $11
80106114:	6a 0b                	push   $0xb
  jmp alltraps
80106116:	e9 04 fa ff ff       	jmp    80105b1f <alltraps>

8010611b <vector12>:
.globl vector12
vector12:
  pushl $12
8010611b:	6a 0c                	push   $0xc
  jmp alltraps
8010611d:	e9 fd f9 ff ff       	jmp    80105b1f <alltraps>

80106122 <vector13>:
.globl vector13
vector13:
  pushl $13
80106122:	6a 0d                	push   $0xd
  jmp alltraps
80106124:	e9 f6 f9 ff ff       	jmp    80105b1f <alltraps>

80106129 <vector14>:
.globl vector14
vector14:
  pushl $14
80106129:	6a 0e                	push   $0xe
  jmp alltraps
8010612b:	e9 ef f9 ff ff       	jmp    80105b1f <alltraps>

80106130 <vector15>:
.globl vector15
vector15:
  pushl $0
80106130:	6a 00                	push   $0x0
  pushl $15
80106132:	6a 0f                	push   $0xf
  jmp alltraps
80106134:	e9 e6 f9 ff ff       	jmp    80105b1f <alltraps>

80106139 <vector16>:
.globl vector16
vector16:
  pushl $0
80106139:	6a 00                	push   $0x0
  pushl $16
8010613b:	6a 10                	push   $0x10
  jmp alltraps
8010613d:	e9 dd f9 ff ff       	jmp    80105b1f <alltraps>

80106142 <vector17>:
.globl vector17
vector17:
  pushl $17
80106142:	6a 11                	push   $0x11
  jmp alltraps
80106144:	e9 d6 f9 ff ff       	jmp    80105b1f <alltraps>

80106149 <vector18>:
.globl vector18
vector18:
  pushl $0
80106149:	6a 00                	push   $0x0
  pushl $18
8010614b:	6a 12                	push   $0x12
  jmp alltraps
8010614d:	e9 cd f9 ff ff       	jmp    80105b1f <alltraps>

80106152 <vector19>:
.globl vector19
vector19:
  pushl $0
80106152:	6a 00                	push   $0x0
  pushl $19
80106154:	6a 13                	push   $0x13
  jmp alltraps
80106156:	e9 c4 f9 ff ff       	jmp    80105b1f <alltraps>

8010615b <vector20>:
.globl vector20
vector20:
  pushl $0
8010615b:	6a 00                	push   $0x0
  pushl $20
8010615d:	6a 14                	push   $0x14
  jmp alltraps
8010615f:	e9 bb f9 ff ff       	jmp    80105b1f <alltraps>

80106164 <vector21>:
.globl vector21
vector21:
  pushl $0
80106164:	6a 00                	push   $0x0
  pushl $21
80106166:	6a 15                	push   $0x15
  jmp alltraps
80106168:	e9 b2 f9 ff ff       	jmp    80105b1f <alltraps>

8010616d <vector22>:
.globl vector22
vector22:
  pushl $0
8010616d:	6a 00                	push   $0x0
  pushl $22
8010616f:	6a 16                	push   $0x16
  jmp alltraps
80106171:	e9 a9 f9 ff ff       	jmp    80105b1f <alltraps>

80106176 <vector23>:
.globl vector23
vector23:
  pushl $0
80106176:	6a 00                	push   $0x0
  pushl $23
80106178:	6a 17                	push   $0x17
  jmp alltraps
8010617a:	e9 a0 f9 ff ff       	jmp    80105b1f <alltraps>

8010617f <vector24>:
.globl vector24
vector24:
  pushl $0
8010617f:	6a 00                	push   $0x0
  pushl $24
80106181:	6a 18                	push   $0x18
  jmp alltraps
80106183:	e9 97 f9 ff ff       	jmp    80105b1f <alltraps>

80106188 <vector25>:
.globl vector25
vector25:
  pushl $0
80106188:	6a 00                	push   $0x0
  pushl $25
8010618a:	6a 19                	push   $0x19
  jmp alltraps
8010618c:	e9 8e f9 ff ff       	jmp    80105b1f <alltraps>

80106191 <vector26>:
.globl vector26
vector26:
  pushl $0
80106191:	6a 00                	push   $0x0
  pushl $26
80106193:	6a 1a                	push   $0x1a
  jmp alltraps
80106195:	e9 85 f9 ff ff       	jmp    80105b1f <alltraps>

8010619a <vector27>:
.globl vector27
vector27:
  pushl $0
8010619a:	6a 00                	push   $0x0
  pushl $27
8010619c:	6a 1b                	push   $0x1b
  jmp alltraps
8010619e:	e9 7c f9 ff ff       	jmp    80105b1f <alltraps>

801061a3 <vector28>:
.globl vector28
vector28:
  pushl $0
801061a3:	6a 00                	push   $0x0
  pushl $28
801061a5:	6a 1c                	push   $0x1c
  jmp alltraps
801061a7:	e9 73 f9 ff ff       	jmp    80105b1f <alltraps>

801061ac <vector29>:
.globl vector29
vector29:
  pushl $0
801061ac:	6a 00                	push   $0x0
  pushl $29
801061ae:	6a 1d                	push   $0x1d
  jmp alltraps
801061b0:	e9 6a f9 ff ff       	jmp    80105b1f <alltraps>

801061b5 <vector30>:
.globl vector30
vector30:
  pushl $0
801061b5:	6a 00                	push   $0x0
  pushl $30
801061b7:	6a 1e                	push   $0x1e
  jmp alltraps
801061b9:	e9 61 f9 ff ff       	jmp    80105b1f <alltraps>

801061be <vector31>:
.globl vector31
vector31:
  pushl $0
801061be:	6a 00                	push   $0x0
  pushl $31
801061c0:	6a 1f                	push   $0x1f
  jmp alltraps
801061c2:	e9 58 f9 ff ff       	jmp    80105b1f <alltraps>

801061c7 <vector32>:
.globl vector32
vector32:
  pushl $0
801061c7:	6a 00                	push   $0x0
  pushl $32
801061c9:	6a 20                	push   $0x20
  jmp alltraps
801061cb:	e9 4f f9 ff ff       	jmp    80105b1f <alltraps>

801061d0 <vector33>:
.globl vector33
vector33:
  pushl $0
801061d0:	6a 00                	push   $0x0
  pushl $33
801061d2:	6a 21                	push   $0x21
  jmp alltraps
801061d4:	e9 46 f9 ff ff       	jmp    80105b1f <alltraps>

801061d9 <vector34>:
.globl vector34
vector34:
  pushl $0
801061d9:	6a 00                	push   $0x0
  pushl $34
801061db:	6a 22                	push   $0x22
  jmp alltraps
801061dd:	e9 3d f9 ff ff       	jmp    80105b1f <alltraps>

801061e2 <vector35>:
.globl vector35
vector35:
  pushl $0
801061e2:	6a 00                	push   $0x0
  pushl $35
801061e4:	6a 23                	push   $0x23
  jmp alltraps
801061e6:	e9 34 f9 ff ff       	jmp    80105b1f <alltraps>

801061eb <vector36>:
.globl vector36
vector36:
  pushl $0
801061eb:	6a 00                	push   $0x0
  pushl $36
801061ed:	6a 24                	push   $0x24
  jmp alltraps
801061ef:	e9 2b f9 ff ff       	jmp    80105b1f <alltraps>

801061f4 <vector37>:
.globl vector37
vector37:
  pushl $0
801061f4:	6a 00                	push   $0x0
  pushl $37
801061f6:	6a 25                	push   $0x25
  jmp alltraps
801061f8:	e9 22 f9 ff ff       	jmp    80105b1f <alltraps>

801061fd <vector38>:
.globl vector38
vector38:
  pushl $0
801061fd:	6a 00                	push   $0x0
  pushl $38
801061ff:	6a 26                	push   $0x26
  jmp alltraps
80106201:	e9 19 f9 ff ff       	jmp    80105b1f <alltraps>

80106206 <vector39>:
.globl vector39
vector39:
  pushl $0
80106206:	6a 00                	push   $0x0
  pushl $39
80106208:	6a 27                	push   $0x27
  jmp alltraps
8010620a:	e9 10 f9 ff ff       	jmp    80105b1f <alltraps>

8010620f <vector40>:
.globl vector40
vector40:
  pushl $0
8010620f:	6a 00                	push   $0x0
  pushl $40
80106211:	6a 28                	push   $0x28
  jmp alltraps
80106213:	e9 07 f9 ff ff       	jmp    80105b1f <alltraps>

80106218 <vector41>:
.globl vector41
vector41:
  pushl $0
80106218:	6a 00                	push   $0x0
  pushl $41
8010621a:	6a 29                	push   $0x29
  jmp alltraps
8010621c:	e9 fe f8 ff ff       	jmp    80105b1f <alltraps>

80106221 <vector42>:
.globl vector42
vector42:
  pushl $0
80106221:	6a 00                	push   $0x0
  pushl $42
80106223:	6a 2a                	push   $0x2a
  jmp alltraps
80106225:	e9 f5 f8 ff ff       	jmp    80105b1f <alltraps>

8010622a <vector43>:
.globl vector43
vector43:
  pushl $0
8010622a:	6a 00                	push   $0x0
  pushl $43
8010622c:	6a 2b                	push   $0x2b
  jmp alltraps
8010622e:	e9 ec f8 ff ff       	jmp    80105b1f <alltraps>

80106233 <vector44>:
.globl vector44
vector44:
  pushl $0
80106233:	6a 00                	push   $0x0
  pushl $44
80106235:	6a 2c                	push   $0x2c
  jmp alltraps
80106237:	e9 e3 f8 ff ff       	jmp    80105b1f <alltraps>

8010623c <vector45>:
.globl vector45
vector45:
  pushl $0
8010623c:	6a 00                	push   $0x0
  pushl $45
8010623e:	6a 2d                	push   $0x2d
  jmp alltraps
80106240:	e9 da f8 ff ff       	jmp    80105b1f <alltraps>

80106245 <vector46>:
.globl vector46
vector46:
  pushl $0
80106245:	6a 00                	push   $0x0
  pushl $46
80106247:	6a 2e                	push   $0x2e
  jmp alltraps
80106249:	e9 d1 f8 ff ff       	jmp    80105b1f <alltraps>

8010624e <vector47>:
.globl vector47
vector47:
  pushl $0
8010624e:	6a 00                	push   $0x0
  pushl $47
80106250:	6a 2f                	push   $0x2f
  jmp alltraps
80106252:	e9 c8 f8 ff ff       	jmp    80105b1f <alltraps>

80106257 <vector48>:
.globl vector48
vector48:
  pushl $0
80106257:	6a 00                	push   $0x0
  pushl $48
80106259:	6a 30                	push   $0x30
  jmp alltraps
8010625b:	e9 bf f8 ff ff       	jmp    80105b1f <alltraps>

80106260 <vector49>:
.globl vector49
vector49:
  pushl $0
80106260:	6a 00                	push   $0x0
  pushl $49
80106262:	6a 31                	push   $0x31
  jmp alltraps
80106264:	e9 b6 f8 ff ff       	jmp    80105b1f <alltraps>

80106269 <vector50>:
.globl vector50
vector50:
  pushl $0
80106269:	6a 00                	push   $0x0
  pushl $50
8010626b:	6a 32                	push   $0x32
  jmp alltraps
8010626d:	e9 ad f8 ff ff       	jmp    80105b1f <alltraps>

80106272 <vector51>:
.globl vector51
vector51:
  pushl $0
80106272:	6a 00                	push   $0x0
  pushl $51
80106274:	6a 33                	push   $0x33
  jmp alltraps
80106276:	e9 a4 f8 ff ff       	jmp    80105b1f <alltraps>

8010627b <vector52>:
.globl vector52
vector52:
  pushl $0
8010627b:	6a 00                	push   $0x0
  pushl $52
8010627d:	6a 34                	push   $0x34
  jmp alltraps
8010627f:	e9 9b f8 ff ff       	jmp    80105b1f <alltraps>

80106284 <vector53>:
.globl vector53
vector53:
  pushl $0
80106284:	6a 00                	push   $0x0
  pushl $53
80106286:	6a 35                	push   $0x35
  jmp alltraps
80106288:	e9 92 f8 ff ff       	jmp    80105b1f <alltraps>

8010628d <vector54>:
.globl vector54
vector54:
  pushl $0
8010628d:	6a 00                	push   $0x0
  pushl $54
8010628f:	6a 36                	push   $0x36
  jmp alltraps
80106291:	e9 89 f8 ff ff       	jmp    80105b1f <alltraps>

80106296 <vector55>:
.globl vector55
vector55:
  pushl $0
80106296:	6a 00                	push   $0x0
  pushl $55
80106298:	6a 37                	push   $0x37
  jmp alltraps
8010629a:	e9 80 f8 ff ff       	jmp    80105b1f <alltraps>

8010629f <vector56>:
.globl vector56
vector56:
  pushl $0
8010629f:	6a 00                	push   $0x0
  pushl $56
801062a1:	6a 38                	push   $0x38
  jmp alltraps
801062a3:	e9 77 f8 ff ff       	jmp    80105b1f <alltraps>

801062a8 <vector57>:
.globl vector57
vector57:
  pushl $0
801062a8:	6a 00                	push   $0x0
  pushl $57
801062aa:	6a 39                	push   $0x39
  jmp alltraps
801062ac:	e9 6e f8 ff ff       	jmp    80105b1f <alltraps>

801062b1 <vector58>:
.globl vector58
vector58:
  pushl $0
801062b1:	6a 00                	push   $0x0
  pushl $58
801062b3:	6a 3a                	push   $0x3a
  jmp alltraps
801062b5:	e9 65 f8 ff ff       	jmp    80105b1f <alltraps>

801062ba <vector59>:
.globl vector59
vector59:
  pushl $0
801062ba:	6a 00                	push   $0x0
  pushl $59
801062bc:	6a 3b                	push   $0x3b
  jmp alltraps
801062be:	e9 5c f8 ff ff       	jmp    80105b1f <alltraps>

801062c3 <vector60>:
.globl vector60
vector60:
  pushl $0
801062c3:	6a 00                	push   $0x0
  pushl $60
801062c5:	6a 3c                	push   $0x3c
  jmp alltraps
801062c7:	e9 53 f8 ff ff       	jmp    80105b1f <alltraps>

801062cc <vector61>:
.globl vector61
vector61:
  pushl $0
801062cc:	6a 00                	push   $0x0
  pushl $61
801062ce:	6a 3d                	push   $0x3d
  jmp alltraps
801062d0:	e9 4a f8 ff ff       	jmp    80105b1f <alltraps>

801062d5 <vector62>:
.globl vector62
vector62:
  pushl $0
801062d5:	6a 00                	push   $0x0
  pushl $62
801062d7:	6a 3e                	push   $0x3e
  jmp alltraps
801062d9:	e9 41 f8 ff ff       	jmp    80105b1f <alltraps>

801062de <vector63>:
.globl vector63
vector63:
  pushl $0
801062de:	6a 00                	push   $0x0
  pushl $63
801062e0:	6a 3f                	push   $0x3f
  jmp alltraps
801062e2:	e9 38 f8 ff ff       	jmp    80105b1f <alltraps>

801062e7 <vector64>:
.globl vector64
vector64:
  pushl $0
801062e7:	6a 00                	push   $0x0
  pushl $64
801062e9:	6a 40                	push   $0x40
  jmp alltraps
801062eb:	e9 2f f8 ff ff       	jmp    80105b1f <alltraps>

801062f0 <vector65>:
.globl vector65
vector65:
  pushl $0
801062f0:	6a 00                	push   $0x0
  pushl $65
801062f2:	6a 41                	push   $0x41
  jmp alltraps
801062f4:	e9 26 f8 ff ff       	jmp    80105b1f <alltraps>

801062f9 <vector66>:
.globl vector66
vector66:
  pushl $0
801062f9:	6a 00                	push   $0x0
  pushl $66
801062fb:	6a 42                	push   $0x42
  jmp alltraps
801062fd:	e9 1d f8 ff ff       	jmp    80105b1f <alltraps>

80106302 <vector67>:
.globl vector67
vector67:
  pushl $0
80106302:	6a 00                	push   $0x0
  pushl $67
80106304:	6a 43                	push   $0x43
  jmp alltraps
80106306:	e9 14 f8 ff ff       	jmp    80105b1f <alltraps>

8010630b <vector68>:
.globl vector68
vector68:
  pushl $0
8010630b:	6a 00                	push   $0x0
  pushl $68
8010630d:	6a 44                	push   $0x44
  jmp alltraps
8010630f:	e9 0b f8 ff ff       	jmp    80105b1f <alltraps>

80106314 <vector69>:
.globl vector69
vector69:
  pushl $0
80106314:	6a 00                	push   $0x0
  pushl $69
80106316:	6a 45                	push   $0x45
  jmp alltraps
80106318:	e9 02 f8 ff ff       	jmp    80105b1f <alltraps>

8010631d <vector70>:
.globl vector70
vector70:
  pushl $0
8010631d:	6a 00                	push   $0x0
  pushl $70
8010631f:	6a 46                	push   $0x46
  jmp alltraps
80106321:	e9 f9 f7 ff ff       	jmp    80105b1f <alltraps>

80106326 <vector71>:
.globl vector71
vector71:
  pushl $0
80106326:	6a 00                	push   $0x0
  pushl $71
80106328:	6a 47                	push   $0x47
  jmp alltraps
8010632a:	e9 f0 f7 ff ff       	jmp    80105b1f <alltraps>

8010632f <vector72>:
.globl vector72
vector72:
  pushl $0
8010632f:	6a 00                	push   $0x0
  pushl $72
80106331:	6a 48                	push   $0x48
  jmp alltraps
80106333:	e9 e7 f7 ff ff       	jmp    80105b1f <alltraps>

80106338 <vector73>:
.globl vector73
vector73:
  pushl $0
80106338:	6a 00                	push   $0x0
  pushl $73
8010633a:	6a 49                	push   $0x49
  jmp alltraps
8010633c:	e9 de f7 ff ff       	jmp    80105b1f <alltraps>

80106341 <vector74>:
.globl vector74
vector74:
  pushl $0
80106341:	6a 00                	push   $0x0
  pushl $74
80106343:	6a 4a                	push   $0x4a
  jmp alltraps
80106345:	e9 d5 f7 ff ff       	jmp    80105b1f <alltraps>

8010634a <vector75>:
.globl vector75
vector75:
  pushl $0
8010634a:	6a 00                	push   $0x0
  pushl $75
8010634c:	6a 4b                	push   $0x4b
  jmp alltraps
8010634e:	e9 cc f7 ff ff       	jmp    80105b1f <alltraps>

80106353 <vector76>:
.globl vector76
vector76:
  pushl $0
80106353:	6a 00                	push   $0x0
  pushl $76
80106355:	6a 4c                	push   $0x4c
  jmp alltraps
80106357:	e9 c3 f7 ff ff       	jmp    80105b1f <alltraps>

8010635c <vector77>:
.globl vector77
vector77:
  pushl $0
8010635c:	6a 00                	push   $0x0
  pushl $77
8010635e:	6a 4d                	push   $0x4d
  jmp alltraps
80106360:	e9 ba f7 ff ff       	jmp    80105b1f <alltraps>

80106365 <vector78>:
.globl vector78
vector78:
  pushl $0
80106365:	6a 00                	push   $0x0
  pushl $78
80106367:	6a 4e                	push   $0x4e
  jmp alltraps
80106369:	e9 b1 f7 ff ff       	jmp    80105b1f <alltraps>

8010636e <vector79>:
.globl vector79
vector79:
  pushl $0
8010636e:	6a 00                	push   $0x0
  pushl $79
80106370:	6a 4f                	push   $0x4f
  jmp alltraps
80106372:	e9 a8 f7 ff ff       	jmp    80105b1f <alltraps>

80106377 <vector80>:
.globl vector80
vector80:
  pushl $0
80106377:	6a 00                	push   $0x0
  pushl $80
80106379:	6a 50                	push   $0x50
  jmp alltraps
8010637b:	e9 9f f7 ff ff       	jmp    80105b1f <alltraps>

80106380 <vector81>:
.globl vector81
vector81:
  pushl $0
80106380:	6a 00                	push   $0x0
  pushl $81
80106382:	6a 51                	push   $0x51
  jmp alltraps
80106384:	e9 96 f7 ff ff       	jmp    80105b1f <alltraps>

80106389 <vector82>:
.globl vector82
vector82:
  pushl $0
80106389:	6a 00                	push   $0x0
  pushl $82
8010638b:	6a 52                	push   $0x52
  jmp alltraps
8010638d:	e9 8d f7 ff ff       	jmp    80105b1f <alltraps>

80106392 <vector83>:
.globl vector83
vector83:
  pushl $0
80106392:	6a 00                	push   $0x0
  pushl $83
80106394:	6a 53                	push   $0x53
  jmp alltraps
80106396:	e9 84 f7 ff ff       	jmp    80105b1f <alltraps>

8010639b <vector84>:
.globl vector84
vector84:
  pushl $0
8010639b:	6a 00                	push   $0x0
  pushl $84
8010639d:	6a 54                	push   $0x54
  jmp alltraps
8010639f:	e9 7b f7 ff ff       	jmp    80105b1f <alltraps>

801063a4 <vector85>:
.globl vector85
vector85:
  pushl $0
801063a4:	6a 00                	push   $0x0
  pushl $85
801063a6:	6a 55                	push   $0x55
  jmp alltraps
801063a8:	e9 72 f7 ff ff       	jmp    80105b1f <alltraps>

801063ad <vector86>:
.globl vector86
vector86:
  pushl $0
801063ad:	6a 00                	push   $0x0
  pushl $86
801063af:	6a 56                	push   $0x56
  jmp alltraps
801063b1:	e9 69 f7 ff ff       	jmp    80105b1f <alltraps>

801063b6 <vector87>:
.globl vector87
vector87:
  pushl $0
801063b6:	6a 00                	push   $0x0
  pushl $87
801063b8:	6a 57                	push   $0x57
  jmp alltraps
801063ba:	e9 60 f7 ff ff       	jmp    80105b1f <alltraps>

801063bf <vector88>:
.globl vector88
vector88:
  pushl $0
801063bf:	6a 00                	push   $0x0
  pushl $88
801063c1:	6a 58                	push   $0x58
  jmp alltraps
801063c3:	e9 57 f7 ff ff       	jmp    80105b1f <alltraps>

801063c8 <vector89>:
.globl vector89
vector89:
  pushl $0
801063c8:	6a 00                	push   $0x0
  pushl $89
801063ca:	6a 59                	push   $0x59
  jmp alltraps
801063cc:	e9 4e f7 ff ff       	jmp    80105b1f <alltraps>

801063d1 <vector90>:
.globl vector90
vector90:
  pushl $0
801063d1:	6a 00                	push   $0x0
  pushl $90
801063d3:	6a 5a                	push   $0x5a
  jmp alltraps
801063d5:	e9 45 f7 ff ff       	jmp    80105b1f <alltraps>

801063da <vector91>:
.globl vector91
vector91:
  pushl $0
801063da:	6a 00                	push   $0x0
  pushl $91
801063dc:	6a 5b                	push   $0x5b
  jmp alltraps
801063de:	e9 3c f7 ff ff       	jmp    80105b1f <alltraps>

801063e3 <vector92>:
.globl vector92
vector92:
  pushl $0
801063e3:	6a 00                	push   $0x0
  pushl $92
801063e5:	6a 5c                	push   $0x5c
  jmp alltraps
801063e7:	e9 33 f7 ff ff       	jmp    80105b1f <alltraps>

801063ec <vector93>:
.globl vector93
vector93:
  pushl $0
801063ec:	6a 00                	push   $0x0
  pushl $93
801063ee:	6a 5d                	push   $0x5d
  jmp alltraps
801063f0:	e9 2a f7 ff ff       	jmp    80105b1f <alltraps>

801063f5 <vector94>:
.globl vector94
vector94:
  pushl $0
801063f5:	6a 00                	push   $0x0
  pushl $94
801063f7:	6a 5e                	push   $0x5e
  jmp alltraps
801063f9:	e9 21 f7 ff ff       	jmp    80105b1f <alltraps>

801063fe <vector95>:
.globl vector95
vector95:
  pushl $0
801063fe:	6a 00                	push   $0x0
  pushl $95
80106400:	6a 5f                	push   $0x5f
  jmp alltraps
80106402:	e9 18 f7 ff ff       	jmp    80105b1f <alltraps>

80106407 <vector96>:
.globl vector96
vector96:
  pushl $0
80106407:	6a 00                	push   $0x0
  pushl $96
80106409:	6a 60                	push   $0x60
  jmp alltraps
8010640b:	e9 0f f7 ff ff       	jmp    80105b1f <alltraps>

80106410 <vector97>:
.globl vector97
vector97:
  pushl $0
80106410:	6a 00                	push   $0x0
  pushl $97
80106412:	6a 61                	push   $0x61
  jmp alltraps
80106414:	e9 06 f7 ff ff       	jmp    80105b1f <alltraps>

80106419 <vector98>:
.globl vector98
vector98:
  pushl $0
80106419:	6a 00                	push   $0x0
  pushl $98
8010641b:	6a 62                	push   $0x62
  jmp alltraps
8010641d:	e9 fd f6 ff ff       	jmp    80105b1f <alltraps>

80106422 <vector99>:
.globl vector99
vector99:
  pushl $0
80106422:	6a 00                	push   $0x0
  pushl $99
80106424:	6a 63                	push   $0x63
  jmp alltraps
80106426:	e9 f4 f6 ff ff       	jmp    80105b1f <alltraps>

8010642b <vector100>:
.globl vector100
vector100:
  pushl $0
8010642b:	6a 00                	push   $0x0
  pushl $100
8010642d:	6a 64                	push   $0x64
  jmp alltraps
8010642f:	e9 eb f6 ff ff       	jmp    80105b1f <alltraps>

80106434 <vector101>:
.globl vector101
vector101:
  pushl $0
80106434:	6a 00                	push   $0x0
  pushl $101
80106436:	6a 65                	push   $0x65
  jmp alltraps
80106438:	e9 e2 f6 ff ff       	jmp    80105b1f <alltraps>

8010643d <vector102>:
.globl vector102
vector102:
  pushl $0
8010643d:	6a 00                	push   $0x0
  pushl $102
8010643f:	6a 66                	push   $0x66
  jmp alltraps
80106441:	e9 d9 f6 ff ff       	jmp    80105b1f <alltraps>

80106446 <vector103>:
.globl vector103
vector103:
  pushl $0
80106446:	6a 00                	push   $0x0
  pushl $103
80106448:	6a 67                	push   $0x67
  jmp alltraps
8010644a:	e9 d0 f6 ff ff       	jmp    80105b1f <alltraps>

8010644f <vector104>:
.globl vector104
vector104:
  pushl $0
8010644f:	6a 00                	push   $0x0
  pushl $104
80106451:	6a 68                	push   $0x68
  jmp alltraps
80106453:	e9 c7 f6 ff ff       	jmp    80105b1f <alltraps>

80106458 <vector105>:
.globl vector105
vector105:
  pushl $0
80106458:	6a 00                	push   $0x0
  pushl $105
8010645a:	6a 69                	push   $0x69
  jmp alltraps
8010645c:	e9 be f6 ff ff       	jmp    80105b1f <alltraps>

80106461 <vector106>:
.globl vector106
vector106:
  pushl $0
80106461:	6a 00                	push   $0x0
  pushl $106
80106463:	6a 6a                	push   $0x6a
  jmp alltraps
80106465:	e9 b5 f6 ff ff       	jmp    80105b1f <alltraps>

8010646a <vector107>:
.globl vector107
vector107:
  pushl $0
8010646a:	6a 00                	push   $0x0
  pushl $107
8010646c:	6a 6b                	push   $0x6b
  jmp alltraps
8010646e:	e9 ac f6 ff ff       	jmp    80105b1f <alltraps>

80106473 <vector108>:
.globl vector108
vector108:
  pushl $0
80106473:	6a 00                	push   $0x0
  pushl $108
80106475:	6a 6c                	push   $0x6c
  jmp alltraps
80106477:	e9 a3 f6 ff ff       	jmp    80105b1f <alltraps>

8010647c <vector109>:
.globl vector109
vector109:
  pushl $0
8010647c:	6a 00                	push   $0x0
  pushl $109
8010647e:	6a 6d                	push   $0x6d
  jmp alltraps
80106480:	e9 9a f6 ff ff       	jmp    80105b1f <alltraps>

80106485 <vector110>:
.globl vector110
vector110:
  pushl $0
80106485:	6a 00                	push   $0x0
  pushl $110
80106487:	6a 6e                	push   $0x6e
  jmp alltraps
80106489:	e9 91 f6 ff ff       	jmp    80105b1f <alltraps>

8010648e <vector111>:
.globl vector111
vector111:
  pushl $0
8010648e:	6a 00                	push   $0x0
  pushl $111
80106490:	6a 6f                	push   $0x6f
  jmp alltraps
80106492:	e9 88 f6 ff ff       	jmp    80105b1f <alltraps>

80106497 <vector112>:
.globl vector112
vector112:
  pushl $0
80106497:	6a 00                	push   $0x0
  pushl $112
80106499:	6a 70                	push   $0x70
  jmp alltraps
8010649b:	e9 7f f6 ff ff       	jmp    80105b1f <alltraps>

801064a0 <vector113>:
.globl vector113
vector113:
  pushl $0
801064a0:	6a 00                	push   $0x0
  pushl $113
801064a2:	6a 71                	push   $0x71
  jmp alltraps
801064a4:	e9 76 f6 ff ff       	jmp    80105b1f <alltraps>

801064a9 <vector114>:
.globl vector114
vector114:
  pushl $0
801064a9:	6a 00                	push   $0x0
  pushl $114
801064ab:	6a 72                	push   $0x72
  jmp alltraps
801064ad:	e9 6d f6 ff ff       	jmp    80105b1f <alltraps>

801064b2 <vector115>:
.globl vector115
vector115:
  pushl $0
801064b2:	6a 00                	push   $0x0
  pushl $115
801064b4:	6a 73                	push   $0x73
  jmp alltraps
801064b6:	e9 64 f6 ff ff       	jmp    80105b1f <alltraps>

801064bb <vector116>:
.globl vector116
vector116:
  pushl $0
801064bb:	6a 00                	push   $0x0
  pushl $116
801064bd:	6a 74                	push   $0x74
  jmp alltraps
801064bf:	e9 5b f6 ff ff       	jmp    80105b1f <alltraps>

801064c4 <vector117>:
.globl vector117
vector117:
  pushl $0
801064c4:	6a 00                	push   $0x0
  pushl $117
801064c6:	6a 75                	push   $0x75
  jmp alltraps
801064c8:	e9 52 f6 ff ff       	jmp    80105b1f <alltraps>

801064cd <vector118>:
.globl vector118
vector118:
  pushl $0
801064cd:	6a 00                	push   $0x0
  pushl $118
801064cf:	6a 76                	push   $0x76
  jmp alltraps
801064d1:	e9 49 f6 ff ff       	jmp    80105b1f <alltraps>

801064d6 <vector119>:
.globl vector119
vector119:
  pushl $0
801064d6:	6a 00                	push   $0x0
  pushl $119
801064d8:	6a 77                	push   $0x77
  jmp alltraps
801064da:	e9 40 f6 ff ff       	jmp    80105b1f <alltraps>

801064df <vector120>:
.globl vector120
vector120:
  pushl $0
801064df:	6a 00                	push   $0x0
  pushl $120
801064e1:	6a 78                	push   $0x78
  jmp alltraps
801064e3:	e9 37 f6 ff ff       	jmp    80105b1f <alltraps>

801064e8 <vector121>:
.globl vector121
vector121:
  pushl $0
801064e8:	6a 00                	push   $0x0
  pushl $121
801064ea:	6a 79                	push   $0x79
  jmp alltraps
801064ec:	e9 2e f6 ff ff       	jmp    80105b1f <alltraps>

801064f1 <vector122>:
.globl vector122
vector122:
  pushl $0
801064f1:	6a 00                	push   $0x0
  pushl $122
801064f3:	6a 7a                	push   $0x7a
  jmp alltraps
801064f5:	e9 25 f6 ff ff       	jmp    80105b1f <alltraps>

801064fa <vector123>:
.globl vector123
vector123:
  pushl $0
801064fa:	6a 00                	push   $0x0
  pushl $123
801064fc:	6a 7b                	push   $0x7b
  jmp alltraps
801064fe:	e9 1c f6 ff ff       	jmp    80105b1f <alltraps>

80106503 <vector124>:
.globl vector124
vector124:
  pushl $0
80106503:	6a 00                	push   $0x0
  pushl $124
80106505:	6a 7c                	push   $0x7c
  jmp alltraps
80106507:	e9 13 f6 ff ff       	jmp    80105b1f <alltraps>

8010650c <vector125>:
.globl vector125
vector125:
  pushl $0
8010650c:	6a 00                	push   $0x0
  pushl $125
8010650e:	6a 7d                	push   $0x7d
  jmp alltraps
80106510:	e9 0a f6 ff ff       	jmp    80105b1f <alltraps>

80106515 <vector126>:
.globl vector126
vector126:
  pushl $0
80106515:	6a 00                	push   $0x0
  pushl $126
80106517:	6a 7e                	push   $0x7e
  jmp alltraps
80106519:	e9 01 f6 ff ff       	jmp    80105b1f <alltraps>

8010651e <vector127>:
.globl vector127
vector127:
  pushl $0
8010651e:	6a 00                	push   $0x0
  pushl $127
80106520:	6a 7f                	push   $0x7f
  jmp alltraps
80106522:	e9 f8 f5 ff ff       	jmp    80105b1f <alltraps>

80106527 <vector128>:
.globl vector128
vector128:
  pushl $0
80106527:	6a 00                	push   $0x0
  pushl $128
80106529:	68 80 00 00 00       	push   $0x80
  jmp alltraps
8010652e:	e9 ec f5 ff ff       	jmp    80105b1f <alltraps>

80106533 <vector129>:
.globl vector129
vector129:
  pushl $0
80106533:	6a 00                	push   $0x0
  pushl $129
80106535:	68 81 00 00 00       	push   $0x81
  jmp alltraps
8010653a:	e9 e0 f5 ff ff       	jmp    80105b1f <alltraps>

8010653f <vector130>:
.globl vector130
vector130:
  pushl $0
8010653f:	6a 00                	push   $0x0
  pushl $130
80106541:	68 82 00 00 00       	push   $0x82
  jmp alltraps
80106546:	e9 d4 f5 ff ff       	jmp    80105b1f <alltraps>

8010654b <vector131>:
.globl vector131
vector131:
  pushl $0
8010654b:	6a 00                	push   $0x0
  pushl $131
8010654d:	68 83 00 00 00       	push   $0x83
  jmp alltraps
80106552:	e9 c8 f5 ff ff       	jmp    80105b1f <alltraps>

80106557 <vector132>:
.globl vector132
vector132:
  pushl $0
80106557:	6a 00                	push   $0x0
  pushl $132
80106559:	68 84 00 00 00       	push   $0x84
  jmp alltraps
8010655e:	e9 bc f5 ff ff       	jmp    80105b1f <alltraps>

80106563 <vector133>:
.globl vector133
vector133:
  pushl $0
80106563:	6a 00                	push   $0x0
  pushl $133
80106565:	68 85 00 00 00       	push   $0x85
  jmp alltraps
8010656a:	e9 b0 f5 ff ff       	jmp    80105b1f <alltraps>

8010656f <vector134>:
.globl vector134
vector134:
  pushl $0
8010656f:	6a 00                	push   $0x0
  pushl $134
80106571:	68 86 00 00 00       	push   $0x86
  jmp alltraps
80106576:	e9 a4 f5 ff ff       	jmp    80105b1f <alltraps>

8010657b <vector135>:
.globl vector135
vector135:
  pushl $0
8010657b:	6a 00                	push   $0x0
  pushl $135
8010657d:	68 87 00 00 00       	push   $0x87
  jmp alltraps
80106582:	e9 98 f5 ff ff       	jmp    80105b1f <alltraps>

80106587 <vector136>:
.globl vector136
vector136:
  pushl $0
80106587:	6a 00                	push   $0x0
  pushl $136
80106589:	68 88 00 00 00       	push   $0x88
  jmp alltraps
8010658e:	e9 8c f5 ff ff       	jmp    80105b1f <alltraps>

80106593 <vector137>:
.globl vector137
vector137:
  pushl $0
80106593:	6a 00                	push   $0x0
  pushl $137
80106595:	68 89 00 00 00       	push   $0x89
  jmp alltraps
8010659a:	e9 80 f5 ff ff       	jmp    80105b1f <alltraps>

8010659f <vector138>:
.globl vector138
vector138:
  pushl $0
8010659f:	6a 00                	push   $0x0
  pushl $138
801065a1:	68 8a 00 00 00       	push   $0x8a
  jmp alltraps
801065a6:	e9 74 f5 ff ff       	jmp    80105b1f <alltraps>

801065ab <vector139>:
.globl vector139
vector139:
  pushl $0
801065ab:	6a 00                	push   $0x0
  pushl $139
801065ad:	68 8b 00 00 00       	push   $0x8b
  jmp alltraps
801065b2:	e9 68 f5 ff ff       	jmp    80105b1f <alltraps>

801065b7 <vector140>:
.globl vector140
vector140:
  pushl $0
801065b7:	6a 00                	push   $0x0
  pushl $140
801065b9:	68 8c 00 00 00       	push   $0x8c
  jmp alltraps
801065be:	e9 5c f5 ff ff       	jmp    80105b1f <alltraps>

801065c3 <vector141>:
.globl vector141
vector141:
  pushl $0
801065c3:	6a 00                	push   $0x0
  pushl $141
801065c5:	68 8d 00 00 00       	push   $0x8d
  jmp alltraps
801065ca:	e9 50 f5 ff ff       	jmp    80105b1f <alltraps>

801065cf <vector142>:
.globl vector142
vector142:
  pushl $0
801065cf:	6a 00                	push   $0x0
  pushl $142
801065d1:	68 8e 00 00 00       	push   $0x8e
  jmp alltraps
801065d6:	e9 44 f5 ff ff       	jmp    80105b1f <alltraps>

801065db <vector143>:
.globl vector143
vector143:
  pushl $0
801065db:	6a 00                	push   $0x0
  pushl $143
801065dd:	68 8f 00 00 00       	push   $0x8f
  jmp alltraps
801065e2:	e9 38 f5 ff ff       	jmp    80105b1f <alltraps>

801065e7 <vector144>:
.globl vector144
vector144:
  pushl $0
801065e7:	6a 00                	push   $0x0
  pushl $144
801065e9:	68 90 00 00 00       	push   $0x90
  jmp alltraps
801065ee:	e9 2c f5 ff ff       	jmp    80105b1f <alltraps>

801065f3 <vector145>:
.globl vector145
vector145:
  pushl $0
801065f3:	6a 00                	push   $0x0
  pushl $145
801065f5:	68 91 00 00 00       	push   $0x91
  jmp alltraps
801065fa:	e9 20 f5 ff ff       	jmp    80105b1f <alltraps>

801065ff <vector146>:
.globl vector146
vector146:
  pushl $0
801065ff:	6a 00                	push   $0x0
  pushl $146
80106601:	68 92 00 00 00       	push   $0x92
  jmp alltraps
80106606:	e9 14 f5 ff ff       	jmp    80105b1f <alltraps>

8010660b <vector147>:
.globl vector147
vector147:
  pushl $0
8010660b:	6a 00                	push   $0x0
  pushl $147
8010660d:	68 93 00 00 00       	push   $0x93
  jmp alltraps
80106612:	e9 08 f5 ff ff       	jmp    80105b1f <alltraps>

80106617 <vector148>:
.globl vector148
vector148:
  pushl $0
80106617:	6a 00                	push   $0x0
  pushl $148
80106619:	68 94 00 00 00       	push   $0x94
  jmp alltraps
8010661e:	e9 fc f4 ff ff       	jmp    80105b1f <alltraps>

80106623 <vector149>:
.globl vector149
vector149:
  pushl $0
80106623:	6a 00                	push   $0x0
  pushl $149
80106625:	68 95 00 00 00       	push   $0x95
  jmp alltraps
8010662a:	e9 f0 f4 ff ff       	jmp    80105b1f <alltraps>

8010662f <vector150>:
.globl vector150
vector150:
  pushl $0
8010662f:	6a 00                	push   $0x0
  pushl $150
80106631:	68 96 00 00 00       	push   $0x96
  jmp alltraps
80106636:	e9 e4 f4 ff ff       	jmp    80105b1f <alltraps>

8010663b <vector151>:
.globl vector151
vector151:
  pushl $0
8010663b:	6a 00                	push   $0x0
  pushl $151
8010663d:	68 97 00 00 00       	push   $0x97
  jmp alltraps
80106642:	e9 d8 f4 ff ff       	jmp    80105b1f <alltraps>

80106647 <vector152>:
.globl vector152
vector152:
  pushl $0
80106647:	6a 00                	push   $0x0
  pushl $152
80106649:	68 98 00 00 00       	push   $0x98
  jmp alltraps
8010664e:	e9 cc f4 ff ff       	jmp    80105b1f <alltraps>

80106653 <vector153>:
.globl vector153
vector153:
  pushl $0
80106653:	6a 00                	push   $0x0
  pushl $153
80106655:	68 99 00 00 00       	push   $0x99
  jmp alltraps
8010665a:	e9 c0 f4 ff ff       	jmp    80105b1f <alltraps>

8010665f <vector154>:
.globl vector154
vector154:
  pushl $0
8010665f:	6a 00                	push   $0x0
  pushl $154
80106661:	68 9a 00 00 00       	push   $0x9a
  jmp alltraps
80106666:	e9 b4 f4 ff ff       	jmp    80105b1f <alltraps>

8010666b <vector155>:
.globl vector155
vector155:
  pushl $0
8010666b:	6a 00                	push   $0x0
  pushl $155
8010666d:	68 9b 00 00 00       	push   $0x9b
  jmp alltraps
80106672:	e9 a8 f4 ff ff       	jmp    80105b1f <alltraps>

80106677 <vector156>:
.globl vector156
vector156:
  pushl $0
80106677:	6a 00                	push   $0x0
  pushl $156
80106679:	68 9c 00 00 00       	push   $0x9c
  jmp alltraps
8010667e:	e9 9c f4 ff ff       	jmp    80105b1f <alltraps>

80106683 <vector157>:
.globl vector157
vector157:
  pushl $0
80106683:	6a 00                	push   $0x0
  pushl $157
80106685:	68 9d 00 00 00       	push   $0x9d
  jmp alltraps
8010668a:	e9 90 f4 ff ff       	jmp    80105b1f <alltraps>

8010668f <vector158>:
.globl vector158
vector158:
  pushl $0
8010668f:	6a 00                	push   $0x0
  pushl $158
80106691:	68 9e 00 00 00       	push   $0x9e
  jmp alltraps
80106696:	e9 84 f4 ff ff       	jmp    80105b1f <alltraps>

8010669b <vector159>:
.globl vector159
vector159:
  pushl $0
8010669b:	6a 00                	push   $0x0
  pushl $159
8010669d:	68 9f 00 00 00       	push   $0x9f
  jmp alltraps
801066a2:	e9 78 f4 ff ff       	jmp    80105b1f <alltraps>

801066a7 <vector160>:
.globl vector160
vector160:
  pushl $0
801066a7:	6a 00                	push   $0x0
  pushl $160
801066a9:	68 a0 00 00 00       	push   $0xa0
  jmp alltraps
801066ae:	e9 6c f4 ff ff       	jmp    80105b1f <alltraps>

801066b3 <vector161>:
.globl vector161
vector161:
  pushl $0
801066b3:	6a 00                	push   $0x0
  pushl $161
801066b5:	68 a1 00 00 00       	push   $0xa1
  jmp alltraps
801066ba:	e9 60 f4 ff ff       	jmp    80105b1f <alltraps>

801066bf <vector162>:
.globl vector162
vector162:
  pushl $0
801066bf:	6a 00                	push   $0x0
  pushl $162
801066c1:	68 a2 00 00 00       	push   $0xa2
  jmp alltraps
801066c6:	e9 54 f4 ff ff       	jmp    80105b1f <alltraps>

801066cb <vector163>:
.globl vector163
vector163:
  pushl $0
801066cb:	6a 00                	push   $0x0
  pushl $163
801066cd:	68 a3 00 00 00       	push   $0xa3
  jmp alltraps
801066d2:	e9 48 f4 ff ff       	jmp    80105b1f <alltraps>

801066d7 <vector164>:
.globl vector164
vector164:
  pushl $0
801066d7:	6a 00                	push   $0x0
  pushl $164
801066d9:	68 a4 00 00 00       	push   $0xa4
  jmp alltraps
801066de:	e9 3c f4 ff ff       	jmp    80105b1f <alltraps>

801066e3 <vector165>:
.globl vector165
vector165:
  pushl $0
801066e3:	6a 00                	push   $0x0
  pushl $165
801066e5:	68 a5 00 00 00       	push   $0xa5
  jmp alltraps
801066ea:	e9 30 f4 ff ff       	jmp    80105b1f <alltraps>

801066ef <vector166>:
.globl vector166
vector166:
  pushl $0
801066ef:	6a 00                	push   $0x0
  pushl $166
801066f1:	68 a6 00 00 00       	push   $0xa6
  jmp alltraps
801066f6:	e9 24 f4 ff ff       	jmp    80105b1f <alltraps>

801066fb <vector167>:
.globl vector167
vector167:
  pushl $0
801066fb:	6a 00                	push   $0x0
  pushl $167
801066fd:	68 a7 00 00 00       	push   $0xa7
  jmp alltraps
80106702:	e9 18 f4 ff ff       	jmp    80105b1f <alltraps>

80106707 <vector168>:
.globl vector168
vector168:
  pushl $0
80106707:	6a 00                	push   $0x0
  pushl $168
80106709:	68 a8 00 00 00       	push   $0xa8
  jmp alltraps
8010670e:	e9 0c f4 ff ff       	jmp    80105b1f <alltraps>

80106713 <vector169>:
.globl vector169
vector169:
  pushl $0
80106713:	6a 00                	push   $0x0
  pushl $169
80106715:	68 a9 00 00 00       	push   $0xa9
  jmp alltraps
8010671a:	e9 00 f4 ff ff       	jmp    80105b1f <alltraps>

8010671f <vector170>:
.globl vector170
vector170:
  pushl $0
8010671f:	6a 00                	push   $0x0
  pushl $170
80106721:	68 aa 00 00 00       	push   $0xaa
  jmp alltraps
80106726:	e9 f4 f3 ff ff       	jmp    80105b1f <alltraps>

8010672b <vector171>:
.globl vector171
vector171:
  pushl $0
8010672b:	6a 00                	push   $0x0
  pushl $171
8010672d:	68 ab 00 00 00       	push   $0xab
  jmp alltraps
80106732:	e9 e8 f3 ff ff       	jmp    80105b1f <alltraps>

80106737 <vector172>:
.globl vector172
vector172:
  pushl $0
80106737:	6a 00                	push   $0x0
  pushl $172
80106739:	68 ac 00 00 00       	push   $0xac
  jmp alltraps
8010673e:	e9 dc f3 ff ff       	jmp    80105b1f <alltraps>

80106743 <vector173>:
.globl vector173
vector173:
  pushl $0
80106743:	6a 00                	push   $0x0
  pushl $173
80106745:	68 ad 00 00 00       	push   $0xad
  jmp alltraps
8010674a:	e9 d0 f3 ff ff       	jmp    80105b1f <alltraps>

8010674f <vector174>:
.globl vector174
vector174:
  pushl $0
8010674f:	6a 00                	push   $0x0
  pushl $174
80106751:	68 ae 00 00 00       	push   $0xae
  jmp alltraps
80106756:	e9 c4 f3 ff ff       	jmp    80105b1f <alltraps>

8010675b <vector175>:
.globl vector175
vector175:
  pushl $0
8010675b:	6a 00                	push   $0x0
  pushl $175
8010675d:	68 af 00 00 00       	push   $0xaf
  jmp alltraps
80106762:	e9 b8 f3 ff ff       	jmp    80105b1f <alltraps>

80106767 <vector176>:
.globl vector176
vector176:
  pushl $0
80106767:	6a 00                	push   $0x0
  pushl $176
80106769:	68 b0 00 00 00       	push   $0xb0
  jmp alltraps
8010676e:	e9 ac f3 ff ff       	jmp    80105b1f <alltraps>

80106773 <vector177>:
.globl vector177
vector177:
  pushl $0
80106773:	6a 00                	push   $0x0
  pushl $177
80106775:	68 b1 00 00 00       	push   $0xb1
  jmp alltraps
8010677a:	e9 a0 f3 ff ff       	jmp    80105b1f <alltraps>

8010677f <vector178>:
.globl vector178
vector178:
  pushl $0
8010677f:	6a 00                	push   $0x0
  pushl $178
80106781:	68 b2 00 00 00       	push   $0xb2
  jmp alltraps
80106786:	e9 94 f3 ff ff       	jmp    80105b1f <alltraps>

8010678b <vector179>:
.globl vector179
vector179:
  pushl $0
8010678b:	6a 00                	push   $0x0
  pushl $179
8010678d:	68 b3 00 00 00       	push   $0xb3
  jmp alltraps
80106792:	e9 88 f3 ff ff       	jmp    80105b1f <alltraps>

80106797 <vector180>:
.globl vector180
vector180:
  pushl $0
80106797:	6a 00                	push   $0x0
  pushl $180
80106799:	68 b4 00 00 00       	push   $0xb4
  jmp alltraps
8010679e:	e9 7c f3 ff ff       	jmp    80105b1f <alltraps>

801067a3 <vector181>:
.globl vector181
vector181:
  pushl $0
801067a3:	6a 00                	push   $0x0
  pushl $181
801067a5:	68 b5 00 00 00       	push   $0xb5
  jmp alltraps
801067aa:	e9 70 f3 ff ff       	jmp    80105b1f <alltraps>

801067af <vector182>:
.globl vector182
vector182:
  pushl $0
801067af:	6a 00                	push   $0x0
  pushl $182
801067b1:	68 b6 00 00 00       	push   $0xb6
  jmp alltraps
801067b6:	e9 64 f3 ff ff       	jmp    80105b1f <alltraps>

801067bb <vector183>:
.globl vector183
vector183:
  pushl $0
801067bb:	6a 00                	push   $0x0
  pushl $183
801067bd:	68 b7 00 00 00       	push   $0xb7
  jmp alltraps
801067c2:	e9 58 f3 ff ff       	jmp    80105b1f <alltraps>

801067c7 <vector184>:
.globl vector184
vector184:
  pushl $0
801067c7:	6a 00                	push   $0x0
  pushl $184
801067c9:	68 b8 00 00 00       	push   $0xb8
  jmp alltraps
801067ce:	e9 4c f3 ff ff       	jmp    80105b1f <alltraps>

801067d3 <vector185>:
.globl vector185
vector185:
  pushl $0
801067d3:	6a 00                	push   $0x0
  pushl $185
801067d5:	68 b9 00 00 00       	push   $0xb9
  jmp alltraps
801067da:	e9 40 f3 ff ff       	jmp    80105b1f <alltraps>

801067df <vector186>:
.globl vector186
vector186:
  pushl $0
801067df:	6a 00                	push   $0x0
  pushl $186
801067e1:	68 ba 00 00 00       	push   $0xba
  jmp alltraps
801067e6:	e9 34 f3 ff ff       	jmp    80105b1f <alltraps>

801067eb <vector187>:
.globl vector187
vector187:
  pushl $0
801067eb:	6a 00                	push   $0x0
  pushl $187
801067ed:	68 bb 00 00 00       	push   $0xbb
  jmp alltraps
801067f2:	e9 28 f3 ff ff       	jmp    80105b1f <alltraps>

801067f7 <vector188>:
.globl vector188
vector188:
  pushl $0
801067f7:	6a 00                	push   $0x0
  pushl $188
801067f9:	68 bc 00 00 00       	push   $0xbc
  jmp alltraps
801067fe:	e9 1c f3 ff ff       	jmp    80105b1f <alltraps>

80106803 <vector189>:
.globl vector189
vector189:
  pushl $0
80106803:	6a 00                	push   $0x0
  pushl $189
80106805:	68 bd 00 00 00       	push   $0xbd
  jmp alltraps
8010680a:	e9 10 f3 ff ff       	jmp    80105b1f <alltraps>

8010680f <vector190>:
.globl vector190
vector190:
  pushl $0
8010680f:	6a 00                	push   $0x0
  pushl $190
80106811:	68 be 00 00 00       	push   $0xbe
  jmp alltraps
80106816:	e9 04 f3 ff ff       	jmp    80105b1f <alltraps>

8010681b <vector191>:
.globl vector191
vector191:
  pushl $0
8010681b:	6a 00                	push   $0x0
  pushl $191
8010681d:	68 bf 00 00 00       	push   $0xbf
  jmp alltraps
80106822:	e9 f8 f2 ff ff       	jmp    80105b1f <alltraps>

80106827 <vector192>:
.globl vector192
vector192:
  pushl $0
80106827:	6a 00                	push   $0x0
  pushl $192
80106829:	68 c0 00 00 00       	push   $0xc0
  jmp alltraps
8010682e:	e9 ec f2 ff ff       	jmp    80105b1f <alltraps>

80106833 <vector193>:
.globl vector193
vector193:
  pushl $0
80106833:	6a 00                	push   $0x0
  pushl $193
80106835:	68 c1 00 00 00       	push   $0xc1
  jmp alltraps
8010683a:	e9 e0 f2 ff ff       	jmp    80105b1f <alltraps>

8010683f <vector194>:
.globl vector194
vector194:
  pushl $0
8010683f:	6a 00                	push   $0x0
  pushl $194
80106841:	68 c2 00 00 00       	push   $0xc2
  jmp alltraps
80106846:	e9 d4 f2 ff ff       	jmp    80105b1f <alltraps>

8010684b <vector195>:
.globl vector195
vector195:
  pushl $0
8010684b:	6a 00                	push   $0x0
  pushl $195
8010684d:	68 c3 00 00 00       	push   $0xc3
  jmp alltraps
80106852:	e9 c8 f2 ff ff       	jmp    80105b1f <alltraps>

80106857 <vector196>:
.globl vector196
vector196:
  pushl $0
80106857:	6a 00                	push   $0x0
  pushl $196
80106859:	68 c4 00 00 00       	push   $0xc4
  jmp alltraps
8010685e:	e9 bc f2 ff ff       	jmp    80105b1f <alltraps>

80106863 <vector197>:
.globl vector197
vector197:
  pushl $0
80106863:	6a 00                	push   $0x0
  pushl $197
80106865:	68 c5 00 00 00       	push   $0xc5
  jmp alltraps
8010686a:	e9 b0 f2 ff ff       	jmp    80105b1f <alltraps>

8010686f <vector198>:
.globl vector198
vector198:
  pushl $0
8010686f:	6a 00                	push   $0x0
  pushl $198
80106871:	68 c6 00 00 00       	push   $0xc6
  jmp alltraps
80106876:	e9 a4 f2 ff ff       	jmp    80105b1f <alltraps>

8010687b <vector199>:
.globl vector199
vector199:
  pushl $0
8010687b:	6a 00                	push   $0x0
  pushl $199
8010687d:	68 c7 00 00 00       	push   $0xc7
  jmp alltraps
80106882:	e9 98 f2 ff ff       	jmp    80105b1f <alltraps>

80106887 <vector200>:
.globl vector200
vector200:
  pushl $0
80106887:	6a 00                	push   $0x0
  pushl $200
80106889:	68 c8 00 00 00       	push   $0xc8
  jmp alltraps
8010688e:	e9 8c f2 ff ff       	jmp    80105b1f <alltraps>

80106893 <vector201>:
.globl vector201
vector201:
  pushl $0
80106893:	6a 00                	push   $0x0
  pushl $201
80106895:	68 c9 00 00 00       	push   $0xc9
  jmp alltraps
8010689a:	e9 80 f2 ff ff       	jmp    80105b1f <alltraps>

8010689f <vector202>:
.globl vector202
vector202:
  pushl $0
8010689f:	6a 00                	push   $0x0
  pushl $202
801068a1:	68 ca 00 00 00       	push   $0xca
  jmp alltraps
801068a6:	e9 74 f2 ff ff       	jmp    80105b1f <alltraps>

801068ab <vector203>:
.globl vector203
vector203:
  pushl $0
801068ab:	6a 00                	push   $0x0
  pushl $203
801068ad:	68 cb 00 00 00       	push   $0xcb
  jmp alltraps
801068b2:	e9 68 f2 ff ff       	jmp    80105b1f <alltraps>

801068b7 <vector204>:
.globl vector204
vector204:
  pushl $0
801068b7:	6a 00                	push   $0x0
  pushl $204
801068b9:	68 cc 00 00 00       	push   $0xcc
  jmp alltraps
801068be:	e9 5c f2 ff ff       	jmp    80105b1f <alltraps>

801068c3 <vector205>:
.globl vector205
vector205:
  pushl $0
801068c3:	6a 00                	push   $0x0
  pushl $205
801068c5:	68 cd 00 00 00       	push   $0xcd
  jmp alltraps
801068ca:	e9 50 f2 ff ff       	jmp    80105b1f <alltraps>

801068cf <vector206>:
.globl vector206
vector206:
  pushl $0
801068cf:	6a 00                	push   $0x0
  pushl $206
801068d1:	68 ce 00 00 00       	push   $0xce
  jmp alltraps
801068d6:	e9 44 f2 ff ff       	jmp    80105b1f <alltraps>

801068db <vector207>:
.globl vector207
vector207:
  pushl $0
801068db:	6a 00                	push   $0x0
  pushl $207
801068dd:	68 cf 00 00 00       	push   $0xcf
  jmp alltraps
801068e2:	e9 38 f2 ff ff       	jmp    80105b1f <alltraps>

801068e7 <vector208>:
.globl vector208
vector208:
  pushl $0
801068e7:	6a 00                	push   $0x0
  pushl $208
801068e9:	68 d0 00 00 00       	push   $0xd0
  jmp alltraps
801068ee:	e9 2c f2 ff ff       	jmp    80105b1f <alltraps>

801068f3 <vector209>:
.globl vector209
vector209:
  pushl $0
801068f3:	6a 00                	push   $0x0
  pushl $209
801068f5:	68 d1 00 00 00       	push   $0xd1
  jmp alltraps
801068fa:	e9 20 f2 ff ff       	jmp    80105b1f <alltraps>

801068ff <vector210>:
.globl vector210
vector210:
  pushl $0
801068ff:	6a 00                	push   $0x0
  pushl $210
80106901:	68 d2 00 00 00       	push   $0xd2
  jmp alltraps
80106906:	e9 14 f2 ff ff       	jmp    80105b1f <alltraps>

8010690b <vector211>:
.globl vector211
vector211:
  pushl $0
8010690b:	6a 00                	push   $0x0
  pushl $211
8010690d:	68 d3 00 00 00       	push   $0xd3
  jmp alltraps
80106912:	e9 08 f2 ff ff       	jmp    80105b1f <alltraps>

80106917 <vector212>:
.globl vector212
vector212:
  pushl $0
80106917:	6a 00                	push   $0x0
  pushl $212
80106919:	68 d4 00 00 00       	push   $0xd4
  jmp alltraps
8010691e:	e9 fc f1 ff ff       	jmp    80105b1f <alltraps>

80106923 <vector213>:
.globl vector213
vector213:
  pushl $0
80106923:	6a 00                	push   $0x0
  pushl $213
80106925:	68 d5 00 00 00       	push   $0xd5
  jmp alltraps
8010692a:	e9 f0 f1 ff ff       	jmp    80105b1f <alltraps>

8010692f <vector214>:
.globl vector214
vector214:
  pushl $0
8010692f:	6a 00                	push   $0x0
  pushl $214
80106931:	68 d6 00 00 00       	push   $0xd6
  jmp alltraps
80106936:	e9 e4 f1 ff ff       	jmp    80105b1f <alltraps>

8010693b <vector215>:
.globl vector215
vector215:
  pushl $0
8010693b:	6a 00                	push   $0x0
  pushl $215
8010693d:	68 d7 00 00 00       	push   $0xd7
  jmp alltraps
80106942:	e9 d8 f1 ff ff       	jmp    80105b1f <alltraps>

80106947 <vector216>:
.globl vector216
vector216:
  pushl $0
80106947:	6a 00                	push   $0x0
  pushl $216
80106949:	68 d8 00 00 00       	push   $0xd8
  jmp alltraps
8010694e:	e9 cc f1 ff ff       	jmp    80105b1f <alltraps>

80106953 <vector217>:
.globl vector217
vector217:
  pushl $0
80106953:	6a 00                	push   $0x0
  pushl $217
80106955:	68 d9 00 00 00       	push   $0xd9
  jmp alltraps
8010695a:	e9 c0 f1 ff ff       	jmp    80105b1f <alltraps>

8010695f <vector218>:
.globl vector218
vector218:
  pushl $0
8010695f:	6a 00                	push   $0x0
  pushl $218
80106961:	68 da 00 00 00       	push   $0xda
  jmp alltraps
80106966:	e9 b4 f1 ff ff       	jmp    80105b1f <alltraps>

8010696b <vector219>:
.globl vector219
vector219:
  pushl $0
8010696b:	6a 00                	push   $0x0
  pushl $219
8010696d:	68 db 00 00 00       	push   $0xdb
  jmp alltraps
80106972:	e9 a8 f1 ff ff       	jmp    80105b1f <alltraps>

80106977 <vector220>:
.globl vector220
vector220:
  pushl $0
80106977:	6a 00                	push   $0x0
  pushl $220
80106979:	68 dc 00 00 00       	push   $0xdc
  jmp alltraps
8010697e:	e9 9c f1 ff ff       	jmp    80105b1f <alltraps>

80106983 <vector221>:
.globl vector221
vector221:
  pushl $0
80106983:	6a 00                	push   $0x0
  pushl $221
80106985:	68 dd 00 00 00       	push   $0xdd
  jmp alltraps
8010698a:	e9 90 f1 ff ff       	jmp    80105b1f <alltraps>

8010698f <vector222>:
.globl vector222
vector222:
  pushl $0
8010698f:	6a 00                	push   $0x0
  pushl $222
80106991:	68 de 00 00 00       	push   $0xde
  jmp alltraps
80106996:	e9 84 f1 ff ff       	jmp    80105b1f <alltraps>

8010699b <vector223>:
.globl vector223
vector223:
  pushl $0
8010699b:	6a 00                	push   $0x0
  pushl $223
8010699d:	68 df 00 00 00       	push   $0xdf
  jmp alltraps
801069a2:	e9 78 f1 ff ff       	jmp    80105b1f <alltraps>

801069a7 <vector224>:
.globl vector224
vector224:
  pushl $0
801069a7:	6a 00                	push   $0x0
  pushl $224
801069a9:	68 e0 00 00 00       	push   $0xe0
  jmp alltraps
801069ae:	e9 6c f1 ff ff       	jmp    80105b1f <alltraps>

801069b3 <vector225>:
.globl vector225
vector225:
  pushl $0
801069b3:	6a 00                	push   $0x0
  pushl $225
801069b5:	68 e1 00 00 00       	push   $0xe1
  jmp alltraps
801069ba:	e9 60 f1 ff ff       	jmp    80105b1f <alltraps>

801069bf <vector226>:
.globl vector226
vector226:
  pushl $0
801069bf:	6a 00                	push   $0x0
  pushl $226
801069c1:	68 e2 00 00 00       	push   $0xe2
  jmp alltraps
801069c6:	e9 54 f1 ff ff       	jmp    80105b1f <alltraps>

801069cb <vector227>:
.globl vector227
vector227:
  pushl $0
801069cb:	6a 00                	push   $0x0
  pushl $227
801069cd:	68 e3 00 00 00       	push   $0xe3
  jmp alltraps
801069d2:	e9 48 f1 ff ff       	jmp    80105b1f <alltraps>

801069d7 <vector228>:
.globl vector228
vector228:
  pushl $0
801069d7:	6a 00                	push   $0x0
  pushl $228
801069d9:	68 e4 00 00 00       	push   $0xe4
  jmp alltraps
801069de:	e9 3c f1 ff ff       	jmp    80105b1f <alltraps>

801069e3 <vector229>:
.globl vector229
vector229:
  pushl $0
801069e3:	6a 00                	push   $0x0
  pushl $229
801069e5:	68 e5 00 00 00       	push   $0xe5
  jmp alltraps
801069ea:	e9 30 f1 ff ff       	jmp    80105b1f <alltraps>

801069ef <vector230>:
.globl vector230
vector230:
  pushl $0
801069ef:	6a 00                	push   $0x0
  pushl $230
801069f1:	68 e6 00 00 00       	push   $0xe6
  jmp alltraps
801069f6:	e9 24 f1 ff ff       	jmp    80105b1f <alltraps>

801069fb <vector231>:
.globl vector231
vector231:
  pushl $0
801069fb:	6a 00                	push   $0x0
  pushl $231
801069fd:	68 e7 00 00 00       	push   $0xe7
  jmp alltraps
80106a02:	e9 18 f1 ff ff       	jmp    80105b1f <alltraps>

80106a07 <vector232>:
.globl vector232
vector232:
  pushl $0
80106a07:	6a 00                	push   $0x0
  pushl $232
80106a09:	68 e8 00 00 00       	push   $0xe8
  jmp alltraps
80106a0e:	e9 0c f1 ff ff       	jmp    80105b1f <alltraps>

80106a13 <vector233>:
.globl vector233
vector233:
  pushl $0
80106a13:	6a 00                	push   $0x0
  pushl $233
80106a15:	68 e9 00 00 00       	push   $0xe9
  jmp alltraps
80106a1a:	e9 00 f1 ff ff       	jmp    80105b1f <alltraps>

80106a1f <vector234>:
.globl vector234
vector234:
  pushl $0
80106a1f:	6a 00                	push   $0x0
  pushl $234
80106a21:	68 ea 00 00 00       	push   $0xea
  jmp alltraps
80106a26:	e9 f4 f0 ff ff       	jmp    80105b1f <alltraps>

80106a2b <vector235>:
.globl vector235
vector235:
  pushl $0
80106a2b:	6a 00                	push   $0x0
  pushl $235
80106a2d:	68 eb 00 00 00       	push   $0xeb
  jmp alltraps
80106a32:	e9 e8 f0 ff ff       	jmp    80105b1f <alltraps>

80106a37 <vector236>:
.globl vector236
vector236:
  pushl $0
80106a37:	6a 00                	push   $0x0
  pushl $236
80106a39:	68 ec 00 00 00       	push   $0xec
  jmp alltraps
80106a3e:	e9 dc f0 ff ff       	jmp    80105b1f <alltraps>

80106a43 <vector237>:
.globl vector237
vector237:
  pushl $0
80106a43:	6a 00                	push   $0x0
  pushl $237
80106a45:	68 ed 00 00 00       	push   $0xed
  jmp alltraps
80106a4a:	e9 d0 f0 ff ff       	jmp    80105b1f <alltraps>

80106a4f <vector238>:
.globl vector238
vector238:
  pushl $0
80106a4f:	6a 00                	push   $0x0
  pushl $238
80106a51:	68 ee 00 00 00       	push   $0xee
  jmp alltraps
80106a56:	e9 c4 f0 ff ff       	jmp    80105b1f <alltraps>

80106a5b <vector239>:
.globl vector239
vector239:
  pushl $0
80106a5b:	6a 00                	push   $0x0
  pushl $239
80106a5d:	68 ef 00 00 00       	push   $0xef
  jmp alltraps
80106a62:	e9 b8 f0 ff ff       	jmp    80105b1f <alltraps>

80106a67 <vector240>:
.globl vector240
vector240:
  pushl $0
80106a67:	6a 00                	push   $0x0
  pushl $240
80106a69:	68 f0 00 00 00       	push   $0xf0
  jmp alltraps
80106a6e:	e9 ac f0 ff ff       	jmp    80105b1f <alltraps>

80106a73 <vector241>:
.globl vector241
vector241:
  pushl $0
80106a73:	6a 00                	push   $0x0
  pushl $241
80106a75:	68 f1 00 00 00       	push   $0xf1
  jmp alltraps
80106a7a:	e9 a0 f0 ff ff       	jmp    80105b1f <alltraps>

80106a7f <vector242>:
.globl vector242
vector242:
  pushl $0
80106a7f:	6a 00                	push   $0x0
  pushl $242
80106a81:	68 f2 00 00 00       	push   $0xf2
  jmp alltraps
80106a86:	e9 94 f0 ff ff       	jmp    80105b1f <alltraps>

80106a8b <vector243>:
.globl vector243
vector243:
  pushl $0
80106a8b:	6a 00                	push   $0x0
  pushl $243
80106a8d:	68 f3 00 00 00       	push   $0xf3
  jmp alltraps
80106a92:	e9 88 f0 ff ff       	jmp    80105b1f <alltraps>

80106a97 <vector244>:
.globl vector244
vector244:
  pushl $0
80106a97:	6a 00                	push   $0x0
  pushl $244
80106a99:	68 f4 00 00 00       	push   $0xf4
  jmp alltraps
80106a9e:	e9 7c f0 ff ff       	jmp    80105b1f <alltraps>

80106aa3 <vector245>:
.globl vector245
vector245:
  pushl $0
80106aa3:	6a 00                	push   $0x0
  pushl $245
80106aa5:	68 f5 00 00 00       	push   $0xf5
  jmp alltraps
80106aaa:	e9 70 f0 ff ff       	jmp    80105b1f <alltraps>

80106aaf <vector246>:
.globl vector246
vector246:
  pushl $0
80106aaf:	6a 00                	push   $0x0
  pushl $246
80106ab1:	68 f6 00 00 00       	push   $0xf6
  jmp alltraps
80106ab6:	e9 64 f0 ff ff       	jmp    80105b1f <alltraps>

80106abb <vector247>:
.globl vector247
vector247:
  pushl $0
80106abb:	6a 00                	push   $0x0
  pushl $247
80106abd:	68 f7 00 00 00       	push   $0xf7
  jmp alltraps
80106ac2:	e9 58 f0 ff ff       	jmp    80105b1f <alltraps>

80106ac7 <vector248>:
.globl vector248
vector248:
  pushl $0
80106ac7:	6a 00                	push   $0x0
  pushl $248
80106ac9:	68 f8 00 00 00       	push   $0xf8
  jmp alltraps
80106ace:	e9 4c f0 ff ff       	jmp    80105b1f <alltraps>

80106ad3 <vector249>:
.globl vector249
vector249:
  pushl $0
80106ad3:	6a 00                	push   $0x0
  pushl $249
80106ad5:	68 f9 00 00 00       	push   $0xf9
  jmp alltraps
80106ada:	e9 40 f0 ff ff       	jmp    80105b1f <alltraps>

80106adf <vector250>:
.globl vector250
vector250:
  pushl $0
80106adf:	6a 00                	push   $0x0
  pushl $250
80106ae1:	68 fa 00 00 00       	push   $0xfa
  jmp alltraps
80106ae6:	e9 34 f0 ff ff       	jmp    80105b1f <alltraps>

80106aeb <vector251>:
.globl vector251
vector251:
  pushl $0
80106aeb:	6a 00                	push   $0x0
  pushl $251
80106aed:	68 fb 00 00 00       	push   $0xfb
  jmp alltraps
80106af2:	e9 28 f0 ff ff       	jmp    80105b1f <alltraps>

80106af7 <vector252>:
.globl vector252
vector252:
  pushl $0
80106af7:	6a 00                	push   $0x0
  pushl $252
80106af9:	68 fc 00 00 00       	push   $0xfc
  jmp alltraps
80106afe:	e9 1c f0 ff ff       	jmp    80105b1f <alltraps>

80106b03 <vector253>:
.globl vector253
vector253:
  pushl $0
80106b03:	6a 00                	push   $0x0
  pushl $253
80106b05:	68 fd 00 00 00       	push   $0xfd
  jmp alltraps
80106b0a:	e9 10 f0 ff ff       	jmp    80105b1f <alltraps>

80106b0f <vector254>:
.globl vector254
vector254:
  pushl $0
80106b0f:	6a 00                	push   $0x0
  pushl $254
80106b11:	68 fe 00 00 00       	push   $0xfe
  jmp alltraps
80106b16:	e9 04 f0 ff ff       	jmp    80105b1f <alltraps>

80106b1b <vector255>:
.globl vector255
vector255:
  pushl $0
80106b1b:	6a 00                	push   $0x0
  pushl $255
80106b1d:	68 ff 00 00 00       	push   $0xff
  jmp alltraps
80106b22:	e9 f8 ef ff ff       	jmp    80105b1f <alltraps>
80106b27:	66 90                	xchg   %ax,%ax
80106b29:	66 90                	xchg   %ax,%ax
80106b2b:	66 90                	xchg   %ax,%ax
80106b2d:	66 90                	xchg   %ax,%ax
80106b2f:	90                   	nop

80106b30 <deallocuvm.part.0>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.

int
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106b30:	55                   	push   %ebp
80106b31:	89 e5                	mov    %esp,%ebp
80106b33:	57                   	push   %edi
80106b34:	89 c7                	mov    %eax,%edi
80106b36:	56                   	push   %esi
80106b37:	53                   	push   %ebx
  uint a, pa;

  if(newsz >= oldsz)
    return oldsz;

  a = PGROUNDUP(newsz);
80106b38:	8d 99 ff 0f 00 00    	lea    0xfff(%ecx),%ebx
80106b3e:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
deallocuvm(pde_t *pgdir, uint oldsz, uint newsz)
80106b44:	83 ec 1c             	sub    $0x1c,%esp
80106b47:	89 4d e0             	mov    %ecx,-0x20(%ebp)
  for(; a < oldsz; a += PGSIZE){
80106b4a:	39 d3                	cmp    %edx,%ebx
80106b4c:	73 5d                	jae    80106bab <deallocuvm.part.0+0x7b>
80106b4e:	89 d6                	mov    %edx,%esi
  pde = &pgdir[PDX(va)];
80106b50:	89 d8                	mov    %ebx,%eax
80106b52:	c1 e8 16             	shr    $0x16,%eax
  if(*pde & PTE_P){
80106b55:	8b 04 87             	mov    (%edi,%eax,4),%eax
80106b58:	a8 01                	test   $0x1,%al
80106b5a:	74 45                	je     80106ba1 <deallocuvm.part.0+0x71>
  return &pgtab[PTX(va)];
80106b5c:	89 d9                	mov    %ebx,%ecx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106b5e:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80106b63:	c1 e9 0a             	shr    $0xa,%ecx
80106b66:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
80106b6c:	8d 8c 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%ecx
    pte = walkpgdir(pgdir, (char*)a, 0);

    if(pte == 0)
80106b73:	85 c9                	test   %ecx,%ecx
80106b75:	74 2a                	je     80106ba1 <deallocuvm.part.0+0x71>
      continue;

    if((*pte & PTE_P) != 0){
80106b77:	8b 01                	mov    (%ecx),%eax
80106b79:	a8 01                	test   $0x1,%al
80106b7b:	74 24                	je     80106ba1 <deallocuvm.part.0+0x71>
      pa = PTE_ADDR(*pte);
      if(pa == 0)
80106b7d:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106b82:	74 32                	je     80106bb6 <deallocuvm.part.0+0x86>
        panic("kfree");
      kfree(P2V(pa));
80106b84:	83 ec 0c             	sub    $0xc,%esp
80106b87:	05 00 00 00 80       	add    $0x80000000,%eax
80106b8c:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
80106b8f:	50                   	push   %eax
80106b90:	e8 0b b9 ff ff       	call   801024a0 <kfree>
      *pte = 0;
80106b95:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80106b98:	83 c4 10             	add    $0x10,%esp
80106b9b:	c7 01 00 00 00 00    	movl   $0x0,(%ecx)
  for(; a < oldsz; a += PGSIZE){
80106ba1:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106ba7:	39 f3                	cmp    %esi,%ebx
80106ba9:	72 a5                	jb     80106b50 <deallocuvm.part.0+0x20>
    }
  }

  return newsz;
}
80106bab:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106bae:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106bb1:	5b                   	pop    %ebx
80106bb2:	5e                   	pop    %esi
80106bb3:	5f                   	pop    %edi
80106bb4:	5d                   	pop    %ebp
80106bb5:	c3                   	ret
        panic("kfree");
80106bb6:	83 ec 0c             	sub    $0xc,%esp
80106bb9:	68 ec 79 10 80       	push   $0x801079ec
80106bbe:	e8 bd 97 ff ff       	call   80100380 <panic>
80106bc3:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106bca:	00 
80106bcb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi

80106bd0 <seginit>:
{
80106bd0:	55                   	push   %ebp
80106bd1:	89 e5                	mov    %esp,%ebp
80106bd3:	83 ec 18             	sub    $0x18,%esp
  c = &cpus[cpuid()];
80106bd6:	e8 f5 cd ff ff       	call   801039d0 <cpuid>
  pd[0] = size-1;
80106bdb:	ba 2f 00 00 00       	mov    $0x2f,%edx
  c->gdt[SEG_KCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, 0);
80106be0:	69 c0 b0 00 00 00    	imul   $0xb0,%eax,%eax
80106be6:	66 89 55 f2          	mov    %dx,-0xe(%ebp)
80106bea:	c7 80 38 28 11 80 ff 	movl   $0xffff,-0x7feed7c8(%eax)
80106bf1:	ff 00 00 
80106bf4:	c7 80 3c 28 11 80 00 	movl   $0xcf9a00,-0x7feed7c4(%eax)
80106bfb:	9a cf 00 
  c->gdt[SEG_KDATA] = SEG(STA_W, 0, 0xffffffff, 0);
80106bfe:	c7 80 40 28 11 80 ff 	movl   $0xffff,-0x7feed7c0(%eax)
80106c05:	ff 00 00 
80106c08:	c7 80 44 28 11 80 00 	movl   $0xcf9200,-0x7feed7bc(%eax)
80106c0f:	92 cf 00 
  c->gdt[SEG_UCODE] = SEG(STA_X|STA_R, 0, 0xffffffff, DPL_USER);
80106c12:	c7 80 48 28 11 80 ff 	movl   $0xffff,-0x7feed7b8(%eax)
80106c19:	ff 00 00 
80106c1c:	c7 80 4c 28 11 80 00 	movl   $0xcffa00,-0x7feed7b4(%eax)
80106c23:	fa cf 00 
  c->gdt[SEG_UDATA] = SEG(STA_W, 0, 0xffffffff, DPL_USER);
80106c26:	c7 80 50 28 11 80 ff 	movl   $0xffff,-0x7feed7b0(%eax)
80106c2d:	ff 00 00 
80106c30:	c7 80 54 28 11 80 00 	movl   $0xcff200,-0x7feed7ac(%eax)
80106c37:	f2 cf 00 
  lgdt(c->gdt, sizeof(c->gdt));
80106c3a:	05 30 28 11 80       	add    $0x80112830,%eax
  pd[1] = (uint)p;
80106c3f:	66 89 45 f4          	mov    %ax,-0xc(%ebp)
  pd[2] = (uint)p >> 16;
80106c43:	c1 e8 10             	shr    $0x10,%eax
80106c46:	66 89 45 f6          	mov    %ax,-0xa(%ebp)
  asm volatile("lgdt (%0)" : : "r" (pd));
80106c4a:	8d 45 f2             	lea    -0xe(%ebp),%eax
80106c4d:	0f 01 10             	lgdtl  (%eax)
}
80106c50:	c9                   	leave
80106c51:	c3                   	ret
80106c52:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106c59:	00 
80106c5a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80106c60 <mappages>:
{
80106c60:	55                   	push   %ebp
80106c61:	89 e5                	mov    %esp,%ebp
80106c63:	57                   	push   %edi
80106c64:	56                   	push   %esi
80106c65:	53                   	push   %ebx
80106c66:	83 ec 1c             	sub    $0x1c,%esp
80106c69:	8b 45 0c             	mov    0xc(%ebp),%eax
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106c6c:	8b 55 10             	mov    0x10(%ebp),%edx
  a = (char*)PGROUNDDOWN((uint)va);
80106c6f:	89 c3                	mov    %eax,%ebx
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106c71:	8d 44 10 ff          	lea    -0x1(%eax,%edx,1),%eax
80106c75:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  a = (char*)PGROUNDDOWN((uint)va);
80106c7a:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
  last = (char*)PGROUNDDOWN(((uint)va) + size - 1);
80106c80:	89 45 e0             	mov    %eax,-0x20(%ebp)
80106c83:	8b 45 14             	mov    0x14(%ebp),%eax
80106c86:	29 d8                	sub    %ebx,%eax
80106c88:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106c8b:	eb 3c                	jmp    80106cc9 <mappages+0x69>
80106c8d:	8d 76 00             	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80106c90:	89 da                	mov    %ebx,%edx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106c92:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80106c97:	c1 ea 0a             	shr    $0xa,%edx
80106c9a:	81 e2 fc 0f 00 00    	and    $0xffc,%edx
80106ca0:	8d 84 10 00 00 00 80 	lea    -0x80000000(%eax,%edx,1),%eax
    if((pte = walkpgdir(pgdir, a, 1)) == 0)
80106ca7:	85 c0                	test   %eax,%eax
80106ca9:	74 75                	je     80106d20 <mappages+0xc0>
    if(*pte & PTE_P)
80106cab:	f6 00 01             	testb  $0x1,(%eax)
80106cae:	0f 85 86 00 00 00    	jne    80106d3a <mappages+0xda>
    *pte = pa | perm | PTE_P;
80106cb4:	0b 75 18             	or     0x18(%ebp),%esi
80106cb7:	83 ce 01             	or     $0x1,%esi
80106cba:	89 30                	mov    %esi,(%eax)
    if(a == last)
80106cbc:	8b 45 e0             	mov    -0x20(%ebp),%eax
80106cbf:	39 c3                	cmp    %eax,%ebx
80106cc1:	74 6d                	je     80106d30 <mappages+0xd0>
    a += PGSIZE;
80106cc3:	81 c3 00 10 00 00    	add    $0x1000,%ebx
  for(;;){
80106cc9:	8b 45 e4             	mov    -0x1c(%ebp),%eax
  pde = &pgdir[PDX(va)];
80106ccc:	8b 4d 08             	mov    0x8(%ebp),%ecx
80106ccf:	8d 34 03             	lea    (%ebx,%eax,1),%esi
80106cd2:	89 d8                	mov    %ebx,%eax
80106cd4:	c1 e8 16             	shr    $0x16,%eax
80106cd7:	8d 3c 81             	lea    (%ecx,%eax,4),%edi
  if(*pde & PTE_P){
80106cda:	8b 07                	mov    (%edi),%eax
80106cdc:	a8 01                	test   $0x1,%al
80106cde:	75 b0                	jne    80106c90 <mappages+0x30>
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
80106ce0:	e8 8b b9 ff ff       	call   80102670 <kalloc>
80106ce5:	85 c0                	test   %eax,%eax
80106ce7:	74 37                	je     80106d20 <mappages+0xc0>
    memset(pgtab, 0, PGSIZE);
80106ce9:	83 ec 04             	sub    $0x4,%esp
80106cec:	68 00 10 00 00       	push   $0x1000
80106cf1:	6a 00                	push   $0x0
80106cf3:	50                   	push   %eax
80106cf4:	89 45 dc             	mov    %eax,-0x24(%ebp)
80106cf7:	e8 f4 da ff ff       	call   801047f0 <memset>
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106cfc:	8b 55 dc             	mov    -0x24(%ebp),%edx
  return &pgtab[PTX(va)];
80106cff:	83 c4 10             	add    $0x10,%esp
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
80106d02:	8d 82 00 00 00 80    	lea    -0x80000000(%edx),%eax
80106d08:	83 c8 07             	or     $0x7,%eax
80106d0b:	89 07                	mov    %eax,(%edi)
  return &pgtab[PTX(va)];
80106d0d:	89 d8                	mov    %ebx,%eax
80106d0f:	c1 e8 0a             	shr    $0xa,%eax
80106d12:	25 fc 0f 00 00       	and    $0xffc,%eax
80106d17:	01 d0                	add    %edx,%eax
80106d19:	eb 90                	jmp    80106cab <mappages+0x4b>
80106d1b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
}
80106d20:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80106d23:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106d28:	5b                   	pop    %ebx
80106d29:	5e                   	pop    %esi
80106d2a:	5f                   	pop    %edi
80106d2b:	5d                   	pop    %ebp
80106d2c:	c3                   	ret
80106d2d:	8d 76 00             	lea    0x0(%esi),%esi
80106d30:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80106d33:	31 c0                	xor    %eax,%eax
}
80106d35:	5b                   	pop    %ebx
80106d36:	5e                   	pop    %esi
80106d37:	5f                   	pop    %edi
80106d38:	5d                   	pop    %ebp
80106d39:	c3                   	ret
      panic("remap");
80106d3a:	83 ec 0c             	sub    $0xc,%esp
80106d3d:	68 35 7c 10 80       	push   $0x80107c35
80106d42:	e8 39 96 ff ff       	call   80100380 <panic>
80106d47:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106d4e:	00 
80106d4f:	90                   	nop

80106d50 <switchkvm>:
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80106d50:	a1 e4 57 11 80       	mov    0x801157e4,%eax
80106d55:	05 00 00 00 80       	add    $0x80000000,%eax
}

static inline void
lcr3(uint val)
{
  asm volatile("movl %0,%%cr3" : : "r" (val));
80106d5a:	0f 22 d8             	mov    %eax,%cr3
}
80106d5d:	c3                   	ret
80106d5e:	66 90                	xchg   %ax,%ax

80106d60 <switchuvm>:
{
80106d60:	55                   	push   %ebp
80106d61:	89 e5                	mov    %esp,%ebp
80106d63:	57                   	push   %edi
80106d64:	56                   	push   %esi
80106d65:	53                   	push   %ebx
80106d66:	83 ec 1c             	sub    $0x1c,%esp
80106d69:	8b 75 08             	mov    0x8(%ebp),%esi
  if(p == 0)
80106d6c:	85 f6                	test   %esi,%esi
80106d6e:	0f 84 cb 00 00 00    	je     80106e3f <switchuvm+0xdf>
  if(p->kstack == 0)
80106d74:	8b 46 08             	mov    0x8(%esi),%eax
80106d77:	85 c0                	test   %eax,%eax
80106d79:	0f 84 da 00 00 00    	je     80106e59 <switchuvm+0xf9>
  if(p->pgdir == 0)
80106d7f:	8b 46 04             	mov    0x4(%esi),%eax
80106d82:	85 c0                	test   %eax,%eax
80106d84:	0f 84 c2 00 00 00    	je     80106e4c <switchuvm+0xec>
  pushcli();
80106d8a:	e8 11 d8 ff ff       	call   801045a0 <pushcli>
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80106d8f:	e8 dc cb ff ff       	call   80103970 <mycpu>
80106d94:	89 c3                	mov    %eax,%ebx
80106d96:	e8 d5 cb ff ff       	call   80103970 <mycpu>
80106d9b:	89 c7                	mov    %eax,%edi
80106d9d:	e8 ce cb ff ff       	call   80103970 <mycpu>
80106da2:	83 c7 08             	add    $0x8,%edi
80106da5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
80106da8:	e8 c3 cb ff ff       	call   80103970 <mycpu>
80106dad:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
80106db0:	ba 67 00 00 00       	mov    $0x67,%edx
80106db5:	66 89 bb 9a 00 00 00 	mov    %di,0x9a(%ebx)
80106dbc:	83 c0 08             	add    $0x8,%eax
80106dbf:	66 89 93 98 00 00 00 	mov    %dx,0x98(%ebx)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80106dc6:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  mycpu()->gdt[SEG_TSS] = SEG16(STS_T32A, &mycpu()->ts,
80106dcb:	83 c1 08             	add    $0x8,%ecx
80106dce:	c1 e8 18             	shr    $0x18,%eax
80106dd1:	c1 e9 10             	shr    $0x10,%ecx
80106dd4:	88 83 9f 00 00 00    	mov    %al,0x9f(%ebx)
80106dda:	88 8b 9c 00 00 00    	mov    %cl,0x9c(%ebx)
80106de0:	b9 99 40 00 00       	mov    $0x4099,%ecx
80106de5:	66 89 8b 9d 00 00 00 	mov    %cx,0x9d(%ebx)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
80106dec:	bb 10 00 00 00       	mov    $0x10,%ebx
  mycpu()->gdt[SEG_TSS].s = 0;
80106df1:	e8 7a cb ff ff       	call   80103970 <mycpu>
80106df6:	80 a0 9d 00 00 00 ef 	andb   $0xef,0x9d(%eax)
  mycpu()->ts.ss0 = SEG_KDATA << 3;
80106dfd:	e8 6e cb ff ff       	call   80103970 <mycpu>
80106e02:	66 89 58 10          	mov    %bx,0x10(%eax)
  mycpu()->ts.esp0 = (uint)p->kstack + KSTACKSIZE;
80106e06:	8b 5e 08             	mov    0x8(%esi),%ebx
80106e09:	81 c3 00 10 00 00    	add    $0x1000,%ebx
80106e0f:	e8 5c cb ff ff       	call   80103970 <mycpu>
80106e14:	89 58 0c             	mov    %ebx,0xc(%eax)
  mycpu()->ts.iomb = (ushort) 0xFFFF;
80106e17:	e8 54 cb ff ff       	call   80103970 <mycpu>
80106e1c:	66 89 78 6e          	mov    %di,0x6e(%eax)
  asm volatile("ltr %0" : : "r" (sel));
80106e20:	b8 28 00 00 00       	mov    $0x28,%eax
80106e25:	0f 00 d8             	ltr    %eax
  lcr3(V2P(p->pgdir));  // switch to process's address space
80106e28:	8b 46 04             	mov    0x4(%esi),%eax
80106e2b:	05 00 00 00 80       	add    $0x80000000,%eax
  asm volatile("movl %0,%%cr3" : : "r" (val));
80106e30:	0f 22 d8             	mov    %eax,%cr3
}
80106e33:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106e36:	5b                   	pop    %ebx
80106e37:	5e                   	pop    %esi
80106e38:	5f                   	pop    %edi
80106e39:	5d                   	pop    %ebp
  popcli();
80106e3a:	e9 b1 d7 ff ff       	jmp    801045f0 <popcli>
    panic("switchuvm: no process");
80106e3f:	83 ec 0c             	sub    $0xc,%esp
80106e42:	68 3b 7c 10 80       	push   $0x80107c3b
80106e47:	e8 34 95 ff ff       	call   80100380 <panic>
    panic("switchuvm: no pgdir");
80106e4c:	83 ec 0c             	sub    $0xc,%esp
80106e4f:	68 66 7c 10 80       	push   $0x80107c66
80106e54:	e8 27 95 ff ff       	call   80100380 <panic>
    panic("switchuvm: no kstack");
80106e59:	83 ec 0c             	sub    $0xc,%esp
80106e5c:	68 51 7c 10 80       	push   $0x80107c51
80106e61:	e8 1a 95 ff ff       	call   80100380 <panic>
80106e66:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106e6d:	00 
80106e6e:	66 90                	xchg   %ax,%ax

80106e70 <inituvm>:
{
80106e70:	55                   	push   %ebp
80106e71:	89 e5                	mov    %esp,%ebp
80106e73:	57                   	push   %edi
80106e74:	56                   	push   %esi
80106e75:	53                   	push   %ebx
80106e76:	83 ec 1c             	sub    $0x1c,%esp
80106e79:	8b 75 10             	mov    0x10(%ebp),%esi
80106e7c:	8b 55 08             	mov    0x8(%ebp),%edx
80106e7f:	8b 7d 0c             	mov    0xc(%ebp),%edi
  if(sz >= PGSIZE)
80106e82:	81 fe ff 0f 00 00    	cmp    $0xfff,%esi
80106e88:	77 50                	ja     80106eda <inituvm+0x6a>
80106e8a:	89 55 e4             	mov    %edx,-0x1c(%ebp)
  mem = kalloc();
80106e8d:	e8 de b7 ff ff       	call   80102670 <kalloc>
  memset(mem, 0, PGSIZE);
80106e92:	83 ec 04             	sub    $0x4,%esp
80106e95:	68 00 10 00 00       	push   $0x1000
  mem = kalloc();
80106e9a:	89 c3                	mov    %eax,%ebx
  memset(mem, 0, PGSIZE);
80106e9c:	6a 00                	push   $0x0
80106e9e:	50                   	push   %eax
80106e9f:	e8 4c d9 ff ff       	call   801047f0 <memset>
  mappages(pgdir, 0, PGSIZE, V2P(mem), PTE_W|PTE_U);
80106ea4:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80106eaa:	c7 04 24 06 00 00 00 	movl   $0x6,(%esp)
80106eb1:	50                   	push   %eax
80106eb2:	68 00 10 00 00       	push   $0x1000
80106eb7:	6a 00                	push   $0x0
80106eb9:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80106ebc:	52                   	push   %edx
80106ebd:	e8 9e fd ff ff       	call   80106c60 <mappages>
  memmove(mem, init, sz);
80106ec2:	83 c4 20             	add    $0x20,%esp
80106ec5:	89 75 10             	mov    %esi,0x10(%ebp)
80106ec8:	89 7d 0c             	mov    %edi,0xc(%ebp)
80106ecb:	89 5d 08             	mov    %ebx,0x8(%ebp)
}
80106ece:	8d 65 f4             	lea    -0xc(%ebp),%esp
80106ed1:	5b                   	pop    %ebx
80106ed2:	5e                   	pop    %esi
80106ed3:	5f                   	pop    %edi
80106ed4:	5d                   	pop    %ebp
  memmove(mem, init, sz);
80106ed5:	e9 a6 d9 ff ff       	jmp    80104880 <memmove>
    panic("inituvm: more than a page");
80106eda:	83 ec 0c             	sub    $0xc,%esp
80106edd:	68 7a 7c 10 80       	push   $0x80107c7a
80106ee2:	e8 99 94 ff ff       	call   80100380 <panic>
80106ee7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106eee:	00 
80106eef:	90                   	nop

80106ef0 <loaduvm>:
{
80106ef0:	55                   	push   %ebp
80106ef1:	89 e5                	mov    %esp,%ebp
80106ef3:	57                   	push   %edi
80106ef4:	56                   	push   %esi
80106ef5:	53                   	push   %ebx
80106ef6:	83 ec 0c             	sub    $0xc,%esp
  if((uint) addr % PGSIZE != 0)
80106ef9:	8b 75 0c             	mov    0xc(%ebp),%esi
{
80106efc:	8b 7d 18             	mov    0x18(%ebp),%edi
  if((uint) addr % PGSIZE != 0)
80106eff:	81 e6 ff 0f 00 00    	and    $0xfff,%esi
80106f05:	0f 85 a2 00 00 00    	jne    80106fad <loaduvm+0xbd>
  for(i = 0; i < sz; i += PGSIZE){
80106f0b:	85 ff                	test   %edi,%edi
80106f0d:	74 7d                	je     80106f8c <loaduvm+0x9c>
80106f0f:	90                   	nop
  pde = &pgdir[PDX(va)];
80106f10:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80106f13:	8b 55 08             	mov    0x8(%ebp),%edx
80106f16:	01 f0                	add    %esi,%eax
  pde = &pgdir[PDX(va)];
80106f18:	89 c1                	mov    %eax,%ecx
80106f1a:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80106f1d:	8b 0c 8a             	mov    (%edx,%ecx,4),%ecx
80106f20:	f6 c1 01             	test   $0x1,%cl
80106f23:	75 13                	jne    80106f38 <loaduvm+0x48>
      panic("loaduvm: address should exist");
80106f25:	83 ec 0c             	sub    $0xc,%esp
80106f28:	68 94 7c 10 80       	push   $0x80107c94
80106f2d:	e8 4e 94 ff ff       	call   80100380 <panic>
80106f32:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  return &pgtab[PTX(va)];
80106f38:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80106f3b:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
  return &pgtab[PTX(va)];
80106f41:	25 fc 0f 00 00       	and    $0xffc,%eax
80106f46:	8d 8c 01 00 00 00 80 	lea    -0x80000000(%ecx,%eax,1),%ecx
    if((pte = walkpgdir(pgdir, addr+i, 0)) == 0)
80106f4d:	85 c9                	test   %ecx,%ecx
80106f4f:	74 d4                	je     80106f25 <loaduvm+0x35>
    if(sz - i < PGSIZE)
80106f51:	89 fb                	mov    %edi,%ebx
80106f53:	b8 00 10 00 00       	mov    $0x1000,%eax
80106f58:	29 f3                	sub    %esi,%ebx
80106f5a:	39 c3                	cmp    %eax,%ebx
80106f5c:	0f 47 d8             	cmova  %eax,%ebx
    if(readi(ip, P2V(pa), offset+i, n) != n)
80106f5f:	53                   	push   %ebx
80106f60:	8b 45 14             	mov    0x14(%ebp),%eax
80106f63:	01 f0                	add    %esi,%eax
80106f65:	50                   	push   %eax
    pa = PTE_ADDR(*pte);
80106f66:	8b 01                	mov    (%ecx),%eax
80106f68:	25 00 f0 ff ff       	and    $0xfffff000,%eax
    if(readi(ip, P2V(pa), offset+i, n) != n)
80106f6d:	05 00 00 00 80       	add    $0x80000000,%eax
80106f72:	50                   	push   %eax
80106f73:	ff 75 10             	push   0x10(%ebp)
80106f76:	e8 35 ab ff ff       	call   80101ab0 <readi>
80106f7b:	83 c4 10             	add    $0x10,%esp
80106f7e:	39 d8                	cmp    %ebx,%eax
80106f80:	75 1e                	jne    80106fa0 <loaduvm+0xb0>
  for(i = 0; i < sz; i += PGSIZE){
80106f82:	81 c6 00 10 00 00    	add    $0x1000,%esi
80106f88:	39 fe                	cmp    %edi,%esi
80106f8a:	72 84                	jb     80106f10 <loaduvm+0x20>
}
80106f8c:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
80106f8f:	31 c0                	xor    %eax,%eax
}
80106f91:	5b                   	pop    %ebx
80106f92:	5e                   	pop    %esi
80106f93:	5f                   	pop    %edi
80106f94:	5d                   	pop    %ebp
80106f95:	c3                   	ret
80106f96:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
80106f9d:	00 
80106f9e:	66 90                	xchg   %ax,%ax
80106fa0:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
80106fa3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80106fa8:	5b                   	pop    %ebx
80106fa9:	5e                   	pop    %esi
80106faa:	5f                   	pop    %edi
80106fab:	5d                   	pop    %ebp
80106fac:	c3                   	ret
    panic("loaduvm: addr must be page aligned");
80106fad:	83 ec 0c             	sub    $0xc,%esp
80106fb0:	68 cc 7e 10 80       	push   $0x80107ecc
80106fb5:	e8 c6 93 ff ff       	call   80100380 <panic>
80106fba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80106fc0 <allocuvm>:
{
80106fc0:	55                   	push   %ebp
80106fc1:	89 e5                	mov    %esp,%ebp
80106fc3:	57                   	push   %edi
80106fc4:	56                   	push   %esi
80106fc5:	53                   	push   %ebx
80106fc6:	83 ec 1c             	sub    $0x1c,%esp
80106fc9:	8b 75 10             	mov    0x10(%ebp),%esi
  if(newsz >= KERNBASE)
80106fcc:	85 f6                	test   %esi,%esi
80106fce:	0f 88 9a 00 00 00    	js     8010706e <allocuvm+0xae>
80106fd4:	89 f2                	mov    %esi,%edx
  if(newsz < oldsz)
80106fd6:	3b 75 0c             	cmp    0xc(%ebp),%esi
80106fd9:	0f 82 a1 00 00 00    	jb     80107080 <allocuvm+0xc0>
  a = PGROUNDUP(oldsz);
80106fdf:	8b 45 0c             	mov    0xc(%ebp),%eax
80106fe2:	05 ff 0f 00 00       	add    $0xfff,%eax
80106fe7:	25 00 f0 ff ff       	and    $0xfffff000,%eax
80106fec:	89 c7                	mov    %eax,%edi
  for(; a < newsz; a += PGSIZE){
80106fee:	39 f0                	cmp    %esi,%eax
80106ff0:	0f 83 8d 00 00 00    	jae    80107083 <allocuvm+0xc3>
80106ff6:	89 75 e4             	mov    %esi,-0x1c(%ebp)
80106ff9:	eb 46                	jmp    80107041 <allocuvm+0x81>
80106ffb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    memset(mem, 0, PGSIZE);
80107000:	83 ec 04             	sub    $0x4,%esp
80107003:	68 00 10 00 00       	push   $0x1000
80107008:	6a 00                	push   $0x0
8010700a:	50                   	push   %eax
8010700b:	e8 e0 d7 ff ff       	call   801047f0 <memset>
    if(mappages(pgdir, (char*)a, PGSIZE, V2P(mem), PTE_W|PTE_U) < 0){
80107010:	8d 83 00 00 00 80    	lea    -0x80000000(%ebx),%eax
80107016:	c7 04 24 06 00 00 00 	movl   $0x6,(%esp)
8010701d:	50                   	push   %eax
8010701e:	68 00 10 00 00       	push   $0x1000
80107023:	57                   	push   %edi
80107024:	ff 75 08             	push   0x8(%ebp)
80107027:	e8 34 fc ff ff       	call   80106c60 <mappages>
8010702c:	83 c4 20             	add    $0x20,%esp
8010702f:	85 c0                	test   %eax,%eax
80107031:	78 5d                	js     80107090 <allocuvm+0xd0>
  for(; a < newsz; a += PGSIZE){
80107033:	81 c7 00 10 00 00    	add    $0x1000,%edi
80107039:	39 f7                	cmp    %esi,%edi
8010703b:	0f 83 87 00 00 00    	jae    801070c8 <allocuvm+0x108>
    mem = kalloc();
80107041:	e8 2a b6 ff ff       	call   80102670 <kalloc>
80107046:	89 c3                	mov    %eax,%ebx
    if(mem == 0){
80107048:	85 c0                	test   %eax,%eax
8010704a:	75 b4                	jne    80107000 <allocuvm+0x40>
      cprintf("allocuvm out of memory\n");
8010704c:	83 ec 0c             	sub    $0xc,%esp
8010704f:	68 b2 7c 10 80       	push   $0x80107cb2
80107054:	e8 57 96 ff ff       	call   801006b0 <cprintf>
  if(newsz >= oldsz)
80107059:	83 c4 10             	add    $0x10,%esp
8010705c:	3b 75 0c             	cmp    0xc(%ebp),%esi
8010705f:	74 0d                	je     8010706e <allocuvm+0xae>
80107061:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107064:	8b 45 08             	mov    0x8(%ebp),%eax
80107067:	89 f2                	mov    %esi,%edx
80107069:	e8 c2 fa ff ff       	call   80106b30 <deallocuvm.part.0>
    return 0;
8010706e:	31 d2                	xor    %edx,%edx
}
80107070:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107073:	89 d0                	mov    %edx,%eax
80107075:	5b                   	pop    %ebx
80107076:	5e                   	pop    %esi
80107077:	5f                   	pop    %edi
80107078:	5d                   	pop    %ebp
80107079:	c3                   	ret
8010707a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    return oldsz;
80107080:	8b 55 0c             	mov    0xc(%ebp),%edx
}
80107083:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107086:	89 d0                	mov    %edx,%eax
80107088:	5b                   	pop    %ebx
80107089:	5e                   	pop    %esi
8010708a:	5f                   	pop    %edi
8010708b:	5d                   	pop    %ebp
8010708c:	c3                   	ret
8010708d:	8d 76 00             	lea    0x0(%esi),%esi
      cprintf("allocuvm out of memory (2)\n");
80107090:	83 ec 0c             	sub    $0xc,%esp
80107093:	68 ca 7c 10 80       	push   $0x80107cca
80107098:	e8 13 96 ff ff       	call   801006b0 <cprintf>
  if(newsz >= oldsz)
8010709d:	83 c4 10             	add    $0x10,%esp
801070a0:	3b 75 0c             	cmp    0xc(%ebp),%esi
801070a3:	74 0d                	je     801070b2 <allocuvm+0xf2>
801070a5:	8b 4d 0c             	mov    0xc(%ebp),%ecx
801070a8:	8b 45 08             	mov    0x8(%ebp),%eax
801070ab:	89 f2                	mov    %esi,%edx
801070ad:	e8 7e fa ff ff       	call   80106b30 <deallocuvm.part.0>
      kfree(mem);
801070b2:	83 ec 0c             	sub    $0xc,%esp
801070b5:	53                   	push   %ebx
801070b6:	e8 e5 b3 ff ff       	call   801024a0 <kfree>
      return 0;
801070bb:	83 c4 10             	add    $0x10,%esp
    return 0;
801070be:	31 d2                	xor    %edx,%edx
801070c0:	eb ae                	jmp    80107070 <allocuvm+0xb0>
801070c2:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
801070c8:	8b 55 e4             	mov    -0x1c(%ebp),%edx
}
801070cb:	8d 65 f4             	lea    -0xc(%ebp),%esp
801070ce:	5b                   	pop    %ebx
801070cf:	5e                   	pop    %esi
801070d0:	89 d0                	mov    %edx,%eax
801070d2:	5f                   	pop    %edi
801070d3:	5d                   	pop    %ebp
801070d4:	c3                   	ret
801070d5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801070dc:	00 
801070dd:	8d 76 00             	lea    0x0(%esi),%esi

801070e0 <deallocuvm>:
{
801070e0:	55                   	push   %ebp
801070e1:	89 e5                	mov    %esp,%ebp
801070e3:	8b 55 0c             	mov    0xc(%ebp),%edx
801070e6:	8b 4d 10             	mov    0x10(%ebp),%ecx
801070e9:	8b 45 08             	mov    0x8(%ebp),%eax
  if(newsz >= oldsz)
801070ec:	39 d1                	cmp    %edx,%ecx
801070ee:	73 10                	jae    80107100 <deallocuvm+0x20>
}
801070f0:	5d                   	pop    %ebp
801070f1:	e9 3a fa ff ff       	jmp    80106b30 <deallocuvm.part.0>
801070f6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801070fd:	00 
801070fe:	66 90                	xchg   %ax,%ax
80107100:	89 d0                	mov    %edx,%eax
80107102:	5d                   	pop    %ebp
80107103:	c3                   	ret
80107104:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010710b:	00 
8010710c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

80107110 <freevm>:

// Free a page table and all the physical memory pages
// in the user part.
void
freevm(pde_t *pgdir)
{
80107110:	55                   	push   %ebp
80107111:	89 e5                	mov    %esp,%ebp
80107113:	57                   	push   %edi
80107114:	56                   	push   %esi
80107115:	53                   	push   %ebx
80107116:	83 ec 0c             	sub    $0xc,%esp
80107119:	8b 75 08             	mov    0x8(%ebp),%esi
  uint i;

  if(pgdir == 0)
8010711c:	85 f6                	test   %esi,%esi
8010711e:	74 59                	je     80107179 <freevm+0x69>
  if(newsz >= oldsz)
80107120:	31 c9                	xor    %ecx,%ecx
80107122:	ba 00 00 00 80       	mov    $0x80000000,%edx
80107127:	89 f0                	mov    %esi,%eax
80107129:	89 f3                	mov    %esi,%ebx
8010712b:	e8 00 fa ff ff       	call   80106b30 <deallocuvm.part.0>
    panic("freevm: no pgdir");
  deallocuvm(pgdir, KERNBASE, 0);
  for(i = 0; i < NPDENTRIES; i++){
80107130:	8d be 00 10 00 00    	lea    0x1000(%esi),%edi
80107136:	eb 0f                	jmp    80107147 <freevm+0x37>
80107138:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010713f:	00 
80107140:	83 c3 04             	add    $0x4,%ebx
80107143:	39 fb                	cmp    %edi,%ebx
80107145:	74 23                	je     8010716a <freevm+0x5a>
    if(pgdir[i] & PTE_P){
80107147:	8b 03                	mov    (%ebx),%eax
80107149:	a8 01                	test   $0x1,%al
8010714b:	74 f3                	je     80107140 <freevm+0x30>
      char * v = P2V(PTE_ADDR(pgdir[i]));
8010714d:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      kfree(v);
80107152:	83 ec 0c             	sub    $0xc,%esp
  for(i = 0; i < NPDENTRIES; i++){
80107155:	83 c3 04             	add    $0x4,%ebx
      char * v = P2V(PTE_ADDR(pgdir[i]));
80107158:	05 00 00 00 80       	add    $0x80000000,%eax
      kfree(v);
8010715d:	50                   	push   %eax
8010715e:	e8 3d b3 ff ff       	call   801024a0 <kfree>
80107163:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < NPDENTRIES; i++){
80107166:	39 fb                	cmp    %edi,%ebx
80107168:	75 dd                	jne    80107147 <freevm+0x37>
    }
  }
  kfree((char*)pgdir);
8010716a:	89 75 08             	mov    %esi,0x8(%ebp)
}
8010716d:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107170:	5b                   	pop    %ebx
80107171:	5e                   	pop    %esi
80107172:	5f                   	pop    %edi
80107173:	5d                   	pop    %ebp
  kfree((char*)pgdir);
80107174:	e9 27 b3 ff ff       	jmp    801024a0 <kfree>
    panic("freevm: no pgdir");
80107179:	83 ec 0c             	sub    $0xc,%esp
8010717c:	68 e6 7c 10 80       	push   $0x80107ce6
80107181:	e8 fa 91 ff ff       	call   80100380 <panic>
80107186:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010718d:	00 
8010718e:	66 90                	xchg   %ax,%ax

80107190 <setupkvm>:
{
80107190:	55                   	push   %ebp
80107191:	89 e5                	mov    %esp,%ebp
80107193:	56                   	push   %esi
80107194:	53                   	push   %ebx
  if((pgdir = (pde_t*)kalloc()) == 0)
80107195:	e8 d6 b4 ff ff       	call   80102670 <kalloc>
8010719a:	85 c0                	test   %eax,%eax
8010719c:	74 5e                	je     801071fc <setupkvm+0x6c>
  memset(pgdir, 0, PGSIZE);
8010719e:	83 ec 04             	sub    $0x4,%esp
801071a1:	89 c6                	mov    %eax,%esi
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801071a3:	bb 20 b4 10 80       	mov    $0x8010b420,%ebx
  memset(pgdir, 0, PGSIZE);
801071a8:	68 00 10 00 00       	push   $0x1000
801071ad:	6a 00                	push   $0x0
801071af:	50                   	push   %eax
801071b0:	e8 3b d6 ff ff       	call   801047f0 <memset>
801071b5:	83 c4 10             	add    $0x10,%esp
                (uint)k->phys_start, k->perm) < 0) {
801071b8:	8b 53 04             	mov    0x4(%ebx),%edx
    if(mappages(pgdir, k->virt, k->phys_end - k->phys_start,
801071bb:	83 ec 0c             	sub    $0xc,%esp
801071be:	ff 73 0c             	push   0xc(%ebx)
801071c1:	52                   	push   %edx
801071c2:	8b 43 08             	mov    0x8(%ebx),%eax
801071c5:	29 d0                	sub    %edx,%eax
801071c7:	50                   	push   %eax
801071c8:	ff 33                	push   (%ebx)
801071ca:	56                   	push   %esi
801071cb:	e8 90 fa ff ff       	call   80106c60 <mappages>
801071d0:	83 c4 20             	add    $0x20,%esp
801071d3:	85 c0                	test   %eax,%eax
801071d5:	78 19                	js     801071f0 <setupkvm+0x60>
  for(k = kmap; k < &kmap[NELEM(kmap)]; k++)
801071d7:	83 c3 10             	add    $0x10,%ebx
801071da:	81 fb 60 b4 10 80    	cmp    $0x8010b460,%ebx
801071e0:	75 d6                	jne    801071b8 <setupkvm+0x28>
}
801071e2:	8d 65 f8             	lea    -0x8(%ebp),%esp
801071e5:	89 f0                	mov    %esi,%eax
801071e7:	5b                   	pop    %ebx
801071e8:	5e                   	pop    %esi
801071e9:	5d                   	pop    %ebp
801071ea:	c3                   	ret
801071eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      freevm(pgdir);
801071f0:	83 ec 0c             	sub    $0xc,%esp
801071f3:	56                   	push   %esi
801071f4:	e8 17 ff ff ff       	call   80107110 <freevm>
      return 0;
801071f9:	83 c4 10             	add    $0x10,%esp
}
801071fc:	8d 65 f8             	lea    -0x8(%ebp),%esp
    return 0;
801071ff:	31 f6                	xor    %esi,%esi
}
80107201:	89 f0                	mov    %esi,%eax
80107203:	5b                   	pop    %ebx
80107204:	5e                   	pop    %esi
80107205:	5d                   	pop    %ebp
80107206:	c3                   	ret
80107207:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010720e:	00 
8010720f:	90                   	nop

80107210 <kvmalloc>:
{
80107210:	55                   	push   %ebp
80107211:	89 e5                	mov    %esp,%ebp
80107213:	83 ec 08             	sub    $0x8,%esp
  kpgdir = setupkvm();
80107216:	e8 75 ff ff ff       	call   80107190 <setupkvm>
8010721b:	a3 e4 57 11 80       	mov    %eax,0x801157e4
  lcr3(V2P(kpgdir));   // switch to the kernel page table
80107220:	05 00 00 00 80       	add    $0x80000000,%eax
80107225:	0f 22 d8             	mov    %eax,%cr3
}
80107228:	c9                   	leave
80107229:	c3                   	ret
8010722a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

80107230 <clearpteu>:

// Clear PTE_U on a page. Used to create an inaccessible
// page beneath the user stack.
void
clearpteu(pde_t *pgdir, char *uva)
{
80107230:	55                   	push   %ebp
80107231:	89 e5                	mov    %esp,%ebp
80107233:	83 ec 08             	sub    $0x8,%esp
80107236:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107239:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
8010723c:	89 c1                	mov    %eax,%ecx
8010723e:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
80107241:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
80107244:	f6 c2 01             	test   $0x1,%dl
80107247:	75 17                	jne    80107260 <clearpteu+0x30>
  pte_t *pte;

  pte = walkpgdir(pgdir, uva, 0);
  if(pte == 0)
    panic("clearpteu");
80107249:	83 ec 0c             	sub    $0xc,%esp
8010724c:	68 f7 7c 10 80       	push   $0x80107cf7
80107251:	e8 2a 91 ff ff       	call   80100380 <panic>
80107256:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010725d:	00 
8010725e:	66 90                	xchg   %ax,%ax
  return &pgtab[PTX(va)];
80107260:	c1 e8 0a             	shr    $0xa,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107263:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  return &pgtab[PTX(va)];
80107269:	25 fc 0f 00 00       	and    $0xffc,%eax
8010726e:	8d 84 02 00 00 00 80 	lea    -0x80000000(%edx,%eax,1),%eax
  if(pte == 0)
80107275:	85 c0                	test   %eax,%eax
80107277:	74 d0                	je     80107249 <clearpteu+0x19>
  *pte &= ~PTE_U;
80107279:	83 20 fb             	andl   $0xfffffffb,(%eax)
}
8010727c:	c9                   	leave
8010727d:	c3                   	ret
8010727e:	66 90                	xchg   %ax,%ax

80107280 <copyuvm>:

// Given a parent process's page table, create a copy
// of it for a child.
pde_t*
copyuvm(pde_t *pgdir, uint sz)
{
80107280:	55                   	push   %ebp
80107281:	89 e5                	mov    %esp,%ebp
80107283:	57                   	push   %edi
80107284:	56                   	push   %esi
80107285:	53                   	push   %ebx
80107286:	83 ec 1c             	sub    $0x1c,%esp
  pde_t *d;
  pte_t *pte;
  uint pa, i, flags;
  char *mem;

  if((d = setupkvm()) == 0)
80107289:	e8 02 ff ff ff       	call   80107190 <setupkvm>
8010728e:	85 c0                	test   %eax,%eax
80107290:	0f 84 c9 00 00 00    	je     8010735f <copyuvm+0xdf>
    return 0;

  for(i = 0; i < sz; i += PGSIZE){
80107296:	8b 4d 0c             	mov    0xc(%ebp),%ecx
80107299:	89 c2                	mov    %eax,%edx
8010729b:	85 c9                	test   %ecx,%ecx
8010729d:	0f 84 9f 00 00 00    	je     80107342 <copyuvm+0xc2>
801072a3:	89 45 e0             	mov    %eax,-0x20(%ebp)
801072a6:	31 f6                	xor    %esi,%esi
801072a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801072af:	00 
  if(*pde & PTE_P){
801072b0:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
801072b3:	89 f0                	mov    %esi,%eax
801072b5:	c1 e8 16             	shr    $0x16,%eax
  if(*pde & PTE_P){
801072b8:	8b 04 82             	mov    (%edx,%eax,4),%eax
801072bb:	a8 01                	test   $0x1,%al
801072bd:	74 71                	je     80107330 <copyuvm+0xb0>
  return &pgtab[PTX(va)];
801072bf:	89 f1                	mov    %esi,%ecx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
801072c1:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
801072c6:	c1 e9 0a             	shr    $0xa,%ecx
801072c9:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
801072cf:	8d 84 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%eax
    pte = walkpgdir(pgdir, (void*)i, 0);

    /* Skip virtual pages that have not been allocated. */
    if(pte == 0 || !(*pte & PTE_P))
801072d6:	85 c0                	test   %eax,%eax
801072d8:	74 56                	je     80107330 <copyuvm+0xb0>
801072da:	8b 00                	mov    (%eax),%eax
801072dc:	a8 01                	test   $0x1,%al
801072de:	74 50                	je     80107330 <copyuvm+0xb0>
      continue;

    pa = PTE_ADDR(*pte);
801072e0:	89 c3                	mov    %eax,%ebx
    flags = PTE_FLAGS(*pte);
801072e2:	25 ff 0f 00 00       	and    $0xfff,%eax
801072e7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
    pa = PTE_ADDR(*pte);
801072ea:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx

    if((mem = kalloc()) == 0)
801072f0:	e8 7b b3 ff ff       	call   80102670 <kalloc>
801072f5:	89 c7                	mov    %eax,%edi
801072f7:	85 c0                	test   %eax,%eax
801072f9:	74 55                	je     80107350 <copyuvm+0xd0>
      goto bad;

    memmove(mem, (char*)P2V(pa), PGSIZE);
801072fb:	83 ec 04             	sub    $0x4,%esp
801072fe:	81 c3 00 00 00 80    	add    $0x80000000,%ebx
80107304:	68 00 10 00 00       	push   $0x1000
80107309:	53                   	push   %ebx
8010730a:	50                   	push   %eax
8010730b:	e8 70 d5 ff ff       	call   80104880 <memmove>

    if(mappages(d, (void*)i, PGSIZE, V2P(mem), flags) < 0){
80107310:	58                   	pop    %eax
80107311:	8d 87 00 00 00 80    	lea    -0x80000000(%edi),%eax
80107317:	ff 75 e4             	push   -0x1c(%ebp)
8010731a:	50                   	push   %eax
8010731b:	68 00 10 00 00       	push   $0x1000
80107320:	56                   	push   %esi
80107321:	ff 75 e0             	push   -0x20(%ebp)
80107324:	e8 37 f9 ff ff       	call   80106c60 <mappages>
80107329:	83 c4 20             	add    $0x20,%esp
8010732c:	85 c0                	test   %eax,%eax
8010732e:	78 40                	js     80107370 <copyuvm+0xf0>
  for(i = 0; i < sz; i += PGSIZE){
80107330:	81 c6 00 10 00 00    	add    $0x1000,%esi
80107336:	3b 75 0c             	cmp    0xc(%ebp),%esi
80107339:	0f 82 71 ff ff ff    	jb     801072b0 <copyuvm+0x30>
8010733f:	8b 55 e0             	mov    -0x20(%ebp),%edx
  return d;

bad:
  freevm(d);
  return 0;
}
80107342:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107345:	89 d0                	mov    %edx,%eax
80107347:	5b                   	pop    %ebx
80107348:	5e                   	pop    %esi
80107349:	5f                   	pop    %edi
8010734a:	5d                   	pop    %ebp
8010734b:	c3                   	ret
8010734c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
80107350:	8b 55 e0             	mov    -0x20(%ebp),%edx
  freevm(d);
80107353:	83 ec 0c             	sub    $0xc,%esp
80107356:	52                   	push   %edx
80107357:	e8 b4 fd ff ff       	call   80107110 <freevm>
  return 0;
8010735c:	83 c4 10             	add    $0x10,%esp
}
8010735f:	8d 65 f4             	lea    -0xc(%ebp),%esp
    return 0;
80107362:	31 d2                	xor    %edx,%edx
}
80107364:	5b                   	pop    %ebx
80107365:	89 d0                	mov    %edx,%eax
80107367:	5e                   	pop    %esi
80107368:	5f                   	pop    %edi
80107369:	5d                   	pop    %ebp
8010736a:	c3                   	ret
8010736b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
      kfree(mem);
80107370:	8b 55 e0             	mov    -0x20(%ebp),%edx
80107373:	83 ec 0c             	sub    $0xc,%esp
80107376:	89 55 e4             	mov    %edx,-0x1c(%ebp)
80107379:	57                   	push   %edi
8010737a:	e8 21 b1 ff ff       	call   801024a0 <kfree>
      goto bad;
8010737f:	8b 55 e4             	mov    -0x1c(%ebp),%edx
80107382:	83 c4 10             	add    $0x10,%esp
80107385:	eb cc                	jmp    80107353 <copyuvm+0xd3>
80107387:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010738e:	00 
8010738f:	90                   	nop

80107390 <uva2ka>:

//PAGEBREAK!
// Map user virtual address to kernel address.
char*
uva2ka(pde_t *pgdir, char *uva)
{
80107390:	55                   	push   %ebp
80107391:	89 e5                	mov    %esp,%ebp
80107393:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
80107396:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
80107399:	89 c1                	mov    %eax,%ecx
8010739b:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
8010739e:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
801073a1:	f6 c2 01             	test   $0x1,%dl
801073a4:	0f 84 8f 02 00 00    	je     80107639 <uva2ka.cold>
  return &pgtab[PTX(va)];
801073aa:	c1 e8 0c             	shr    $0xc,%eax
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
801073ad:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  if((*pte & PTE_P) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  return (char*)P2V(PTE_ADDR(*pte));
}
801073b3:	5d                   	pop    %ebp
  return &pgtab[PTX(va)];
801073b4:	25 ff 03 00 00       	and    $0x3ff,%eax
  if((*pte & PTE_P) == 0)
801073b9:	8b 94 82 00 00 00 80 	mov    -0x80000000(%edx,%eax,4),%edx
  return (char*)P2V(PTE_ADDR(*pte));
801073c0:	89 d0                	mov    %edx,%eax
801073c2:	f7 d2                	not    %edx
801073c4:	25 00 f0 ff ff       	and    $0xfffff000,%eax
801073c9:	05 00 00 00 80       	add    $0x80000000,%eax
801073ce:	83 e2 05             	and    $0x5,%edx
801073d1:	ba 00 00 00 00       	mov    $0x0,%edx
801073d6:	0f 45 c2             	cmovne %edx,%eax
}
801073d9:	c3                   	ret
801073da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801073e0 <copyout>:
// Copy len bytes from p to user address va in page table pgdir.
// Most useful when pgdir is not the current page table.
// uva2ka ensures this only works for PTE_U pages.
int
copyout(pde_t *pgdir, uint va, void *p, uint len)
{
801073e0:	55                   	push   %ebp
801073e1:	89 e5                	mov    %esp,%ebp
801073e3:	57                   	push   %edi
801073e4:	56                   	push   %esi
801073e5:	53                   	push   %ebx
801073e6:	83 ec 0c             	sub    $0xc,%esp
801073e9:	8b 75 14             	mov    0x14(%ebp),%esi
801073ec:	8b 45 0c             	mov    0xc(%ebp),%eax
801073ef:	8b 55 10             	mov    0x10(%ebp),%edx
  char *buf, *pa0;
  uint n, va0;

  buf = (char*)p;
  while(len > 0){
801073f2:	85 f6                	test   %esi,%esi
801073f4:	75 51                	jne    80107447 <copyout+0x67>
801073f6:	e9 9d 00 00 00       	jmp    80107498 <copyout+0xb8>
801073fb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  return (char*)P2V(PTE_ADDR(*pte));
80107400:	81 e3 00 f0 ff ff    	and    $0xfffff000,%ebx
80107406:	8d 8b 00 00 00 80    	lea    -0x80000000(%ebx),%ecx
    va0 = (uint)PGROUNDDOWN(va);
    pa0 = uva2ka(pgdir, (char*)va0);
    if(pa0 == 0)
8010740c:	81 fb 00 00 00 80    	cmp    $0x80000000,%ebx
80107412:	74 74                	je     80107488 <copyout+0xa8>
      return -1;
    n = PGSIZE - (va - va0);
80107414:	89 fb                	mov    %edi,%ebx
80107416:	29 c3                	sub    %eax,%ebx
80107418:	81 c3 00 10 00 00    	add    $0x1000,%ebx
    if(n > len)
8010741e:	39 f3                	cmp    %esi,%ebx
80107420:	0f 47 de             	cmova  %esi,%ebx
      n = len;
    memmove(pa0 + (va - va0), buf, n);
80107423:	29 f8                	sub    %edi,%eax
80107425:	83 ec 04             	sub    $0x4,%esp
80107428:	01 c1                	add    %eax,%ecx
8010742a:	53                   	push   %ebx
8010742b:	52                   	push   %edx
8010742c:	89 55 10             	mov    %edx,0x10(%ebp)
8010742f:	51                   	push   %ecx
80107430:	e8 4b d4 ff ff       	call   80104880 <memmove>
    len -= n;
    buf += n;
80107435:	8b 55 10             	mov    0x10(%ebp),%edx
    va = va0 + PGSIZE;
80107438:	8d 87 00 10 00 00    	lea    0x1000(%edi),%eax
  while(len > 0){
8010743e:	83 c4 10             	add    $0x10,%esp
    buf += n;
80107441:	01 da                	add    %ebx,%edx
  while(len > 0){
80107443:	29 de                	sub    %ebx,%esi
80107445:	74 51                	je     80107498 <copyout+0xb8>
  if(*pde & PTE_P){
80107447:	8b 5d 08             	mov    0x8(%ebp),%ebx
  pde = &pgdir[PDX(va)];
8010744a:	89 c1                	mov    %eax,%ecx
    va0 = (uint)PGROUNDDOWN(va);
8010744c:	89 c7                	mov    %eax,%edi
  pde = &pgdir[PDX(va)];
8010744e:	c1 e9 16             	shr    $0x16,%ecx
    va0 = (uint)PGROUNDDOWN(va);
80107451:	81 e7 00 f0 ff ff    	and    $0xfffff000,%edi
  if(*pde & PTE_P){
80107457:	8b 0c 8b             	mov    (%ebx,%ecx,4),%ecx
8010745a:	f6 c1 01             	test   $0x1,%cl
8010745d:	0f 84 dd 01 00 00    	je     80107640 <copyout.cold>
  return &pgtab[PTX(va)];
80107463:	89 fb                	mov    %edi,%ebx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
80107465:	81 e1 00 f0 ff ff    	and    $0xfffff000,%ecx
  return &pgtab[PTX(va)];
8010746b:	c1 eb 0c             	shr    $0xc,%ebx
8010746e:	81 e3 ff 03 00 00    	and    $0x3ff,%ebx
  if((*pte & PTE_P) == 0)
80107474:	8b 9c 99 00 00 00 80 	mov    -0x80000000(%ecx,%ebx,4),%ebx
  if((*pte & PTE_U) == 0)
8010747b:	89 d9                	mov    %ebx,%ecx
8010747d:	f7 d1                	not    %ecx
8010747f:	83 e1 05             	and    $0x5,%ecx
80107482:	0f 84 78 ff ff ff    	je     80107400 <copyout+0x20>
  }
  return 0;
}
80107488:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return -1;
8010748b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
}
80107490:	5b                   	pop    %ebx
80107491:	5e                   	pop    %esi
80107492:	5f                   	pop    %edi
80107493:	5d                   	pop    %ebp
80107494:	c3                   	ret
80107495:	8d 76 00             	lea    0x0(%esi),%esi
80107498:	8d 65 f4             	lea    -0xc(%ebp),%esp
  return 0;
8010749b:	31 c0                	xor    %eax,%eax
}
8010749d:	5b                   	pop    %ebx
8010749e:	5e                   	pop    %esi
8010749f:	5f                   	pop    %edi
801074a0:	5d                   	pop    %ebp
801074a1:	c3                   	ret
801074a2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801074a9:	00 
801074aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801074b0 <vmprint>:
// Blank page.


void
vmprint(void)
{
801074b0:	55                   	push   %ebp
801074b1:	89 e5                	mov    %esp,%ebp
801074b3:	57                   	push   %edi
801074b4:	56                   	push   %esi
801074b5:	53                   	push   %ebx
801074b6:	83 ec 1c             	sub    $0x1c,%esp
  struct proc *p = myproc();
801074b9:	e8 32 c5 ff ff       	call   801039f0 <myproc>
  uint va;
  int user_pages = 0;
  int page_table_pages = 0;
  int i;

  if(p == 0 || p->pgdir == 0)
801074be:	85 c0                	test   %eax,%eax
801074c0:	74 6e                	je     80107530 <vmprint+0x80>
801074c2:	8b 78 04             	mov    0x4(%eax),%edi
801074c5:	85 ff                	test   %edi,%edi
801074c7:	74 67                	je     80107530 <vmprint+0x80>
    return;

  pgdir = p->pgdir;
  cprintf("Page table for process %d:\n", p->pid);
801074c9:	83 ec 08             	sub    $0x8,%esp
801074cc:	ff 70 10             	push   0x10(%eax)
801074cf:	68 01 7d 10 80       	push   $0x80107d01
801074d4:	e8 d7 91 ff ff       	call   801006b0 <cprintf>
801074d9:	83 c4 10             	add    $0x10,%esp
  int page_table_pages = 0;
801074dc:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)

  for(i = 0; i < NPDENTRIES; i++){
801074e3:	31 c0                	xor    %eax,%eax
  int user_pages = 0;
801074e5:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
801074ec:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if((pgdir[i] & PTE_P) == 0)
801074f0:	8b 14 87             	mov    (%edi,%eax,4),%edx
    page_table_pages++;
    cprintf("Page table page: PDE %d, physical address 0x%x\n",
            i, PTE_ADDR(pgdir[i]));

    for(va = (uint)i << PDXSHIFT;
        va < ((uint)(i + 1) << PDXSHIFT);
801074f3:	8d 70 01             	lea    0x1(%eax),%esi
    if(i >= PDX(KERNBASE))
801074f6:	f6 c2 01             	test   $0x1,%dl
801074f9:	74 07                	je     80107502 <vmprint+0x52>
801074fb:	3d ff 01 00 00       	cmp    $0x1ff,%eax
80107500:	7e 3e                	jle    80107540 <vmprint+0x90>
  for(i = 0; i < NPDENTRIES; i++){
80107502:	81 fe 00 04 00 00    	cmp    $0x400,%esi
80107508:	74 04                	je     8010750e <vmprint+0x5e>
{
8010750a:	89 f0                	mov    %esi,%eax
8010750c:	eb e2                	jmp    801074f0 <vmprint+0x40>
      cprintf("  VA 0x%x -> PA 0x%x flags %x\n",
        va, PTE_ADDR(*pte), *pte & 0xFFF);
    }
  }

  cprintf("User pages: %d\n", user_pages);
8010750e:	83 ec 08             	sub    $0x8,%esp
80107511:	ff 75 e4             	push   -0x1c(%ebp)
80107514:	68 1d 7d 10 80       	push   $0x80107d1d
80107519:	e8 92 91 ff ff       	call   801006b0 <cprintf>
  cprintf("Page-table pages: %d\n", page_table_pages);
8010751e:	58                   	pop    %eax
8010751f:	5a                   	pop    %edx
80107520:	ff 75 dc             	push   -0x24(%ebp)
80107523:	68 2d 7d 10 80       	push   $0x80107d2d
80107528:	e8 83 91 ff ff       	call   801006b0 <cprintf>
8010752d:	83 c4 10             	add    $0x10,%esp
}
80107530:	8d 65 f4             	lea    -0xc(%ebp),%esp
80107533:	5b                   	pop    %ebx
80107534:	5e                   	pop    %esi
80107535:	5f                   	pop    %edi
80107536:	5d                   	pop    %ebp
80107537:	c3                   	ret
80107538:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
8010753f:	00 
    cprintf("Page table page: PDE %d, physical address 0x%x\n",
80107540:	83 ec 04             	sub    $0x4,%esp
80107543:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
    page_table_pages++;
80107549:	83 45 dc 01          	addl   $0x1,-0x24(%ebp)
    cprintf("Page table page: PDE %d, physical address 0x%x\n",
8010754d:	52                   	push   %edx
8010754e:	50                   	push   %eax
8010754f:	68 f0 7e 10 80       	push   $0x80107ef0
80107554:	e8 57 91 ff ff       	call   801006b0 <cprintf>
    for(va = (uint)i << PDXSHIFT;
80107559:	89 f2                	mov    %esi,%edx
8010755b:	83 c4 10             	add    $0x10,%esp
8010755e:	89 75 e0             	mov    %esi,-0x20(%ebp)
80107561:	c1 e2 16             	shl    $0x16,%edx
80107564:	8d 9a 00 00 c0 ff    	lea    -0x400000(%edx),%ebx
8010756a:	89 d6                	mov    %edx,%esi
8010756c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  pde = &pgdir[PDX(va)];
80107570:	89 d8                	mov    %ebx,%eax
80107572:	c1 e8 16             	shr    $0x16,%eax
  if(*pde & PTE_P){
80107575:	8b 04 87             	mov    (%edi,%eax,4),%eax
80107578:	a8 01                	test   $0x1,%al
8010757a:	74 42                	je     801075be <vmprint+0x10e>
  return &pgtab[PTX(va)];
8010757c:	89 d9                	mov    %ebx,%ecx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
8010757e:	25 00 f0 ff ff       	and    $0xfffff000,%eax
  return &pgtab[PTX(va)];
80107583:	c1 e9 0a             	shr    $0xa,%ecx
80107586:	81 e1 fc 0f 00 00    	and    $0xffc,%ecx
8010758c:	8d 84 08 00 00 00 80 	lea    -0x80000000(%eax,%ecx,1),%eax
      if(pte == 0 || (*pte & PTE_P) == 0)
80107593:	85 c0                	test   %eax,%eax
80107595:	74 27                	je     801075be <vmprint+0x10e>
80107597:	8b 00                	mov    (%eax),%eax
80107599:	a8 01                	test   $0x1,%al
8010759b:	74 21                	je     801075be <vmprint+0x10e>
      cprintf("  VA 0x%x -> PA 0x%x flags %x\n",
8010759d:	89 c1                	mov    %eax,%ecx
8010759f:	25 00 f0 ff ff       	and    $0xfffff000,%eax
      user_pages++;
801075a4:	83 45 e4 01          	addl   $0x1,-0x1c(%ebp)
      cprintf("  VA 0x%x -> PA 0x%x flags %x\n",
801075a8:	81 e1 ff 0f 00 00    	and    $0xfff,%ecx
801075ae:	51                   	push   %ecx
801075af:	50                   	push   %eax
801075b0:	53                   	push   %ebx
801075b1:	68 20 7f 10 80       	push   $0x80107f20
801075b6:	e8 f5 90 ff ff       	call   801006b0 <cprintf>
801075bb:	83 c4 10             	add    $0x10,%esp
        va += PGSIZE){
801075be:	81 c3 00 10 00 00    	add    $0x1000,%ebx
        va < ((uint)(i + 1) << PDXSHIFT);
801075c4:	39 f3                	cmp    %esi,%ebx
801075c6:	72 a8                	jb     80107570 <vmprint+0xc0>
801075c8:	8b 75 e0             	mov    -0x20(%ebp),%esi
{
801075cb:	89 f0                	mov    %esi,%eax
801075cd:	e9 1e ff ff ff       	jmp    801074f0 <vmprint+0x40>
801075d2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801075d9:	00 
801075da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

801075e0 <va2pa>:

int
va2pa(pde_t *pgdir, uint va)
{
801075e0:	55                   	push   %ebp
801075e1:	89 e5                	mov    %esp,%ebp
801075e3:	53                   	push   %ebx
801075e4:	8b 45 0c             	mov    0xc(%ebp),%eax
  if(*pde & PTE_P){
801075e7:	8b 55 08             	mov    0x8(%ebp),%edx
  pde = &pgdir[PDX(va)];
801075ea:	89 c1                	mov    %eax,%ecx
801075ec:	c1 e9 16             	shr    $0x16,%ecx
  if(*pde & PTE_P){
801075ef:	8b 14 8a             	mov    (%edx,%ecx,4),%edx
  pte_t *pte = walkpgdir(pgdir, (void *)va, 0);

  if(pte == 0 || (*pte & PTE_P) == 0 || (*pte & PTE_U) == 0)
    return -1;
801075f2:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  if(*pde & PTE_P){
801075f7:	f6 c2 01             	test   $0x1,%dl
801075fa:	74 36                	je     80107632 <va2pa+0x52>
  return &pgtab[PTX(va)];
801075fc:	89 c3                	mov    %eax,%ebx
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
801075fe:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
  return &pgtab[PTX(va)];
80107604:	c1 eb 0a             	shr    $0xa,%ebx
80107607:	81 e3 fc 0f 00 00    	and    $0xffc,%ebx
8010760d:	8d 94 1a 00 00 00 80 	lea    -0x80000000(%edx,%ebx,1),%edx
  if(pte == 0 || (*pte & PTE_P) == 0 || (*pte & PTE_U) == 0)
80107614:	85 d2                	test   %edx,%edx
80107616:	74 1a                	je     80107632 <va2pa+0x52>
80107618:	8b 12                	mov    (%edx),%edx
8010761a:	89 d3                	mov    %edx,%ebx
8010761c:	f7 d3                	not    %ebx
8010761e:	83 e3 05             	and    $0x5,%ebx
80107621:	75 0f                	jne    80107632 <va2pa+0x52>

  return PTE_ADDR(*pte) | (va & 0xFFF);
80107623:	81 e2 00 f0 ff ff    	and    $0xfffff000,%edx
80107629:	25 ff 0f 00 00       	and    $0xfff,%eax
8010762e:	89 d1                	mov    %edx,%ecx
80107630:	09 c1                	or     %eax,%ecx
}
80107632:	8b 5d fc             	mov    -0x4(%ebp),%ebx
80107635:	89 c8                	mov    %ecx,%eax
80107637:	c9                   	leave
80107638:	c3                   	ret

80107639 <uva2ka.cold>:
  if((*pte & PTE_P) == 0)
80107639:	a1 00 00 00 00       	mov    0x0,%eax
8010763e:	0f 0b                	ud2

80107640 <copyout.cold>:
80107640:	a1 00 00 00 00       	mov    0x0,%eax
80107645:	0f 0b                	ud2
80107647:	66 90                	xchg   %ax,%ax
80107649:	66 90                	xchg   %ax,%ax
8010764b:	66 90                	xchg   %ax,%ax
8010764d:	66 90                	xchg   %ax,%ax
8010764f:	90                   	nop

80107650 <seminit>:
  struct semaphore sems[NSEM];
} semtable;

void
seminit(void)
{
80107650:	55                   	push   %ebp
80107651:	89 e5                	mov    %esp,%ebp
80107653:	83 ec 10             	sub    $0x10,%esp
  initlock(&semtable.lock, "semtable");
80107656:	68 43 7d 10 80       	push   $0x80107d43
8010765b:	68 00 58 11 80       	push   $0x80115800
80107660:	e8 9b ce ff ff       	call   80104500 <initlock>
80107665:	83 c4 10             	add    $0x10,%esp
  for(int i = 0; i < NSEM; i++){
80107668:	31 c0                	xor    %eax,%eax
8010766a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    semtable.sems[i].value = 0;
80107670:	c7 04 c5 34 58 11 80 	movl   $0x0,-0x7feea7cc(,%eax,8)
80107677:	00 00 00 00 
    semtable.sems[i].in_use = 0;
8010767b:	c7 04 c5 38 58 11 80 	movl   $0x0,-0x7feea7c8(,%eax,8)
80107682:	00 00 00 00 
  for(int i = 0; i < NSEM; i++){
80107686:	83 c0 01             	add    $0x1,%eax
80107689:	83 f8 08             	cmp    $0x8,%eax
8010768c:	75 e2                	jne    80107670 <seminit+0x20>
  }
}
8010768e:	c9                   	leave
8010768f:	c3                   	ret

80107690 <sem_init>:

int
sem_init(int id, int value)
{
80107690:	55                   	push   %ebp
80107691:	89 e5                	mov    %esp,%ebp
80107693:	56                   	push   %esi
80107694:	53                   	push   %ebx
80107695:	8b 5d 08             	mov    0x8(%ebp),%ebx
80107698:	8b 75 0c             	mov    0xc(%ebp),%esi
  if(id < 0 || id >= NSEM || value < 0)
8010769b:	83 fb 07             	cmp    $0x7,%ebx
8010769e:	77 40                	ja     801076e0 <sem_init+0x50>
801076a0:	85 f6                	test   %esi,%esi
801076a2:	78 3c                	js     801076e0 <sem_init+0x50>
    return -1;

  acquire(&semtable.lock);
801076a4:	83 ec 0c             	sub    $0xc,%esp
  semtable.sems[id].value = value;
801076a7:	83 c3 06             	add    $0x6,%ebx
  acquire(&semtable.lock);
801076aa:	68 00 58 11 80       	push   $0x80115800
801076af:	e8 3c d0 ff ff       	call   801046f0 <acquire>
  semtable.sems[id].value = value;
801076b4:	89 34 dd 04 58 11 80 	mov    %esi,-0x7feea7fc(,%ebx,8)
  semtable.sems[id].in_use = 1;
801076bb:	c7 04 dd 08 58 11 80 	movl   $0x1,-0x7feea7f8(,%ebx,8)
801076c2:	01 00 00 00 
  release(&semtable.lock);
801076c6:	c7 04 24 00 58 11 80 	movl   $0x80115800,(%esp)
801076cd:	e8 be cf ff ff       	call   80104690 <release>
  return 0;
801076d2:	83 c4 10             	add    $0x10,%esp
801076d5:	31 c0                	xor    %eax,%eax
}
801076d7:	8d 65 f8             	lea    -0x8(%ebp),%esp
801076da:	5b                   	pop    %ebx
801076db:	5e                   	pop    %esi
801076dc:	5d                   	pop    %ebp
801076dd:	c3                   	ret
801076de:	66 90                	xchg   %ax,%ax
    return -1;
801076e0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
801076e5:	eb f0                	jmp    801076d7 <sem_init+0x47>
801076e7:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
801076ee:	00 
801076ef:	90                   	nop

801076f0 <sem_wait>:

int
sem_wait(int id)
{
801076f0:	55                   	push   %ebp
801076f1:	89 e5                	mov    %esp,%ebp
801076f3:	56                   	push   %esi
801076f4:	53                   	push   %ebx
801076f5:	8b 75 08             	mov    0x8(%ebp),%esi
  if(id < 0 || id >= NSEM)
801076f8:	83 fe 07             	cmp    $0x7,%esi
801076fb:	0f 87 86 00 00 00    	ja     80107787 <sem_wait+0x97>
    return -1;

  acquire(&semtable.lock);
80107701:	83 ec 0c             	sub    $0xc,%esp
  if(!semtable.sems[id].in_use){
80107704:	8d 5e 06             	lea    0x6(%esi),%ebx
  acquire(&semtable.lock);
80107707:	68 00 58 11 80       	push   $0x80115800
8010770c:	e8 df cf ff ff       	call   801046f0 <acquire>
  if(!semtable.sems[id].in_use){
80107711:	8b 04 f5 38 58 11 80 	mov    -0x7feea7c8(,%esi,8),%eax
80107718:	83 c4 10             	add    $0x10,%esp
8010771b:	85 c0                	test   %eax,%eax
8010771d:	74 58                	je     80107777 <sem_wait+0x87>
    release(&semtable.lock);
    return -1;
  }

  // Must be a while loop so value is re-checked after every wakeup
  while(semtable.sems[id].value == 0){
8010771f:	8b 04 dd 04 58 11 80 	mov    -0x7feea7fc(,%ebx,8),%eax
    sleep(&semtable.sems[id], &semtable.lock);
80107726:	8d 34 f5 34 58 11 80 	lea    -0x7feea7cc(,%esi,8),%esi
  while(semtable.sems[id].value == 0){
8010772d:	85 c0                	test   %eax,%eax
8010772f:	75 23                	jne    80107754 <sem_wait+0x64>
80107731:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    sleep(&semtable.sems[id], &semtable.lock);
80107738:	83 ec 08             	sub    $0x8,%esp
8010773b:	68 00 58 11 80       	push   $0x80115800
80107740:	56                   	push   %esi
80107741:	e8 aa c9 ff ff       	call   801040f0 <sleep>
  while(semtable.sems[id].value == 0){
80107746:	8b 04 dd 04 58 11 80 	mov    -0x7feea7fc(,%ebx,8),%eax
8010774d:	83 c4 10             	add    $0x10,%esp
80107750:	85 c0                	test   %eax,%eax
80107752:	74 e4                	je     80107738 <sem_wait+0x48>
  }
  semtable.sems[id].value--;
80107754:	83 e8 01             	sub    $0x1,%eax
  release(&semtable.lock);
80107757:	83 ec 0c             	sub    $0xc,%esp
  semtable.sems[id].value--;
8010775a:	89 04 dd 04 58 11 80 	mov    %eax,-0x7feea7fc(,%ebx,8)
  release(&semtable.lock);
80107761:	68 00 58 11 80       	push   $0x80115800
80107766:	e8 25 cf ff ff       	call   80104690 <release>
  return 0;
8010776b:	83 c4 10             	add    $0x10,%esp
8010776e:	31 c0                	xor    %eax,%eax
}
80107770:	8d 65 f8             	lea    -0x8(%ebp),%esp
80107773:	5b                   	pop    %ebx
80107774:	5e                   	pop    %esi
80107775:	5d                   	pop    %ebp
80107776:	c3                   	ret
    release(&semtable.lock);
80107777:	83 ec 0c             	sub    $0xc,%esp
8010777a:	68 00 58 11 80       	push   $0x80115800
8010777f:	e8 0c cf ff ff       	call   80104690 <release>
    return -1;
80107784:	83 c4 10             	add    $0x10,%esp
    return -1;
80107787:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
8010778c:	eb e2                	jmp    80107770 <sem_wait+0x80>
8010778e:	66 90                	xchg   %ax,%ax

80107790 <sem_post>:

int
sem_post(int id)
{
80107790:	55                   	push   %ebp
80107791:	89 e5                	mov    %esp,%ebp
80107793:	53                   	push   %ebx
80107794:	83 ec 04             	sub    $0x4,%esp
80107797:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(id < 0 || id >= NSEM)
8010779a:	83 fb 07             	cmp    $0x7,%ebx
8010779d:	77 61                	ja     80107800 <sem_post+0x70>
    return -1;

  acquire(&semtable.lock);
8010779f:	83 ec 0c             	sub    $0xc,%esp
801077a2:	68 00 58 11 80       	push   $0x80115800
801077a7:	e8 44 cf ff ff       	call   801046f0 <acquire>
  if(!semtable.sems[id].in_use){
801077ac:	8b 14 dd 38 58 11 80 	mov    -0x7feea7c8(,%ebx,8),%edx
801077b3:	8d 43 06             	lea    0x6(%ebx),%eax
801077b6:	83 c4 10             	add    $0x10,%esp
801077b9:	85 d2                	test   %edx,%edx
801077bb:	74 33                	je     801077f0 <sem_post+0x60>
    release(&semtable.lock);
    return -1;
  }

  semtable.sems[id].value++;
  wakeup(&semtable.sems[id]);
801077bd:	83 ec 0c             	sub    $0xc,%esp
  semtable.sems[id].value++;
801077c0:	83 04 c5 04 58 11 80 	addl   $0x1,-0x7feea7fc(,%eax,8)
801077c7:	01 
  wakeup(&semtable.sems[id]);
801077c8:	8d 04 dd 34 58 11 80 	lea    -0x7feea7cc(,%ebx,8),%eax
801077cf:	50                   	push   %eax
801077d0:	e8 db c9 ff ff       	call   801041b0 <wakeup>
  release(&semtable.lock);
801077d5:	c7 04 24 00 58 11 80 	movl   $0x80115800,(%esp)
801077dc:	e8 af ce ff ff       	call   80104690 <release>
  return 0;
801077e1:	83 c4 10             	add    $0x10,%esp
801077e4:	31 c0                	xor    %eax,%eax
}
801077e6:	8b 5d fc             	mov    -0x4(%ebp),%ebx
801077e9:	c9                   	leave
801077ea:	c3                   	ret
801077eb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    release(&semtable.lock);
801077f0:	83 ec 0c             	sub    $0xc,%esp
801077f3:	68 00 58 11 80       	push   $0x80115800
801077f8:	e8 93 ce ff ff       	call   80104690 <release>
    return -1;
801077fd:	83 c4 10             	add    $0x10,%esp
    return -1;
80107800:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
80107805:	eb df                	jmp    801077e6 <sem_post+0x56>

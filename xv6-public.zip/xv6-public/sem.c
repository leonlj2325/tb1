#include "types.h"
#include "defs.h"
#include "param.h"
#include "spinlock.h"

#define NSEM 8

struct semaphore {
  int value;
  int in_use;
};

struct {
  struct spinlock lock;
  struct semaphore sems[NSEM];
} semtable;

void
seminit(void)
{
  initlock(&semtable.lock, "semtable");
  for(int i = 0; i < NSEM; i++){
    semtable.sems[i].value = 0;
    semtable.sems[i].in_use = 0;
  }
}

int
sem_init(int id, int value)
{
  if(id < 0 || id >= NSEM || value < 0)
    return -1;

  acquire(&semtable.lock);
  semtable.sems[id].value = value;
  semtable.sems[id].in_use = 1;
  release(&semtable.lock);
  return 0;
}

int
sem_wait(int id)
{
  if(id < 0 || id >= NSEM)
    return -1;

  acquire(&semtable.lock);
  if(!semtable.sems[id].in_use){
    release(&semtable.lock);
    return -1;
  }

  // Must be a while loop so value is re-checked after every wakeup
  while(semtable.sems[id].value == 0){
    sleep(&semtable.sems[id], &semtable.lock);
  }
  semtable.sems[id].value--;
  release(&semtable.lock);
  return 0;
}

int
sem_post(int id)
{
  if(id < 0 || id >= NSEM)
    return -1;

  acquire(&semtable.lock);
  if(!semtable.sems[id].in_use){
    release(&semtable.lock);
    return -1;
  }

  semtable.sems[id].value++;
  wakeup(&semtable.sems[id]);
  release(&semtable.lock);
  return 0;
}

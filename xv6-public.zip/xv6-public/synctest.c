#include "types.h"
#include "user.h"

int
main(void)
{
  sem_init(0, 1); // A starts unlocked
  sem_init(1, 0); // B waits
  sem_init(2, 0); // C waits

  if(fork() == 0){
    for(int i = 0; i < 5; i++){
      sem_wait(0);
      printf(1, "A ");
      sem_post(1);
    }
    exit();
  }

  if(fork() == 0){
    for(int i = 0; i < 5; i++){
      sem_wait(1);
      printf(1, "B ");
      sem_post(2);
    }
    exit();
  }

  if(fork() == 0){
    for(int i = 0; i < 5; i++){
      sem_wait(2);
      printf(1, "C ");
      sem_post(0);
    }
    exit();
  }

  for(int i = 0; i < 3; i++)
    wait();

  printf(1, "\nDone\n");
  exit();
}

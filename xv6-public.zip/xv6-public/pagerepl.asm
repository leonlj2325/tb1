
_pagerepl:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
  return faults;
}

int
main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
  for(n = 3; n <= 5; n++){
    ff = fifo(n);
    lf = lru(n);

    fifo_hits = (NREF - ff) * 100 / NREF;
    lru_hits = (NREF - lf) * 100 / NREF;
   e:	bf 14 00 00 00       	mov    $0x14,%edi
{
  13:	56                   	push   %esi
  14:	53                   	push   %ebx
  for(n = 3; n <= 5; n++){
  15:	bb 03 00 00 00       	mov    $0x3,%ebx
{
  1a:	51                   	push   %ecx
  1b:	83 ec 10             	sub    $0x10,%esp
  printf(1, "Page Replacement Simulation\n");
  1e:	68 58 09 00 00       	push   $0x958
  23:	6a 01                	push   $0x1
  25:	e8 26 06 00 00       	call   650 <printf>
  printf(1, "Total page accesses: %d\n\n", NREF);
  2a:	83 c4 0c             	add    $0xc,%esp
  2d:	6a 14                	push   $0x14
  2f:	68 75 09 00 00       	push   $0x975
  34:	6a 01                	push   $0x1
  36:	e8 15 06 00 00       	call   650 <printf>
  printf(1, "Frames  FIFO Faults  FIFO Hit%%  LRU Faults  LRU Hit%%\n");
  3b:	58                   	pop    %eax
  3c:	5a                   	pop    %edx
  3d:	68 98 09 00 00       	push   $0x998
  42:	6a 01                	push   $0x1
  44:	e8 07 06 00 00       	call   650 <printf>
  49:	83 c4 10             	add    $0x10,%esp
    ff = fifo(n);
  4c:	83 ec 0c             	sub    $0xc,%esp
  4f:	53                   	push   %ebx
  50:	e8 4b 00 00 00       	call   a0 <fifo>
    lf = lru(n);
  55:	89 1c 24             	mov    %ebx,(%esp)
    ff = fifo(n);
  58:	89 c6                	mov    %eax,%esi
    lf = lru(n);
  5a:	e8 f1 00 00 00       	call   150 <lru>
    lru_hits = (NREF - lf) * 100 / NREF;
  5f:	89 fa                	mov    %edi,%edx
    lf = lru(n);
  61:	83 c4 0c             	add    $0xc,%esp
    lru_hits = (NREF - lf) * 100 / NREF;
  64:	29 c2                	sub    %eax,%edx
  66:	8d 14 92             	lea    (%edx,%edx,4),%edx

    printf(1, "  %d        %d          %d%%         %d          %d%%\n",
  69:	52                   	push   %edx
  6a:	50                   	push   %eax
    fifo_hits = (NREF - ff) * 100 / NREF;
  6b:	89 f8                	mov    %edi,%eax
  6d:	29 f0                	sub    %esi,%eax
  6f:	8d 04 80             	lea    (%eax,%eax,4),%eax
    printf(1, "  %d        %d          %d%%         %d          %d%%\n",
  72:	50                   	push   %eax
  73:	56                   	push   %esi
  74:	53                   	push   %ebx
  for(n = 3; n <= 5; n++){
  75:	83 c3 01             	add    $0x1,%ebx
    printf(1, "  %d        %d          %d%%         %d          %d%%\n",
  78:	68 d0 09 00 00       	push   $0x9d0
  7d:	6a 01                	push   $0x1
  7f:	e8 cc 05 00 00       	call   650 <printf>
  for(n = 3; n <= 5; n++){
  84:	83 c4 20             	add    $0x20,%esp
  87:	83 fb 06             	cmp    $0x6,%ebx
  8a:	75 c0                	jne    4c <main+0x4c>
           n, ff, fifo_hits, lf, lru_hits);
  }

  exit();
  8c:	e8 32 04 00 00       	call   4c3 <exit>
  91:	66 90                	xchg   %ax,%ax
  93:	66 90                	xchg   %ax,%ax
  95:	66 90                	xchg   %ax,%ax
  97:	66 90                	xchg   %ax,%ax
  99:	66 90                	xchg   %ax,%ax
  9b:	66 90                	xchg   %ax,%ax
  9d:	66 90                	xchg   %ax,%ax
  9f:	90                   	nop

000000a0 <fifo>:
{
  a0:	55                   	push   %ebp
  a1:	89 e5                	mov    %esp,%ebp
  a3:	57                   	push   %edi
  int faults = 0;
  a4:	31 ff                	xor    %edi,%edi
{
  a6:	56                   	push   %esi
  int count = 0;
  a7:	31 f6                	xor    %esi,%esi
{
  a9:	53                   	push   %ebx
  for(i = 0; i < NREF; i++){
  aa:	31 db                	xor    %ebx,%ebx
{
  ac:	83 ec 24             	sub    $0x24,%esp
    frames[i] = -1;
  af:	c7 45 e0 ff ff ff ff 	movl   $0xffffffff,-0x20(%ebp)
{
  b6:	8b 4d 08             	mov    0x8(%ebp),%ecx
    frames[i] = -1;
  b9:	c7 45 e4 ff ff ff ff 	movl   $0xffffffff,-0x1c(%ebp)
  c0:	c7 45 e8 ff ff ff ff 	movl   $0xffffffff,-0x18(%ebp)
  c7:	c7 45 ec ff ff ff ff 	movl   $0xffffffff,-0x14(%ebp)
  ce:	c7 45 f0 ff ff ff ff 	movl   $0xffffffff,-0x10(%ebp)
  int next = 0;
  d5:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  dc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
      frames[count] = refs[i];
  e0:	8b 14 9d 80 0d 00 00 	mov    0xd80(,%ebx,4),%edx
    for(j = 0; j < n; j++){
  e7:	31 c0                	xor    %eax,%eax
  e9:	85 c9                	test   %ecx,%ecx
  eb:	7f 0a                	jg     f7 <fifo+0x57>
  ed:	eb 21                	jmp    110 <fifo+0x70>
  ef:	90                   	nop
  f0:	83 c0 01             	add    $0x1,%eax
  f3:	39 c1                	cmp    %eax,%ecx
  f5:	74 19                	je     110 <fifo+0x70>
      if(frames[j] == refs[i]){
  f7:	39 54 85 e0          	cmp    %edx,-0x20(%ebp,%eax,4)
  fb:	75 f3                	jne    f0 <fifo+0x50>
  for(i = 0; i < NREF; i++){
  fd:	83 c3 01             	add    $0x1,%ebx
 100:	83 fb 14             	cmp    $0x14,%ebx
 103:	75 db                	jne    e0 <fifo+0x40>
}
 105:	83 c4 24             	add    $0x24,%esp
 108:	89 f8                	mov    %edi,%eax
 10a:	5b                   	pop    %ebx
 10b:	5e                   	pop    %esi
 10c:	5f                   	pop    %edi
 10d:	5d                   	pop    %ebp
 10e:	c3                   	ret
 10f:	90                   	nop
    faults++;
 110:	83 c7 01             	add    $0x1,%edi
    if(count < n){
 113:	39 ce                	cmp    %ecx,%esi
 115:	7d 19                	jge    130 <fifo+0x90>
  for(i = 0; i < NREF; i++){
 117:	83 c3 01             	add    $0x1,%ebx
      frames[count] = refs[i];
 11a:	89 54 b5 e0          	mov    %edx,-0x20(%ebp,%esi,4)
      count++;
 11e:	83 c6 01             	add    $0x1,%esi
  for(i = 0; i < NREF; i++){
 121:	83 fb 14             	cmp    $0x14,%ebx
 124:	75 ba                	jne    e0 <fifo+0x40>
 126:	eb dd                	jmp    105 <fifo+0x65>
 128:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 12f:	00 
      frames[next] = refs[i];
 130:	8b 45 d0             	mov    -0x30(%ebp),%eax
  for(i = 0; i < NREF; i++){
 133:	83 c3 01             	add    $0x1,%ebx
      frames[next] = refs[i];
 136:	89 54 85 e0          	mov    %edx,-0x20(%ebp,%eax,4)
      next = (next + 1) % n;
 13a:	83 c0 01             	add    $0x1,%eax
 13d:	99                   	cltd
 13e:	f7 f9                	idiv   %ecx
 140:	89 55 d0             	mov    %edx,-0x30(%ebp)
  for(i = 0; i < NREF; i++){
 143:	83 fb 14             	cmp    $0x14,%ebx
 146:	75 98                	jne    e0 <fifo+0x40>
 148:	eb bb                	jmp    105 <fifo+0x65>
 14a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000150 <lru>:
{
 150:	55                   	push   %ebp
  for(i = 0; i < NREF; i++){
 151:	31 c9                	xor    %ecx,%ecx
{
 153:	89 e5                	mov    %esp,%ebp
 155:	57                   	push   %edi
 156:	56                   	push   %esi
  int count = 0;
 157:	31 f6                	xor    %esi,%esi
{
 159:	53                   	push   %ebx
 15a:	83 ec 3c             	sub    $0x3c,%esp
    frames[i] = -1;
 15d:	c7 45 cc ff ff ff ff 	movl   $0xffffffff,-0x34(%ebp)
{
 164:	8b 7d 08             	mov    0x8(%ebp),%edi
    last_used[i] = -1;
 167:	c7 45 e0 ff ff ff ff 	movl   $0xffffffff,-0x20(%ebp)
    frames[i] = -1;
 16e:	c7 45 d0 ff ff ff ff 	movl   $0xffffffff,-0x30(%ebp)
    last_used[i] = -1;
 175:	c7 45 e4 ff ff ff ff 	movl   $0xffffffff,-0x1c(%ebp)
    frames[i] = -1;
 17c:	c7 45 d4 ff ff ff ff 	movl   $0xffffffff,-0x2c(%ebp)
    last_used[i] = -1;
 183:	c7 45 e8 ff ff ff ff 	movl   $0xffffffff,-0x18(%ebp)
    frames[i] = -1;
 18a:	c7 45 d8 ff ff ff ff 	movl   $0xffffffff,-0x28(%ebp)
    last_used[i] = -1;
 191:	c7 45 ec ff ff ff ff 	movl   $0xffffffff,-0x14(%ebp)
    frames[i] = -1;
 198:	c7 45 dc ff ff ff ff 	movl   $0xffffffff,-0x24(%ebp)
    last_used[i] = -1;
 19f:	c7 45 f0 ff ff ff ff 	movl   $0xffffffff,-0x10(%ebp)
  int faults = 0;
 1a6:	c7 45 c0 00 00 00 00 	movl   $0x0,-0x40(%ebp)
 1ad:	8d 76 00             	lea    0x0(%esi),%esi
      frames[count] = refs[i];
 1b0:	8b 14 8d 80 0d 00 00 	mov    0xd80(,%ecx,4),%edx
    for(j = 0; j < n; j++){
 1b7:	31 c0                	xor    %eax,%eax
 1b9:	85 ff                	test   %edi,%edi
 1bb:	7e 4b                	jle    208 <lru+0xb8>
      if(frames[j] == refs[i]){
 1bd:	39 54 85 cc          	cmp    %edx,-0x34(%ebp,%eax,4)
 1c1:	74 0f                	je     1d2 <lru+0x82>
    for(j = 0; j < n; j++){
 1c3:	8d 58 01             	lea    0x1(%eax),%ebx
 1c6:	39 df                	cmp    %ebx,%edi
 1c8:	74 26                	je     1f0 <lru+0xa0>
 1ca:	89 d8                	mov    %ebx,%eax
      if(frames[j] == refs[i]){
 1cc:	39 54 85 cc          	cmp    %edx,-0x34(%ebp,%eax,4)
 1d0:	75 f1                	jne    1c3 <lru+0x73>
      last_used[victim] = i;
 1d2:	89 4c 85 e0          	mov    %ecx,-0x20(%ebp,%eax,4)
  for(i = 0; i < NREF; i++){
 1d6:	83 c1 01             	add    $0x1,%ecx
 1d9:	83 f9 14             	cmp    $0x14,%ecx
 1dc:	75 d2                	jne    1b0 <lru+0x60>
}
 1de:	8b 45 c0             	mov    -0x40(%ebp),%eax
 1e1:	83 c4 3c             	add    $0x3c,%esp
 1e4:	5b                   	pop    %ebx
 1e5:	5e                   	pop    %esi
 1e6:	5f                   	pop    %edi
 1e7:	5d                   	pop    %ebp
 1e8:	c3                   	ret
 1e9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    faults++;
 1f0:	83 45 c0 01          	addl   $0x1,-0x40(%ebp)
    if(count < n){
 1f4:	39 f7                	cmp    %esi,%edi
 1f6:	7e 28                	jle    220 <lru+0xd0>
      frames[count] = refs[i];
 1f8:	89 54 b5 cc          	mov    %edx,-0x34(%ebp,%esi,4)
      last_used[count] = i;
 1fc:	89 4c b5 e0          	mov    %ecx,-0x20(%ebp,%esi,4)
      count++;
 200:	83 c6 01             	add    $0x1,%esi
 203:	eb d1                	jmp    1d6 <lru+0x86>
 205:	8d 76 00             	lea    0x0(%esi),%esi
    faults++;
 208:	83 45 c0 01          	addl   $0x1,-0x40(%ebp)
    if(count < n){
 20c:	39 f7                	cmp    %esi,%edi
 20e:	7f e8                	jg     1f8 <lru+0xa8>
      victim = 0;
 210:	c7 45 bc 00 00 00 00 	movl   $0x0,-0x44(%ebp)
      frames[victim] = refs[i];
 217:	8b 45 bc             	mov    -0x44(%ebp),%eax
 21a:	89 54 85 cc          	mov    %edx,-0x34(%ebp,%eax,4)
 21e:	eb b2                	jmp    1d2 <lru+0x82>
      victim = 0;
 220:	c7 45 bc 00 00 00 00 	movl   $0x0,-0x44(%ebp)
      for(j = 1; j < n; j++){
 227:	bb 01 00 00 00       	mov    $0x1,%ebx
 22c:	83 ff 01             	cmp    $0x1,%edi
 22f:	74 e6                	je     217 <lru+0xc7>
 231:	89 75 bc             	mov    %esi,-0x44(%ebp)
 234:	89 55 b8             	mov    %edx,-0x48(%ebp)
 237:	31 d2                	xor    %edx,%edx
 239:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
          victim = j;
 240:	8b 74 9d e0          	mov    -0x20(%ebp,%ebx,4),%esi
 244:	39 74 95 e0          	cmp    %esi,-0x20(%ebp,%edx,4)
      for(j = 1; j < n; j++){
 248:	8d 73 01             	lea    0x1(%ebx),%esi
          victim = j;
 24b:	0f 4f d3             	cmovg  %ebx,%edx
      for(j = 1; j < n; j++){
 24e:	39 c3                	cmp    %eax,%ebx
 250:	74 0e                	je     260 <lru+0x110>
 252:	89 f3                	mov    %esi,%ebx
 254:	eb ea                	jmp    240 <lru+0xf0>
 256:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 25d:	00 
 25e:	66 90                	xchg   %ax,%ax
 260:	8b 75 bc             	mov    -0x44(%ebp),%esi
 263:	89 55 bc             	mov    %edx,-0x44(%ebp)
 266:	8b 55 b8             	mov    -0x48(%ebp),%edx
      frames[victim] = refs[i];
 269:	8b 45 bc             	mov    -0x44(%ebp),%eax
 26c:	89 54 85 cc          	mov    %edx,-0x34(%ebp,%eax,4)
 270:	e9 5d ff ff ff       	jmp    1d2 <lru+0x82>
 275:	66 90                	xchg   %ax,%ax
 277:	66 90                	xchg   %ax,%ax
 279:	66 90                	xchg   %ax,%ax
 27b:	66 90                	xchg   %ax,%ax
 27d:	66 90                	xchg   %ax,%ax
 27f:	90                   	nop

00000280 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 280:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 281:	31 c0                	xor    %eax,%eax
{
 283:	89 e5                	mov    %esp,%ebp
 285:	53                   	push   %ebx
 286:	8b 4d 08             	mov    0x8(%ebp),%ecx
 289:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 28c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 290:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 294:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 297:	83 c0 01             	add    $0x1,%eax
 29a:	84 d2                	test   %dl,%dl
 29c:	75 f2                	jne    290 <strcpy+0x10>
    ;
  return os;
}
 29e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2a1:	89 c8                	mov    %ecx,%eax
 2a3:	c9                   	leave
 2a4:	c3                   	ret
 2a5:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2ac:	00 
 2ad:	8d 76 00             	lea    0x0(%esi),%esi

000002b0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2b0:	55                   	push   %ebp
 2b1:	89 e5                	mov    %esp,%ebp
 2b3:	53                   	push   %ebx
 2b4:	8b 55 08             	mov    0x8(%ebp),%edx
 2b7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 2ba:	0f b6 02             	movzbl (%edx),%eax
 2bd:	84 c0                	test   %al,%al
 2bf:	75 17                	jne    2d8 <strcmp+0x28>
 2c1:	eb 3a                	jmp    2fd <strcmp+0x4d>
 2c3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 2c8:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 2cc:	83 c2 01             	add    $0x1,%edx
 2cf:	8d 59 01             	lea    0x1(%ecx),%ebx
  while(*p && *p == *q)
 2d2:	84 c0                	test   %al,%al
 2d4:	74 1a                	je     2f0 <strcmp+0x40>
 2d6:	89 d9                	mov    %ebx,%ecx
 2d8:	0f b6 19             	movzbl (%ecx),%ebx
 2db:	38 c3                	cmp    %al,%bl
 2dd:	74 e9                	je     2c8 <strcmp+0x18>
  return (uchar)*p - (uchar)*q;
 2df:	29 d8                	sub    %ebx,%eax
}
 2e1:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2e4:	c9                   	leave
 2e5:	c3                   	ret
 2e6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2ed:	00 
 2ee:	66 90                	xchg   %ax,%ax
  return (uchar)*p - (uchar)*q;
 2f0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 2f4:	31 c0                	xor    %eax,%eax
 2f6:	29 d8                	sub    %ebx,%eax
}
 2f8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2fb:	c9                   	leave
 2fc:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 2fd:	0f b6 19             	movzbl (%ecx),%ebx
 300:	31 c0                	xor    %eax,%eax
 302:	eb db                	jmp    2df <strcmp+0x2f>
 304:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 30b:	00 
 30c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000310 <strlen>:

uint
strlen(const char *s)
{
 310:	55                   	push   %ebp
 311:	89 e5                	mov    %esp,%ebp
 313:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 316:	80 3a 00             	cmpb   $0x0,(%edx)
 319:	74 15                	je     330 <strlen+0x20>
 31b:	31 c0                	xor    %eax,%eax
 31d:	8d 76 00             	lea    0x0(%esi),%esi
 320:	83 c0 01             	add    $0x1,%eax
 323:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 327:	89 c1                	mov    %eax,%ecx
 329:	75 f5                	jne    320 <strlen+0x10>
    ;
  return n;
}
 32b:	89 c8                	mov    %ecx,%eax
 32d:	5d                   	pop    %ebp
 32e:	c3                   	ret
 32f:	90                   	nop
  for(n = 0; s[n]; n++)
 330:	31 c9                	xor    %ecx,%ecx
}
 332:	5d                   	pop    %ebp
 333:	89 c8                	mov    %ecx,%eax
 335:	c3                   	ret
 336:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 33d:	00 
 33e:	66 90                	xchg   %ax,%ax

00000340 <memset>:

void*
memset(void *dst, int c, uint n)
{
 340:	55                   	push   %ebp
 341:	89 e5                	mov    %esp,%ebp
 343:	57                   	push   %edi
 344:	8b 55 08             	mov    0x8(%ebp),%edx
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 347:	8b 4d 10             	mov    0x10(%ebp),%ecx
 34a:	8b 45 0c             	mov    0xc(%ebp),%eax
 34d:	89 d7                	mov    %edx,%edi
 34f:	fc                   	cld
 350:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 352:	8b 7d fc             	mov    -0x4(%ebp),%edi
 355:	89 d0                	mov    %edx,%eax
 357:	c9                   	leave
 358:	c3                   	ret
 359:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi

00000360 <strchr>:

char*
strchr(const char *s, char c)
{
 360:	55                   	push   %ebp
 361:	89 e5                	mov    %esp,%ebp
 363:	8b 45 08             	mov    0x8(%ebp),%eax
 366:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 36a:	0f b6 10             	movzbl (%eax),%edx
 36d:	84 d2                	test   %dl,%dl
 36f:	75 12                	jne    383 <strchr+0x23>
 371:	eb 1d                	jmp    390 <strchr+0x30>
 373:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 378:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 37c:	83 c0 01             	add    $0x1,%eax
 37f:	84 d2                	test   %dl,%dl
 381:	74 0d                	je     390 <strchr+0x30>
    if(*s == c)
 383:	38 d1                	cmp    %dl,%cl
 385:	75 f1                	jne    378 <strchr+0x18>
      return (char*)s;
  return 0;
}
 387:	5d                   	pop    %ebp
 388:	c3                   	ret
 389:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 390:	31 c0                	xor    %eax,%eax
}
 392:	5d                   	pop    %ebp
 393:	c3                   	ret
 394:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 39b:	00 
 39c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

000003a0 <gets>:

char*
gets(char *buf, int max)
{
 3a0:	55                   	push   %ebp
 3a1:	89 e5                	mov    %esp,%ebp
 3a3:	57                   	push   %edi
 3a4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 3a5:	8d 75 e7             	lea    -0x19(%ebp),%esi
{
 3a8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 3a9:	31 db                	xor    %ebx,%ebx
{
 3ab:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 3ae:	eb 27                	jmp    3d7 <gets+0x37>
    cc = read(0, &c, 1);
 3b0:	83 ec 04             	sub    $0x4,%esp
 3b3:	6a 01                	push   $0x1
 3b5:	56                   	push   %esi
 3b6:	6a 00                	push   $0x0
 3b8:	e8 1e 01 00 00       	call   4db <read>
    if(cc < 1)
 3bd:	83 c4 10             	add    $0x10,%esp
 3c0:	85 c0                	test   %eax,%eax
 3c2:	7e 1d                	jle    3e1 <gets+0x41>
      break;
    buf[i++] = c;
 3c4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 3c8:	8b 55 08             	mov    0x8(%ebp),%edx
 3cb:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 3cf:	3c 0a                	cmp    $0xa,%al
 3d1:	74 10                	je     3e3 <gets+0x43>
 3d3:	3c 0d                	cmp    $0xd,%al
 3d5:	74 0c                	je     3e3 <gets+0x43>
  for(i=0; i+1 < max; ){
 3d7:	89 df                	mov    %ebx,%edi
 3d9:	83 c3 01             	add    $0x1,%ebx
 3dc:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 3df:	7c cf                	jl     3b0 <gets+0x10>
 3e1:	89 fb                	mov    %edi,%ebx
      break;
  }
  buf[i] = '\0';
 3e3:	8b 45 08             	mov    0x8(%ebp),%eax
 3e6:	c6 04 18 00          	movb   $0x0,(%eax,%ebx,1)
  return buf;
}
 3ea:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3ed:	5b                   	pop    %ebx
 3ee:	5e                   	pop    %esi
 3ef:	5f                   	pop    %edi
 3f0:	5d                   	pop    %ebp
 3f1:	c3                   	ret
 3f2:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 3f9:	00 
 3fa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000400 <stat>:

int
stat(const char *n, struct stat *st)
{
 400:	55                   	push   %ebp
 401:	89 e5                	mov    %esp,%ebp
 403:	56                   	push   %esi
 404:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 405:	83 ec 08             	sub    $0x8,%esp
 408:	6a 00                	push   $0x0
 40a:	ff 75 08             	push   0x8(%ebp)
 40d:	e8 f1 00 00 00       	call   503 <open>
  if(fd < 0)
 412:	83 c4 10             	add    $0x10,%esp
 415:	85 c0                	test   %eax,%eax
 417:	78 27                	js     440 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 419:	83 ec 08             	sub    $0x8,%esp
 41c:	ff 75 0c             	push   0xc(%ebp)
 41f:	89 c3                	mov    %eax,%ebx
 421:	50                   	push   %eax
 422:	e8 f4 00 00 00       	call   51b <fstat>
  close(fd);
 427:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 42a:	89 c6                	mov    %eax,%esi
  close(fd);
 42c:	e8 ba 00 00 00       	call   4eb <close>
  return r;
 431:	83 c4 10             	add    $0x10,%esp
}
 434:	8d 65 f8             	lea    -0x8(%ebp),%esp
 437:	89 f0                	mov    %esi,%eax
 439:	5b                   	pop    %ebx
 43a:	5e                   	pop    %esi
 43b:	5d                   	pop    %ebp
 43c:	c3                   	ret
 43d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 440:	be ff ff ff ff       	mov    $0xffffffff,%esi
 445:	eb ed                	jmp    434 <stat+0x34>
 447:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 44e:	00 
 44f:	90                   	nop

00000450 <atoi>:

int
atoi(const char *s)
{
 450:	55                   	push   %ebp
 451:	89 e5                	mov    %esp,%ebp
 453:	53                   	push   %ebx
 454:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 457:	0f be 02             	movsbl (%edx),%eax
 45a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 45d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 460:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 465:	77 1e                	ja     485 <atoi+0x35>
 467:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 46e:	00 
 46f:	90                   	nop
    n = n*10 + *s++ - '0';
 470:	83 c2 01             	add    $0x1,%edx
 473:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 476:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 47a:	0f be 02             	movsbl (%edx),%eax
 47d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 480:	80 fb 09             	cmp    $0x9,%bl
 483:	76 eb                	jbe    470 <atoi+0x20>
  return n;
}
 485:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 488:	89 c8                	mov    %ecx,%eax
 48a:	c9                   	leave
 48b:	c3                   	ret
 48c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000490 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 490:	55                   	push   %ebp
 491:	89 e5                	mov    %esp,%ebp
 493:	57                   	push   %edi
 494:	8b 45 10             	mov    0x10(%ebp),%eax
 497:	8b 55 08             	mov    0x8(%ebp),%edx
 49a:	56                   	push   %esi
 49b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 49e:	85 c0                	test   %eax,%eax
 4a0:	7e 13                	jle    4b5 <memmove+0x25>
 4a2:	01 d0                	add    %edx,%eax
  dst = vdst;
 4a4:	89 d7                	mov    %edx,%edi
 4a6:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4ad:	00 
 4ae:	66 90                	xchg   %ax,%ax
    *dst++ = *src++;
 4b0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 4b1:	39 f8                	cmp    %edi,%eax
 4b3:	75 fb                	jne    4b0 <memmove+0x20>
  return vdst;
}
 4b5:	5e                   	pop    %esi
 4b6:	89 d0                	mov    %edx,%eax
 4b8:	5f                   	pop    %edi
 4b9:	5d                   	pop    %ebp
 4ba:	c3                   	ret

000004bb <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 4bb:	b8 01 00 00 00       	mov    $0x1,%eax
 4c0:	cd 40                	int    $0x40
 4c2:	c3                   	ret

000004c3 <exit>:
SYSCALL(exit)
 4c3:	b8 02 00 00 00       	mov    $0x2,%eax
 4c8:	cd 40                	int    $0x40
 4ca:	c3                   	ret

000004cb <wait>:
SYSCALL(wait)
 4cb:	b8 03 00 00 00       	mov    $0x3,%eax
 4d0:	cd 40                	int    $0x40
 4d2:	c3                   	ret

000004d3 <pipe>:
SYSCALL(pipe)
 4d3:	b8 04 00 00 00       	mov    $0x4,%eax
 4d8:	cd 40                	int    $0x40
 4da:	c3                   	ret

000004db <read>:
SYSCALL(read)
 4db:	b8 05 00 00 00       	mov    $0x5,%eax
 4e0:	cd 40                	int    $0x40
 4e2:	c3                   	ret

000004e3 <write>:
SYSCALL(write)
 4e3:	b8 10 00 00 00       	mov    $0x10,%eax
 4e8:	cd 40                	int    $0x40
 4ea:	c3                   	ret

000004eb <close>:
SYSCALL(close)
 4eb:	b8 15 00 00 00       	mov    $0x15,%eax
 4f0:	cd 40                	int    $0x40
 4f2:	c3                   	ret

000004f3 <kill>:
SYSCALL(kill)
 4f3:	b8 06 00 00 00       	mov    $0x6,%eax
 4f8:	cd 40                	int    $0x40
 4fa:	c3                   	ret

000004fb <exec>:
SYSCALL(exec)
 4fb:	b8 07 00 00 00       	mov    $0x7,%eax
 500:	cd 40                	int    $0x40
 502:	c3                   	ret

00000503 <open>:
SYSCALL(open)
 503:	b8 0f 00 00 00       	mov    $0xf,%eax
 508:	cd 40                	int    $0x40
 50a:	c3                   	ret

0000050b <mknod>:
SYSCALL(mknod)
 50b:	b8 11 00 00 00       	mov    $0x11,%eax
 510:	cd 40                	int    $0x40
 512:	c3                   	ret

00000513 <unlink>:
SYSCALL(unlink)
 513:	b8 12 00 00 00       	mov    $0x12,%eax
 518:	cd 40                	int    $0x40
 51a:	c3                   	ret

0000051b <fstat>:
SYSCALL(fstat)
 51b:	b8 08 00 00 00       	mov    $0x8,%eax
 520:	cd 40                	int    $0x40
 522:	c3                   	ret

00000523 <link>:
SYSCALL(link)
 523:	b8 13 00 00 00       	mov    $0x13,%eax
 528:	cd 40                	int    $0x40
 52a:	c3                   	ret

0000052b <mkdir>:
SYSCALL(mkdir)
 52b:	b8 14 00 00 00       	mov    $0x14,%eax
 530:	cd 40                	int    $0x40
 532:	c3                   	ret

00000533 <chdir>:
SYSCALL(chdir)
 533:	b8 09 00 00 00       	mov    $0x9,%eax
 538:	cd 40                	int    $0x40
 53a:	c3                   	ret

0000053b <dup>:
SYSCALL(dup)
 53b:	b8 0a 00 00 00       	mov    $0xa,%eax
 540:	cd 40                	int    $0x40
 542:	c3                   	ret

00000543 <getpid>:
SYSCALL(getpid)
 543:	b8 0b 00 00 00       	mov    $0xb,%eax
 548:	cd 40                	int    $0x40
 54a:	c3                   	ret

0000054b <sbrk>:
SYSCALL(sbrk)
 54b:	b8 0c 00 00 00       	mov    $0xc,%eax
 550:	cd 40                	int    $0x40
 552:	c3                   	ret

00000553 <sleep>:
SYSCALL(sleep)
 553:	b8 0d 00 00 00       	mov    $0xd,%eax
 558:	cd 40                	int    $0x40
 55a:	c3                   	ret

0000055b <uptime>:
SYSCALL(uptime)
 55b:	b8 0e 00 00 00       	mov    $0xe,%eax
 560:	cd 40                	int    $0x40
 562:	c3                   	ret

00000563 <vmprint>:
SYSCALL(vmprint)
 563:	b8 16 00 00 00       	mov    $0x16,%eax
 568:	cd 40                	int    $0x40
 56a:	c3                   	ret

0000056b <getfaults>:
SYSCALL(getfaults)
 56b:	b8 17 00 00 00       	mov    $0x17,%eax
 570:	cd 40                	int    $0x40
 572:	c3                   	ret

00000573 <set_burst>:
SYSCALL(set_burst)
 573:	b8 18 00 00 00       	mov    $0x18,%eax
 578:	cd 40                	int    $0x40
 57a:	c3                   	ret

0000057b <sem_init>:
SYSCALL(sem_init)
 57b:	b8 19 00 00 00       	mov    $0x19,%eax
 580:	cd 40                	int    $0x40
 582:	c3                   	ret

00000583 <sem_wait>:
SYSCALL(sem_wait)
 583:	b8 1a 00 00 00       	mov    $0x1a,%eax
 588:	cd 40                	int    $0x40
 58a:	c3                   	ret

0000058b <sem_post>:
SYSCALL(sem_post)
 58b:	b8 1b 00 00 00       	mov    $0x1b,%eax
 590:	cd 40                	int    $0x40
 592:	c3                   	ret

00000593 <freepages>:
SYSCALL(freepages)
 593:	b8 1c 00 00 00       	mov    $0x1c,%eax
 598:	cd 40                	int    $0x40
 59a:	c3                   	ret

0000059b <va2pa>:
SYSCALL(va2pa)
 59b:	b8 1d 00 00 00       	mov    $0x1d,%eax
 5a0:	cd 40                	int    $0x40
 5a2:	c3                   	ret
 5a3:	66 90                	xchg   %ax,%ax
 5a5:	66 90                	xchg   %ax,%ax
 5a7:	66 90                	xchg   %ax,%ax
 5a9:	66 90                	xchg   %ax,%ax
 5ab:	66 90                	xchg   %ax,%ax
 5ad:	66 90                	xchg   %ax,%ax
 5af:	90                   	nop

000005b0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 5b0:	55                   	push   %ebp
 5b1:	89 e5                	mov    %esp,%ebp
 5b3:	57                   	push   %edi
 5b4:	56                   	push   %esi
 5b5:	53                   	push   %ebx
 5b6:	89 cb                	mov    %ecx,%ebx
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    neg = 1;
    x = -xx;
 5b8:	89 d1                	mov    %edx,%ecx
{
 5ba:	83 ec 3c             	sub    $0x3c,%esp
 5bd:	89 45 c0             	mov    %eax,-0x40(%ebp)
  if(sgn && xx < 0){
 5c0:	85 d2                	test   %edx,%edx
 5c2:	0f 89 80 00 00 00    	jns    648 <printint+0x98>
 5c8:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 5cc:	74 7a                	je     648 <printint+0x98>
    x = -xx;
 5ce:	f7 d9                	neg    %ecx
    neg = 1;
 5d0:	b8 01 00 00 00       	mov    $0x1,%eax
  } else {
    x = xx;
  }

  i = 0;
 5d5:	89 45 c4             	mov    %eax,-0x3c(%ebp)
 5d8:	31 f6                	xor    %esi,%esi
 5da:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  do{
    buf[i++] = digits[x % base];
 5e0:	89 c8                	mov    %ecx,%eax
 5e2:	31 d2                	xor    %edx,%edx
 5e4:	89 f7                	mov    %esi,%edi
 5e6:	f7 f3                	div    %ebx
 5e8:	8d 76 01             	lea    0x1(%esi),%esi
 5eb:	0f b6 92 60 0a 00 00 	movzbl 0xa60(%edx),%edx
 5f2:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 5f6:	89 ca                	mov    %ecx,%edx
 5f8:	89 c1                	mov    %eax,%ecx
 5fa:	39 da                	cmp    %ebx,%edx
 5fc:	73 e2                	jae    5e0 <printint+0x30>
  if(neg)
 5fe:	8b 45 c4             	mov    -0x3c(%ebp),%eax
 601:	85 c0                	test   %eax,%eax
 603:	74 07                	je     60c <printint+0x5c>
    buf[i++] = '-';
 605:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)

  while(--i >= 0)
 60a:	89 f7                	mov    %esi,%edi
 60c:	8d 5d d8             	lea    -0x28(%ebp),%ebx
 60f:	8b 75 c0             	mov    -0x40(%ebp),%esi
 612:	01 df                	add    %ebx,%edi
 614:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    putc(fd, buf[i]);
 618:	0f b6 07             	movzbl (%edi),%eax
  write(fd, &c, 1);
 61b:	83 ec 04             	sub    $0x4,%esp
 61e:	88 45 d7             	mov    %al,-0x29(%ebp)
 621:	8d 45 d7             	lea    -0x29(%ebp),%eax
 624:	6a 01                	push   $0x1
 626:	50                   	push   %eax
 627:	56                   	push   %esi
 628:	e8 b6 fe ff ff       	call   4e3 <write>
  while(--i >= 0)
 62d:	89 f8                	mov    %edi,%eax
 62f:	83 c4 10             	add    $0x10,%esp
 632:	83 ef 01             	sub    $0x1,%edi
 635:	39 c3                	cmp    %eax,%ebx
 637:	75 df                	jne    618 <printint+0x68>
}
 639:	8d 65 f4             	lea    -0xc(%ebp),%esp
 63c:	5b                   	pop    %ebx
 63d:	5e                   	pop    %esi
 63e:	5f                   	pop    %edi
 63f:	5d                   	pop    %ebp
 640:	c3                   	ret
 641:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  neg = 0;
 648:	31 c0                	xor    %eax,%eax
 64a:	eb 89                	jmp    5d5 <printint+0x25>
 64c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000650 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 650:	55                   	push   %ebp
 651:	89 e5                	mov    %esp,%ebp
 653:	57                   	push   %edi
 654:	56                   	push   %esi
 655:	53                   	push   %ebx
 656:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 659:	8b 75 0c             	mov    0xc(%ebp),%esi
{
 65c:	8b 7d 08             	mov    0x8(%ebp),%edi
  for(i = 0; fmt[i]; i++){
 65f:	0f b6 1e             	movzbl (%esi),%ebx
 662:	83 c6 01             	add    $0x1,%esi
 665:	84 db                	test   %bl,%bl
 667:	74 67                	je     6d0 <printf+0x80>
 669:	8d 4d 10             	lea    0x10(%ebp),%ecx
 66c:	31 d2                	xor    %edx,%edx
 66e:	89 4d d0             	mov    %ecx,-0x30(%ebp)
 671:	eb 34                	jmp    6a7 <printf+0x57>
 673:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 678:	89 55 d4             	mov    %edx,-0x2c(%ebp)
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
 67b:	ba 25 00 00 00       	mov    $0x25,%edx
      if(c == '%'){
 680:	83 f8 25             	cmp    $0x25,%eax
 683:	74 18                	je     69d <printf+0x4d>
  write(fd, &c, 1);
 685:	83 ec 04             	sub    $0x4,%esp
 688:	8d 45 e7             	lea    -0x19(%ebp),%eax
 68b:	88 5d e7             	mov    %bl,-0x19(%ebp)
 68e:	6a 01                	push   $0x1
 690:	50                   	push   %eax
 691:	57                   	push   %edi
 692:	e8 4c fe ff ff       	call   4e3 <write>
 697:	8b 55 d4             	mov    -0x2c(%ebp),%edx
      } else {
        putc(fd, c);
 69a:	83 c4 10             	add    $0x10,%esp
  for(i = 0; fmt[i]; i++){
 69d:	0f b6 1e             	movzbl (%esi),%ebx
 6a0:	83 c6 01             	add    $0x1,%esi
 6a3:	84 db                	test   %bl,%bl
 6a5:	74 29                	je     6d0 <printf+0x80>
    c = fmt[i] & 0xff;
 6a7:	0f b6 c3             	movzbl %bl,%eax
    if(state == 0){
 6aa:	85 d2                	test   %edx,%edx
 6ac:	74 ca                	je     678 <printf+0x28>
      }
    } else if(state == '%'){
 6ae:	83 fa 25             	cmp    $0x25,%edx
 6b1:	75 ea                	jne    69d <printf+0x4d>
      if(c == 'd'){
 6b3:	83 f8 25             	cmp    $0x25,%eax
 6b6:	0f 84 04 01 00 00    	je     7c0 <printf+0x170>
 6bc:	83 e8 63             	sub    $0x63,%eax
 6bf:	83 f8 15             	cmp    $0x15,%eax
 6c2:	77 1c                	ja     6e0 <printf+0x90>
 6c4:	ff 24 85 08 0a 00 00 	jmp    *0xa08(,%eax,4)
 6cb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        putc(fd, c);
      }
      state = 0;
    }
  }
}
 6d0:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6d3:	5b                   	pop    %ebx
 6d4:	5e                   	pop    %esi
 6d5:	5f                   	pop    %edi
 6d6:	5d                   	pop    %ebp
 6d7:	c3                   	ret
 6d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 6df:	00 
  write(fd, &c, 1);
 6e0:	83 ec 04             	sub    $0x4,%esp
 6e3:	8d 55 e7             	lea    -0x19(%ebp),%edx
 6e6:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
 6ea:	6a 01                	push   $0x1
 6ec:	52                   	push   %edx
 6ed:	89 55 d4             	mov    %edx,-0x2c(%ebp)
 6f0:	57                   	push   %edi
 6f1:	e8 ed fd ff ff       	call   4e3 <write>
 6f6:	83 c4 0c             	add    $0xc,%esp
 6f9:	88 5d e7             	mov    %bl,-0x19(%ebp)
 6fc:	6a 01                	push   $0x1
 6fe:	8b 55 d4             	mov    -0x2c(%ebp),%edx
 701:	52                   	push   %edx
 702:	57                   	push   %edi
 703:	e8 db fd ff ff       	call   4e3 <write>
        putc(fd, c);
 708:	83 c4 10             	add    $0x10,%esp
      state = 0;
 70b:	31 d2                	xor    %edx,%edx
 70d:	eb 8e                	jmp    69d <printf+0x4d>
 70f:	90                   	nop
        printint(fd, *ap, 16, 0);
 710:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 713:	83 ec 0c             	sub    $0xc,%esp
 716:	b9 10 00 00 00       	mov    $0x10,%ecx
 71b:	8b 13                	mov    (%ebx),%edx
 71d:	6a 00                	push   $0x0
 71f:	89 f8                	mov    %edi,%eax
        ap++;
 721:	83 c3 04             	add    $0x4,%ebx
        printint(fd, *ap, 16, 0);
 724:	e8 87 fe ff ff       	call   5b0 <printint>
        ap++;
 729:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 72c:	83 c4 10             	add    $0x10,%esp
      state = 0;
 72f:	31 d2                	xor    %edx,%edx
 731:	e9 67 ff ff ff       	jmp    69d <printf+0x4d>
        s = (char*)*ap;
 736:	8b 45 d0             	mov    -0x30(%ebp),%eax
 739:	8b 18                	mov    (%eax),%ebx
        ap++;
 73b:	83 c0 04             	add    $0x4,%eax
 73e:	89 45 d0             	mov    %eax,-0x30(%ebp)
        if(s == 0)
 741:	85 db                	test   %ebx,%ebx
 743:	0f 84 87 00 00 00    	je     7d0 <printf+0x180>
        while(*s != 0){
 749:	0f b6 03             	movzbl (%ebx),%eax
      state = 0;
 74c:	31 d2                	xor    %edx,%edx
        while(*s != 0){
 74e:	84 c0                	test   %al,%al
 750:	0f 84 47 ff ff ff    	je     69d <printf+0x4d>
 756:	8d 55 e7             	lea    -0x19(%ebp),%edx
 759:	89 75 d4             	mov    %esi,-0x2c(%ebp)
 75c:	89 de                	mov    %ebx,%esi
 75e:	89 d3                	mov    %edx,%ebx
  write(fd, &c, 1);
 760:	83 ec 04             	sub    $0x4,%esp
 763:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 766:	83 c6 01             	add    $0x1,%esi
  write(fd, &c, 1);
 769:	6a 01                	push   $0x1
 76b:	53                   	push   %ebx
 76c:	57                   	push   %edi
 76d:	e8 71 fd ff ff       	call   4e3 <write>
        while(*s != 0){
 772:	0f b6 06             	movzbl (%esi),%eax
 775:	83 c4 10             	add    $0x10,%esp
 778:	84 c0                	test   %al,%al
 77a:	75 e4                	jne    760 <printf+0x110>
      state = 0;
 77c:	8b 75 d4             	mov    -0x2c(%ebp),%esi
 77f:	31 d2                	xor    %edx,%edx
 781:	e9 17 ff ff ff       	jmp    69d <printf+0x4d>
        printint(fd, *ap, 10, 1);
 786:	8b 5d d0             	mov    -0x30(%ebp),%ebx
 789:	83 ec 0c             	sub    $0xc,%esp
 78c:	b9 0a 00 00 00       	mov    $0xa,%ecx
 791:	8b 13                	mov    (%ebx),%edx
 793:	6a 01                	push   $0x1
 795:	eb 88                	jmp    71f <printf+0xcf>
        putc(fd, *ap);
 797:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  write(fd, &c, 1);
 79a:	83 ec 04             	sub    $0x4,%esp
 79d:	8d 55 e7             	lea    -0x19(%ebp),%edx
        putc(fd, *ap);
 7a0:	8b 03                	mov    (%ebx),%eax
        ap++;
 7a2:	83 c3 04             	add    $0x4,%ebx
        putc(fd, *ap);
 7a5:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 7a8:	6a 01                	push   $0x1
 7aa:	52                   	push   %edx
 7ab:	57                   	push   %edi
 7ac:	e8 32 fd ff ff       	call   4e3 <write>
        ap++;
 7b1:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 7b4:	83 c4 10             	add    $0x10,%esp
      state = 0;
 7b7:	31 d2                	xor    %edx,%edx
 7b9:	e9 df fe ff ff       	jmp    69d <printf+0x4d>
 7be:	66 90                	xchg   %ax,%ax
  write(fd, &c, 1);
 7c0:	83 ec 04             	sub    $0x4,%esp
 7c3:	88 5d e7             	mov    %bl,-0x19(%ebp)
 7c6:	8d 55 e7             	lea    -0x19(%ebp),%edx
 7c9:	6a 01                	push   $0x1
 7cb:	e9 31 ff ff ff       	jmp    701 <printf+0xb1>
 7d0:	b8 28 00 00 00       	mov    $0x28,%eax
          s = "(null)";
 7d5:	bb 8f 09 00 00       	mov    $0x98f,%ebx
 7da:	e9 77 ff ff ff       	jmp    756 <printf+0x106>
 7df:	90                   	nop

000007e0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7e0:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7e1:	a1 d0 0d 00 00       	mov    0xdd0,%eax
{
 7e6:	89 e5                	mov    %esp,%ebp
 7e8:	57                   	push   %edi
 7e9:	56                   	push   %esi
 7ea:	53                   	push   %ebx
 7eb:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 7ee:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7f8:	8b 10                	mov    (%eax),%edx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7fa:	39 c8                	cmp    %ecx,%eax
 7fc:	73 32                	jae    830 <free+0x50>
 7fe:	39 d1                	cmp    %edx,%ecx
 800:	72 04                	jb     806 <free+0x26>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 802:	39 d0                	cmp    %edx,%eax
 804:	72 32                	jb     838 <free+0x58>
      break;
  if(bp + bp->s.size == p->s.ptr){
 806:	8b 73 fc             	mov    -0x4(%ebx),%esi
 809:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 80c:	39 fa                	cmp    %edi,%edx
 80e:	74 30                	je     840 <free+0x60>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 810:	89 53 f8             	mov    %edx,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 813:	8b 50 04             	mov    0x4(%eax),%edx
 816:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 819:	39 f1                	cmp    %esi,%ecx
 81b:	74 3a                	je     857 <free+0x77>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 81d:	89 08                	mov    %ecx,(%eax)
  } else
    p->s.ptr = bp;
  freep = p;
}
 81f:	5b                   	pop    %ebx
  freep = p;
 820:	a3 d0 0d 00 00       	mov    %eax,0xdd0
}
 825:	5e                   	pop    %esi
 826:	5f                   	pop    %edi
 827:	5d                   	pop    %ebp
 828:	c3                   	ret
 829:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 830:	39 d0                	cmp    %edx,%eax
 832:	72 04                	jb     838 <free+0x58>
 834:	39 d1                	cmp    %edx,%ecx
 836:	72 ce                	jb     806 <free+0x26>
{
 838:	89 d0                	mov    %edx,%eax
 83a:	eb bc                	jmp    7f8 <free+0x18>
 83c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    bp->s.size += p->s.ptr->s.size;
 840:	03 72 04             	add    0x4(%edx),%esi
 843:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 846:	8b 10                	mov    (%eax),%edx
 848:	8b 12                	mov    (%edx),%edx
 84a:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 84d:	8b 50 04             	mov    0x4(%eax),%edx
 850:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 853:	39 f1                	cmp    %esi,%ecx
 855:	75 c6                	jne    81d <free+0x3d>
    p->s.size += bp->s.size;
 857:	03 53 fc             	add    -0x4(%ebx),%edx
  freep = p;
 85a:	a3 d0 0d 00 00       	mov    %eax,0xdd0
    p->s.size += bp->s.size;
 85f:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 862:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 865:	89 08                	mov    %ecx,(%eax)
}
 867:	5b                   	pop    %ebx
 868:	5e                   	pop    %esi
 869:	5f                   	pop    %edi
 86a:	5d                   	pop    %ebp
 86b:	c3                   	ret
 86c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000870 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 870:	55                   	push   %ebp
 871:	89 e5                	mov    %esp,%ebp
 873:	57                   	push   %edi
 874:	56                   	push   %esi
 875:	53                   	push   %ebx
 876:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 879:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 87c:	8b 15 d0 0d 00 00    	mov    0xdd0,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 882:	8d 78 07             	lea    0x7(%eax),%edi
 885:	c1 ef 03             	shr    $0x3,%edi
 888:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 88b:	85 d2                	test   %edx,%edx
 88d:	0f 84 8d 00 00 00    	je     920 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 893:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 895:	8b 48 04             	mov    0x4(%eax),%ecx
 898:	39 f9                	cmp    %edi,%ecx
 89a:	73 64                	jae    900 <malloc+0x90>
  if(nu < 4096)
 89c:	bb 00 10 00 00       	mov    $0x1000,%ebx
 8a1:	39 df                	cmp    %ebx,%edi
 8a3:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 8a6:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 8ad:	eb 0a                	jmp    8b9 <malloc+0x49>
 8af:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8b0:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 8b2:	8b 48 04             	mov    0x4(%eax),%ecx
 8b5:	39 f9                	cmp    %edi,%ecx
 8b7:	73 47                	jae    900 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8b9:	89 c2                	mov    %eax,%edx
 8bb:	3b 05 d0 0d 00 00    	cmp    0xdd0,%eax
 8c1:	75 ed                	jne    8b0 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 8c3:	83 ec 0c             	sub    $0xc,%esp
 8c6:	56                   	push   %esi
 8c7:	e8 7f fc ff ff       	call   54b <sbrk>
  if(p == (char*)-1)
 8cc:	83 c4 10             	add    $0x10,%esp
 8cf:	83 f8 ff             	cmp    $0xffffffff,%eax
 8d2:	74 1c                	je     8f0 <malloc+0x80>
  hp->s.size = nu;
 8d4:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 8d7:	83 ec 0c             	sub    $0xc,%esp
 8da:	83 c0 08             	add    $0x8,%eax
 8dd:	50                   	push   %eax
 8de:	e8 fd fe ff ff       	call   7e0 <free>
  return freep;
 8e3:	8b 15 d0 0d 00 00    	mov    0xdd0,%edx
      if((p = morecore(nunits)) == 0)
 8e9:	83 c4 10             	add    $0x10,%esp
 8ec:	85 d2                	test   %edx,%edx
 8ee:	75 c0                	jne    8b0 <malloc+0x40>
        return 0;
  }
}
 8f0:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 8f3:	31 c0                	xor    %eax,%eax
}
 8f5:	5b                   	pop    %ebx
 8f6:	5e                   	pop    %esi
 8f7:	5f                   	pop    %edi
 8f8:	5d                   	pop    %ebp
 8f9:	c3                   	ret
 8fa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 900:	39 cf                	cmp    %ecx,%edi
 902:	74 4c                	je     950 <malloc+0xe0>
        p->s.size -= nunits;
 904:	29 f9                	sub    %edi,%ecx
 906:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 909:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 90c:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 90f:	89 15 d0 0d 00 00    	mov    %edx,0xdd0
}
 915:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 918:	83 c0 08             	add    $0x8,%eax
}
 91b:	5b                   	pop    %ebx
 91c:	5e                   	pop    %esi
 91d:	5f                   	pop    %edi
 91e:	5d                   	pop    %ebp
 91f:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 920:	c7 05 d0 0d 00 00 d4 	movl   $0xdd4,0xdd0
 927:	0d 00 00 
    base.s.size = 0;
 92a:	b8 d4 0d 00 00       	mov    $0xdd4,%eax
    base.s.ptr = freep = prevp = &base;
 92f:	c7 05 d4 0d 00 00 d4 	movl   $0xdd4,0xdd4
 936:	0d 00 00 
    base.s.size = 0;
 939:	c7 05 d8 0d 00 00 00 	movl   $0x0,0xdd8
 940:	00 00 00 
    if(p->s.size >= nunits){
 943:	e9 54 ff ff ff       	jmp    89c <malloc+0x2c>
 948:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 94f:	00 
        prevp->s.ptr = p->s.ptr;
 950:	8b 08                	mov    (%eax),%ecx
 952:	89 0a                	mov    %ecx,(%edx)
 954:	eb b9                	jmp    90f <malloc+0x9f>

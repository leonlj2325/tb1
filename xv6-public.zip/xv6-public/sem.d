sem.o: sem.c /usr/include/stdc-predef.h types.h defs.h param.h spinlock.h

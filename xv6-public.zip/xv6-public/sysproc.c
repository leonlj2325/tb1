#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;

  addr = myproc()->sz;

  if(n < 0)
    return -1;

  myproc()->sz += n;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

int
sys_vmprint(void)
{
  vmprint();
  return 0;
}

int
sys_getfaults(void)
{
  return myproc()->faults;
}

int
sys_set_burst(void)
{
  int pid, bt;

  // Fetch 1st argument (index 0) and 2nd argument (index 1)
  if(argint(0, &pid) < 0 || argint(1, &bt) < 0)
    return -1;

  return set_burst(pid, bt);
}

int
sys_sem_init(void)
{
  int id, value;
  if(argint(0, &id) < 0 || argint(1, &value) < 0)
    return -1;
  return sem_init(id, value);
}

int
sys_sem_wait(void)
{
  int id;
  if(argint(0, &id) < 0)
    return -1;
  return sem_wait(id);
}

int
sys_sem_post(void)
{
  int id;
  if(argint(0, &id) < 0)
    return -1;
  return sem_post(id);
}

int
sys_freepages(void)
{
  return freepages();
}

int
sys_va2pa(void)
{
  int va;
  if(argint(0, &va) < 0)
    return -1;
  return va2pa(myproc()->pgdir, (uint)va);
}

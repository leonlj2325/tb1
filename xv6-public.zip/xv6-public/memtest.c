#include "types.h"
#include "user.h"

int global_var = 123;

int
main(void)
{
  printf(1, "(i) Free pages at startup: %d\n", freepages());

  sbrk(10 * 4096);
  printf(1, "(ii) Free pages after sbrk(10*4096): %d\n", freepages());

  printf(1, "(iii) Global VA: 0x%x, PA: 0x%x\n",
         (uint)&global_var, va2pa((int)&global_var));

  printf(1, "(iv) va2pa(0x7FFFFFFF): %d\n", va2pa(0x7FFFFFFF));

  int pid = fork();
  if(pid == 0){
    printf(1, "(v-child) Global VA: 0x%x, PA: 0x%x, Free pages: %d\n",
           (uint)&global_var, va2pa((int)&global_var), freepages());
    exit();
  } else {
    printf(1, "(v-parent) Global VA: 0x%x, PA: 0x%x, Free pages during fork: %d\n",
           (uint)&global_var, va2pa((int)&global_var), freepages());
    wait();
    printf(1, "(v-after-wait) Free pages after child reaped: %d\n", freepages());
  }

  exit();
}

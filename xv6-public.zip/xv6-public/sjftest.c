#include "types.h"
#include "user.h"

void
work(void)
{
  volatile int x = 0;
  for(int i = 0; i < 50000000; i++){
    x += i;
  }
}

int
main(void)
{
  int bursts[4] = {40, 10, 30, 20};

  for(int i = 0; i < 4; i++){
    int pid = fork();
    if(pid == 0){
      // Child runs CPU-bound loop[cite: 13]
      work();
      printf(1, "Child PID %d (burst %d) FINISHED\n", getpid(), bursts[i]);
      exit();
    } else {
      // Parent sets the child's burst time immediately[cite: 13]
      set_burst(pid, bursts[i]);
    }
  }

  // Once all 4 are forked and have burst times set, parent waits
  for(int i = 0; i < 4; i++){
    wait();
  }

  exit();
}

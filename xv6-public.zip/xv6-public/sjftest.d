sjftest.o: sjftest.c /usr/include/stdc-predef.h types.h user.h

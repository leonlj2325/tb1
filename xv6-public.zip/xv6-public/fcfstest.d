fcfstest.o: fcfstest.c /usr/include/stdc-predef.h types.h user.h
